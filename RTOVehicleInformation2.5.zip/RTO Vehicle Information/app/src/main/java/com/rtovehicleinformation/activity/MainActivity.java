package com.rtovehicleinformation.activity;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
//import com.google.android.gms.common.api.GoogleApiClient;
//import com.google.android.gms.common.api.Result;
//import com.google.android.gms.common.api.ResultCallback;
//import com.google.android.gms.common.api.Status;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.location.LocationServices;
//import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rtovehicleinformation.BuildConfig;
import com.rtovehicleinformation.Model.PersonalizedAds;
import com.rtovehicleinformation.Model.PetrolDieselData;
import com.rtovehicleinformation.R;
import com.rtovehicleinformation.kprogresshud.KProgressHUD;
import com.rtovehicleinformation.utils.Const;
import com.rtovehicleinformation.utils.Pref;
import com.rtovehicleinformation.utils.Utils;

import org.json.JSONObject;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.google.android.gms.location.LocationServices.API;

public class MainActivity extends AppCompatActivity implements LocationListener, NavigationView.OnNavigationItemSelectedListener {

    Activity activity = MainActivity.this;

    String Latitude;
    PersonalizedAds ads;
    String city;
    String country;
    GoogleApiClient googleApiClient;

    LocationManager locationManager;
    String longitude;
    List<PetrolDieselData> petroldata;
    String strDate;

    @BindView(R.id.changeCity)
    TextView tvchangeCity;

    @BindView(R.id.city)
    TextView tvcityState;

    @BindView(R.id.diesel)
    TextView tvdiesel;

    @BindView(R.id.dieselname)
    TextView tvdieselname;

    @BindView(R.id.errorMsg)
    TextView tverrorMsg;

    @BindView(R.id.petrol)
    TextView tvpetrol;

    @BindView(R.id.petrolDiesel)
    LinearLayout layoutpetrolDiesel;

    @BindView(R.id.petrolname)
    TextView tvpetrolname;

    @BindView(R.id.progress)
    ProgressBar progress;

    @BindView(R.id.retry)
    TextView tvretry;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.cv_owner_info)
    CardView reg;

    @BindView(R.id.cv_trafficSymbols)
    CardView trafficSymbols;

    @BindView(R.id.cv_trending)
    CardView trending;

    @BindView(R.id.cv_vehicleExpense)
    CardView vehicleExpense;

    @BindView(R.id.cv_vehicleMileage)
    CardView vehicleMileage;


    @BindView(R.id.view1)
    View view1;

    @BindView(R.id.view2)
    View view2;

    @BindView(R.id.iv_nav_drawer)
    ImageView ivNavDrawer;

    @BindView(R.id.drawer_layout)
    DrawerLayout mDrawerLayout;

    @BindView(R.id.tv_version)
    TextView tvVersionCode;

    public ActionBarDrawerToggle mDrawerToggle;

    public KProgressHUD hud;
    AdRequest adRequest;
    AdView adView;
    public InterstitialAd mInterstitialAd;
    int id;


    private class GeocoderHandler extends Handler {

        private GeocoderHandler() {
        }

        public void handleMessage(Message message) {
            String str;
            if (message.what != 1) {
                str = null;
            } else {
                str = message.getData().getString("address");
            }
            if (!str.isEmpty()) {
                String[] split = str.split("\n");
                MainActivity mainActivity = MainActivity.this;
                mainActivity.city = split[0];
                mainActivity.country = split[1];
                Pref.setStringValue(mainActivity, Const.PREF_LAST_CITY, MainActivity.this.city);
                Pref.setStringValue(MainActivity.this, Const.PREF_LAST_COUNTRY, MainActivity.this.country);
            }
        }
    }

    public void onProviderDisabled(String str) {
    }

    public void onProviderEnabled(String str) {
    }

    public void onStatusChanged(String str, int i, Bundle bundle) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        loadBannerAd();
        interstitialAd();
        GetAppVersion();
        NavigationView navigationView = findViewById(R.id.nav_view);
        ivNavDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.START);
            }
        });
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
        this.strDate = new SimpleDateFormat("ddMMMyyyy").format(Calendar.getInstance().getTime());
        init();
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        } else {
            initLocation();
        }
    }

    private void init() {
        this.tvretry.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Utils.checkConnectivity(activity, false)) {
                    tverrorMsg.setVisibility(View.GONE);
                    tvretry.setVisibility(View.GONE);
                    initLocation();
                } else {
                    Toast.makeText(MainActivity.this, "Please check your Internet Connection.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        vehicleExpense.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 101;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    VehicelExpanse();
                }

            }
        });
        vehicleMileage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 102;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    VehicelMileage();
                }
            }
        });
        reg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 100;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    OwnerInfo();
                }


            }
        });
        trafficSymbols.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 103;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    TrafficSymbole();
                }
            }
        });
        trending.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    try {
                        hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();

                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                                id = 104;
                                mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    Tranding();
                }
            }
        });
    }

    private void GetAppVersion() {
        PackageInfo info = null;
        PackageManager manager = activity.getPackageManager();
        try {
            info = manager.getPackageInfo(activity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (info != null) {
            tvVersionCode.setText("v" + info.versionName);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        SelectedNavItem(menuItem.getItemId());
        return true;
    }

    private void SelectedNavItem(int itemId) {
        switch (itemId) {
            case R.id.nav_rate_us:
                RateApp();
                break;
            case R.id.nav_invite:
                ShareApp();
                break;
//            case R.id.nav_more:
//                startActivity(new Intent(activity,));
//                break;
            case R.id.nav_feddback:
                Feedback();
                break;
            case R.id.nav_privacy:
                Intent intent1 = new Intent("android.intent.action.VIEW");
                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
                break;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    private void Feedback() {
        Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
        intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
        intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
        startActivity(Intent.createChooser(intent2, "Send email..."));
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareApp() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Wavy Music");
            String shareMessage = "\nGet free RTO Vehicle Information at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void OwnerInfo() {
        startActivity(new Intent(activity, HomeActivity.class));
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }

    private void VehicelExpanse() {
        startActivity(new Intent(activity, VehicleExpenseActivity.class));
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }

    private void VehicelMileage() {
        startActivity(new Intent(activity, MileageActivity.class));
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }

    private void TrafficSymbole() {
        startActivity(new Intent(activity, TrafficSymbolsActivity.class));
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }

    private void Tranding() {
        startActivity(new Intent(activity, TrendingActivity.class));
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }

    private void loadBannerAd() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }


    private void interstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                RequestInterstitial();
                switch (id) {
                    case 100:
                        OwnerInfo();
                        break;
                    case 101:
                        VehicelExpanse();
                        break;
                    case 102:
                        VehicelMileage();
                        break;
                    case 103:
                        TrafficSymbole();
                        break;
                    case 104:
                        Tranding();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
        RequestInterstitial();
    }

    public void RequestInterstitial() {
        try {
            if (mInterstitialAd != null) {
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            } else {
                mInterstitialAd = new InterstitialAd(activity);
                mInterstitialAd.setAdUnitId(getString(R.string.interstitial));
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void geocode(final String s, final String s2, final Context context, final Handler handler) {
        new Thread() {
            @Override
            public void run() {
                final Geocoder geocoder = new Geocoder(context, Locale.getDefault());
                try {
                    try {
                        final List fromLocation = geocoder.getFromLocation((double) Float.parseFloat(s), (double) Float.parseFloat(s2), 1);
                        String string;
                        if (fromLocation != null && fromLocation.size() > 0) {
                            Address address = (Address) fromLocation.get(0);
                            final StringBuilder sb = new StringBuilder();
                            sb.append(address.getLocality());
                            sb.append("\n");
                            sb.append(address.getCountryName());
                            sb.append("\n");
                            string = sb.toString();
                        } else {
                            string = null;
                        }
                        final Message obtain = Message.obtain();
                        obtain.setTarget(handler);
                        if (string != null) {
                            obtain.what = 1;
                            final Bundle data = new Bundle();
                            data.putString("address", string);
                            obtain.setData(data);
                        } else {
                            obtain.what = 1;
                            final Bundle data2 = new Bundle();
                            data2.putString("address", "");
                            obtain.setData(data2);
                        }
                        obtain.sendToTarget();
                        return;
                    } finally {
                    }
                } catch (IOException ex) {
                    Log.e("GeocodingLocation", "Unable to connect to Geocoder", ex);
                    final Message obtain2 = Message.obtain();
                    obtain2.setTarget(handler);
                    obtain2.what = 1;
                    final Bundle data3 = new Bundle();
                    data3.putString("address", "");
                    obtain2.setData(data3);
                    obtain2.sendToTarget();
                    return;
                }
            }
        }.start();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.homescreen, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            onBackPressed();
            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        } else if (itemId == R.id.share) {
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "RTO Information");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("\nLet me recommend you this application\n\n");
                stringBuilder.append("https://play.google.com/store/apps/details?id=");
                stringBuilder.append(BuildConfig.APPLICATION_ID);
                stringBuilder.append("\n\n");
                intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                startActivity(Intent.createChooser(intent, "choose one"));
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
            } catch (Exception unused) {
                unused.printStackTrace();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onLocationChanged(Location location) {
        if (location != null) {
            this.Latitude = String.valueOf(location.getLatitude());
            this.longitude = String.valueOf(location.getLongitude());
            if (location != null) {
                geocode(this.Latitude, this.longitude, this.getApplication(), new GeocoderHandler());
            }
        }
    }

    private void GetPrice() {
        RequestQueue newRequestQueue = Volley.newRequestQueue(this);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("http://yptech.in/petrolprice//priceapi.php?priceDate=");
        stringBuilder.append(this.strDate);
        newRequestQueue.add(new JsonObjectRequest(0, stringBuilder.toString(), null, new Response.Listener<JSONObject>() {
            public void onResponse(JSONObject jSONObject) {
                Gson gson = new Gson();
                try {
                    Type type = new TypeToken<List<PetrolDieselData>>() {
                    }.getType();
                    MainActivity.this.petroldata = gson.fromJson(jSONObject.getJSONArray("prices").toString(), type);
                    for (PetrolDieselData petrolDieselData : petroldata) {
                        if (petrolDieselData.getCityName().toLowerCase().equals(Pref.getStringValue(MainActivity.this, Const.PREF_LAST_CITY, "").toLowerCase())) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("₹ ");
                            stringBuilder.append(petrolDieselData.getPPrice());
                            tvpetrol.setText(stringBuilder.toString());
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("₹ ");
                            stringBuilder.append(petrolDieselData.getDPrice());
                            tvdiesel.setText(stringBuilder.toString());
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(petrolDieselData.getCityName());
                            stringBuilder.append(", ");
                            stringBuilder.append(petrolDieselData.getStateName());
                            tvcityState.setText(stringBuilder.toString());

                        }
                        progress.setVisibility(View.GONE);
                        layoutpetrolDiesel.setVisibility(View.VISIBLE);
                        tvchangeCity.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                ConnectivityManager connectivityManager = (ConnectivityManager) MainActivity.this.getSystemService(CONNECTIVITY_SERVICE);
                                NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
                                NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(0);
                                if (((networkInfo != null ? 1 : 0) & (networkInfo2 != null ? 1 : 0)) != 0) {
                                    if ((networkInfo2.isConnected() | networkInfo.isConnected())) {
                                        Intent intent = new Intent(MainActivity.this, CityListActivity.class);
                                        intent.putExtra("data", (Serializable) MainActivity.this.petroldata);
                                        startActivityForResult(intent, 1);
                                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                                        return;
                                    }
                                }
                                layoutpetrolDiesel.setVisibility(View.GONE);
                                progress.setVisibility(View.GONE);
                                tverrorMsg.setVisibility(View.VISIBLE);
                                tvretry.setVisibility(View.VISIBLE);
                                tverrorMsg.setText("Please check your Internet Connection.");
                            }
                        });
                    }
                } catch (Exception unused) {
                    Toast.makeText(MainActivity.this, "Your internet Connection slow..!", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(MainActivity.this, "Check Your Internet Connection..!", Toast.LENGTH_SHORT).show();
            }
        }));
    }

    public void onActivityResult(int i, int i2, @Nullable Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1 && i2 == -1) {
            PetrolDieselData petrolDieselData = (PetrolDieselData) intent.getSerializableExtra("data");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(petrolDieselData.getCityName());
            stringBuilder.append(", ");
            stringBuilder.append(petrolDieselData.getStateName());
            tvcityState.setText(stringBuilder.toString());
            stringBuilder = new StringBuilder();
            stringBuilder.append("₹ ");
            stringBuilder.append(petrolDieselData.getPPrice());
            tvpetrol.setText(stringBuilder.toString());
            stringBuilder = new StringBuilder();
            stringBuilder.append("₹ ");
            stringBuilder.append(petrolDieselData.getDPrice());
            tvdiesel.setText(stringBuilder.toString());
        }

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    if (Utils.checkConnectivity(activity, false)) {
                        initLocation();
                    } else {
                        Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void initLocation() {
        this.progress.setVisibility(View.VISIBLE);
        if (!(ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0)) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"}, 101);
        }
        this.progress.setVisibility(View.VISIBLE);
        if (this.googleApiClient == null) {
            this.googleApiClient = new GoogleApiClient.Builder(getApplicationContext()).addApi(LocationServices.API).build();
            this.googleApiClient.connect();
            LocationRequest create = LocationRequest.create();
            create.setPriority(100);
            create.setInterval(30000);
            create.setFastestInterval(5000);
            LocationSettingsRequest.Builder addLocationRequest = new LocationSettingsRequest.Builder().addLocationRequest(create);
            addLocationRequest.setAlwaysShow(true);
            LocationServices.SettingsApi.checkLocationSettings(this.googleApiClient, addLocationRequest.build()).setResultCallback(new ResultCallback() {
                public void onResult(Result result) {
                    Status status = result.getStatus();
                    int statusCode = status.getStatusCode();
                    if (statusCode != 0 && statusCode == 6) {
                        try {
                            status.startResolutionForResult(MainActivity.this, 1000);
                        } catch (IntentSender.SendIntentException unused) {
                            unused.printStackTrace();
                        }
                    }
                }
            });
            this.googleApiClient = new GoogleApiClient.Builder(this).addApi(API).build();
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            this.locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            this.locationManager.requestLocationUpdates("gps", 0, 0.0f, this);
            onLocationChanged(this.locationManager.getLastKnownLocation("network"));
        }
        GetPrice();
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(MainActivity.this, ExitAppctivity.class));
        finish();
    }
}
