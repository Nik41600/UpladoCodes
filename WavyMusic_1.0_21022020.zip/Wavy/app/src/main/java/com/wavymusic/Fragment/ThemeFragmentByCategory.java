//package com.beatsvideoeditor.Fragment;
//
//import android.annotation.SuppressLint;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.AsyncTask;
//import android.os.Build;
//import android.os.Bundle;
//import android.os.Handler;
//import android.preference.PreferenceManager;
//import android.support.annotation.NonNull;
//import android.support.annotation.RequiresApi;
//import android.support.v4.app.Fragment;
//import android.support.v4.widget.SwipeRefreshLayout;
//import android.support.v7.widget.DefaultItemAnimator;
//import android.support.v7.widget.GridLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
//import android.widget.Toast;
//
//import com.beatsvideoeditor.Adapter.ThemeCategoryAdapter;
//import com.beatsvideoeditor.Model.ThemeHorizontalModel;
//import com.beatsvideoeditor.Preferences.LanguagePref;
//import com.beatsvideoeditor.ProgressBar.kprogresshud.KProgressHUD;
//import com.beatsvideoeditor.R;
//import com.beatsvideoeditor.Retrofit.APIClient;
//import com.beatsvideoeditor.Retrofit.APIInterface;
//import com.beatsvideoeditor.Retrofit.AppConstant;
//import com.beatsvideoeditor.UnityPlayerActivity;
//import com.beatsvideoeditor.Utils.Utils;
//import com.beatsvideoeditor.activity.HomeActivity;
//import com.beatsvideoeditor.application.MyApplication;
//import com.google.gson.Gson;
//import com.google.gson.JsonObject;
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//import java.io.File;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Date;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class ThemeFragmentByCategory extends Fragment {
//
//    public static LanguagePref sharedpreferences;
//    public int id;
//    public Handler i;
//    LinearLayout llInternetCheck;
//    Button btnRetry;
//    RelativeLayout rlLoadingTheme;
//    RecyclerView rvVideos;
//    String offlienResopnseData;
//    int CategoryId = -1;
//    String CatId;
//    SharedPreferences pref;
//    GridLayoutManager gridLayoutManager;
//    KProgressHUD hud;
//    Long timestamps;
//    Date date = new Date();
//    SwipeRefreshLayout mSwipeRefreshLayout;
//    String[] split_AllLan;
//    String[] split_selctedLan;
//    private ArrayList<ThemeHorizontalModel> ThemeListCategoryWise = new ArrayList<>();
//    private ThemeCategoryAdapter themeAdapter;
//    APIInterface apiInterface;
//    public static ThemeFragmentByCategory newInstance(int catid) {
//        ThemeFragmentByCategory fragment = new ThemeFragmentByCategory();
//        Bundle bundle = new Bundle();
//        bundle.putInt("CategoryId", catid);
//        fragment.setArguments(bundle);
//        return fragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            CategoryId = getArguments().getInt("CategoryId");
//            CatId = String.valueOf(CategoryId);
//        }
//    }
//
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.fragment_theme, container, false);
//        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());
//        sharedpreferences = LanguagePref.a(getActivity());
//        split_AllLan = ("35,27,34,33,29,32,30,31,28,24,22,25,36").split(",");
//        split_selctedLan = LanguagePref.a(getActivity()).a("pref_key_language_list", "22").split(",");
//        apiInterface= APIClient.getClient().create(APIInterface.class);
//        BindView(view);
//        SetListener();
//        if (ThemeListCategoryWise != null && ThemeListCategoryWise.size() == 0) {
//            if (CategoryId == 111) {
//                WhatsNewData();
//            } else {
//                SetThemeData();
//            }
//        } else {
//            SetUpAdapter();
//        }
//        return view;
//    }
//
//    private void WhatsNewData() {
//        if (Utils.checkConnectivity(getActivity(), false)) {
//            String id = pref.getString("NewTheme", null);
//            if (id != null && !id.equals("")) {
//                getOfflineCategory(getActivity(), "NewTheme");
//                if (offlienResopnseData != null && timestamps != null) {
//                    new WhatsNewData().execute();
//                }
//            }
//        } else {
//            String id = pref.getString("NewTheme", null);
//            if (id != null && !id.equals("")) {
//                getOfflineCategory(getActivity(), "NewTheme");
//                if (offlienResopnseData != null) {
//                    new WhatsNewData().execute();
//                } else {
//                    llInternetCheck.setVisibility(View.VISIBLE);
//                    rlLoadingTheme.setVisibility(View.GONE);
//                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
//                }
//            }
//        }
//    }
//
//    private void SetThemeData() {
//        if (Utils.checkConnectivity(getActivity(), false)) {
//            String id = pref.getString(CatId, null);
//            if (id != null && !id.equals("")) {
//                getOfflineCategory(getActivity(), CatId);
//                if (offlienResopnseData != null && timestamps != null) {
//                    new GetofflineThemeData().execute();
//                }
//            }
//        } else {
//            String id = pref.getString(CatId, null);
//            if (id != null && !id.equals("")) {
//                getOfflineCategory(getActivity(), CatId);
//                if (offlienResopnseData != null) {
//                    new GetofflineThemeData().execute();
//                } else {
//                    llInternetCheck.setVisibility(View.VISIBLE);
//                    rlLoadingTheme.setVisibility(View.GONE);
//                    Toast.makeText(getActivity(), "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
//                }
//            }
//        }
//    }
//
//    private void BindView(View view) {
//        mSwipeRefreshLayout = view.findViewById(R.id.swipeToRefresh);
//        rvVideos = view.findViewById(R.id.rvVideos);
//        llInternetCheck = view.findViewById(R.id.llRetry);
//        btnRetry = view.findViewById(R.id.btn_catwise_Retry);
//        rlLoadingTheme = view.findViewById(R.id.rl_loading_pager);
//        rvVideos.setNestedScrollingEnabled(false);
//        rvVideos.setHasFixedSize(true);
//    }
//
//    private void SetListener() {
//        btnRetry.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (Utils.checkConnectivity(getActivity(), false)) {
//                    llInternetCheck.setVisibility(View.GONE);
//                    startActivity(new Intent(getActivity(), HomeActivity.class));
//                    getActivity().finish();
//                } else {
//                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_LONG).show();
//                }
//            }
//        });
//        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                if (Utils.checkConnectivity(getActivity(), false)) {
//                    llInternetCheck.setVisibility(View.GONE);
//                    ThemeListCategoryWise.clear();
//                    GetCategoryOfTheme();
//                    mSwipeRefreshLayout.setRefreshing(false);
//                } else {
//                    mSwipeRefreshLayout.setRefreshing(false);
//                    Toast.makeText(getActivity(), "No Internet Connecation!", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//
//    }
//
//    private void SetOfflineCategory(Context c, String userObject, String key, final Date date) {
//        pref = PreferenceManager.getDefaultSharedPreferences(c);
//        SharedPreferences.Editor editor = pref.edit();
//        editor.putString(key, userObject);
//        editor.putLong(key + "_value", date.getTime());
//        editor.apply();
//    }
//
//
//    private void getOfflineCategory(Context ctx, String key) {
//        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
//        offlienResopnseData = pref.getString(key, null);
//        timestamps = pref.getLong(key + "_value", 0);
//        Log.e("TAG", "GetofflineThemeData" + offlienResopnseData);
//    }
//
//
//    private void SetUpAdapter() {
//        RecyclerView recyclerView;
//        int i2 = 0;
//        gridLayoutManager = new GridLayoutManager(getActivity(), 2);
//        themeAdapter = new ThemeCategoryAdapter(getActivity(), ThemeListCategoryWise);
//        rvVideos.setLayoutManager(gridLayoutManager);
//        rvVideos.setItemAnimator(new DefaultItemAnimator());
//        rvVideos.setAdapter(themeAdapter);
//        if (MyApplication.ThemePosition == -1) {
//            recyclerView = this.rvVideos;
//        } else {
//            recyclerView = this.rvVideos;
//            i2 = MyApplication.ThemePosition;
//        }
//        recyclerView.scrollToPosition(i2);
//        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
//            @Override
//            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
//                super.onScrolled(recyclerView, i, i2);
//                StringBuilder stringBuilder = new StringBuilder();
//                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
//                stringBuilder.append("");
//                MyApplication.ThemePosition = gridLayoutManager.findFirstVisibleItemPosition();
//            }
//        });
//        themeAdapter.notifyDataSetChanged();
//        if (!MyApplication.IsHomeAdsDisplay && UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
//            try {
//                hud = KProgressHUD.create(getActivity())
//                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
//                        .setLabel("Showing Ads")
//                        .setDetailsLabel("Please Wait...");
//                hud.show();
//            } catch (IllegalArgumentException e) {
//                e.printStackTrace();
//            } catch (NullPointerException e2) {
//                e2.printStackTrace();
//            } catch (Exception e3) {
//                e3.printStackTrace();
//            }
//            Handler handler = new Handler();
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    try {
//                        hud.dismiss();
//                    } catch (IllegalArgumentException e) {
//                        e.printStackTrace();
//                    } catch (NullPointerException e2) {
//                        e2.printStackTrace();
//                    } catch (Exception e3) {
//                        e3.printStackTrace();
//                    }
//                    if (UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
//                        MyApplication.IsHomeAdsDisplay = true;
//                        UnityPlayerActivity.mInterstitialAd.show();
//                    }
//                }
//            }, 2000);
//        }
//    }
//
//    public boolean CheckFileSize(String file) {
//        return new File(file).exists();
//    }
//
//
//    private void GetCategoryOfTheme() {
//        rlLoadingTheme.setVisibility(View.VISIBLE);
//        Call<JsonObject> call =apiInterface.GetAllTheme(AppConstant.Token,AppConstant.ApplicationId);
//        call.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
//                if (response.isSuccessful()) {
//                    try {
//                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
//                        JSONArray jsonArray = jsonObj.getJSONArray("category");
//                        for (int i = 0; i < jsonArray.length(); i++) {
//                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
//                            int Catid = Integer.parseInt(themeJSONObject.getString("id"));
//                            if (CategoryId == 111) {
//                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
//                                for (int j = 0; j < jSONArray4.length(); j++) {
//                                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
//                                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
//                                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
//                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
//                                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                                        if (themeModel.isNewRealise().equals("1")) {
//                                            ThemeListCategoryWise.add(themeModel);
//                                        }
//                                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
//                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
//                                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                                        if (themeModel.isNewRealise().equals("1")) {
//                                            ThemeListCategoryWise.add(themeModel);
//                                        }
//                                    }
//                                }
//                                SetOfflineCategory(getActivity(), Utils.WhatsNewJson(ThemeListCategoryWise), "111", date);
//                            } else {
//                                if (CategoryId == Catid) {
//                                    SetOfflineCategory(getActivity(), themeJSONObject.toString(), CatId, date);
//                                    JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
//                                    for (int j = 0; j < jSONArray4.length(); j++) {
//                                        ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
//                                        JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
//                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
//                                        if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
//                                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                            themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                            themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                                            ThemeListCategoryWise.add(themeModel);
//                                        } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
//                                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                            themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                            themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                                            ThemeListCategoryWise.add(themeModel);
//                                        }
//                                        if (MyApplication.getInstance().IsNativeAdsLoaded) {
//                                            if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
//                                                themeModel.setNativeAds(true);
//                                                ThemeListCategoryWise.add(j, themeModel);
//                                            }
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                        SetUpAdapter();
//                        rlLoadingTheme.setVisibility(View.GONE);
//                    } catch (final JSONException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
//                rlLoadingTheme.setVisibility(View.VISIBLE);
//            }
//        });
//
//    }
//
//    @SuppressLint("StaticFieldLeak")
//    public class GetofflineThemeData extends AsyncTask<Void, Void, Void> {
//
//        protected void onPreExecute() {
//            rlLoadingTheme.setVisibility(View.VISIBLE);
//        }
//
//        protected Void doInBackground(Void... arg0) {
//            try {
//                JSONObject jsonObj = new JSONObject(offlienResopnseData);
//                int Catid = Integer.parseInt(jsonObj.getString("id"));
//                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
//                for (int j = 0; j < jSONArray4.length(); j++) {
//                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
//                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
//                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
//                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
//                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                        ThemeListCategoryWise.add(themeModel);
//                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
//                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
//                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                        ThemeListCategoryWise.add(themeModel);
//                    }
//                    if (isAdded()) {
//                        if (Utils.checkConnectivity(getActivity(), false)) {
//                            if (MyApplication.getInstance().IsNativeAdsLoaded) {
//                                if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
//                                    themeModel.setNativeAds(true);
//                                    ThemeListCategoryWise.add(j, themeModel);
//                                }
//                            }
//                        }
//                    }
//                }
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            return null;
//        }
//
//        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
//        @Override
//        protected void onPostExecute(Void result) {
//            rlLoadingTheme.setVisibility(View.GONE);
//            SetUpAdapter();
//        }
//    }
//
//
//    @SuppressLint("StaticFieldLeak")
//    public class WhatsNewData extends AsyncTask<Void, Void, Void> {
//
//        protected void onPreExecute() {
//            rlLoadingTheme.setVisibility(View.VISIBLE);
//        }
//
//        protected Void doInBackground(Void... arg0) {
//            try {
//                JSONObject jsonObj = new JSONObject(offlienResopnseData);
//                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
//                for (int j = 0; j < jSONArray4.length(); j++) {
//                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
//                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
//                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(CategoryId))) {
//                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
//                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                        if (themeModel.isNewRealise().equals("1")) {
//                            ThemeListCategoryWise.add(themeModel);
//                        }
//                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(CategoryId))) {
//                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
//                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
//                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
//                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
//                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
//                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
//                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
//                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
//                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
//                        if (themeModel.isNewRealise().equals("1")) {
//                            ThemeListCategoryWise.add(themeModel);
//                        }
//                    }
////                    if (isAdded()) {
////                        if (Utils.checkConnectivity(getActivity(), false)) {
////                            if (MyApplication.getInstance().IsNativeAdsLoaded) {
////                                if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
////                                    themeModel.setNativeAds(true);
////                                    ThemeListCategoryWise.add(j, themeModel);
////                                }
////                            }
////                        }
////                    }
//                }
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            return null;
//        }
//
//        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
//        @Override
//        protected void onPostExecute(Void result) {
//            rlLoadingTheme.setVisibility(View.GONE);
//            SetUpAdapter();
//        }
//    }
//
//}
