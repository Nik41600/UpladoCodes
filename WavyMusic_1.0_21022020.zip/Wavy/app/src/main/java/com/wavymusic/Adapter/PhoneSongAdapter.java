package com.wavymusic.Adapter;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wavymusic.Model.PhoneSongModel;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.WidgetView.CircleImageView;
import com.wavymusic.activity.PhoneSongActivity;

import java.util.List;

public class PhoneSongAdapter extends RecyclerView.Adapter<PhoneSongAdapter.MyViewHolder> {

    public static int FirstSelected = 0;
    public static boolean IsSongPlay = false;
    Context ctx;
    private List<PhoneSongModel> localTracks;
    private LocalmusicInterface localmusicInterface;
    private PhoneSongActivity ActivityOfsong;

    public PhoneSongAdapter(Context ctx, List<PhoneSongModel> localTracks) {
        this.ctx = ctx;
        this.ActivityOfsong = (PhoneSongActivity) ctx;
        this.localTracks = localTracks;
    }

    public void Music(LocalmusicInterface localmusicInterface) {
        this.localmusicInterface = localmusicInterface;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.row_phone_song, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        if (this.localTracks != null) {
            final PhoneSongModel track = localTracks.get(position);
            holder.Songname.setText(track.m5778d());
            if (FirstSelected == 0) {
                FirstSelected = this.localTracks.get(position).a();
                if (localmusicInterface != null) {
                    localmusicInterface.a(track, position);
                }
            }
            if (FirstSelected != this.localTracks.get(position).a()) {
                holder.ivThumb.setBackgroundResource(R.drawable.ic_song_select);
                holder.tvuseSong.setBackgroundResource(R.drawable.bg_song_phone_use_noraml);
                holder.IvplayPause.setImageResource(R.drawable.icon_player_play);
            } else {
                holder.ivThumb.setBackgroundResource(R.drawable.ic_song_select_press);
                holder.tvuseSong.setBackgroundResource(R.drawable.bg_song_phone_use_selected);
                holder.IvplayPause.setImageResource(R.drawable.icon_player_pause_selected);
            }
            holder.itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    if (localmusicInterface != null) {
                        localmusicInterface.a(track, position);
                    }
                }
            });
            holder.tvuseSong.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(View v) {
                    if (FirstSelected != localTracks.get(position).a()) {
                        Toast.makeText(ctx, "Select Song First", Toast.LENGTH_SHORT).show();
                    } else {
                        if (ActivityOfsong.mInterstitialAd != null && ActivityOfsong.mInterstitialAd.isLoaded()) {
                            try {
                                ActivityOfsong.hud = KProgressHUD.create(ctx)
                                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                        .setLabel("Showing Ads")
                                        .setDetailsLabel("Please Wait...");
                                ActivityOfsong.hud.show();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        ActivityOfsong.hud.dismiss();
                                    } catch (IllegalArgumentException e) {
                                        e.printStackTrace();

                                    } catch (NullPointerException e2) {
                                        e2.printStackTrace();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                    if (ActivityOfsong.mInterstitialAd != null && ActivityOfsong.mInterstitialAd.isLoaded()) {
                                        ActivityOfsong.mediacontroler.g();
                                        ActivityOfsong.id = 202;
                                        ActivityOfsong.mInterstitialAd.show();
                                    }
                                }
                            }, 2000);
                        } else {
                            ActivityOfsong.Done();
                        }
                    }
                }

            });
        }
    }

    @Override
    public int getItemCount() {
        return localTracks.size();
    }

    public interface LocalmusicInterface {
        void a();

        void a(PhoneSongModel musicRes, int i);
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        LinearLayout llMain;
        CircleImageView ivThumb;
        TextView Songname, tvSongtime, tvuseSong;
        ImageView IvplayPause;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            llMain = itemView.findViewById(R.id.image_layout);
            ivThumb = itemView.findViewById(R.id.image_content);
            IvplayPause = itemView.findViewById(R.id.ivPopularPlayPause);
            Songname = itemView.findViewById(R.id.tvMusicName);
            tvuseSong = itemView.findViewById(R.id.tvUseMusic);
            tvSongtime = itemView.findViewById(R.id.tvMusicEndTime);
        }
    }
}
