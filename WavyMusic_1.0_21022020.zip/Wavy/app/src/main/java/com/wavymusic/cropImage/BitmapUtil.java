package com.wavymusic.cropImage;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;

public class BitmapUtil
{
  private static final boolean DEBUG = false;

  public static Bitmap decodeByteArray(final byte[] src, final int w, final int h) {
    Bitmap bitmap = null;
    try {
      final BitmapFactory.Options opts = new BitmapFactory.Options();
      opts.inJustDecodeBounds = true;
      BitmapFactory.decodeByteArray(src, 0, src.length, opts);
      if (!opts.mCancel && opts.outWidth != -1 && opts.outHeight != -1) {
        opts.inSampleSize = Math.min(opts.outWidth / w, opts.outHeight / h);
        opts.inJustDecodeBounds = false;
        bitmap = BitmapFactory.decodeByteArray(src, 0, src.length, opts);
      }
    }
    catch (Throwable t) {
      t.printStackTrace();
    }
    return bitmap;
  }

  public static Bitmap decodeByteArrayWithCenterCrop(final byte[] src, final int w, final int h) {
    try {
      return centerCrop(decodeByteArray(src, w, h), w, h);
    }
    catch (Throwable t) {
      t.printStackTrace();
      return null;
    }
  }

  public static Bitmap centerCrop(final Bitmap src, final int w, final int h) {
    return crop(src, w, h, 0.5f, 0.5f);
  }

  public static Bitmap crop(final Bitmap src, final int w, final int h, final float horizontalCenterPercent, final float verticalCenterPercent) {
    if (horizontalCenterPercent < 0.0f || horizontalCenterPercent > 1.0f || verticalCenterPercent < 0.0f || verticalCenterPercent > 1.0f) {
      throw new IllegalArgumentException("horizontalCenterPercent and verticalCenterPercent must be between 0.0f and 1.0f, inclusive.");
    }
    final int srcWidth = src.getWidth();
    final int srcHeight = src.getHeight();
    if (w == srcWidth && h == srcHeight) {
      return src;
    }
    final Matrix m = new Matrix();
    final float scale = Math.max(w / srcWidth, h / srcHeight);
    m.setScale(scale, scale);
    final int srcCroppedW = Math.round(w / scale);
    final int srcCroppedH = Math.round(h / scale);
    final int srcY = (int)(srcHeight * verticalCenterPercent - srcCroppedH / 2);
    return Bitmap.createBitmap(src, Math.max(Math.min((int)(srcWidth * horizontalCenterPercent - srcCroppedW / 2), srcWidth - srcCroppedW), 0), Math.max(Math.min(srcY, srcHeight - srcCroppedH), 0), srcCroppedW, srcCroppedH, m, false);
  }
}
