package com.wavymusic.Model;

import java.util.ArrayList;
import java.util.List;

public class PhoneSongAllFolders {
    List<PhoneSong> musicFolders;

    public PhoneSongAllFolders() {
        musicFolders = new ArrayList<>();
    }

    public List<PhoneSong> getMusicFolders() {
        return musicFolders;
    }

    public void setMusicFolders(List<PhoneSong> musicFolders) {
        this.musicFolders = musicFolders;
    }
}
