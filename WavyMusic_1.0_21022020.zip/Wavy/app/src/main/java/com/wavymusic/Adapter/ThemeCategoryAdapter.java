package com.wavymusic.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wavymusic.Download.ThemeDownload;
import com.wavymusic.Model.ThemeHorizontalModel;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.Retrofit.APIClient;
import com.wavymusic.Retrofit.APIInterface;
import com.wavymusic.Retrofit.AppConstant;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.Utils.Utils;
import com.wavymusic.WidgetView.Indicator;
import com.wavymusic.activity.ThemeActivity;
import com.wavymusic.activity.WallpaperSetActivity;
import com.wavymusic.application.MyApplication;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeCategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_DATA = 0;
    public static final int ITEM_TYPE_AD = 1;
    public int e = -1;
    public int f = -1;
    protected int ScalPosition = -1;
    private Context mContext;
    private ArrayList<ThemeHorizontalModel> themeCategoryList;
    private ThemeActivity ActivityOfTheme;
    private int Adsindex = 0;
    private ColorDrawable[] bgThumb = new ColorDrawable[]{new ColorDrawable(Color.parseColor("#9ACCCD")), new ColorDrawable(Color.parseColor("#8FD8A0")), new ColorDrawable(Color.parseColor("#CBD890")), new ColorDrawable(Color.parseColor("#DACC8F")), new ColorDrawable(Color.parseColor("#D9A790")), new ColorDrawable(Color.parseColor("#D18FD9")), new ColorDrawable(Color.parseColor("#FF6772")), new ColorDrawable(Color.parseColor("#DDFB5C"))};

    public ThemeCategoryAdapter(Context mContext, ArrayList<ThemeHorizontalModel> themeCategoryList) {
        this.mContext = mContext;
        this.ActivityOfTheme = (ThemeActivity) mContext;
        this.themeCategoryList = themeCategoryList;
    }

    public void SetRingTone(final String str, final Context context) {
        new Thread(new Runnable() {
            public final void run() {
                try {
                    if (str != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(Utils.INSTANCE.getOutputPath());
                        stringBuilder.append(File.separator);
                        stringBuilder.append("Ringtone");
                        stringBuilder.append(File.separator);
                        stringBuilder.append("ringtone.mp3");
                        String stringBuilder2 = stringBuilder.toString();
                        File file = new File(stringBuilder2);
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(Utils.INSTANCE.getOutputPath());
                        stringBuilder3.append(File.separator);
                        stringBuilder3.append("Ringtone");
                        CopyFileToStorage(str, stringBuilder2, stringBuilder3.toString());
                        stringBuilder3 = new StringBuilder("path : ");
                        stringBuilder3.append(str);
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_data", file.getAbsolutePath());
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(file.getName());
                        contentValues.put("title", stringBuilder4.toString());
                        contentValues.put("is_ringtone", Boolean.TRUE);
                        contentValues.put("mime_type", "audio/mp3");
                        stringBuilder3 = new StringBuilder("file://");
                        stringBuilder3.append(file.getAbsolutePath());
                        Uri contentUriForPath = MediaStore.Audio.Media.getContentUriForPath(stringBuilder3.toString());
                        ContentResolver contentResolver = context.getContentResolver();
                        StringBuilder stringBuilder5 = new StringBuilder("_data=\"");
                        stringBuilder5.append(file.getAbsolutePath());
                        stringBuilder5.append("\"");
                        contentResolver.delete(contentUriForPath, stringBuilder5.toString(), null);
                        Uri insert = context.getContentResolver().insert(contentUriForPath, contentValues);
                        RingtoneManager.setActualDefaultRingtoneUri(context, 1, insert);
                        ((Activity) context).runOnUiThread(new Runnable() {
                            public final void run() {
                                Toast.makeText(context, context.getString(R.string.rintone_seted), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private ColorDrawable getRandomDrawbleColor() {
        int idx = new Random().nextInt(bgThumb.length);
        return bgThumb[idx];
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        if (viewType == ITEM_TYPE_AD) {
            return new NativeAdViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_native_ad_item, viewGroup, false));
        } else {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_theme_item, viewGroup, false);
            return new ThemeViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (getItemViewType(position) == ITEM_TYPE_AD) {
            final NativeAdViewHolder viewHolder = (NativeAdViewHolder) holder;
            final UnifiedNativeAdView unifiedNativeAdView = (UnifiedNativeAdView) viewHolder.adview;
            if (ActivityOfTheme.mNativeAds != null) {
                if (position <= ActivityOfTheme.mNativeAds.size()) {
                    UnifiedNativeAd nativeAd = ActivityOfTheme.mNativeAds.get(position);
                    if (nativeAd != null) {
                        populateNativeAdView(nativeAd, unifiedNativeAdView);
                    }
                } else {
                    if (Adsindex < ActivityOfTheme.mNativeAds.size()) {
                        UnifiedNativeAd nativeAd = ActivityOfTheme.mNativeAds.get(Adsindex);
                        populateNativeAdView(nativeAd, unifiedNativeAdView);
                        Adsindex++;
                    } else {
                        Adsindex = 0;
                    }
                }
            }
        } else {
            if (holder instanceof ThemeViewHolder) {
                final ThemeViewHolder viewHolder = (ThemeViewHolder) holder;
                final ThemeHorizontalModel themelModel = themeCategoryList.get(position);

                if (position > ScalPosition) {
                    Animation scaleAnimation = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, 1, 0.5f, 1, 0.5f);
                    scaleAnimation.setDuration(400);
                    viewHolder.itemView.startAnimation(scaleAnimation);
                    ScalPosition = position;
                }
                Glide.with(mContext).load(themelModel.getImage()).placeholder(getRandomDrawbleColor()).diskCacheStrategy(DiskCacheStrategy.ALL).into(viewHolder.iv_thumb);
                if (!themelModel.isAvailableOffline) {
                    if (themelModel.isDownloading) {
                        viewHolder.ivDownload.setVisibility(View.GONE);
                        viewHolder.ivUseTheme.setVisibility(View.GONE);
                        viewHolder.layoutInfo.setVisibility(View.GONE);
                        viewHolder.ThemeDownProgress.setVisibility(View.VISIBLE);
                    } else {
                        viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                        viewHolder.ivDownload.setVisibility(View.VISIBLE);
                        viewHolder.ivUseTheme.setVisibility(View.GONE);
                        viewHolder.layoutInfo.setVisibility(View.GONE);
                    }
                } else {
                    viewHolder.ThemeDownProgress.setVisibility(View.GONE);
                    viewHolder.ivDownload.setVisibility(View.GONE);
                    viewHolder.ivUseTheme.setVisibility(View.VISIBLE);
                    viewHolder.layoutInfo.setVisibility(View.VISIBLE);
                }
                if (themelModel.o) {
                    viewHolder.ivPlayRingtone.setImageResource(R.drawable.icon_pause_ringtone);
                } else {
                    viewHolder.ivPlayRingtone.setImageResource(R.drawable.icon_play_ringtone);
                }
                if (themelModel.p) {
                    viewHolder.layoutThemeInfo.setVisibility(View.VISIBLE);
                    viewHolder.ivInfo.setImageResource(R.drawable.icon_close_tool);
                    viewHolder.layoutThemeInfo.bringToFront();
                } else {
                    viewHolder.layoutThemeInfo.setVisibility(View.GONE);
                    viewHolder.ivInfo.setImageResource(R.drawable.menu_dots);
                }
                viewHolder.tvThemeName.setText(themelModel.getThemeName());
                viewHolder.tvThemeName.setSelected(true);
                viewHolder.tvThemeSize.setText(readableFileSize(themelModel.getAnimSoundfilesize()));
//                viewHolder.tvThemeCounter.setText(String.valueOf(themelModel.getThemeCounter()));
                viewHolder.ivInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (themelModel.p) {
                            viewHolder.layoutThemeInfo.setVisibility(View.GONE);
                            viewHolder.ivInfo.setImageResource(R.drawable.menu_dots);
                            themelModel.p = false;
                        } else {
                            if (f == -1) {
                                viewHolder.layoutThemeInfo.setVisibility(View.VISIBLE);
                                viewHolder.ivInfo.setImageResource(R.drawable.icon_close_tool);
                                viewHolder.layoutThemeInfo.bringToFront();
                            } else {
                                viewHolder.layoutThemeInfo.setVisibility(View.VISIBLE);
                                viewHolder.layoutThemeInfo.bringToFront();
                                viewHolder.ivInfo.setImageResource(R.drawable.icon_close_tool);
                                if (f != -1) {
                                    themelModel.p = false;
                                }
                            }
                            themelModel.p = true;
                            f = position;
                            for (ThemeHorizontalModel aThemeCategoryList : themeCategoryList) {
                                aThemeCategoryList.p = false;
                            }
                            themeCategoryList.get(position).p = true;
                        }
                        notifyDataSetChanged();
                    }
                });
                viewHolder.ivSetasRingtone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            if (themelModel.getAnimSoundname() != null) {
                                final String SoundPath = Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getAnimSoundname();
                                SetAsRingTone(mContext, SoundPath, themelModel);
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                });
                viewHolder.ivSetasWallpaper.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppImageAlertDialog);
                        final AlertDialog alertdialog = builder.create();
                        LayoutInflater inflater = ActivityOfTheme.getLayoutInflater();
                        final View dialogView = inflater.inflate(R.layout.set_confirmation_dialog, null);
                        alertdialog.setView(dialogView);
                        alertdialog.show();
                        TextView tvYes = dialogView.findViewById(R.id.tvYes);
                        TextView tvNo = dialogView.findViewById(R.id.tvNo);
                        dialogView.findViewById(R.id.ivCloseDialog).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                themelModel.p = true;
                                alertdialog.dismiss();
                                notifyDataSetChanged();
                            }
                        });

                        tvYes.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                try {
                                    if (themelModel.getThemeName() != null) {
                                        String path = Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getThemeName() + ".png";
                                        themelModel.p = false;
                                        alertdialog.dismiss();
//                                        SetAsWallPapper(mContext, path);
                                        Intent intent = new Intent(mContext, WallpaperSetActivity.class);
                                        intent.putExtra("PreviewPath", path);
                                        mContext.startActivity(intent);
                                        ActivityOfTheme.finish();
                                        notifyDataSetChanged();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        tvNo.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                themelModel.p = true;
                                alertdialog.dismiss();
                                notifyDataSetChanged();
                            }
                        });
                    }

                });

                viewHolder.ivPlayRingtone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            if (themelModel.getAnimSoundPath() != null) {
                                if (!themelModel.o) {
                                    if (e != -1) {
                                        final StringBuilder sb = new StringBuilder();
                                        sb.append(themelModel.getAnimSoundPath());
                                        themeCategoryList.get(e).o = false;
                                    }
                                    e = position;
                                    final StringBuilder sb2 = new StringBuilder("last    ");
                                    sb2.append(e);
                                    PlayPause(themelModel.getAnimSoundPath(), true);
                                    if (e != -1) {
                                        themeCategoryList.get(e).o = false;
                                    }
                                    e = position;
                                    themelModel.o = true;
                                    for (ThemeHorizontalModel aThemeCategoryList : themeCategoryList) {
                                        aThemeCategoryList.o = false;
                                    }
                                    themeCategoryList.get(position).o = true;
                                    notifyDataSetChanged();
                                    return;
                                }
                                PlayPause(themelModel.getAnimSoundPath(), false);
                                themelModel.o = false;
                                viewHolder.ivPlayRingtone.setImageResource(R.drawable.icon_play_ringtone);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                viewHolder.cvthemeSelect.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DownloadThemeFiles(position, viewHolder.ivDownload, viewHolder.ivUseTheme, viewHolder.layoutInfo, viewHolder.ThemeDownProgress, viewHolder.tvThemeDownProgress, themelModel);
                    }
                });

            }

        }
    }

    public final void PlayPause(final String dataSource, final boolean b) {
        if (b) {
            if (dataSource == null) {
                return;
            }
            final MediaPlayer w = ActivityOfTheme.mediaPlayer;
            if (w != null) {
                try {
                    w.stop();
                    w.release();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    final StringBuilder sb = new StringBuilder("stopPlaying()=");
                    sb.append(ex.getMessage());
                }
            }
            ActivityOfTheme.mediaPlayer = new MediaPlayer();
            try {
                ActivityOfTheme.mediaPlayer.setDataSource(dataSource);
                ActivityOfTheme.mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    public final void onPrepared(final MediaPlayer mediaPlayer) {
                        mediaPlayer.start();
                    }
                });
                ActivityOfTheme.mediaPlayer.prepareAsync();
                return;
            } catch (IOException ex2) {
                ex2.printStackTrace();
                return;
            }
        }
        try {
            ActivityOfTheme.mediaPlayer.pause();
        } catch (IllegalStateException ex3) {
            ex3.printStackTrace();
        }
    }

    private void SetAsRingTone(final Context context, final String str, final ThemeHorizontalModel themelModel) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppImageAlertDialog);
        final AlertDialog alertdialog = builder.create();
        LayoutInflater inflater = ActivityOfTheme.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.set_confirmation_dialog, null);
        alertdialog.setView(dialogView);
        alertdialog.show();
        final TextView textView = dialogView.findViewById(R.id.tvMsg);
        TextView tvYes = dialogView.findViewById(R.id.tvYes);
        TextView tvNo = dialogView.findViewById(R.id.tvNo);
        textView.setText(R.string.set_ring);
        dialogView.findViewById(R.id.ivCloseDialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                themelModel.p = true;
                alertdialog.dismiss();
                notifyDataSetChanged();
            }
        });
        tvYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (Build.VERSION.SDK_INT < 23) {
                        themelModel.p = false;
                        SetRingTone(str, context);
                        alertdialog.dismiss();
                        notifyDataSetChanged();
                    } else if (!SetPermission(ActivityOfTheme)) {
                        Toast.makeText(mContext, context.getString(R.string.sys_setings_msg), Toast.LENGTH_LONG).show();
                    } else if (!(str == null || context == null)) {
                        SetRingTone(str, context);
                        themelModel.p = false;
                        notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(context, context.getString(R.string.unable_to_set_ringtone), Toast.LENGTH_SHORT).show();
                }
                alertdialog.dismiss();

            }
        });
        tvNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                themelModel.p = true;
                alertdialog.dismiss();
                notifyDataSetChanged();
            }
        });
    }

    private boolean SetPermission(Activity context) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (Settings.System.canWrite(context)) {
                return true;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                final Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
                final StringBuilder sb = new StringBuilder("package:");
                sb.append(context.getPackageName());
                intent.setData(Uri.parse(sb.toString()));
                context.startActivityForResult(intent, 111);
            }
        }
        return false;
    }


    private void CopyFileToStorage(final String s, final String s2, final String s3) {
        try {
            final File file = new File(s3);
            if (!file.exists()) {
                file.mkdirs();
            }
            final FileInputStream fileInputStream = new FileInputStream(s);
            final FileOutputStream fileOutputStream = new FileOutputStream(s2);
            final byte[] array = new byte[1024];
            while (true) {
                final int read = fileInputStream.read(array);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(array, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException ex2) {
            ex2.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return themeCategoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if ((position > 0) && ((position + 1) % 5 == 0) && MyApplication.getInstance().IsNativeAdsLoaded) {
            return ITEM_TYPE_AD;
        } else {
            return ITEM_TYPE_DATA;
        }

    }


    private String readableFileSize(long size) {
        if (size <= 0) return "0";
        final String[] units = new String[]{"B", "kB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    private void HideShowUnityBannerAds() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);

    }

    private void DownloadThemeFiles(int position, ImageView ivDownload, ImageView ivuseTheme, RelativeLayout layoutInfo, LinearLayout themeDownProgress, TextView tvThemeDownprogress, ThemeHorizontalModel themelModel) {
        int UnitySoundSize = themelModel.getAnimSoundfilesize();
        String SongName = themelModel.getAnimSoundname();
        File SongPath = new File(Utils.INSTANCE.getThemeFolderPath() + File.separator + SongName);
        int SoundFileSize = Integer.parseInt(String.valueOf(SongPath.length()));
        ActivityOfTheme.AllPath = themelModel.getAnimSoundPath() + "?" + Utils.INSTANCE.getThemeFolderPath() + File.separator + themelModel.getThemeName() + ".png" + "?" + themelModel.getGameobjectName();
        if (new File(Utils.INSTANCE.getThemeFolderPath() + SongName).exists()) {
            if (SoundFileSize == UnitySoundSize) {
                if (ActivityOfTheme.mInterstitialAd != null && ActivityOfTheme.mInterstitialAd.isLoaded()) {
                    try {
                        ActivityOfTheme.hud = KProgressHUD.create(mContext)
                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                                .setLabel("Showing Ads")
                                .setDetailsLabel("Please Wait...");
                        ActivityOfTheme.hud.show();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ActivityOfTheme.hud.dismiss();
                            } catch (IllegalArgumentException e) {
                                e.printStackTrace();
                            } catch (NullPointerException e2) {
                                e2.printStackTrace();
                            } catch (Exception e3) {
                                e3.printStackTrace();
                            }
                            if (ActivityOfTheme.mInterstitialAd != null && ActivityOfTheme.mInterstitialAd.isLoaded()) {
                                ActivityOfTheme.id = 100;
                                ActivityOfTheme.mInterstitialAd.show();
                            }
                        }
                    }, 2000);
                } else {
                    try {
                        stopPlaying(ActivityOfTheme.mediaPlayer);
                    } catch (IllegalStateException ex3) {
                        ex3.printStackTrace();
                    }
                    UnityPlayer.UnitySendMessage("StaticThemeDataBase", "OnLoadUserData", ActivityOfTheme.AllPath);
                    HideShowUnityBannerAds();
                    ActivityOfTheme.finish();
                }
            } else {
                if (Utils.checkConnectivity(mContext, true)) {
                    ivDownload.setVisibility(View.GONE);
                    themeDownProgress.setVisibility(View.VISIBLE);
                    DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                    new ThemeDownload(mContext, themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), themelModel.getImage(), themelModel.getThemeName() + ".png", ivDownload, ivuseTheme, layoutInfo, themeDownProgress, tvThemeDownprogress, themelModel);
                } else {
                    Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            if (Utils.checkConnectivity(mContext, true)) {
                ivDownload.setVisibility(View.GONE);
                themeDownProgress.setVisibility(View.VISIBLE);
                DownloadIncrement(themelModel.getCategoryid(), themelModel.getThemeid());
                new ThemeDownload(mContext, themelModel.getAnimsoundurl(), themelModel.getAnimSoundname(), themelModel.getAnimSoundfilesize(), themelModel.getImage(), themelModel.getThemeName() + ".png", ivDownload, ivuseTheme, layoutInfo, themeDownProgress, tvThemeDownprogress, themelModel);
            } else {
                Toast.makeText(mContext, "No Internet Connecation!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void DownloadIncrement(String CatId, String ThemeId) {
        APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);
        Call<JsonObject> call = apiInterface.DownloadIncrement(AppConstant.Token, AppConstant.ApplicationId, CatId, ThemeId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {

                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void populateNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        MediaView mediaView = unifiedNativeAdView.findViewById(R.id.ad_media);
        unifiedNativeAdView.setMediaView(mediaView);
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(nativeAd.getBody());
        }
        if (nativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }
        if (nativeAd.getStore() == null) {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.INVISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            unifiedNativeAdView.findViewById(R.id.appinstall_store_icon).setVisibility(View.VISIBLE);
            unifiedNativeAdView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(nativeAd.getStore());
        }
        if (nativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        unifiedNativeAdView.setNativeAd(nativeAd);

    }

    public class NativeAdViewHolder extends RecyclerView.ViewHolder {
        private View adview;

        public NativeAdViewHolder(View view) {
            super(view);
            this.adview = view;
        }
    }

    public class ThemeViewHolder extends RecyclerView.ViewHolder {
        CardView cvthemeSelect;
        ImageView iv_thumb, ivDownload, ivLikeTheme;
        TextView tvThemeName, tvThemeSize, tvThemeCounter, tvThemeDownProgress;
        ImageView ivUseTheme;
        Indicator indicatorThemeProgress;
        LinearLayout ThemeDownProgress;
        LinearLayout layoutDownloadMask;
        RelativeLayout layoutInfo;
        RelativeLayout layoutThemeInfo;
        ImageView ivSetasWallpaper;
        ImageView ivSetasRingtone;
        ImageView ivPlayRingtone;
        ImageView ivInfo;

        ThemeViewHolder(View itemView) {
            super(itemView);
            cvthemeSelect = itemView.findViewById(R.id.cv_root_card);
            iv_thumb = itemView.findViewById(R.id.ivThumb);
            ivDownload = itemView.findViewById(R.id.ivThumbDownload);
            ivLikeTheme = itemView.findViewById(R.id.iv_like_theme);
            tvThemeName = itemView.findViewById(R.id.tvVideoName);
            tvThemeCounter = itemView.findViewById(R.id.tvLike_counter);
            tvThemeSize = itemView.findViewById(R.id.tvVideoSize);
            tvThemeDownProgress = itemView.findViewById(R.id.tvCounter);
            ThemeDownProgress = itemView.findViewById(R.id.ll_theme_down_progress);
            indicatorThemeProgress = itemView.findViewById(R.id.indicator);
            ivUseTheme = itemView.findViewById(R.id.tvUseTheme);
            layoutDownloadMask = itemView.findViewById(R.id.downloadMask);
            layoutInfo = itemView.findViewById(R.id.layout_info);
            ivInfo = itemView.findViewById(R.id.ivInfo);
            layoutThemeInfo = itemView.findViewById(R.id.rlThemeInfo);
            ivPlayRingtone = itemView.findViewById(R.id.ivPlayRingtone);
            ivSetasWallpaper = itemView.findViewById(R.id.ivSetasWallpaper);
            ivSetasRingtone = itemView.findViewById(R.id.ivSetasRingtone);
        }
    }

}
