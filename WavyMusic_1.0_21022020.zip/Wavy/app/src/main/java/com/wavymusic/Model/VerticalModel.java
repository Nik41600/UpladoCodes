package com.wavymusic.Model;

import java.util.ArrayList;

public class VerticalModel {
    private String CategoryId, name;
    private int CatIcon;
//    private int CatSelectedIcon;
    private ArrayList<ThemeHorizontalModel> arrayList;

    public ArrayList<ThemeHorizontalModel> getArrayList() {
        return arrayList;
    }

    public void setArrayList(ArrayList<ThemeHorizontalModel> arrayList) {
        this.arrayList = arrayList;
    }

//    public int getCatSelectedIcon() {
//        return CatSelectedIcon;
//    }
//
//    public void setCatSelectedIcon(int catSelectedIcon) {
//        CatSelectedIcon = catSelectedIcon;
//    }

    public String getCategoryId() {
        return CategoryId;
    }

    public int getCatIcon() {
        return CatIcon;
    }

    public void setCatIcon(int catIcon) {
        CatIcon = catIcon;
    }

    public void setCategoryId(String categoryId) {
        this.CategoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
