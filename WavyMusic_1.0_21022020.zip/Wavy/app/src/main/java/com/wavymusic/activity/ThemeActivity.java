package com.wavymusic.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wavymusic.Adapter.ThemeCategoryAdapter;
import com.wavymusic.Model.ThemeHorizontalModel;
import com.wavymusic.Preferences.LanguagePref;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.Retrofit.APIClient;
import com.wavymusic.Retrofit.APIInterface;
import com.wavymusic.Retrofit.AppConstant;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.Utils.Utils;
import com.wavymusic.application.MyApplication;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThemeActivity extends AppCompatActivity {

    public AdLoader adLoader;
    public List<UnifiedNativeAd> mNativeAds = new ArrayList<>();
    public MediaPlayer mediaPlayer;
    public InterstitialAd mInterstitialAd;
    public int id;
    public String AllPath;
    public KProgressHUD hud;
    public LanguagePref sharedpreferences;
    Activity activity = ThemeActivity.this;
    LinearLayout llInternetCheck;
    ImageView ivback;
    Button btnRetry;
    RelativeLayout rlLoadingTheme;
    RecyclerView rvVideos;
    SwipeRefreshLayout mSwipeRefreshLayout;
    SharedPreferences pref;
    String[] split_AllLan;
    String[] split_selctedLan;
    TextView tvtitle;
    APIInterface apiInterface;
    String offlienResopnseData;
    String CategoryName, CategoryId;
    Long timestamps;
    GridLayoutManager gridLayoutManager;
    Date date = new Date();
    private ArrayList<ThemeHorizontalModel> ThemeListCategoryWise = new ArrayList<>();
    private ThemeCategoryAdapter categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_by_theme);
        sharedpreferences = LanguagePref.a(this);
        pref = PreferenceManager.getDefaultSharedPreferences(activity);
        split_AllLan = ("35,27,34,33,29,32,30,31,28,24,22,25,36").split(",");
        split_selctedLan = LanguagePref.a(activity).a("pref_key_language_list", "22").split(",");
        CategoryName = getIntent().getStringExtra("CatName");
        CategoryId = getIntent().getStringExtra("CatId");
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "ThemeActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        BindView();
        loadNativeAds();
        CallInterstitialAd();
        SetListener();
        if (CategoryId.equals("111")) {
            WhatsNewData();
        } else {
            SetThemeData();
        }
    }

    private void BindView() {
        tvtitle = findViewById(R.id.tvName);
        mSwipeRefreshLayout = findViewById(R.id.swipeToRefresh);
        rvVideos = findViewById(R.id.rvVideos);
        llInternetCheck = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btn_catwise_Retry);
        ivback = findViewById(R.id.ivBack);
        rlLoadingTheme = findViewById(R.id.rl_loading_pager);
        rvVideos.setNestedScrollingEnabled(false);
        rvVideos.setHasFixedSize(true);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        if (CategoryName != null) {
            tvtitle.setText(CategoryName);
        }
    }


    private void loadNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.native_ad));
        adLoader = builder.forUnifiedNativeAd(
                new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        mNativeAds.add(unifiedNativeAd);
                        MyApplication.getInstance().IsNativeAdsLoaded = true;

                    }
                }).withAdListener(
                new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        MyApplication.getInstance().IsNativeAdsLoaded = false;
                    }
                }).build();

        // Load the Native ads.
        adLoader.loadAds(new AdRequest.Builder().build(), 5);
    }

    private void CallInterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        try {
                            stopPlaying(mediaPlayer);
                        } catch (IllegalStateException ex3) {
                            ex3.printStackTrace();
                        }
                        UnityPlayer.UnitySendMessage("StaticThemeDataBase", "OnLoadUserData", AllPath);
                        HideShowUnityBannerAds();
                        finish();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void HideShowUnityBannerAds() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);
    }

    private void stopPlaying(MediaPlayer mp) {
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
                mp = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void SetListener() {
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.checkConnectivity(activity, false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    startActivity(new Intent(activity, HomeActivity.class));
                    activity.finish();
                } else {
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_LONG).show();
                }
            }
        });
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (Utils.checkConnectivity(activity, false)) {
                    llInternetCheck.setVisibility(View.GONE);
                    ThemeListCategoryWise.clear();
                    GetCategoryOfTheme();
                    mSwipeRefreshLayout.setRefreshing(false);
                } else {
                    mSwipeRefreshLayout.setRefreshing(false);
                    Toast.makeText(activity, "No Internet Connecation!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void SetThemeData() {
        if (Utils.checkConnectivity(activity, false)) {
            String id = pref.getString(CategoryId, null);
            if (id != null && !id.equals("")) {
                getOfflineCategory(activity, CategoryId);
                if (offlienResopnseData != null && timestamps != null) {
                    new GetofflineThemeData().execute();
                }
            }
        } else {
            String id = pref.getString(CategoryId, null);
            if (id != null && !id.equals("")) {
                getOfflineCategory(activity, CategoryId);
                if (offlienResopnseData != null) {
                    new GetofflineThemeData().execute();
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    rlLoadingTheme.setVisibility(View.GONE);
                    Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void WhatsNewData() {
        if (Utils.checkConnectivity(activity, false)) {
            String id = pref.getString("NewTheme", null);
            if (id != null && !id.equals("")) {
                getOfflineCategory(activity, "NewTheme");
                if (offlienResopnseData != null && timestamps != null) {
                    new WhatsNewData().execute();
                }
            }
        } else {
            String id = pref.getString("NewTheme", null);
            if (id != null && !id.equals("")) {
                getOfflineCategory(activity, "NewTheme");
                if (offlienResopnseData != null) {
                    new WhatsNewData().execute();
                } else {
                    llInternetCheck.setVisibility(View.VISIBLE);
                    rlLoadingTheme.setVisibility(View.GONE);
                    Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void GetCategoryOfTheme() {
        rlLoadingTheme.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        JSONArray jsonArray = jsonObj.getJSONArray("category");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject themeJSONObject = jsonArray.getJSONObject(i);
                            String Catid = (themeJSONObject.getString("id"));
                            if (CategoryId.equals("111")) {
                                JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                                        themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                        if (themeModel.isNewRealise().equals("1")) {
                                            ThemeListCategoryWise.add(themeModel);
                                        }
                                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                        themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                                        themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                        if (themeModel.isNewRealise().equals("1")) {
                                            ThemeListCategoryWise.add(themeModel);
                                        }
                                    }
                                }
                                SetOfflineCategory(activity, Utils.WhatsNewJson(ThemeListCategoryWise), "NewTheme", date);
                            } else {
                                if (CategoryId.equals(Catid)) {
                                    SetOfflineCategory(activity, themeJSONObject.toString(), CategoryId, date);
                                    JSONArray jSONArray4 = themeJSONObject.getJSONArray("themes");
                                    for (int j = 0; j < jSONArray4.length(); j++) {
                                        ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                                        JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                        if (!Arrays.asList(split_AllLan).contains(Catid)) {
                                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                                            themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                            ThemeListCategoryWise.add(themeModel);
                                        } else if (Arrays.asList(split_selctedLan).contains(Catid)) {
                                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                            themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                            themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                                            themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                            ThemeListCategoryWise.add(themeModel);
                                        }
                                        if (MyApplication.getInstance().IsNativeAdsLoaded) {
                                            if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                                themeModel.setNativeAds(true);
                                                ThemeListCategoryWise.add(j, themeModel);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        SetUpAdapter();
                        rlLoadingTheme.setVisibility(View.GONE);
                    } catch (final JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                rlLoadingTheme.setVisibility(View.VISIBLE);
            }
        });

    }

    private void SetUpAdapter() {
        RecyclerView recyclerView;
        int i2 = 0;
        gridLayoutManager = new GridLayoutManager(activity, 2);
        categoryAdapter = new ThemeCategoryAdapter(activity, ThemeListCategoryWise);
        rvVideos.setLayoutManager(gridLayoutManager);
        rvVideos.setItemAnimator(new DefaultItemAnimator());
        rvVideos.setAdapter(categoryAdapter);
        if (MyApplication.ThemePosition == -1) {
            recyclerView = this.rvVideos;
        } else {
            recyclerView = this.rvVideos;
            i2 = MyApplication.ThemePosition;
        }
        recyclerView.scrollToPosition(i2);
        rvVideos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(gridLayoutManager.findFirstVisibleItemPosition());
                MyApplication.ThemePosition = gridLayoutManager.findFirstVisibleItemPosition();
            }
        });
        categoryAdapter.notifyDataSetChanged();
        if (!MyApplication.IsHomeAdsDisplay && UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(activity)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (UnityPlayerActivity.mInterstitialAd != null && UnityPlayerActivity.mInterstitialAd.isLoaded()) {
                        MyApplication.IsHomeAdsDisplay = true;
                        UnityPlayerActivity.mInterstitialAd.show();
                    }
                }
            }, 2000);
        }
    }

    private void SetOfflineCategory(Context c, String userObject, String key, final Date date) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.putLong(key + "_value", date.getTime());
        editor.apply();
    }

    private void getOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        offlienResopnseData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    @SuppressLint("StaticFieldLeak")
    public class GetofflineThemeData extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                int Catid = Integer.parseInt(jsonObj.getString("id"));
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(Catid))) {
                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                        themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                        ThemeListCategoryWise.add(themeModel);
                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(Catid))) {
                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                        themeModel.setImage(jsonobjecttheme.getString("small_thumbnail"));
                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                        themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                        ThemeListCategoryWise.add(themeModel);
                    }
                    if (Utils.checkConnectivity(activity, false)) {
                        if (MyApplication.getInstance().IsNativeAdsLoaded) {
                            if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                                themeModel.setNativeAds(true);
                                ThemeListCategoryWise.add(j, themeModel);
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class WhatsNewData extends AsyncTask<Void, Void, Void> {

        protected void onPreExecute() {
            rlLoadingTheme.setVisibility(View.VISIBLE);
        }

        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(offlienResopnseData);
                JSONArray jSONArray4 = jsonObj.getJSONArray("themes");
                for (int j = 0; j < jSONArray4.length(); j++) {
                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                    if (!Arrays.asList(split_AllLan).contains(String.valueOf(CategoryId))) {
                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                        themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                        if (themeModel.isNewRealise().equals("1")) {
                            ThemeListCategoryWise.add(themeModel);
                        }
                    } else if (Arrays.asList(split_selctedLan).contains(String.valueOf(CategoryId))) {
                        themeModel.setThemeid(jsonobjecttheme.getString("id"));
                        themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                        themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                        themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                        themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                        themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.setAnimSoundPath(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.isAvailableOffline = CheckFileSize(Utils.INSTANCE.getThemeFolderPath() + File.separator + jsonobjecttheme.getString("sound_filename") + ".mp3");
                        themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                        themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                        themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                        if (themeModel.isNewRealise().equals("1")) {
                            ThemeListCategoryWise.add(themeModel);
                        }
                    }
                    if (MyApplication.getInstance().IsNativeAdsLoaded) {
                        if ((ThemeListCategoryWise.size() + 1) % 5 == 0) {
                            themeModel.setNativeAds(true);
                            ThemeListCategoryWise.add(j, themeModel);
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Void result) {
            rlLoadingTheme.setVisibility(View.GONE);
            SetUpAdapter();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(activity, HomeActivity.class));
        finish();
    }
}
