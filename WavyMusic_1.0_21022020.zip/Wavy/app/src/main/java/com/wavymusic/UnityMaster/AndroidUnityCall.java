//package com.wavymusic.UnityMaster;
//
//import android.content.Context;
//import android.content.Intent;
//import android.net.Uri;
//import android.os.Handler;
//import android.view.View;
//
//import com.wavymusic.Preferences.LanguagePref;
//import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
//import com.wavymusic.UnityPlayerActivity;
//import com.wavymusic.Utils.AppGeneral;
//import com.wavymusic.Utils.Utils;
//import com.wavymusic.activity.HomeActivity;
//import com.wavymusic.activity.LanguageSelectActivity;
//import com.wavymusic.activity.SelectImageActivity;
//import com.wavymusic.activity.SongSelectActivity;
//import com.wavymusic.activity.TextEditActivity;
//import com.wavymusic.activity.VideoplayActivity;
//import com.wavymusic.application.MyApplication;
//
//import java.io.File;
//
//public class AndroidUnityCall {
//
//    public static KProgressHUD hud;
//
//    public static void HomeActivity(Context context) {
//        if (LanguagePref.a(context).a("pref_key_is_language_set", false)) {
//            if (MyApplication.IsHomeAdsDisplay) {
//                loadHomeActivityWithAds(context);
//            } else {
//                loadHomeActivity(context);
//            }
//        } else {
//            Intent intent = new Intent(context, LanguageSelectActivity.class);
//            intent.putExtra("isFromMain", false);
//            context.startActivity(intent);
//        }
//    }
//
//    private static void loadHomeActivityWithAds(final Context context) {
//        MyApplication.AppLaunchContex = context;
//        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
//            public final void run() {
//                if (MyApplication.IsHomeAdsDisplay && MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
//                    try {
//                        hud = KProgressHUD.create(context)
//                                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
//                                .setLabel("Showing Ads")
//                                .setDetailsLabel("Please Wait...");
//                        hud.show();
//                    } catch (IllegalArgumentException e) {
//                        e.printStackTrace();
//                    } catch (NullPointerException e2) {
//                        e2.printStackTrace();
//                    } catch (Exception e3) {
//                        e3.printStackTrace();
//                    }
//                    Handler handler = new Handler();
//                    handler.postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            try {
//                                hud.dismiss();
//                            } catch (IllegalArgumentException e) {
//                                e.printStackTrace();
//                            } catch (NullPointerException e2) {
//                                e2.printStackTrace();
//                            } catch (Exception e3) {
//                                e3.printStackTrace();
//                            }
//                            if (MyApplication.mInterstitialAd != null && MyApplication.mInterstitialAd.isLoaded()) {
//                                MyApplication.IsHomeAdsDisplay = true;
//                                MyApplication.mInterstitialAd.show();
//                            }
//                        }
//                    }, 2000);
//                } else {
//                    loadHomeActivity(context);
//                }
//            }
//        });
//    }
//
//    public static void loadHomeActivity(Context context) {
//        Intent intent = new Intent(context, HomeActivity.class);
//        context.startActivity(intent);
//    }
//
//    public static void OpenGallery(Context context) {
//        MyApplication.IsSelectImageFrom = false;
//        MyApplication.TotalSelectedImage = 6;
//        MyApplication.getInstance().getCropImages().clear();
//        Intent intent = new Intent(context, SelectImageActivity.class);
//        intent.putExtra("NoofImage", 6);
//        context.startActivity(intent);
//    }
//
//    public static void SelectSong(Context context) {
//        context.startActivity(new Intent(context, SongSelectActivity.class));
//    }
//
//    public static void ChangeName(Context context, String str) {
//        Intent intent = new Intent(context, TextEditActivity.class);
//        intent.putExtra("JsonStr", str);
//        context.startActivity(intent);
//    }
//
//    public static void PlayVideo(Context context, String VideoPath) {
//        Intent intent = new Intent(context, VideoplayActivity.class);
//        intent.putExtra("VideoUrl", VideoPath);
//        intent.putExtra("VideoPosition", 0);
//        intent.putExtra("AllVideoList", Utils.getAllCreatedVideoList(context));
//        intent.putExtra("IsVideoFromAndroidList", false);
//        context.startActivity(intent);
//        ScanVideoList(context, AppGeneral.VideoOutputFullPath);
//        AppGeneral.LastTime = 0.0f;
//        DeleteCropImages();
//    }
//
//    public static void HideBannerAds(Context context){
//        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
//            public final void run() {
//                try {
//                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//    }
//
//   /* public static void createVideo(Context context, String str, String str2, String str3, String str4) {
////        String VideoINputName = str3.replace("Mbit", "Beats");
//        AppGeneral.AudioVideoShort(context, str2, str3);
//    }
//
//    public static void prepareSongForCreateVideo(Context context, String str, String str2, String str3, String str4) {
//        String VideoINputName = str3.replace("Mbit", "Beats");
//        ((UnityPlayerActivity) context).runOnUiThread(new Runnable() {
//            public final void run() {
//                try {
//                    UnityPlayerActivity.layoutAdView.setVisibility(View.GONE);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//        AppGeneral.AddSongTOVideo(context, str2, str4, str, str3);
//    }*/
//
//
//    public static void DeleteCropImages() {
//        Utils util = new Utils();
//        String path = util.getOutputPath() + "CropTempImg" + File.separator;
//        File folder = new File(path);
//        util.deleteRecursive(folder);
//    }
//
//    public static void ScanVideoList(Context cntx, String path) {
//        try {
//            android.media.MediaScannerConnection.scanFile(cntx,
//                    new String[]{path},
//                    new String[]{"video/mp4"},
//                    new android.media.MediaScannerConnection.OnScanCompletedListener() {
//                        public void onScanCompleted(String path, Uri uri) {
//                        }
//                    });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}
