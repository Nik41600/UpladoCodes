package com.wavymusic.Model;

import android.support.v7.widget.RecyclerView;

public class HorizontalRecycleviewGetSet {

    RecyclerView HorizontalRecyclerview;

    public RecyclerView getHorizontalRecyclerview() {
        return HorizontalRecyclerview;
    }

    public void setHorizontalRecyclerview(RecyclerView horizontalRecyclerview) {
        HorizontalRecyclerview = horizontalRecyclerview;
    }
}
