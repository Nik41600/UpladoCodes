package com.wavymusic.Model;

import java.util.ArrayList;
import java.util.List;

public class PhoneSong {
    private String folderName;
    private List<PhoneSongModel> localTracks;

    public PhoneSong(String folderName, List<PhoneSongModel> localTracks) {
        this.folderName = folderName;
        this.localTracks = localTracks;
    }

    public PhoneSong(String folderName) {
        this.folderName = folderName;
        localTracks = new ArrayList<>();
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public List<PhoneSongModel> getLocalTracks() {
        return localTracks;
    }

    public void setLocalTracks(List<PhoneSongModel> localTracks) {
        this.localTracks = localTracks;
    }


}
