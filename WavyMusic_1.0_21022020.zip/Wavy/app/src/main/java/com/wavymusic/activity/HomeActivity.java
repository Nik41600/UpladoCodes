package com.wavymusic.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.wavymusic.Adapter.CategoryVerticalAdapter;
import com.wavymusic.Model.ThemeHorizontalModel;
import com.wavymusic.Model.VerticalModel;
import com.wavymusic.Preferences.LanguagePref;
import com.wavymusic.ProgressBar.kprogresshud.KProgressHUD;
import com.wavymusic.R;
import com.wavymusic.Retrofit.APIClient;
import com.wavymusic.Retrofit.APIInterface;
import com.wavymusic.Retrofit.AppConstant;
import com.wavymusic.UnityPlayerActivity;
import com.wavymusic.Utils.AppGeneral;
import com.wavymusic.Utils.Utils;
import com.wavymusic.application.MyApplication;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.unity3d.player.UnityPlayer;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private final int REQUEST_PERMISSION_SETTING = 101;
    public MediaPlayer mediaPlayer;
    public String ThemeValue;
    public AdLoader adLoader;
    public List<UnifiedNativeAd> mNativeAds = new ArrayList<>();
    public InterstitialAd mInterstitialAd;
    public KProgressHUD hud;
    public int id;
    public ActionBarDrawerToggle mDrawerToggle;
    Activity activity = HomeActivity.this;
    ArrayList<VerticalModel> categorylist = new ArrayList<VerticalModel>();
    RecyclerView rvCategory;
    LinearLayout llRetry;
    RelativeLayout loading;
    Button btnRetry;
    TextView tvAppVersion;
    ImageView ivNavDrawer, ivCreation;
    LinearLayoutManager layoutManager;
    CategoryVerticalAdapter categoryAdapter;
    APIInterface apiInterface;
    SharedPreferences pref;
    String OfflineData;
    String WhsThemeItem;
    Long timestamps;
    Date date = new Date();
    String[] split_AllLan;
    String[] split_selctedLan;
    private ArrayList<ThemeHorizontalModel> WhatsNewList = new ArrayList<>();
    private boolean B = false;
    private boolean C = false;
    private boolean D = false;
    PackageInfo info = null;
    private DrawerLayout mDrawerLayout;
//    private BroadcastReceiver broadcastReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        split_AllLan = ("35,27,34,33,29,32,30,31,28,24,22,25,36").split(",");
        split_selctedLan = LanguagePref.a(activity).a("pref_key_language_list", "22").split(",");
        apiInterface = APIClient.getClient().create(APIInterface.class);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "HomeActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);

//        broadcastReceiver = new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
//                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
//                    displayFirebaseRegId();
//                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
//                    String message = intent.getStringExtra("message");
//                    Toast.makeText(getApplicationContext(), "Push notification: " + message, Toast.LENGTH_LONG).show();
//                }
//            }
//        };
//        displayFirebaseRegId();
        CallNativeAds();
        CallInterstitialAd();
        BindViewId();
        GetAppVersion();
        if (Build.VERSION.SDK_INT < 23) {
            SetTheme();
        } else if (!this.B || this.C) {
            this.C = false;
            this.D = false;
            RequestPermission(false);
        }
        if (this.D) {
            this.C = true;
        }
        SetAdapter();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver,
//                new IntentFilter(Config.REGISTRATION_COMPLETE));
//        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver,
//                new IntentFilter(Config.PUSH_NOTIFICATION));
//        NotificationUtils.clearNotifications(getApplicationContext());
    }

    @Override
    protected void onPause() {
        super.onPause();
//        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
    }


//    private void displayFirebaseRegId() {
//        SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
//        String regId = pref.getString("regId", null);
//        if (!TextUtils.isEmpty(regId)) {
//            Log.e("TAG", "Firebase Reg Id:" + regId);
//        }
//    }

    private void CallInterstitialAd() {
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case 100:
                        UnityPlayer.UnitySendMessage("StaticThemeDataBase", "OnLoadUserData", ThemeValue);
                        HideShowUnityBannerAds();
                        finish();
                        break;
                    case 101:
                        GoToExitApp();
                        break;
                }
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();

            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);

            }
        });
    }

    private void CallNativeAds() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getString(R.string.native_ad));
        adLoader = builder.forUnifiedNativeAd(
                new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
                    @Override
                    public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                        mNativeAds.add(unifiedNativeAd);
                        MyApplication.getInstance().IsNativeAdsLoaded = true;

                    }
                }).withAdListener(
                new AdListener() {
                    @Override
                    public void onAdFailedToLoad(int errorCode) {
                        MyApplication.getInstance().IsNativeAdsLoaded = false;
                    }
                }).build();
        adLoader.loadAds(new AdRequest.Builder().build(), 5);
    }

    private void HideShowUnityBannerAds() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    UnityPlayerActivity.layoutAdView.setVisibility(View.VISIBLE);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 3000);

    }

    public void RequestPermission(boolean z) {
        if ((ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            Utils.CreateDirectory();
            AppGeneral.loadFFMpeg(activity);
            SetTheme();
        } else if (z) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle("Necessary permission");
            builder.setMessage("Allow Required Permission");
            builder.setCancelable(false);
            builder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    OpenPremissionSetting();
                }
            });
            builder.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
//                    UnityPlayerActivity.mUnityPlayer.quit();
                    finish();
                }
            });
            builder.show();
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
                AppGeneral.loadFFMpeg(activity);
                SetTheme();
            } else {
                RequestPermission(true);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0) {
                if (iArr[0] == 0 && iArr[1] == PackageManager.PERMISSION_GRANTED) {
                    Utils.CreateDirectory();
                    AppGeneral.loadFFMpeg(activity);
                    SetTheme();
                } else if ((iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) || (iArr[1] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.READ_EXTERNAL_STORAGE))) {
                    this.B = true;
                    RequestPermission(true);
                }
            }
        }
    }

    public void OpenPremissionSetting() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
        intent.setData(uri);
        activity.startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }

    private void SetTheme() {
//        NewgetOfflineCategory(activity, "NewTheme");
//        if (WhsThemeItem != null && timestamps != null) {
//            NewTheme();
//        }

        getThemeJson(activity, "ThemeJson");
        if (Utils.checkConnectivity(activity, false)) {
            if (OfflineData != null && timestamps != null) {
                if (Math.abs(System.currentTimeMillis() - timestamps) > 900000) {
                    CallGetAllTheme();
                } else {
                    if (OfflineData != null) {
                        new CatOfflineData().execute();
                    }
                }
            } else {
                CallGetAllTheme();
            }
        } else {
            if (OfflineData != null) {
                new CatOfflineData().execute();
            } else {
                llRetry.setVisibility(View.VISIBLE);
                loading.setVisibility(View.GONE);
                Toast.makeText(activity, "Data/Wifi Not Available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void BindViewId() {
        mDrawerLayout = findViewById(R.id.drawer_layout);
        ivNavDrawer = findViewById(R.id.ivNavDrawer);
        ivCreation = findViewById(R.id.iv_mycreation);
        llRetry = findViewById(R.id.llRetry);
        btnRetry = findViewById(R.id.btnRetry);
        loading = findViewById(R.id.rl_loading);
        tvAppVersion = findViewById(R.id.tv_version);
        rvCategory = findViewById(R.id.rvAllcategory);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ivCreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity, YourVideoActivity.class));
                finish();
            }
        });
        ivNavDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.START);
            }
        });
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
    }

    private void GetAppVersion() {
        PackageManager manager = activity.getPackageManager();
        try {
            info = manager.getPackageInfo(activity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (info != null) {
            tvAppVersion.setText("v" + info.versionName);
        }
    }

    private void SetAdapter() {
        rvCategory.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rvCategory.setLayoutManager(layoutManager);
        categoryAdapter = new CategoryVerticalAdapter(this, categorylist/*, catNameArrayList*/);
        rvCategory.setAdapter(categoryAdapter);
        rvCategory.setNestedScrollingEnabled(false);
    }

    private void NewTheme() {
        try {
            /*WhatsNew Theme Start*/
            ArrayList<ThemeHorizontalModel> WhHorizonModelArrayList = new ArrayList<ThemeHorizontalModel>();
            VerticalModel whatsNewModel = new VerticalModel();
            whatsNewModel.setCategoryId("111");
            whatsNewModel.setCatIcon(Utils.INSTANCE.CatThumb("New"));
            whatsNewModel.setName("New");
            JSONObject whatsNewJsonObj = new JSONObject(WhsThemeItem);
            JSONArray whatsNewjSONArray = whatsNewJsonObj.getJSONArray("themes");
            for (int j = 0; j < whatsNewjSONArray.length(); j++) {
                ThemeHorizontalModel Whatsnewmodel = new ThemeHorizontalModel();
                JSONObject jsonobjecttheme = whatsNewjSONArray.getJSONObject(j);
                Whatsnewmodel.setThemeid(jsonobjecttheme.getString("id"));
                Whatsnewmodel.setCategoryid(jsonobjecttheme.getString("category"));
                Whatsnewmodel.setThemeName(jsonobjecttheme.getString("theme_name"));
                Whatsnewmodel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                Whatsnewmodel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                Whatsnewmodel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                Whatsnewmodel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + Whatsnewmodel.getAnimSoundname());
                Whatsnewmodel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + Whatsnewmodel.getAnimSoundname());
                Whatsnewmodel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                Whatsnewmodel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                Whatsnewmodel.setNewRealise(jsonobjecttheme.getString("is_release"));
                WhHorizonModelArrayList.add(Whatsnewmodel);
            }
            categorylist.add(0, whatsNewModel);
            whatsNewModel.setArrayList(WhHorizonModelArrayList);
            /*WhatsNew Theme End*/
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void CallGetAllTheme() {
        loading.setVisibility(View.VISIBLE);
        Call<JsonObject> call = apiInterface.GetAllTheme(AppConstant.Token, AppConstant.ApplicationId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonObj = new JSONObject(new Gson().toJson(response.body()));
                        SetThemeJson(activity, jsonObj.toString(), "ThemeJson", date);
                        JSONArray category = jsonObj.getJSONArray("category");
                        for (int i = 0; i < category.length(); i++) {
                            JSONObject tabcategoryJSONObject = category.getJSONObject(i);
                            String CategoryId = tabcategoryJSONObject.getString("id");
                            SetThemeJson(activity, tabcategoryJSONObject.toString(), CategoryId, date);
                            ArrayList<ThemeHorizontalModel> HorizonModelArrayList = new ArrayList<ThemeHorizontalModel>();
                            VerticalModel mVerticalModel = new VerticalModel();
                            mVerticalModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                            if (!Arrays.asList(split_AllLan).contains(mVerticalModel.getCategoryId())) {
                                mVerticalModel.setCatIcon(Utils.INSTANCE.CatThumb(tabcategoryJSONObject.getString("name")));
                                mVerticalModel.setName(tabcategoryJSONObject.getString("name"));
                                JSONArray jSONArray4 = tabcategoryJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                    themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                    themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                    themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                                    themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                    themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                    themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                                    themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                    HorizonModelArrayList.add(themeModel);
                                    if (themeModel.isNewRealise().equals("1")) {
                                        WhatsNewList.add(themeModel);
                                    }
                                }
                                categorylist.add(mVerticalModel);
                                mVerticalModel.setArrayList(HorizonModelArrayList);
                            } else if (Arrays.asList(split_selctedLan).contains(mVerticalModel.getCategoryId())) {
                                mVerticalModel.setCatIcon(Utils.INSTANCE.CatThumb(tabcategoryJSONObject.getString("name")));
                                mVerticalModel.setName(tabcategoryJSONObject.getString("name"));
                                JSONArray jSONArray4 = tabcategoryJSONObject.getJSONArray("themes");
                                for (int j = 0; j < jSONArray4.length(); j++) {
                                    ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                                    JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                                    themeModel.setThemeid(jsonobjecttheme.getString("id"));
                                    themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                                    themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                                    themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                                    themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                                    themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                                    themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                                    themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                                    themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                                    themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                                    themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                                    HorizonModelArrayList.add(themeModel);
                                    if (themeModel.isNewRealise().equals("1")) {
                                        WhatsNewList.add(themeModel);
                                    }
                                }
                                categorylist.add(mVerticalModel);
                                mVerticalModel.setArrayList(HorizonModelArrayList);
                            }
                        }
                        SetThemeJson(activity, Utils.WhatsNewJson(WhatsNewList), "NewTheme", date);
                        NewgetOfflineCategory(activity, "NewTheme");
                        if (WhsThemeItem != null && timestamps != null) {
                            NewTheme();
                        }
                        loading.setVisibility(View.GONE);
                        categoryAdapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void SetThemeJson(Context c, String userObject, String key, final Date date) {
        pref = PreferenceManager.getDefaultSharedPreferences(c);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, userObject);
        editor.putLong(key + "_value", date.getTime());
        editor.apply();
    }

    private void getThemeJson(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        OfflineData = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }

    private void NewgetOfflineCategory(Context ctx, String key) {
        pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        WhsThemeItem = pref.getString(key, null);
        timestamps = pref.getLong(key + "_value", 0);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        SelectedNavItem(menuItem.getItemId());
        return true;
    }

    private void SelectedNavItem(int itemId) {
        switch (itemId) {
            case R.id.nav_my_video:
                startActivity(new Intent(activity, YourVideoActivity.class));
                finish();
                break;
            case R.id.nav_ringtone:
                startActivity(new Intent(activity, RingtoneActivity.class));
                finish();
                break;
            case R.id.nav_feddback:
                Feedback();
                break;
            case R.id.nav_Select_songlanguage:
                startActivity(new Intent(activity, LanguageSelectActivity.class));
                finish();
                break;
            case R.id.nav_rate_us:
                RateApp();
                break;
            case R.id.nav_invite:
                ShareAPP();
                break;
            case R.id.nav_privacy:
                Intent intent1 = new Intent("android.intent.action.VIEW");
                intent1.setData(Uri.parse(getResources().getString(R.string.privacy_link)));
                break;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    private void Feedback() {
        Intent intent2 = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", getResources().getString(R.string.feedback_email), null));
        intent2.putExtra("android.intent.extra.SUBJECT", "Feedback");
        intent2.putExtra("android.intent.extra.TEXT", "Write your feedback here");
        startActivity(Intent.createChooser(intent2, "Send email..."));
    }

    private void RateApp() {
        Uri uri = Uri.parse("market://details?id=" + activity.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        }
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + activity.getPackageName())));
        }
    }

    private void ShareAPP() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Wavy Music");
            String shareMessage = "\nGet free Wavy Music at here:";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + activity.getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void GoToExitApp() {
        startActivity(new Intent(activity, ExitAppActivity.class));
        finish();
    }

    public void onBackPressed() {
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            try {
                hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Showing Ads")
                        .setDetailsLabel("Please Wait...");
                hud.show();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NullPointerException e2) {
                e2.printStackTrace();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        hud.dismiss();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();

                    } catch (NullPointerException e2) {
                        e2.printStackTrace();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                    if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                        id = 101;
                        mInterstitialAd.show();
                    }
                }
            }, 2000);
        } else {
            GoToExitApp();
        }
    }

    public boolean CheckFileSize(String file) {
        return new File(file).exists();
    }

    @SuppressLint("StaticFieldLeak")
    private class CatOfflineData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                JSONObject jsonObj = new JSONObject(OfflineData);
                JSONArray tabcategory = jsonObj.getJSONArray("category");
                for (int i = 0; i < tabcategory.length(); i++) {
                    JSONObject tabcategoryJSONObject = tabcategory.getJSONObject(i);
                    ArrayList<ThemeHorizontalModel> HorizonModelArrayList = new ArrayList<ThemeHorizontalModel>();
                    VerticalModel mVerticalModel = new VerticalModel();
                    mVerticalModel.setCategoryId(tabcategoryJSONObject.getString("id"));
                    if (!Arrays.asList(split_AllLan).contains(mVerticalModel.getCategoryId())) {
                        mVerticalModel.setCatIcon(Utils.INSTANCE.CatThumb(tabcategoryJSONObject.getString("name")));
                        mVerticalModel.setName(tabcategoryJSONObject.getString("name"));
                        JSONArray jSONArray4 = tabcategoryJSONObject.getJSONArray("themes");
                        for (int j = 0; j < jSONArray4.length(); j++) {
                            ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                            JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                            themeModel.setThemeid(jsonobjecttheme.getString("id"));
                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                            themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                            themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                            HorizonModelArrayList.add(themeModel);
                            if (themeModel.isNewRealise().equals("1")) {
                                WhatsNewList.add(themeModel);
                            }
                        }
                        categorylist.add(mVerticalModel);
                        mVerticalModel.setArrayList(HorizonModelArrayList);
                    } else if (Arrays.asList(split_selctedLan).contains(mVerticalModel.getCategoryId())) {
                        mVerticalModel.setCatIcon(Utils.INSTANCE.CatThumb(tabcategoryJSONObject.getString("name")));
                        mVerticalModel.setName(tabcategoryJSONObject.getString("name"));
                        JSONArray jSONArray4 = tabcategoryJSONObject.getJSONArray("themes");
                        for (int j = 0; j < jSONArray4.length(); j++) {
                            ThemeHorizontalModel themeModel = new ThemeHorizontalModel();
                            JSONObject jsonobjecttheme = jSONArray4.getJSONObject(j);
                            themeModel.setThemeid(jsonobjecttheme.getString("id"));
                            themeModel.setCategoryid(jsonobjecttheme.getString("category"));
                            themeModel.setThemeName(jsonobjecttheme.getString("theme_name"));
                            themeModel.setImage(jsonobjecttheme.getString("theme_thumbnail"));
                            themeModel.setAnimsoundurl(jsonobjecttheme.getString("sound_file"));
                            themeModel.setAnimSoundname(jsonobjecttheme.getString("sound_filename") + ".mp3");
                            themeModel.setAnimSoundPath(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + File.separator + themeModel.getAnimSoundname());
                            themeModel.isAvailableOffline = CheckFileSize(new File(Utils.PathOfFolder).getAbsolutePath() + File.separator + themeModel.getAnimSoundname());
                            themeModel.setAnimSoundfilesize(Integer.parseInt(jsonobjecttheme.getString("sound_size")));
                            themeModel.setGameobjectName(jsonobjecttheme.getString("game_object"));
                            themeModel.setNewRealise(jsonobjecttheme.getString("is_release"));
                            HorizonModelArrayList.add(themeModel);
                            if (themeModel.isNewRealise().equals("1")) {
                                WhatsNewList.add(themeModel);
                            }
                        }
                        categorylist.add(mVerticalModel);
                        mVerticalModel.setArrayList(HorizonModelArrayList);
                    }
                }
                SetThemeJson(activity, Utils.WhatsNewJson(WhatsNewList), "NewTheme", date);
                NewgetOfflineCategory(activity, "NewTheme");
                if (WhsThemeItem != null && timestamps != null) {
                    NewTheme();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            loading.setVisibility(View.GONE);
            categoryAdapter.notifyDataSetChanged();
        }
    }

}
