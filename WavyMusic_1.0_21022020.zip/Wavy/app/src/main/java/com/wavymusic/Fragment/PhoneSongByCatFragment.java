package com.wavymusic.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wavymusic.Adapter.PhoneSongAdapter;
import com.wavymusic.Model.PhoneSong;
import com.wavymusic.Model.PhoneSongModel;
import com.wavymusic.R;
import com.wavymusic.activity.PhoneSongActivity;

import java.util.List;

import static com.wavymusic.activity.PhoneSongActivity.PhoneSongFolders;

public class PhoneSongByCatFragment extends Fragment {

    public List<PhoneSongModel> PhonsSongList;
    public PhoneSong phoneSong;
    Integer Folderid = -1;
    Integer TabIndex = -1;
    RecyclerView rvPhoneSong;
    PhoneSongAdapter mPhonsSongAdp;



    public static Fragment getInstance(int Folderid, int TabIndex) {
        Bundle bundle = new Bundle();
        bundle.putInt("Folderid", Folderid);
        bundle.putInt("TabIndex", TabIndex);
        PhoneSongByCatFragment songByCatFragmentent = new PhoneSongByCatFragment();
        songByCatFragmentent.setArguments(bundle);
        return songByCatFragmentent;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Folderid = getArguments().getInt("Folderid");
        TabIndex = getArguments().getInt("TabIndex");
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_phone_song, container, false);
        phoneSong = PhoneSongFolders.getMusicFolders().get(Folderid);
        PhonsSongList = phoneSong.getLocalTracks();
        rvPhoneSong = view.findViewById(R.id.rv_recycler_view);
        mPhonsSongAdp = new PhoneSongAdapter(getContext(), PhonsSongList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvPhoneSong.setLayoutManager(mLayoutManager);
        rvPhoneSong.setItemAnimator(new DefaultItemAnimator());
        this.mPhonsSongAdp.Music(new musicInterface());
        rvPhoneSong.setAdapter(mPhonsSongAdp);
        return view;
    }

    class musicInterface implements PhoneSongAdapter.LocalmusicInterface {

        public void a() {
            ((PhoneSongActivity)getActivity()).Getcontent();

        }

        public void a(PhoneSongModel phoneSongModel, int i) {
            PhoneSongAdapter.FirstSelected = phoneSongModel.a();
            ((PhoneSongActivity)getActivity()).Music(phoneSongModel);
            ((PhoneSongActivity)getActivity()).mediacontroler.f();
            if (rvPhoneSong != null && !rvPhoneSong.isComputingLayout()) {
                mPhonsSongAdp.notifyDataSetChanged();
            }
        }
    }
}
