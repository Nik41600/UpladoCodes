package com.wavymusic.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.wavymusic.Model.HorizontalRecycleviewGetSet;
import com.wavymusic.Model.ThemeHorizontalModel;
import com.wavymusic.Model.VerticalModel;
import com.wavymusic.R;
import com.wavymusic.Utils.Utils;
import com.wavymusic.activity.ThemeActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class CategoryVerticalAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int ITEM_TYPE_DATA = 0;
    private static final int ITEM_TYPE_AD = 1;
    CategoryHorizontalViewAdapter themeitemAdp;
    private int Vertical_Position;
    private HashMap<Integer, HorizontalRecycleviewGetSet> HorizontalRecycleHashmap;
    private HashMap<Integer, CategoryHorizontalViewAdapter> HorizontalAdapterHashmap;
    private Context mContext;
    private ArrayList<VerticalModel> categoryList;

    public CategoryVerticalAdapter(Context mContext, ArrayList<VerticalModel> mArrayList) {
        this.mContext = mContext;
        this.categoryList = mArrayList;
        HorizontalRecycleHashmap = new HashMap<>();
        HorizontalAdapterHashmap = new HashMap<>();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        if (viewType == ITEM_TYPE_AD) {
//            return new NativeAdViewHolder((NativeAdLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.native_ad_item, parent, false));
//        } else {
//            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item_categorie_vertical, parent, false);
//            return new VerticalRecyclerViewHolder(v);
//        }

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_theme_vertical, parent, false);
        return new VerticalRecyclerViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        HorizontalRecycleviewGetSet horizontalRecycleviewGetSet = new HorizontalRecycleviewGetSet();
        VerticalRecyclerViewHolder categoryViewHolder = (VerticalRecyclerViewHolder) holder;
        Vertical_Position = position;
        final VerticalModel catModel = categoryList.get(position);
        ArrayList<ThemeHorizontalModel> singleSectionItems = catModel.getArrayList();
        categoryViewHolder.ivCatThumb.setImageResource(Utils.INSTANCE.CatThumb(catModel.getName()));
        categoryViewHolder.tvTitle.setText(categoryList.get(position).getName());

        themeitemAdp = new CategoryHorizontalViewAdapter(mContext, singleSectionItems, Vertical_Position);
        categoryViewHolder.rvHorizontal.setHasFixedSize(true);
        categoryViewHolder.rvHorizontal.setLayoutManager(new LinearLayoutManager(mContext,
                LinearLayoutManager.HORIZONTAL, false));
        HorizontalAdapterHashmap.put(position, themeitemAdp);
        categoryViewHolder.rvHorizontal.setAdapter(themeitemAdp);
        categoryViewHolder.rvHorizontal.setNestedScrollingEnabled(false);
        horizontalRecycleviewGetSet.setHorizontalRecyclerview(categoryViewHolder.rvHorizontal);
        HorizontalRecycleHashmap.put(position, horizontalRecycleviewGetSet);

        categoryViewHolder.tvMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ThemeActivity.class);
                intent.putExtra("CatName", catModel.getName());
                intent.putExtra("CatId", catModel.getCategoryId());
                mContext.startActivity(intent);
                ((Activity) mContext).finish();
            }
        });
    }

    public void setList(ArrayList<VerticalModel> mArrayList) {
        this.categoryList.addAll(mArrayList);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if ((position > 0) && ((position + 1) % 3 == 0)) {
            return ITEM_TYPE_AD;
        }
        return ITEM_TYPE_DATA;
    }

    public class VerticalRecyclerViewHolder extends RecyclerView.ViewHolder {

        public RecyclerView rvHorizontal;
        TextView tvTitle;
        TextView tvMore;
        private ImageView ivCatThumb;

        public VerticalRecyclerViewHolder(View itemView) {
            super(itemView);
            rvHorizontal = itemView.findViewById(R.id.rvHorizontal);
            ivCatThumb = itemView.findViewById(R.id.iv_cat_thumb);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvMore = itemView.findViewById(R.id.tvMore);

        }
    }
}
