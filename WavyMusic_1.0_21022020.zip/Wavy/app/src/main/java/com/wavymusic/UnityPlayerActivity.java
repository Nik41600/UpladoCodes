package com.wavymusic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.wavymusic.Utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.unity3d.player.UnityPlayer;


public class UnityPlayerActivity extends Activity {
    private static final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    public static UnityPlayer mUnityPlayer; // don't change the name of this variable; referenced from native code
    public static LinearLayout layoutAdView;
    public static InterstitialAd mInterstitialAd;
    public static AlertDialog alertDialog;
//        private LinearLayout adContainer;
    public static String m;
    public static String n;
    public static UnityPlayerActivity l;
//    public RewardedVideoAd mRewardedVideoAd;
    Activity activity = UnityPlayerActivity.this;
    int AdsCount = 0;
    AdRequest adRequest;
    AdView adView;
    private boolean v = false;
    private boolean w = false;
    private boolean x = false;
    private boolean B;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View view;
        int systemUiVisibility;
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) {
            view = this.getWindow().getDecorView();
            systemUiVisibility = 8;
        } else {
            if (Build.VERSION.SDK_INT < 19) {
            }
            view = this.getWindow().getDecorView();
            systemUiVisibility = 4102;
        }
        view.setSystemUiVisibility(systemUiVisibility);
        this.getWindow().setFlags(1024, 1024);
        super.onCreate(savedInstanceState);
        getWindow().setFormat(PixelFormat.RGBX_8888); // <--- This makes xperia play happy
        l = this;
        if (mInterstitialAd != null) {
            mInterstitialAd = null;
        }
        mInterstitialAd = new InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                mInterstitialAd = null;
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                AdsCount++;
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                if (mInterstitialAd != null) {
                    mInterstitialAd = null;
                }
                if (AdsCount <= 2) {
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                }

            }
        });
        mUnityPlayer = new UnityPlayer(this);
        setContentView(R.layout.unity_ui);
        ((FrameLayout) findViewById(R.id.layout_unity_main)).addView(mUnityPlayer, 0);
        layoutAdView = findViewById(R.id.llBanner_unity);
        mUnityPlayer.requestFocus();
//        BannerAds();
    }

    public void PremissionFromSetting(UnityPlayerActivity unityPlayerActivity) {
        unityPlayerActivity.x = true;
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", unityPlayerActivity.getPackageName(), null);
        intent.setData(uri);
        unityPlayerActivity.startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
    }

    private void RequestPermission(boolean z) {
        if ((ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            Utils.CreateDirectory();
//            AppGeneral.loadFFMpeg(activity);
        } else if (z) {
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
            alertDialogBuilder.setTitle("Necessary permission");
            alertDialogBuilder.setMessage("Allow Required Permission");
            alertDialogBuilder.setCancelable(false);
            alertDialogBuilder.setPositiveButton("Settings",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            PremissionFromSetting(UnityPlayerActivity.this);
                        }
                    });

            alertDialogBuilder.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            alertDialog = alertDialogBuilder.create();
            alertDialog.show();

        } else {
            ActivityCompat.requestPermissions(activity, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, EXTERNAL_STORAGE_PERMISSION_CONSTANT);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Utils.CreateDirectory();
//                AppGeneral.loadFFMpeg(activity);
            }
        }
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        if (i == EXTERNAL_STORAGE_PERMISSION_CONSTANT) {
            if (iArr.length > 0 && iArr[0] != 0 && iArr[0] == -1 && !ActivityCompat.shouldShowRequestPermissionRationale(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                this.v = true;
                RequestPermission(true);
            }
        }
    }
//
//    public void loadRewardedVideo() {
//        mRewardedVideoAd = MobileAds.getRewardedVideoAdInstance(this);
//        mRewardedVideoAd.loadAd(getResources().getString(R.string.RewardedVideo), new AdRequest.Builder().build());
//        mRewardedVideoAd.setRewardedVideoAdListener(new RewardedVideoAdListener() {
//            @Override
//            public void onRewarded(RewardItem rewardItem) {
//                B = true;
//            }
//
//            @Override
//            public void onRewardedVideoAdLoaded() {
//            }
//
//            @Override
//            public void onRewardedVideoAdOpened() {
//            }
//
//            @Override
//            public void onRewardedVideoStarted() {
//            }
//
//            @Override
//            public void onRewardedVideoAdClosed() {
//                if (B) {
//                    String str = "";
//                    String str2 = "";
//                    B = false;
//                    if (UnityPlayerActivity.n.equalsIgnoreCase("0")) {
//                        str = "UnlockParticle";
////                        str = "GameManager";
//                        str2 = "UnloackParticalsFromAndroid";
//                    } else if (UnityPlayerActivity.n.equalsIgnoreCase("1")) {
//                        str = "UnlockTransaction";
////                        str = "GameManager";
//                        str2 = "UnlockTransactionFromAndroid";
//                    }
//                    UnityPlayer.UnitySendMessage(str, str2, UnityPlayerActivity.m);
//                }
//                i();
//            }
//
//            @Override
//            public void onRewardedVideoAdLeftApplication() {
//            }
//
//            @Override
//            public void onRewardedVideoAdFailedToLoad(int i) {
//            }
//
//            @Override
//            public void onRewardedVideoCompleted() {
//
//            }
//        });
//
//    }
//
//    public final void i() {
//        mRewardedVideoAd.loadAd(getResources().getString(R.string.RewardedVideo), new AdRequest.Builder().build());
//    }
//
    private void BannerAds() {
        adView = findViewById(R.id.adView);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }


    // Quit Unity
    @Override
    protected void onDestroy() {
        final InterstitialAd u = mInterstitialAd;
//        this.adView.removeView(this.adView);
//        AdView adView = this.adView;
//        if (adView != null) {
//            adView.destroy();
//            this.adView = null;
//        }
        mUnityPlayer.quit();
        super.onDestroy();
    }


    // Pause Unity
    @Override
    protected void onPause() {
        super.onPause();
        mUnityPlayer.pause();
//        mRewardedVideoAd.pause(this);
    }

    // Resume Unity
    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT < 23) {
            Utils.CreateDirectory();
//            AppGeneral.loadFFMpeg(this);
        } else if (!this.v || this.w) {
            this.w = false;
            this.x = false;
            RequestPermission(false);
        }
        if (this.x) {
            this.w = true;
        }
        mUnityPlayer.resume();
    }

    // This ensures the layout will be correct.
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mUnityPlayer.configurationChanged(newConfig);
    }

    // Notify Unity of the focus change.
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        mUnityPlayer.windowFocusChanged(hasFocus);
    }

    // For some reason the multiple keyevent type is not supported by the ndk.
    // Force event injection by overriding dispatchKeyEvent().
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_MULTIPLE)
            return mUnityPlayer.injectEvent(event);
        return super.dispatchKeyEvent(event);
    }

    // Pass any events not handled by (unfocused) views straight to UnityPlayer
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }

    /*API12*/
    public boolean onGenericMotionEvent(MotionEvent event) {
        return mUnityPlayer.injectEvent(event);
    }
}
