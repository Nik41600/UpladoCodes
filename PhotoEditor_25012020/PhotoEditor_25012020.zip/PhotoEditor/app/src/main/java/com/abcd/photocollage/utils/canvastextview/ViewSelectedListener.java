package com.abcd.photocollage.utils.canvastextview;

public interface ViewSelectedListener
{
  void setSelectedView(final CanvasTextView p0);
}
