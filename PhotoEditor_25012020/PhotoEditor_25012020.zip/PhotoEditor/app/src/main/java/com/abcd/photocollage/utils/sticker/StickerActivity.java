package com.abcd.photocollage.utils.sticker;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.DrawerLayout.SimpleDrawerListener;
import android.support.v7.app.AlertDialog.Builder;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.shyamsoft.photoeditor.R;

import java.util.ArrayList;

public class StickerActivity extends FragmentActivity implements OnItemClickListener {
    int ae = 0;
    float aFloat = 0.0f;
    ListView listView;
    OnClickListener onClickListener = new OnClickListener() {
        public final void onClick(View view) {
            if (view.getId() == R.id.textView_header) {
                StickerActivity.this.b();
            }
        }
    };
    ArrayList<Integer> arrayList = new ArrayList();
    Animation animation;
    Animation animation1;
    StickerGridItem[][] stickerGridItems;
    ImageView imageView;
    int anInt = 0;
    Activity activity;
    int anInt1 = 0;
    DrawerLayout drawerLayout;
    public StickerGalleryFragment.StickerGalleryListener f;
    StickerGridAdapter stickerGridAdapter;
    GridView gridView;
    TextView textView;

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (this.anInt + this.arrayList.size() >= 25) {
            Builder builder = new Builder(this);
            builder.setMessage((int) R.string.sticker_choose_limit);
            builder.setPositiveButton((CharSequence) "OK", new DialogInterface.OnClickListener() {
                public final void onClick(DialogInterface dialogInterface, int i) {
                }
            });
            builder.create().show();
            return;
        }
        int i2 = 0;
        if (this.stickerGridAdapter.stickerGridItems[i].anInt1 == 0) {
            StickerGridItem stickerGridItem = this.stickerGridAdapter.stickerGridItems[i];
            stickerGridItem.anInt1++;
        } else {
            this.stickerGridAdapter.stickerGridItems[i].anInt1 = 0;
        }
        ImageView imageView = (ImageView) view.findViewById(R.id.image_view_item_selected);
        if (imageView.getVisibility() == View.INVISIBLE && this.stickerGridAdapter.stickerGridItems[i].anInt1 == 1) {
            imageView.setVisibility(View.VISIBLE);
        }
        if (imageView.getVisibility() == View.VISIBLE && this.stickerGridAdapter.stickerGridItems[i].anInt1 == 0) {
            imageView.setVisibility(View.INVISIBLE);
        }
        int i3 = this.stickerGridAdapter.stickerGridItems[i].anInt;
        if (this.stickerGridAdapter.stickerGridItems[i].anInt1 == 1) {
            this.arrayList.add(Integer.valueOf(i3));
        } else {
            while (i2 < this.arrayList.size()) {
                if (((Integer) this.arrayList.get(i2)).intValue() == i3) {
                    this.arrayList.remove(i2);
                    break;
                }
                i2++;
            }
        }
        TextView textView = this.textView;
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this.anInt + this.arrayList.size());
        stringBuilder2.append(" ");
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append(getString(R.string.sticker_items_selected));
        textView.setText(stringBuilder.toString());
    }

    private void S() {
        int length = Utility.f73a.length;
        this.stickerGridItems = new StickerGridItem[length][];
        for (int i = 0; i < length; i++) {
            int length2 = Utility.f73a[i].length;
            this.stickerGridItems[i] = new StickerGridItem[length2];
            for (int i2 = 0; i2 < length2; i2++) {
                this.stickerGridItems[i][i2] = new StickerGridItem(Utility.f73a[i][i2]);
            }
        }
    }

    public final void b() {
        if (this.drawerLayout.isDrawerOpen(this.listView)) {
            int length = this.stickerGridItems.length;
            this.drawerLayout.closeDrawer(this.listView);
            return;
        }
        finish();
        this.drawerLayout.closeDrawer(this.listView);
    }

    public final void c() {
        int[] iArr = new int[2];
        this.imageView.getLocationOnScreen(iArr);
        this.ae = this.imageView.getWidth() + iArr[0];
        StringBuilder stringBuilder = new StringBuilder("initialTogglePos ");
        stringBuilder.append(this.ae);
        Log.e("GalleryActivity", stringBuilder.toString());
    }

    public final void StickerGalleryFragment(Activity activity) {
        this.activity = activity;
    }

    private boolean isOnline() {
        try {
            return ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo().isConnectedOrConnecting();
        } catch (Exception unused) {
            return false;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().addFlags(1024);
        setContentView(R.layout.sticker_fragment_gallery);
        this.textView = (TextView) findViewById(R.id.textView_header);
        this.textView.setOnClickListener(this.onClickListener);
        ((ImageButton) findViewById(R.id.sticker_gallery_ok)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                final StickerGridItem[][] am = StickerActivity.this.stickerGridItems;
                final int n = 0;
                for (int length = am.length, i = 0; i < length; ++i) {
                    final StickerGridItem[] array = StickerActivity.this.stickerGridItems[i];
                    for (int length2 = array.length, j = 0; j < length2; ++j) {
                        array[j].anInt1 = 0;
                    }
                }
                final int size = StickerActivity.this.arrayList.size();
                final int[] array2 = new int[size];
                for (int k = n; k < size; ++k) {
                    array2[k] = StickerActivity.this.arrayList.get(k);
                }
                StickerActivity.this.arrayList.clear();
                final Intent intent = new Intent();
                final Bundle bundle = new Bundle();
                bundle.putIntArray("MyArray", array2);
                intent.putExtras(bundle);
                StickerActivity.this.setResult(-1, intent);
                StickerActivity.this.finish();
            }
        });
        this.imageView = (ImageView) findViewById(R.id.toggle_button);
        this.animation = AnimationUtils.loadAnimation(this, R.anim.slide_in_left_galler_toggle);
        this.animation1 = AnimationUtils.loadAnimation(this, R.anim.slide_out_left_gallery_toggle);
        this.animation.setFillAfter(true);
        this.animation1.setFillAfter(true);
        this.gridView = (GridView) findViewById(R.id.gridView);
        S();
        this.stickerGridAdapter = new StickerGridAdapter(this, this.stickerGridItems[0], this.gridView);
        this.gridView.setAdapter(this.stickerGridAdapter);
        this.gridView.setOnItemClickListener(this);
        if (this.drawerLayout != null) {
            this.drawerLayout.postDelayed(new Runnable() {
                public final void run() {
                    StickerActivity.this.drawerLayout.closeDrawer(StickerActivity.this.listView);
                }
            }, 600);
        }
        this.imageView.setOnTouchListener(new OnTouchListener() {
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                StickerActivity.this.drawerLayout.openDrawer(StickerActivity.this.listView);
                return true;
            }
        });
        this.imageView.post(new Runnable() {
            public final void run() {
                StickerActivity.this.c();
            }
        });
        NavigationDrawerListAdapter navigationDrawerListAdapter = new NavigationDrawerListAdapter(this);
        this.drawerLayout = (DrawerLayout) findViewById(R.id.layout_gallery_fragment_drawer);
        this.listView = (ListView) findViewById(R.id.drawer);
        this.listView.setAdapter(navigationDrawerListAdapter);
        this.listView.setItemChecked(0, true);
        this.listView.setOnItemClickListener(new OnItemClickListener() {
            public final void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                StickerActivity.this.drawerLayout.closeDrawer(StickerActivity.this.listView);
                if (StickerActivity.this.anInt1 != i) {
                    StickerActivity.this.S();
                    StickerActivity.this.stickerGridAdapter.stickerGridItems = StickerActivity.this.stickerGridItems[i];
                    StickerActivity.this.gridView.smoothScrollToPosition(i);
                    StickerActivity.this.stickerGridAdapter.notifyDataSetChanged();
                }
                StickerActivity.this.anInt1 = i;
            }
        });
        this.drawerLayout.setDrawerListener(new SimpleDrawerListener() {
            public void onDrawerClosed(View view) {
            }

            public void onDrawerOpened(View view) {
            }

            public void onDrawerStateChanged(int i) {
            }

            public void onDrawerSlide(View view, float f) {
                if (StickerActivity.this.ae <= 0) {
                    StickerActivity.this.c();
                }
                StickerActivity.this.aFloat = (-f) * ((float) StickerActivity.this.ae);
                if (VERSION.SDK_INT >= 11) {
                    StickerActivity.this.imageView.setX(StickerActivity.this.aFloat);
                }
            }
        });
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}