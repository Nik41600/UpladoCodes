package com.abcd.photocollage.utils.canvastextview;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.support.v7.app.AlertDialog.Builder;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.abcd.photocollage.utils.canvastextview.CustomRelativeLayout.RemoveTextListener;
import com.shyamsoft.photoeditor.R;

public class CanvasTextView extends View {
    static final float MIN_ZOOM = 0.8f;
    private static final String TAG = "CanvasTextView";
    float actualRadius = this.padding;
    ApplyTextInterface applyListener;
    Paint bitmapPaint = new Paint(1);
    float bitmapWidth;
    PointF center = new PointF();
    float circlePadding = 5.0f;
    GestureDetector gestureDetector;
    Matrix identityMatrix = new Matrix();
    Matrix inverse = new Matrix();
    boolean isInCircle = false;
    boolean isOnRect = false;
    boolean isOnTouch = false;
    float padding = 30.0f;
    float paddingWidth = 10.0f;
    PointF previosPos = new PointF();
    float[] pts = new float[2];
    float radius = 40.0f;
    private RectF rect;
    Paint rectPaint;
    Paint rectPaintOnTouch;
    Paint redPaint = new Paint(1);
    Bitmap removeBitmap;
    Matrix removeBitmapMatrix = new Matrix();
    RemoveTextListener removeTextListener;
    float scale = 1.0f;
    Bitmap scaleBitmap;
    Matrix scaleBitmapMatrix = new Matrix();
    SingleTapInterface singleTapListener;
    PointF start = new PointF();
    private double startAngle = 0.0d;
    Matrix startMatrix = new Matrix();
    Rect textBoundrect;
    TextDataItem textData;
    private boolean textSelected = false;
    float[] values = new float[9];
    ViewSelectedListener viewSelectedListener;
    Paint whitePaint = new Paint(1);
    PointF zoomStart = new PointF();

    private class GestureListener extends SimpleOnGestureListener {
        private GestureListener() {
        }

        public boolean onDown(MotionEvent motionEvent) {
            if (CanvasTextView.this.isInCircle || CanvasTextView.this.isOnRect) {
                return true;
            }
            CanvasTextView.this.textSelected = false;
            return false;
        }

        public boolean onSingleTapUp(MotionEvent motionEvent) {
            Log.d("Single Tap", "Tapped at");
            CanvasTextView.this.pts[0] = motionEvent.getX();
            CanvasTextView.this.pts[1] = motionEvent.getY();
            CanvasTextView.this.textData.canvasMatrix.invert(CanvasTextView.this.inverse);
            CanvasTextView.this.inverse.mapPoints(CanvasTextView.this.pts, CanvasTextView.this.pts);
            CanvasTextView.this.isOnRect = CanvasTextView.this.isOnRect(CanvasTextView.this.pts[0], CanvasTextView.this.pts[1]);
            if (CanvasTextView.this.isOnRect) {
                Log.d("textSelected", "single Tapped at");
                CanvasTextView.this.textSelected = true;
                CanvasTextView.this.singleTapped();
            } else {
                CanvasTextView.this.textSelected = false;
            }
            if (CanvasTextView.this.isInCircle || CanvasTextView.this.isOnRect) {
                return true;
            }
            return false;
        }

        public boolean onDoubleTap(MotionEvent motionEvent) {
            CanvasTextView.this.pts[0] = motionEvent.getX();
            CanvasTextView.this.pts[1] = motionEvent.getY();
            CanvasTextView.this.textData.canvasMatrix.invert(CanvasTextView.this.inverse);
            CanvasTextView.this.inverse.mapPoints(CanvasTextView.this.pts, CanvasTextView.this.pts);
            CanvasTextView.this.isOnRect = CanvasTextView.this.isOnRect(CanvasTextView.this.pts[0], CanvasTextView.this.pts[1]);
            if (CanvasTextView.this.isOnRect) {
                CanvasTextView.this.textSelected = true;
                CanvasTextView.this.singleTapped();
            } else {
                CanvasTextView.this.textSelected = false;
            }
            return true;
        }
    }

    public void setTextSelected(boolean z) {
        this.textSelected = z;
        postInvalidate();
    }

    public boolean getTextSelected() {
        return this.textSelected;
    }

    public void setApplyInterface(ApplyTextInterface applyTextInterface) {
        this.applyListener = applyTextInterface;
    }

    public void setRemoveTextListener(RemoveTextListener removeTextListener) {
        this.removeTextListener = removeTextListener;
    }

    public CanvasTextView(Context context, TextDataItem textDataItem, Bitmap bitmap, Bitmap bitmap2) {
        super(context);
        Context context2 = context;
        TextDataItem textDataItem2 = textDataItem;
        float dimension = context.getResources().getDimension(R.dimen.myFontSize);
        float f = (float) getResources().getDisplayMetrics().widthPixels;
        float f2 = (float) getResources().getDisplayMetrics().heightPixels;
        this.rectPaint = new Paint(1);
        this.rectPaint.setColor(2011028957);
        this.redPaint.setColor(getResources().getColor(R.color.red));
        this.whitePaint.setColor(getResources().getColor(R.color.text_white));
        this.bitmapPaint.setFilterBitmap(true);
        this.rectPaintOnTouch = new Paint(1);
        this.rectPaintOnTouch.setColor(2011028957);
        this.textBoundrect = new Rect();
        if (textDataItem2 == null) {
            this.textData = new TextDataItem(dimension);
            this.textData.textPaint.getTextBounds(TextDataItem.defaultMessage, 0, TextDataItem.defaultMessage.length(), this.textBoundrect);
            this.textData.xPos = (f / 2.0f) - ((float) (this.textBoundrect.width() / 2));
            this.textData.yPos = f2 / 3.0f;
        } else {
            this.textData = textDataItem2;
            if (this.textData.getFontPath() != null) {
                Typeface typeface = FontCache.get(context2, this.textData.getFontPath());
                if (typeface != null) {
                    this.textData.textPaint.setTypeface(typeface);
                }
            }
            this.textData.textPaint.getTextBounds(this.textData.message, 0, this.textData.message.length(), this.textBoundrect);
        }
        this.rect = new RectF(this.textData.xPos - this.paddingWidth, (this.textData.yPos - ((float) this.textBoundrect.height())) - this.padding, (this.textData.xPos + ((float) this.textBoundrect.width())) + (this.paddingWidth * 2.0f), this.textData.yPos + this.padding);
        this.gestureDetector = new GestureDetector(context2, new GestureListener());
        this.actualRadius = f / 20.0f;
        this.circlePadding = this.actualRadius / 2.0f;
        if (this.actualRadius <= 5.0f) {
            this.actualRadius = this.padding;
        }
        this.removeBitmap = bitmap;
        this.scaleBitmap = bitmap2;
        this.bitmapWidth = (float) this.removeBitmap.getWidth();
        this.removeBitmapMatrix.reset();
        this.scaleBitmapMatrix.reset();
        float f3 = (this.actualRadius * 2.0f) / this.bitmapWidth;
        this.removeBitmapMatrix.postScale(f3, f3);
        this.removeBitmapMatrix.postTranslate(this.rect.left - ((this.bitmapWidth * f3) / 2.0f), this.rect.top - ((this.bitmapWidth * f3) / 2.0f));
        this.scaleBitmapMatrix.postScale(f3, f3);
        this.scaleBitmapMatrix.postTranslate(this.rect.right - ((this.bitmapWidth * f3) / 2.0f), this.rect.bottom - ((this.bitmapWidth * f3) / 2.0f));
        this.scale = getScale();
        this.scaleBitmapMatrix.postScale(1.0f / this.scale, 1.0f / this.scale, this.rect.right, this.rect.bottom);
        this.removeBitmapMatrix.postScale(1.0f / this.scale, 1.0f / this.scale, this.rect.left, this.rect.top);
    }

    public void setMatrix(CustomMatrix customMatrix) {
        this.textData.canvasMatrix = customMatrix;
        this.scale = getScale();
    }

    public void onDraw(Canvas canvas) {
        canvas.setMatrix(this.textData.canvasMatrix);
        if (this.textSelected) {
            if (this.isOnTouch) {
                canvas.drawRect(this.rect, this.rectPaintOnTouch);
            } else {
                canvas.drawRect(this.rect, this.rectPaint);
            }
            float f = this.actualRadius / this.scale;
            canvas.drawCircle(this.rect.right, this.rect.bottom, f, this.whitePaint);
            canvas.drawCircle(this.rect.left, this.rect.top, f, this.redPaint);
            canvas.drawBitmap(this.scaleBitmap, this.scaleBitmapMatrix, this.bitmapPaint);
            canvas.drawBitmap(this.removeBitmap, this.removeBitmapMatrix, this.bitmapPaint);
        }
        Log.e("message", this.textData.message);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.textData.xPos);
        Log.e("X", stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.textData.yPos);
        Log.e("Y", stringBuilder.toString());
        canvas.drawText(this.textData.message, this.textData.xPos, this.textData.yPos, this.textData.textPaint);
    }


    public void singleTapped() {
        this.singleTapListener.onSingleTap(this.textData);
    }

    public void setTextColor(int i) {
        this.textData.textPaint.setColor(i);
        postInvalidate();
    }

    public void setNewTextData(TextDataItem textDataItem) {
        this.textData = textDataItem;
        float f = this.rect.right;
        this.rect.right = (this.rect.left + textDataItem.textPaint.measureText(textDataItem.message)) + (2.0f * this.paddingWidth);
        this.scaleBitmapMatrix.postTranslate(this.rect.right - f, 0.0f);
        postInvalidate();
    }

    public boolean isOnRect(float f, float f2) {
        if (f <= this.rect.left || f >= this.rect.right || f2 <= this.rect.top || f2 >= this.rect.bottom) {
            return false;
        }
        this.textSelected = true;
        return true;
    }

    public boolean isInCircle(float f, float f2) {
        if (((f - this.rect.right) * (f - this.rect.right)) + ((f2 - this.rect.bottom) * (f2 - this.rect.bottom)) >= (this.radius * this.radius) / (this.scale * this.scale)) {
            return false;
        }
        this.textSelected = true;
        return true;
    }
    public boolean isOnCross(float f, float f2) {
        if (((f - this.rect.left) * (f - this.rect.left)) + ((f2 - this.rect.top) * (f2 - this.rect.top)) >= ((this.actualRadius + this.circlePadding) * (this.actualRadius + this.circlePadding)) / (this.scale * this.scale)) {
            return false;
        }
        Log.e(TAG, "isOncross");
        this.textSelected = true;
        return true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        switch (motionEvent.getAction()) {
            case 0:
                this.isOnTouch = true;
                this.pts[0] = x;
                this.pts[1] = y;
                this.textData.canvasMatrix.invert(this.inverse);
                this.inverse.mapPoints(this.pts, this.pts);
                if (!(this.textSelected && isOnCross(this.pts[0], this.pts[1]))) {
                    this.isOnRect = isOnRect(this.pts[0], this.pts[1]);
                    this.isInCircle = isInCircle(this.pts[0], this.pts[1]);
                    this.start.set(x, y);
                    this.previosPos.set(x, y);
                    this.zoomStart.set(x, y);
                    this.pts[0] = this.rect.centerX();
                    this.pts[1] = this.rect.centerY();
                    this.textData.canvasMatrix.mapPoints(this.pts, this.pts);
                    this.startAngle = (double) (-pointToAngle(x, y, this.pts[0], this.pts[1]));
                    this.startMatrix.set(this.textData.canvasMatrix);
                    if (this.isInCircle || this.isOnRect) {
                        this.viewSelectedListener.setSelectedView(this);
                        break;
                    }
                }
                if (!this.textSelected || !isOnCross(this.pts[0], this.pts[1])) {
                    return false;
                }
                createDeleteDialog(getContext(), this);
                return true;
            case 1:
                this.isOnTouch = false;
                this.isOnRect = false;
                break;
            case 2:
                if (!this.isInCircle && this.isOnRect) {
                    this.textData.canvasMatrix.set(this.startMatrix);
                    this.textData.canvasMatrix.postTranslate(x - this.previosPos.x, y - this.previosPos.y);
                    break;
                }
                double d = (double) ((float) (-pointToAngle(x, y, this.pts[0], this.pts[1])));
                this.textData.canvasMatrix.postRotate((float) (this.startAngle - d), this.pts[0], this.pts[1]);
                this.startAngle = d;
                float sqrt = ((float) Math.sqrt((double) (((x - this.pts[0]) * (x - this.pts[0])) + ((y - this.pts[1]) * (y - this.pts[1]))))) / ((float) Math.sqrt((double) (((this.zoomStart.x - this.pts[0]) * (this.zoomStart.x - this.pts[0])) + ((this.zoomStart.y - this.pts[1]) * (this.zoomStart.y - this.pts[1])))));
                this.scale = getScale();
                if (this.scale >= MIN_ZOOM || (this.scale < MIN_ZOOM && sqrt > 1.0f)) {
                    this.textData.canvasMatrix.postScale(sqrt, sqrt, this.pts[0], this.pts[1]);
                    this.zoomStart.set(x, y);
                    this.scale = getScale();
                    float f = 1.0f / sqrt;
                    this.scaleBitmapMatrix.postScale(f, f, this.rect.right, this.rect.bottom);
                    this.removeBitmapMatrix.postScale(f, f, this.rect.left, this.rect.top);
                    break;
                }
                break;
        }
        postInvalidate();
        return this.gestureDetector.onTouchEvent(motionEvent);
    }

    public void createDeleteDialog(Context context, final View view) {
        Builder builder = new Builder(context);
        builder.setMessage((int) R.string.collage_lib_delete_message).setCancelable(true).setPositiveButton(context.getString(17039379), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                CanvasTextView.this.deleteView(view);
            }
        }).setNegativeButton(context.getString(17039369), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }

    public void deleteView(View view) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
            this.removeTextListener.onRemove();
        }
    }

    public float getScale() {
        this.textData.canvasMatrix.getValues(this.values);
        float f = this.values[0];
        float f2 = this.values[3];
        return (float) Math.sqrt((double) ((f * f) + (f2 * f2)));
    }

    public void setSingleTapListener(SingleTapInterface singleTapInterface) {
        this.singleTapListener = singleTapInterface;
    }

    public void setViewSelectedListener(ViewSelectedListener viewSelectedListener) {
        this.viewSelectedListener = viewSelectedListener;
    }

    private int pointToAngle(float f, float f2, float f3, float f4) {
        if (f >= f3 && f2 < f4) {
            return ((int) Math.toDegrees(Math.atan(((double) (f - f3)) / ((double) (f4 - f2))))) + 270;
        }
        if (f > f3 && f2 >= f4) {
            return (int) Math.toDegrees(Math.atan(((double) (f2 - f4)) / ((double) (f - f3))));
        }
        if (f <= f3 && f2 > f4) {
            return ((int) Math.toDegrees(Math.atan(((double) (f3 - f)) / ((double) (f2 - f4))))) + 90;
        }
        if (f < f3 && f2 <= f4) {
            return ((int) Math.toDegrees(Math.atan(((double) (f4 - f2)) / ((double) (f3 - f))))) + 180;
        }
        throw new IllegalArgumentException();
    }
}