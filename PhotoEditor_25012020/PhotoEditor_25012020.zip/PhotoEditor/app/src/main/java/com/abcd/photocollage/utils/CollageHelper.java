package com.abcd.photocollage.utils;

import com.google.android.gms.ads.*;
import android.view.*;
import com.abcd.photocollage.fragments.*;
import android.support.v4.app.*;
import com.abcd.photocollage.activities.*;
import android.content.*;

public class CollageHelper
{
    protected static final String TAG = "CollageHelper";

    public static FragmentSelectImage addGalleryFragment(final FragmentActivity fragmentActivity, final int n, final InterstitialAd interstitialAd, final boolean b, final View view) {
        final FragmentManager supportFragmentManager = fragmentActivity.getSupportFragmentManager();
        final FragmentSelectImage fragmentSelectImage = (FragmentSelectImage)supportFragmentManager.findFragmentByTag("myFragmentTag");
        if (fragmentSelectImage == null) {
            final FragmentSelectImage fragmentSelectImage2 = new FragmentSelectImage();
            final FragmentTransaction beginTransaction = supportFragmentManager.beginTransaction();
            beginTransaction.add(n, fragmentSelectImage2, "myFragmentTag");
            beginTransaction.commitAllowingStateLoss();
            fragmentSelectImage2.GalleryListener(createGalleryListener(fragmentActivity, fragmentSelectImage2, interstitialAd, b, view));
            fragmentActivity.findViewById(n).bringToFront();
            return fragmentSelectImage2;
        }
        fragmentActivity.getSupportFragmentManager().beginTransaction().show(fragmentSelectImage).commitAllowingStateLoss();
        return fragmentSelectImage;
    }

    public static FragmentSelectImage.GalleryListener createGalleryListener(final FragmentActivity fragmentActivity, final FragmentSelectImage fragmentSelectImage, final InterstitialAd interstitialAd, final boolean b, final View view) {
        return new FragmentSelectImage.GalleryListener() {
            @Override
            public void onGalleryCancel() {
                if (view != null && view.getVisibility() != View.VISIBLE) {
                    view.setVisibility(View.VISIBLE);
                }
                fragmentActivity.getSupportFragmentManager().beginTransaction().hide(fragmentSelectImage).commitAllowingStateLoss();
            }

            @Override
            public void onGalleryOkImageArray(final long[] array, final int[] array2, final boolean b, final boolean b2) {
                if (view != null && view.getVisibility() != View.VISIBLE) {
                    view.setVisibility(View.VISIBLE);
                }
                final Intent intent = new Intent((Context)fragmentActivity, (Class)CollageActivity.class);
                intent.putExtra("photo_id_list", array);
                intent.putExtra("photo_orientation_list", array2);
                intent.putExtra("is_scrap_book", b);
                intent.putExtra("is_shape", b2);
                fragmentActivity.startActivity(intent);
            }

            @Override
            public void onGalleryOkImageArrayRemoveFragment(final long[] array, final int[] array2, final boolean b, final boolean b2) {
            }

            @Override
            public void onGalleryOkSingleImage(final long n, final int n2, final boolean b, final boolean b2) {
            }
        };
    }

    public static FragmentSelectImage getGalleryFragment(final FragmentActivity fragmentActivity) {
        return (FragmentSelectImage)fragmentActivity.getSupportFragmentManager().findFragmentByTag("myFragmentTag");
    }
}
