package com.abcd.photocollage.collagelist;


import java.util.ArrayList;
import java.util.List;

public class CollageLayout
{
  public int[][] exceptionIndexForShapes;
  boolean isScalable;
  public List<MaskPair> maskPairList;
  int porterDuffClearBorderIntex;
  public List shapeList;
  public boolean useLine;

  public CollageLayout() {
    this.useLine = true;
    this.isScalable = false;
    this.porterDuffClearBorderIntex = -1;
    this.exceptionIndexForShapes = null;
    this.maskPairList = new ArrayList<MaskPair>();
  }

  public CollageLayout(final List shapeList) {
    this.useLine = true;
    this.isScalable = false;
    this.porterDuffClearBorderIntex = -1;
    this.exceptionIndexForShapes = null;
    this.maskPairList = new ArrayList<MaskPair>();
    this.shapeList = shapeList;
  }

  public int getClearIndex() {
    return this.porterDuffClearBorderIntex;
  }

  public int[] getexceptionIndex(final int n) {
    if (this.exceptionIndexForShapes != null && n < this.exceptionIndexForShapes.length && n >= 0) {
      return this.exceptionIndexForShapes[n];
    }
    return null;
  }

  public void setClearIndex(final int porterDuffClearBorderIntex) {
    if (porterDuffClearBorderIntex >= 0 && porterDuffClearBorderIntex < this.shapeList.size()) {
      this.porterDuffClearBorderIntex = porterDuffClearBorderIntex;
    }
  }
}
