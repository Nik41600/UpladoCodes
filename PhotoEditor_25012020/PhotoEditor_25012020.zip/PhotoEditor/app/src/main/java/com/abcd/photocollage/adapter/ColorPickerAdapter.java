package com.abcd.photocollage.adapter;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.shyamsoft.photoeditor.R;

import java.util.ArrayList;
import java.util.List;

@SuppressLint({"InflateParams"})
public class ColorPickerAdapter extends RecylceAdapterBase<ColorPickerAdapter.ViewHolder> implements View.OnClickListener {
    private static final String TAG = "Adapter";
    int colorCount;
    int colorDefault;
    private List<Integer> colorList;
    int colorSelected;
    String[] colors;
    CollageAdapter.CurrentCollageIndexChangedListener listener;
    RecyclerView recylceView;
    View selectedListItem;
    int selectedPosition;

    public ColorPickerAdapter(final CollageAdapter.CurrentCollageIndexChangedListener listener, final int colorDefault, final int colorSelected) {
        this.colorCount = 60;
        this.colorList = new ArrayList<Integer>();
        this.colors = new String[]{"#FFFFFF", "#EFDECD", "#CD4A4A", "#CC6666", "#BC5D58", "#FF5349", "#FD5E53", "#FD7C6E", "#FDBCB4", "#FF6E4A", "#FFA089", "#EA7E5D", "#B4674D", "#A5694F", "#FF7538", "#FF7F49", "#DD9475", "#FF8243", "#FFA474", "#9F8170", "#CD9575", "#EFCDB8", "#D68A59", "#DEAA88", "#FAA76C", "#FFCFAB", "#FFBD88", "#FDD9B5", "#FFA343", "#EFDBC5", "#FFB653", "#E7C697", "#8A795D", "#FAE7B5", "#FFCF48", "#FCD975", "#FDDB6D", "#FCE883", "#F0E891", "#ECEABE", "#BAB86C", "#FDFC74", "#FDFC74", "#FFFF99", "#C5E384", "#B2EC5D", "#87A96B", "#A8E4A0", "#1DF914", "#76FF7A", "#71BC78", "#6DAE81", "#9FE2BF", "#1CAC78", "#30BA8F", "#45CEA2", "#3BB08F", "#1CD3A2", "#17806D", "#158078", "#1FCECB", "#78DBE2", "#77DDE7", "#80DAEB", "#414A4C", "#199EBD", "#1CA9C9", "#1DACD6", "#9ACEEB", "#1A4876", "#1974D2", "#2B6CC4", "#1F75FE", "#C5D0E6", "#B0B7C6", "#5D76CB", "#A2ADD0", "#979AAA", "#ADADD6", "#7366BD", "#7442C8", "#7851A9", "#9D81BA", "#926EAE", "#CDA4DE", "#8F509D", "#C364C5", "#FB7EFD", "#FC74FD", "#8E4585", "#FF1DCE", "#FF1DCE", "#FF48D0", "#E6A8D7", "#C0448F", "#6E5160", "#DD4492", "#FF43A4", "#F664AF", "#FCB4D5", "#FFBCD9", "#F75394", "#FFAACC", "#E3256B", "#FDD7E4", "#CA3767", "#DE5D83", "#FC89AC", "#F780A1", "#C8385A", "#EE204D", "#FF496C", "#EF98AA", "#FC6C85", "#FC2847", "#FF9BAA", "#CB4154", "#EDEDED", "#DBD7D2", "#CDC5C2", "#95918C", "#232323"};
        this.listener = listener;
        this.colorDefault = colorDefault;
        this.colorSelected = colorSelected;
        this.createColorList();
    }

    private void createColorList() {
        final String[] colors = this.colors;
        for (int i = 0; i < colors.length; ++i) {
            this.colorList.add(Color.parseColor(colors[i]));
        }
    }

    @Override
    public int getItemCount() {
        return this.colorList.size();
    }

    public void onAttachedToRecyclerView(final RecyclerView recylceView) {
        this.recylceView = recylceView;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int n) {
        viewHolder.setItem(this.colorList.get(n));
        if (this.selectedPosition == n) {
            viewHolder.itemView.setBackgroundColor(this.colorSelected);
            return;
        }
        viewHolder.itemView.setBackgroundColor(this.colorDefault);
    }

    public void onClick(final View selectedListItem) {
        final int childPosition = this.recylceView.getChildPosition(selectedListItem);
        final RecyclerView.ViewHolder viewHolderForPosition = this.recylceView.findViewHolderForPosition(this.selectedPosition);
        if (viewHolderForPosition != null) {
            final View itemView = viewHolderForPosition.itemView;
            if (itemView != null) {
                itemView.setBackgroundColor(this.colorDefault);
            }
        }
        if (this.selectedListItem != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("selectedListItem ");
            sb.append(childPosition);
            Log.d("Adapter", sb.toString());
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("onClick ");
        sb2.append(childPosition);
        Log.d("Adapter", sb2.toString());
        this.listener.onIndexChanged(this.colorList.get(childPosition));
        this.selectedPosition = childPosition;
        selectedListItem.setBackgroundColor(this.colorSelected);
        this.selectedListItem = selectedListItem;
    }

    @Override
    public ViewHolder onCreateViewHolder(final ViewGroup viewGroup, final int n) {
        final View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.color_recycler_view_item, (ViewGroup) null);
        final ViewHolder viewHolder = new ViewHolder(inflate);
        viewHolder.setCurrentCollageIndexChangedListener(this.listener);
        inflate.setOnClickListener((View.OnClickListener) this);
        return viewHolder;
    }

    @Override
    public void setSelectedPositinVoid() {
        this.selectedListItem = null;
        this.selectedPosition = -1;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private static final String TAG = "ViewHolder";
        public View colorPickerView;
        private int item;
        CollageAdapter.CurrentCollageIndexChangedListener viewHolderListener;

        public ViewHolder(final View view) {
            super(view);
            this.colorPickerView = view.findViewById(R.id.color_picker_view);
        }

        public void setCurrentCollageIndexChangedListener(final CollageAdapter.CurrentCollageIndexChangedListener viewHolderListener) {
            this.viewHolderListener = viewHolderListener;
        }

        public void setItem(final int item) {
            this.item = item;
            this.colorPickerView.setBackgroundColor(this.item);
        }
    }
}
