package com.abcd.photocollage.utils.canvastextview;

import android.graphics.*;
import java.io.*;

public class CustomPaint extends Paint implements Serializable
{
  private static final long serialVersionUID = -2455397208601380474L;
  int color;
  float textSize;

  public CustomPaint() {
    super.setAntiAlias(true);
  }

  public CustomPaint(final CustomPaint customPaint) {
    super((Paint)customPaint);
    this.color = customPaint.color;
    this.textSize = customPaint.textSize;
    super.setAntiAlias(true);
  }

  private void readObject(final ObjectInputStream objectInputStream) throws Exception, ClassNotFoundException {
    objectInputStream.defaultReadObject();
    this.color = objectInputStream.readInt();
    this.textSize = objectInputStream.readFloat();
    super.setColor(this.color);
    super.setTextSize(this.textSize);
    super.setAntiAlias(true);
  }

  private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
    objectOutputStream.defaultWriteObject();
    this.color = super.getColor();
    this.textSize = super.getTextSize();
    objectOutputStream.writeInt(this.color);
    objectOutputStream.writeFloat(this.textSize);
  }
}
