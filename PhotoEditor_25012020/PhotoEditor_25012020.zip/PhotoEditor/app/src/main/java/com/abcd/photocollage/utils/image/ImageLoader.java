package com.abcd.photocollage.utils.image;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.shyamsoft.photoeditor.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public class ImageLoader {
    String TAG;
    Context context;
    int count;
    public String filemanagerstring;
    ImageLoaded imageLoadedListener;
    String loadImageMessage;
    public String selectedImagePath;

    public ImageLoader(final Context context) {
        this.TAG = "ImageLoader";
        this.count = 0;
        this.loadImageMessage = "Loading image!";
        this.context = context;
    }

    private boolean checkFileExtension(String lowerCase) {
        lowerCase = this.getFileExtension(lowerCase).toLowerCase();
        return lowerCase.contains("jpg") || lowerCase.contains("png") || lowerCase.contains("jpeg") || lowerCase.contains("gif") || lowerCase.contains("bmp") || lowerCase.contains("webp") || lowerCase.contains("dump");
    }

    private Bitmap getBitmapFromUri(final Uri uri) throws IOException {
        final ParcelFileDescriptor openFileDescriptor = this.context.getContentResolver().openFileDescriptor(uri, "r");
        final Bitmap decodeFileDescriptor = BitmapFactory.decodeFileDescriptor(openFileDescriptor.getFileDescriptor());
        openFileDescriptor.close();
        return decodeFileDescriptor;
    }

    private String getFileExtension(final String s) {
        String s2 = s;
        if (s == null) {
            s2 = "";
        }
        final int lastIndex = s2.lastIndexOf(".");
        if (lastIndex > 0) {
            return s2.substring(lastIndex);
        }
        return "";
    }

    public static boolean isDownloadsDocument(final Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(final Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(final Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(final Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    private String saveImageToTemp(final Bitmap bitmap) throws FileNotFoundException {
        final StringBuilder sb = new StringBuilder(String.valueOf(ImageUtility.getPrefferredDirectoryPath(this.context, false, true, false)));
        sb.append("temp/dump.dump");
        final String string = sb.toString();
        final File file = new File(string);
        file.getParentFile().mkdirs();
        final String tag = this.TAG;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("resultPath ");
        sb2.append(string);
        Log.i(tag, sb2.toString());
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, (OutputStream) new FileOutputStream(string));
        bitmap.recycle();
        final String tag2 = this.TAG;
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("is file exist ");
        sb3.append(file.exists());
        Log.i(tag2, sb3.toString());
        return string;
    }

    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                String path = cursor.getString(index);
                //[BUGFIX]-Add by TCTNJ,chuang.wang, 2014-07-12,PR728605 Begin
                if (path != null && path.endsWith("RAW")) {
                    //[BUGFIX]-Add by TCTNJ,chuang.wang, 2014-07-12,PR728605 END
                    List<String> segments = uri.getPathSegments();
                    String dbName = segments.get(0);
                    String id = segments.get(1);
                    path = context.getDatabasePath(dbName + "_att") + "/" + id;
                }
                return path;
            }
        } catch (Exception e) {
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    public void getImageFromIntent(final Intent intent) {
        Uri data;
        if ((data = intent.getData()) == null) {
            data = (Uri) intent.getExtras().get("android.intent.extra.STREAM");
        }
        if (Build.VERSION.SDK_INT < 19) {
            this.selectedImagePath = this.getRealPathFromURI(context, data);
            final String tag = this.TAG;
            final StringBuilder sb = new StringBuilder();
            sb.append("getImageFromIntent selectedImagePath  ");
            sb.append(this.selectedImagePath);
            Log.e(tag, sb.toString());
            this.startActivityFromUri(data);
            return;
        }
        this.selectedImagePath = this.getPathForKitKat(data);
        final String tag2 = this.TAG;
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("getPathForKitKat ");
        sb2.append(this.selectedImagePath);
        Log.w(tag2, sb2.toString());
        if (this.selectedImagePath == null) {
            new LoadImage19Task().execute(new Uri[]{data});
            return;
        }
        this.startActivityFromUri(data);
    }

    @SuppressLint({"NewApi"})
    public String getPathForKitKat(Uri uri) {
        final boolean b = Build.VERSION.SDK_INT >= 19;
        final Uri uri2 = null;
        if (b && DocumentsContract.isDocumentUri(this.context, uri)) {
            if (isExternalStorageDocument(uri)) {
                final String[] split = DocumentsContract.getDocumentId(uri).split(":");
                if ("primary".equalsIgnoreCase(split[0])) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append(Environment.getExternalStorageDirectory());
                    sb.append("/");
                    sb.append(split[1]);
                    return sb.toString();
                }
            } else {
                if (isDownloadsDocument(uri)) {
                    uri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), (long) Long.valueOf(DocumentsContract.getDocumentId(uri)));
                    return this.getDataColumn(this.context, uri, null, null);
                }
                if (isMediaDocument(uri)) {
                    final String[] split2 = DocumentsContract.getDocumentId(uri).split(":");
                    final String s = split2[0];
                    if ("image".equals(s)) {
                        uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    } else if ("video".equals(s)) {
                        uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else {
                        uri = uri2;
                        if ("audio".equals(s)) {
                            uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                        }
                    }
                    return this.getDataColumn(this.context, uri, "_id=?", new String[]{split2[1]});
                }
            }
        } else if ("content".equalsIgnoreCase(uri.getScheme())) {
            if (isGooglePhotosUri(uri)) {
                return uri.getLastPathSegment();
            }
            return this.getDataColumn(this.context, uri, null, null);
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    public String getRealPathFromURI(Context context, Uri contentUri) {
        Cursor cursor = context.getContentResolver().query(contentUri, null, null, null, null);
        cursor.moveToFirst();
        String document_id = cursor.getString(0);
        document_id = document_id.substring(document_id.lastIndexOf(":") + 1);
        cursor.close();

        cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null
                , MediaStore.Images.Media._ID + " = ? ", new String[]{document_id}, null);
        cursor.moveToFirst();
        String path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
        cursor.close();

        return path;
    }

    public String getRealPathFromURI19(final Uri uri) throws IOException {
        return this.saveImageToTemp(this.getBitmapFromUri(uri));
    }

    public void setListener(final ImageLoaded imageLoadedListener) {
        this.imageLoadedListener = imageLoadedListener;
    }

    void startActivityFromUri(final Uri uri) {
        this.filemanagerstring = uri.getPath();
        final String tag = this.TAG;
        final StringBuilder sb = new StringBuilder();
        sb.append("startActivityFromUri selectedImagePath");
        sb.append(this.selectedImagePath);
        Log.w(tag, sb.toString());
        if (this.selectedImagePath == null) {
            this.selectedImagePath = this.filemanagerstring;
            final String tag2 = this.TAG;
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("null selectedImagePath ");
            sb2.append(this.selectedImagePath);
            Log.w(tag2, sb2.toString());
        }
        if (this.selectedImagePath == null || this.selectedImagePath.length() == 0 || this.selectedImagePath.toLowerCase().contains("http")) {
            new LoadImage19Task().execute(new Uri[]{uri});
            ++this.count;
            return;
        }
        if (this.checkFileExtension(this.selectedImagePath)) {
            this.imageLoadedListener.callFileSizeAlertDialogBuilder();
            return;
        }
        final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder(this.context);
        alertDialog$Builder.setMessage((CharSequence) "Image Format Error").setCancelable(false).setNegativeButton((CharSequence) "Ok", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                dialogInterface.cancel();
            }
        });
        alertDialog$Builder.create().show();
    }

    public interface ImageLoaded {
        void callFileSizeAlertDialogBuilder();
    }

    private class LoadImage19Task extends AsyncTask<Uri, Void, Void> {
        String path;
        ProgressDialog saveImageDialog;
        Uri uri;

        protected Void doInBackground(final Uri... array) {
            if (array != null) {
                try {
                    this.uri = array[0];
                    if (this.uri != null) {
                        this.path = ImageLoader.this.getRealPathFromURI19(this.uri);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            return null;
        }

        protected void onPostExecute(final Void void1) {
            super.onPostExecute(void1);
            ImageLoader.this.selectedImagePath = this.path;
            ImageLoader.this.startActivityFromUri(this.uri);
            try {
                this.saveImageDialog.dismiss();
            } catch (Exception ex) {
            }
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ImageLoader.this.loadImageMessage = ImageLoader.this.context.getString(R.string.loading_image);
            try {
                (this.saveImageDialog = new ProgressDialog(ImageLoader.this.context)).setMessage((CharSequence) ImageLoader.this.loadImageMessage);
                this.saveImageDialog.show();
            } catch (Exception ex) {
            }
        }
    }
}
