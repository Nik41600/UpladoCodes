package com.abcd.photocollage.utils.sticker;

public class StickerGridItem {
  int anInt;
  int anInt1 = 0;

  public StickerGridItem(int i) {
    this.anInt = i;
    this.anInt1 = 0;
  }
}