package com.abcd.photocollage.utils;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

public class Parameter implements Serializable, Parcelable {
    public static final Parcelable.Creator<Parameter> CREATOR;
    public static final int seek_bar_brightness = 0;
    public static final int seek_bar_saturation = 3;
    public static final int seek_bar_sharpen = 5;
    public static final int seek_bar_temperature = 2;
    public static final int seek_bar_tint = 4;
    private static final long serialVersionUID = -3588782317514910667L;
    public static AtomicInteger uniqueId;
    public int blur;
    public int brightness;
    public int contrast;
    public float highlight;
    public int id;
    public int saturation;
    public int seekBarMode;
    public int selectedBorderIndex;
    public int selectedFilterIndex;
    public int selectedOverlayIndex;
    public int selectedTextureIndex;
    public float shadow;
    public float sharpen;
    public int temperature;
    public int tint;

    static {
        Parameter.uniqueId = new AtomicInteger();
        CREATOR = (Parcelable.Creator) new Parcelable.Creator<Parameter>() {
            public Parameter createFromParcel(final Parcel parcel) {
                return new Parameter(parcel);
            }

            public Parameter[] newArray(final int n) {
                return new Parameter[n];
            }
        };
    }

    public Parameter() {
        this.sharpen = 0.0f;
        this.blur = 0;
        this.highlight = 0.0f;
        this.shadow = 0.0f;
        this.seekBarMode = 0;
        this.reset();
        this.id = Parameter.uniqueId.getAndIncrement();
        this.seekBarMode = 0;
    }

    public Parameter(final Parcel parcel) {
        this.sharpen = 0.0f;
        this.blur = 0;
        this.highlight = 0.0f;
        this.shadow = 0.0f;
        this.seekBarMode = 0;
        this.brightness = parcel.readInt();
        this.contrast = parcel.readInt();
        this.temperature = parcel.readInt();
        this.saturation = parcel.readInt();
        this.tint = parcel.readInt();
        this.selectedTextureIndex = parcel.readInt();
        this.selectedBorderIndex = parcel.readInt();
        this.selectedOverlayIndex = parcel.readInt();
        this.selectedFilterIndex = parcel.readInt();
        this.seekBarMode = parcel.readInt();
        this.sharpen = parcel.readFloat();
        this.blur = parcel.readInt();
        this.highlight = parcel.readFloat();
        this.shadow = parcel.readFloat();
        this.id = parcel.readInt();
    }

    public Parameter(final Parameter parameter) {
        this.sharpen = 0.0f;
        this.blur = 0;
        this.highlight = 0.0f;
        this.shadow = 0.0f;
        this.seekBarMode = 0;
        this.set(parameter);
    }

    private void readObject(final ObjectInputStream objectInputStream) throws Exception, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.brightness = objectInputStream.readInt();
        this.contrast = objectInputStream.readInt();
        this.temperature = objectInputStream.readInt();
        this.saturation = objectInputStream.readInt();
        this.tint = objectInputStream.readInt();
        this.selectedTextureIndex = objectInputStream.readInt();
        this.selectedBorderIndex = objectInputStream.readInt();
        this.selectedOverlayIndex = objectInputStream.readInt();
        this.selectedFilterIndex = objectInputStream.readInt();
        this.seekBarMode = objectInputStream.readInt();
        try {
            this.sharpen = objectInputStream.readFloat();
            this.blur = objectInputStream.readInt();
            this.highlight = objectInputStream.readFloat();
            this.shadow = objectInputStream.readFloat();
            this.id = objectInputStream.readInt();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeInt(this.brightness);
        objectOutputStream.writeInt(this.contrast);
        objectOutputStream.writeInt(this.temperature);
        objectOutputStream.writeInt(this.saturation);
        objectOutputStream.writeInt(this.tint);
        objectOutputStream.writeInt(this.selectedTextureIndex);
        objectOutputStream.writeInt(this.selectedBorderIndex);
        objectOutputStream.writeInt(this.selectedOverlayIndex);
        objectOutputStream.writeInt(this.selectedFilterIndex);
        objectOutputStream.writeInt(this.seekBarMode);
        objectOutputStream.writeFloat(this.sharpen);
        objectOutputStream.writeInt(this.blur);
        objectOutputStream.writeFloat(this.highlight);
        objectOutputStream.writeFloat(this.shadow);
        objectOutputStream.writeInt(this.id);
    }

    public Parameter copy() {
        return new Parameter(this);
    }

    public int describeContents() {
        return 0;
    }

    public int getBlurValue() {
        return this.blur * 4;
    }

    public int getBrightProgress() {
        if (this.brightness < 0) {
            return this.brightness / 3 + 50;
        }
        return this.brightness / 5 + 50;
    }

    public int getContrastProgress() {
        return this.contrast / 2 + 50;
    }

    public int getHighlightValue() {
        return (int) (this.highlight * 255.0f + 50.0f);
    }

    public int getId() {
        return this.id;
    }

    public int getShadowValue() {
        return (int) (this.shadow * 255.0f + 50.0f);
    }

    public int getSharpenValue() {
        return (int) (this.sharpen * 100.0f);
    }

    public int getTemperatureProgress() {
        return this.temperature / 2 + 50;
    }

    public int getTintProgressValue() {
        return this.tint + 50;
    }

    public boolean isParameterReallyChanged(final Parameter parameter) {
        if (this.contrast == parameter.contrast && this.brightness == parameter.brightness && this.saturation == parameter.saturation && this.temperature == parameter.temperature && this.tint == parameter.tint && this.sharpen == parameter.sharpen && this.blur == parameter.blur && this.highlight == parameter.highlight && this.shadow == parameter.shadow && this.selectedBorderIndex == parameter.selectedBorderIndex && this.selectedFilterIndex == parameter.selectedFilterIndex && this.selectedOverlayIndex == parameter.selectedOverlayIndex) {
            final int selectedTextureIndex = this.selectedTextureIndex;
            final int selectedTextureIndex2 = parameter.selectedTextureIndex;
        }
        return true;
    }

    public void reset() {
        this.brightness = 0;
        this.contrast = 0;
        this.temperature = 0;
        this.saturation = 50;
        this.tint = 0;
        this.selectedTextureIndex = 0;
        this.selectedBorderIndex = 0;
        this.selectedOverlayIndex = 0;
        this.selectedFilterIndex = 0;
        this.sharpen = 0.0f;
        this.blur = 0;
        this.highlight = 0.0f;
        this.shadow = 0.0f;
    }

    public void set(final Parameter parameter) {
        this.brightness = parameter.brightness;
        this.temperature = parameter.temperature;
        this.contrast = parameter.contrast;
        this.saturation = parameter.saturation;
        this.tint = parameter.tint;
        this.selectedTextureIndex = parameter.selectedTextureIndex;
        this.selectedBorderIndex = parameter.selectedBorderIndex;
        this.selectedOverlayIndex = parameter.selectedOverlayIndex;
        this.selectedFilterIndex = parameter.selectedFilterIndex;
        this.sharpen = parameter.sharpen;
        this.blur = parameter.blur;
        this.highlight = parameter.highlight;
        this.shadow = parameter.shadow;
        this.seekBarMode = parameter.seekBarMode;
        this.id = parameter.id;
    }

    public void setBlur(final int n) {
        float n2;
        if ((n2 = n / 4.0f) > 25.0f) {
            n2 = 25.0f;
        }
        this.blur = (int) n2;
    }

    public void setBrightness(int n) {
        n -= 50;
        if (n < 0) {
            this.brightness = n * 3;
            return;
        }
        this.brightness = n * 5;
    }

    public void setContrast(final int n) {
        this.contrast = (n - 50) * 2;
    }

    public void setHighlight(final int n) {
        this.highlight = (n - 50) / 255.0f;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setSaturation(final int saturation) {
        this.saturation = saturation;
    }

    public void setShadow(final int n) {
        this.shadow = (n - 50) / 255.0f;
    }

    public void setSharpen(final int n) {
        this.sharpen = n / 100.0f;
    }

    public void setTemperature(final int n) {
        this.temperature = (n - 50) * 2;
    }

    public void setTint(final int n) {
        this.tint = n - 50;
    }

    public void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeInt(this.brightness);
        parcel.writeInt(this.contrast);
        parcel.writeInt(this.temperature);
        parcel.writeInt(this.saturation);
        parcel.writeInt(this.tint);
        parcel.writeInt(this.selectedTextureIndex);
        parcel.writeInt(this.selectedBorderIndex);
        parcel.writeInt(this.selectedOverlayIndex);
        parcel.writeInt(this.selectedFilterIndex);
        parcel.writeInt(this.seekBarMode);
        parcel.writeFloat(this.sharpen);
        parcel.writeInt(this.blur);
        parcel.writeFloat(this.highlight);
        parcel.writeFloat(this.shadow);
        parcel.writeInt(this.id);
    }
}
