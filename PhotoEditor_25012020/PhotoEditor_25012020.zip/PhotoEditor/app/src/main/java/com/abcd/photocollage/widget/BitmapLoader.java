package com.abcd.photocollage.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.util.Log;

public class BitmapLoader {
  public Bitmap load(Context context, int[] iArr, String str) throws Exception {
    Options options = new Options();
    options.inJustDecodeBounds = true;
    BitmapFactory.decodeFile(str, options);
    int i = options.outWidth;
    int i2 = options.outHeight;
    int i3 = iArr[0];
    int i4 = iArr[1];
    int i5 = 2;
    if (i2 > i4 || i > i3) {
      i /= 2;
      i2 /= 2;
      while (i2 / i5 > i4 && i / i5 > i3) {
        i5 *= 2;
      }
    }
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(i5);
    stringBuilder.append("");
    Log.e("Sample Size", stringBuilder.toString());
    options.inSampleSize = i5;
    options.inJustDecodeBounds = false;
    return BitmapProcessing.modifyOrientation(BitmapFactory.decodeFile(str, options), str);
  }
}