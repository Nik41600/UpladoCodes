package com.abcd.photocollage.adapter;

import android.content.*;
import android.view.*;
import android.app.*;
import android.widget.*;
import android.graphics.*;

import com.shyamsoft.photoeditor.R;

public class FontStyleAdapter extends BaseAdapter {
	private Context context;
	private final String[] str_values;

	public FontStyleAdapter(final Context context,
							final String[] mobileValues) {
		this.context = context;
		this.str_values = mobileValues;
	}

	public int getCount() {
		return this.str_values.length;
	}

	public Object getItem(final int n) {
		return null;
	}

	public long getItemId(final int n) {
		return 0L;
	}

	public View getView(final int n, View inflate, final ViewGroup viewGroup) {
		RecordHolder tag;
		if (inflate == null) {
			inflate = ((Activity) this.context).getLayoutInflater().inflate(
					R.layout.row_grid, viewGroup, false);
			tag = new RecordHolder();
			tag.tvFont = (TextView) inflate.findViewById(R.id.item_text);
			inflate.setTag((Object) tag);
		} else {
			tag = (RecordHolder) inflate.getTag();
		}
		tag.typeface = Typeface.createFromAsset(this.context.getAssets(),
				this.str_values[n]);
		tag.tvFont.setTypeface(tag.typeface);
		return inflate;
	}

	static class RecordHolder {
		TextView tvFont;
		Typeface typeface;
	}
}
