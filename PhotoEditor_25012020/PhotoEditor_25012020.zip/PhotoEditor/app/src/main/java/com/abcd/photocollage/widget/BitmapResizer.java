package com.abcd.photocollage.widget;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.Rect;
import android.media.ExifInterface;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class BitmapResizer {
    public static Bitmap decodeBitmapFromFile(final String s, final int n) {
        try {
            new ExifInterface(s).getAttributeInt("Orientation", 0);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        final Bitmap decodeFile = decodeFile(s, n);
        if (decodeFile == null) {
            return null;
        }
        if (decodeFile == null) {
            return decodeFile;
        }
        if (Build.VERSION.SDK_INT >= 13) {
            return decodeFile;
        }
        final Bitmap copy = decodeFile.copy(Bitmap.Config.ARGB_8888, true);
        if (decodeFile != copy) {
            decodeFile.recycle();
        }
        return copy;
    }


    private static Bitmap decodeFile(final String s, final int n) {
        final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
        int inSampleSize = 1;
        bitmapFactory$Options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(s, bitmapFactory$Options);
        for (int outWidth = bitmapFactory$Options.outWidth, outHeight = bitmapFactory$Options.outHeight; Math.max(outWidth, outHeight) / 2 > n; outWidth /= 2, outHeight /= 2, inSampleSize *= 2) {
        }
        final BitmapFactory.Options bitmapFactory$Options2 = new BitmapFactory.Options();
        bitmapFactory$Options2.inSampleSize = inSampleSize;
        final Bitmap decodeFile = BitmapFactory.decodeFile(s, bitmapFactory$Options2);
        return decodeFile;
    }

    public static Point decodeFileSize(final File file, final int n) {
        try {
            final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
            bitmapFactory$Options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream((InputStream) new FileInputStream(file), (Rect) null, bitmapFactory$Options);
            int outWidth;
            int outHeight;
            int n2;
            for (outWidth = bitmapFactory$Options.outWidth, outHeight = bitmapFactory$Options.outHeight, n2 = 1; Math.max(outWidth, outHeight) / 2 > n; outWidth /= 2, outHeight /= 2, n2 *= 2) {
            }
            if (n2 == 1) {
                return new Point(-1, -1);
            }
            return new Point(outWidth, outHeight);
        } catch (FileNotFoundException ex) {
            return null;
        }
    }


}
