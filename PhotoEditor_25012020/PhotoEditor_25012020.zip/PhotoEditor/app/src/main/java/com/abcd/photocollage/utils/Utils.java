package com.abcd.photocollage.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Debug;
import android.provider.MediaStore;
import android.util.Log;

import com.shyamsoft.photoeditor.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Utils {
    private static final String TAG = "Utils";
    private static final float limitDivider = 30.0f;
    private static final float limitDividerGinger = 160.0f;
    public static final int[] patternResIdList;
    public static final int[][] patternResIdList2;
    public static final int[] patternResIdList3;
    private static final int[][] r0;

    static {
        patternResIdList = new int[]{R.drawable.no_pattern, R.drawable.color_picker, R.drawable.pattern_01, R.drawable.pattern_02, R.drawable.pattern_03, R.drawable.pattern_04, R.drawable.pattern_05, R.drawable.pattern_06, R.drawable.pattern_07, R.drawable.pattern_08, R.drawable.pattern_09, R.drawable.pattern_10, R.drawable.pattern_11, R.drawable.pattern_12, R.drawable.pattern_13, R.drawable.pattern_14, R.drawable.pattern_15, R.drawable.pattern_16, R.drawable.pattern_17, R.drawable.pattern_18, R.drawable.pattern_19, R.drawable.pattern_20, R.drawable.pattern_21, R.drawable.pattern_22, R.drawable.pattern_23, R.drawable.pattern_24, R.drawable.pattern_25, R.drawable.pattern_26, R.drawable.pattern_27, R.drawable.pattern_28, R.drawable.pattern_29, R.drawable.pattern_30, R.drawable.pattern_31, R.drawable.pattern_32, R.drawable.pattern_33, R.drawable.pattern_34, R.drawable.pattern_35, R.drawable.pattern_36, R.drawable.pattern_37, R.drawable.pattern_38, R.drawable.pattern_39, R.drawable.pattern_40, R.drawable.pattern_41, R.drawable.pattern_42, R.drawable.pattern_43, R.drawable.pattern_44, R.drawable.pattern_45, R.drawable.pattern_46, R.drawable.pattern_47, R.drawable.pattern_48, R.drawable.pattern_49, R.drawable.pattern_50, R.drawable.pattern_51, R.drawable.pattern_52, R.drawable.pattern_53, R.drawable.pattern_54, R.drawable.pattern_55, R.drawable.pattern_56, R.drawable.pattern_57};
        (r0 = new int[12][])[0] = new int[]{R.drawable.pattern_085, R.drawable.pattern_086, R.drawable.pattern_087, R.drawable.pattern_088, R.drawable.pattern_089, R.drawable.pattern_090, R.drawable.pattern_091, R.drawable.pattern_092, R.drawable.pattern_093, R.drawable.pattern_094, R.drawable.pattern_095, R.drawable.pattern_096};
        Utils.r0[1] = new int[]{R.drawable.pattern_097, R.drawable.pattern_098, R.drawable.pattern_099, R.drawable.pattern_100, R.drawable.pattern_101, R.drawable.pattern_102, R.drawable.pattern_103, R.drawable.pattern_104, R.drawable.pattern_105, R.drawable.pattern_106, R.drawable.pattern_107, R.drawable.pattern_108};
        Utils.r0[2] = new int[]{R.drawable.pattern_061, R.drawable.pattern_062, R.drawable.pattern_063, R.drawable.pattern_064, R.drawable.pattern_065, R.drawable.pattern_066, R.drawable.pattern_067, R.drawable.pattern_068, R.drawable.pattern_069, R.drawable.pattern_070, R.drawable.pattern_071, R.drawable.pattern_072};
        Utils.r0[3] = new int[]{R.drawable.pattern_073, R.drawable.pattern_074, R.drawable.pattern_075, R.drawable.pattern_076, R.drawable.pattern_077, R.drawable.pattern_078, R.drawable.pattern_079, R.drawable.pattern_080, R.drawable.pattern_081, R.drawable.pattern_082, R.drawable.pattern_083, R.drawable.pattern_084};
        Utils.r0[4] = new int[]{R.drawable.pattern_109, R.drawable.pattern_110, R.drawable.pattern_111, R.drawable.pattern_112, R.drawable.pattern_113, R.drawable.pattern_114, R.drawable.pattern_115, R.drawable.pattern_116, R.drawable.pattern_117, R.drawable.pattern_118, R.drawable.pattern_119, R.drawable.pattern_120};
        Utils.r0[5] = new int[]{R.drawable.pattern_121, R.drawable.pattern_122, R.drawable.pattern_123, R.drawable.pattern_124, R.drawable.pattern_125, R.drawable.pattern_126, R.drawable.pattern_127, R.drawable.pattern_128, R.drawable.pattern_129, R.drawable.pattern_130, R.drawable.pattern_131};
        Utils.r0[6] = new int[]{R.drawable.pattern_132, R.drawable.pattern_133, R.drawable.pattern_134, R.drawable.pattern_135, R.drawable.pattern_136, R.drawable.pattern_137, R.drawable.pattern_138, R.drawable.pattern_139, R.drawable.pattern_140, R.drawable.pattern_141, R.drawable.pattern_142};
        Utils.r0[7] = new int[]{R.drawable.pattern_49, R.drawable.pattern_50, R.drawable.pattern_51, R.drawable.pattern_52, R.drawable.pattern_53, R.drawable.pattern_54, R.drawable.pattern_55, R.drawable.pattern_56, R.drawable.pattern_57, R.drawable.pattern_058, R.drawable.pattern_059, R.drawable.pattern_060};
        Utils.r0[8] = new int[]{R.drawable.pattern_01, R.drawable.pattern_02, R.drawable.pattern_03, R.drawable.pattern_04, R.drawable.pattern_05, R.drawable.pattern_06, R.drawable.pattern_07, R.drawable.pattern_08, R.drawable.pattern_09, R.drawable.pattern_10, R.drawable.pattern_11, R.drawable.pattern_12};
        Utils.r0[9] = new int[]{R.drawable.pattern_13, R.drawable.pattern_14, R.drawable.pattern_15, R.drawable.pattern_16, R.drawable.pattern_17, R.drawable.pattern_18, R.drawable.pattern_19, R.drawable.pattern_20, R.drawable.pattern_21, R.drawable.pattern_22, R.drawable.pattern_23, R.drawable.pattern_24};
        Utils.r0[10] = new int[]{R.drawable.pattern_25, R.drawable.pattern_26, R.drawable.pattern_27, R.drawable.pattern_28, R.drawable.pattern_29, R.drawable.pattern_30, R.drawable.pattern_31, R.drawable.pattern_32, R.drawable.pattern_33, R.drawable.pattern_34, R.drawable.pattern_35, R.drawable.pattern_36};
        Utils.r0[11] = new int[]{R.drawable.pattern_37, R.drawable.pattern_38, R.drawable.pattern_39, R.drawable.pattern_40, R.drawable.pattern_41, R.drawable.pattern_42, R.drawable.pattern_43, R.drawable.pattern_44, R.drawable.pattern_45, R.drawable.pattern_46, R.drawable.pattern_47, R.drawable.pattern_48};
        patternResIdList2 = Utils.r0;
        patternResIdList3 = new int[]{R.drawable.no_pattern, R.drawable.color_picker, R.drawable.pattern_icon_08, R.drawable.pattern_icon_09, R.drawable.pattern_icon_06, R.drawable.pattern_icon_07, R.drawable.pattern_icon_10, R.drawable.pattern_icon_11, R.drawable.pattern_icon_12, R.drawable.pattern_icon_05, R.drawable.pattern_icon_01, R.drawable.pattern_icon_02, R.drawable.pattern_icon_03, R.drawable.pattern_icon_04};
    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;

        int stretch_width = Math.round((float) width / (float) reqWidth);
        int stretch_height = Math.round((float) height / (float) reqHeight);

        if (stretch_width <= stretch_height)
            return stretch_height;
        else
            return stretch_width;
    }

    @SuppressLint({"NewApi"})
    public static Bitmap decodeFile(final String s, final int n, final boolean b) {
        try {
            final File file = new File(s);
            final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
            bitmapFactory$Options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream((InputStream) new FileInputStream(file), (Rect) null, bitmapFactory$Options);
            final BitmapFactory.Options bitmapFactory$Options2 = new BitmapFactory.Options();
            if (Build.VERSION.SDK_INT >= 11 && b) {
                bitmapFactory$Options2.inMutable = true;
            }
            bitmapFactory$Options2.inSampleSize = calculateInSampleSize(bitmapFactory$Options, n, n);
            final Bitmap decodeStream = BitmapFactory.decodeStream((InputStream) new FileInputStream(file), (Rect) null, bitmapFactory$Options2);
            ExifInterface exifInterface;
            try {
                exifInterface = new ExifInterface(s);
            } catch (IOException ex) {
                ex.printStackTrace();
                exifInterface = null;
            }
            final Bitmap rotateImage = rotateImage(decodeStream, exifInterface.getAttributeInt("Orientation", 0));
            if (rotateImage.isMutable()) {
                return rotateImage;
            }
            final Bitmap copy = rotateImage.copy(Bitmap.Config.ARGB_8888, true);
            if (copy != rotateImage) {
                rotateImage.recycle();
            }
            return copy;
        } catch (FileNotFoundException ex2) {
            return null;
        }
    }

    public static double getLeftSizeOfMemory() {
        return Double.valueOf(Runtime.getRuntime().maxMemory()) - (Double.valueOf(Runtime.getRuntime().totalMemory()) - Double.valueOf(Runtime.getRuntime().freeMemory())) - Double.valueOf(Debug.getNativeHeapAllocatedSize());
    }

    @SuppressLint({"NewApi"})
    public static Bitmap getScaledBitmapFromId(final Context context, final long n, final int n2, final int n3, final boolean b) {
        final Uri withAppendedPath = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Long.toString(n));
        final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
        bitmapFactory$Options.inJustDecodeBounds = true;
        AssetFileDescriptor openAssetFileDescriptor;
        try {
            openAssetFileDescriptor = context.getContentResolver().openAssetFileDescriptor(withAppendedPath, "r");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            openAssetFileDescriptor = null;
        }
        if (openAssetFileDescriptor == null) {
            return null;
        }
        BitmapFactory.decodeFileDescriptor(openAssetFileDescriptor.getFileDescriptor(), (Rect) null, bitmapFactory$Options);
        final BitmapFactory.Options bitmapFactory$Options2 = new BitmapFactory.Options();
        bitmapFactory$Options2.inSampleSize = calculateInSampleSize(bitmapFactory$Options, n3, n3);
        if (Build.VERSION.SDK_INT >= 11 && b) {
            bitmapFactory$Options2.inMutable = true;
        }
        final Bitmap decodeFileDescriptor = BitmapFactory.decodeFileDescriptor(openAssetFileDescriptor.getFileDescriptor(), (Rect) null, bitmapFactory$Options2);
        if (decodeFileDescriptor == null) {
            return null;
        }
        final Bitmap rotateImage = rotateImage(decodeFileDescriptor, n2);
        if (rotateImage != null && decodeFileDescriptor != rotateImage) {
            decodeFileDescriptor.recycle();
        }
        if (rotateImage.isMutable()) {
            return rotateImage;
        }
        if (!b) {
            return rotateImage;
        }
        Log.e(Utils.TAG, "bitmap is not mutable");
        final Bitmap copy = rotateImage.copy(Bitmap.Config.ARGB_8888, true);
        if (copy != rotateImage) {
            rotateImage.recycle();
        }
        return copy;
    }

    public static int maxSizeForSave() {
        final int n = (int) Math.sqrt(getLeftSizeOfMemory() / 40.0);
        if (n > 1080) {
            return 1080;
        }
        return n;
    }

    public static int maxSizeForSave(final Context context, final float n) {
        float n2;
        if (Build.VERSION.SDK_INT <= 11) {
            n2 = 160.0f;
        } else {
            n2 = 30.0f;
        }
        final String tag = Utils.TAG;
        final StringBuilder sb = new StringBuilder();
        sb.append("divider = ");
        sb.append(n2);
        Log.e(tag, sb.toString());
        final int n3 = (int) Math.sqrt(getLeftSizeOfMemory() / n2);
        if (n3 > 0) {
            return (int) Math.min(n3, n);
        }
        return (int) n;
    }

    public static float pointToAngle(float n, float n2, final float n3, final float n4) {
        if (n >= n3 && n2 < n4) {
            n = (float) (270.0 + Math.toDegrees(Math.atan((n - n3) / (n4 - n2))));
        } else if (n > n3 && n2 >= n4) {
            n = (float) Math.toDegrees(Math.atan((n2 - n4) / (n - n3)));
        } else if (n <= n3 && n2 > n4) {
            n = (float) (90.0 + Math.toDegrees(Math.atan((n3 - n) / (n2 - n4))));
        } else if (n < n3 && n2 <= n4) {
            n = (int) Math.toDegrees(Math.atan((n4 - n2) / (n3 - n))) + 180;
        } else {
            n = 0.0f;
        }
        n2 = n;
        if (n < -180.0f) {
            n2 = n + 360.0f;
        }
        if (n2 > 180.0f) {
            return n2 - 360.0f;
        }
        return n2;
    }

    private static Bitmap rotateImage(final Bitmap bitmap, final int n) {
        final Matrix matrix = new Matrix();
        if (n == 90) {
            matrix.postRotate(90.0f);
        } else if (n == 180) {
            matrix.postRotate(180.0f);
        } else if (n == 270) {
            matrix.postRotate(270.0f);
        }
        if (n == 0) {
            return bitmap;
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }
}
