package com.abcd.photocollage.utils.canvastextview;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.support.v4.internal.view.SupportMenu;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class TextDataItem implements Serializable {
    public static final int defBgAlpha = 255;
    public static final int defBgColor = 0;
    public static final String defaultMessage = "Preview Text";
    private static final long serialVersionUID = 3789254181897332363L;
    public CustomMatrix canvasMatrix;
    private String fontPath;
    public CustomMatrix imageSaveMatrix;
    public boolean isTypeFaceSet;
    public String message;
    public CustomPaint textPaint;
    public float textSize;
    public float xPos;
    public float yPos;

    public void setTextFont(String str, Context context) {

        this.fontPath = str;
        if (this.fontPath != null) {
            Typeface typeface = FontCache.get(context, this.fontPath);
            if (typeface != null) {
                this.textPaint.setTypeface(typeface);
            }
            this.isTypeFaceSet = true;
        }
    }

    public String getFontPath() {
        return this.fontPath;
    }

    public TextDataItem(float f) {
        this.message = defaultMessage;
        this.isTypeFaceSet = false;
        this.canvasMatrix = new CustomMatrix();
        this.textPaint = new CustomPaint();
        this.textPaint.setAntiAlias(true);
        this.textPaint.setColor(SupportMenu.CATEGORY_MASK);
        this.textSize = f;
        this.textPaint.setTextSize(f);
        this.fontPath = null;
    }

    public TextDataItem() {
        this.message = defaultMessage;
        this.isTypeFaceSet = false;
        this.canvasMatrix = new CustomMatrix();
        this.textPaint = new CustomPaint();
        this.textPaint.setAntiAlias(true);
        this.textPaint.setColor(-1);
        this.textSize = 60.0f;
        this.textPaint.setTextSize(this.textSize);
        this.fontPath = null;
    }

    public TextDataItem(TextDataItem textDataItem) {
        this.message = defaultMessage;
        this.isTypeFaceSet = false;
        this.canvasMatrix = new CustomMatrix(textDataItem.canvasMatrix);
        this.textPaint = new CustomPaint(textDataItem.textPaint);
        this.textPaint.setAntiAlias(true);
        this.message = new String(textDataItem.message);
        this.textSize = textDataItem.textSize;
        this.xPos = textDataItem.xPos;
        this.yPos = textDataItem.yPos;
        if (textDataItem.imageSaveMatrix != null) {
            this.imageSaveMatrix = new CustomMatrix(textDataItem.imageSaveMatrix);
        }
        if (textDataItem.fontPath != null) {
            this.fontPath = textDataItem.fontPath;
        }
    }

    public void setImageSaveMatrix(Matrix matrix) {
        CustomMatrix customMatrix = new CustomMatrix(matrix);
        matrix.invert(customMatrix);
        customMatrix.preConcat(this.canvasMatrix);
        this.imageSaveMatrix = customMatrix;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeFloat(this.xPos);
        objectOutputStream.writeFloat(this.yPos);
        objectOutputStream.writeFloat(this.textSize);
        objectOutputStream.writeObject(this.textPaint);
        objectOutputStream.writeObject(this.message);
        objectOutputStream.writeObject(this.canvasMatrix);
        objectOutputStream.writeObject(this.imageSaveMatrix);
        objectOutputStream.writeObject(this.fontPath);
    }

    private void readObject(ObjectInputStream objectInputStream) throws Exception, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.xPos = objectInputStream.readFloat();
        this.yPos = objectInputStream.readFloat();
        this.textSize = objectInputStream.readFloat();
        this.textPaint = (CustomPaint) objectInputStream.readObject();
        this.message = (String) objectInputStream.readObject();
        this.canvasMatrix = (CustomMatrix) objectInputStream.readObject();
        this.imageSaveMatrix = (CustomMatrix) objectInputStream.readObject();
        try {
            this.fontPath = (String) objectInputStream.readObject();
        } catch (Exception unused) {
            this.fontPath = null;
        }
        this.textPaint.setAntiAlias(true);
        this.isTypeFaceSet = false;
    }
}