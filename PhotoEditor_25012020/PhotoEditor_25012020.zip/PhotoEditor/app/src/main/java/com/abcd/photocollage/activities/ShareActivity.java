package com.abcd.photocollage.activities;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.content.FileProvider;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.abcd.photocollage.kprogresshud.KProgressHUD;
import com.abcd.photocollage.widget.BitmapLoader;
import com.abcd.photocollage.myStudio.ActivityStudio;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.shyamsoft.photoeditor.R;

import java.io.File;

public class ShareActivity extends AppCompatActivity implements View.OnClickListener {
    private Bundle bundle;
    private String imagePath;
    private ImageView shareImageview;
    private AdView adView;
    private InterstitialAd mInterstitialAd;;
    private KProgressHUD hud;
    private ImageView ivBack, ivhome;

    public void myClickHandler(View view) {
        Intent intent;
        File file;
        int id = view.getId();
        if (id == R.id.instagramShare) {
            try {
                ShareImage("com.instagram.android", "Instagram");
            } catch (Exception unused) {
                Toast.makeText(this, getString(R.string.no_instagram_app), Toast.LENGTH_SHORT).show();
            }
        }

        if (id == R.id.share_imageView) {
            Toast.makeText(this, getString(R.string.saved_image_message), Toast.LENGTH_SHORT).show();
        }

        if (id == R.id.whatsup_share) {
            try {
                ShareImage("com.whatsapp", "Whatsapp");
            } catch (Exception unused2) {
                Toast.makeText(this, getString(R.string.no_whatsapp_app), Toast.LENGTH_SHORT).show();
            }
        }
        if (id == R.id.facebook_share) {
            ShareImage("com.facebook.katana", "Facebook");
        }
        if (id == R.id.more) {
            Parcelable fromFile;
            if (Build.VERSION.SDK_INT <= 19) {
                fromFile = Uri.fromFile(new File(this.imagePath));
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(getPackageName());
                stringBuilder.append(".provider");
                fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.imagePath));
            }
            Intent intentshare = new Intent("android.intent.action.SEND");
            intentshare.setType("image/*");
            intentshare.putExtra("android.intent.extra.STREAM", fromFile);
            intentshare.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intentshare, getString(R.string.share_your_story)));
        }
    }

    public void ShareImage(String str, String str2) {
        Parcelable fromFile;
        if (Build.VERSION.SDK_INT <= 19) {
            fromFile = Uri.fromFile(new File(this.imagePath));
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getPackageName());
            stringBuilder.append(".provider");
            fromFile = FileProvider.getUriForFile(this, stringBuilder.toString(), new File(this.imagePath));
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.STREAM", fromFile);
        if (isPackageInstalled(str, getApplicationContext())) {
            intent.setPackage(str);
            startActivity(Intent.createChooser(intent, getString(R.string.share_your_story)));
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Please Install ");
        stringBuilder2.append(str2);
        Toast.makeText(this, stringBuilder2.toString(), Toast.LENGTH_SHORT).show();
    }


    private boolean isPackageInstalled(final String s, final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(s, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ex) {
            return false;
        }
    }


    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_share);
        this.bundle = this.getIntent().getExtras();
        if (this.bundle != null) {
            this.imagePath = this.bundle.getString("imagePath");
        }
        this.shareImageview = this.findViewById(R.id.share_imageView);
        new BitmapWorkerTask().execute(new Void[0]);
        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(this);
        this.ivhome = (ImageView) findViewById(R.id.iv_home);
        ivhome.setOnClickListener(this);
        loadAd();
        BannerAd();

    }

    public void BannerAd() {
        //Banner Ad
        adView = findViewById(R.id.AdView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    public boolean onCreateOptionsMenu(final Menu menu) {
        this.getMenuInflater().inflate(R.menu.save_image_toolbar_menu, menu);
        return true;
    }

    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        final Intent intent = new Intent((Context) this, (Class) ActivityStudio.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        this.startActivity(intent);
        this.finish();
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId()){

            case R.id.ivBack:
                id = R.id.ivBack;
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    final Intent intent = new Intent(ShareActivity.this, (Class) HomeActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
            break;

            case R.id.iv_home:
                id = R.id.iv_home;
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    final Intent intent = new Intent(ShareActivity.this, (Class) HomeActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
            break;
        }

    }

    private class BitmapWorkerTask extends AsyncTask<Void, Void, Bitmap> {
        BitmapLoader bitmapLoader;
        DisplayMetrics metrics;

        public BitmapWorkerTask() {
            new File(ShareActivity.this.imagePath);
            this.metrics = ShareActivity.this.getResources().getDisplayMetrics();
            this.bitmapLoader = new BitmapLoader();
        }

        protected Bitmap doInBackground(final Void... array) {
            try {
                return this.bitmapLoader.load(ShareActivity.this.getApplicationContext(), new int[]{this.metrics.widthPixels, this.metrics.heightPixels}, ShareActivity.this.imagePath);
            } catch (Exception ex) {
                return null;
            }
        }

        protected void onPostExecute(final Bitmap imageBitmap) {
            if (imageBitmap != null) {
                ShareActivity.this.shareImageview.setImageBitmap(imageBitmap);
                return;
            }
            Toast.makeText((Context) ShareActivity.this, (CharSequence) ShareActivity.this.getString(R.string.error_img_not_found), Toast.LENGTH_SHORT).show();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }
    }

    private int id;
    public void loadAd()
    {
        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(adRequestfull);
        mInterstitialAd.setAdListener(new AdListener() {

            public void onAdLoaded()
            {
                super.onAdLoaded();
            }

            public void onAdClosed() {

                hud.dismiss();
                switch (id)
                {
                    case R.id.ivBack:
                        final Intent intent = new Intent(ShareActivity.this, (Class) HomeActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                        break;

                    case R.id.iv_home:
                        final Intent intent1 = new Intent(ShareActivity.this, (Class) HomeActivity.class);
                        intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent1);
                        finish();
                        break;
                }
                mInterstitialAd.loadAd(adRequestfull);
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                //Ads couldn't loaded
            }
        });

        mInterstitialAd.loadAd(adRequestfull);
    }

    public void DialogShow(){
        try {
            hud = KProgressHUD.create(ShareActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //interstitialAd.show();
                hud.dismiss();
                mInterstitialAd.show();
            }
        }, 2000);
    }
}
