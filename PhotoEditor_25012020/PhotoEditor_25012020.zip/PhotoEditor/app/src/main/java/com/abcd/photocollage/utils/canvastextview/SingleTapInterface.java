package com.abcd.photocollage.utils.canvastextview;

public interface SingleTapInterface
{
  void onSingleTap(final TextDataItem p0);
}
