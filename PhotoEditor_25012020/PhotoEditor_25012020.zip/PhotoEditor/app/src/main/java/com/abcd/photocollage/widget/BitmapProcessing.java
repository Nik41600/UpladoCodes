package com.abcd.photocollage.widget;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LightingColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;

import java.io.IOException;

public class BitmapProcessing {
    public static Bitmap flip(final Bitmap bitmap, final boolean b, final boolean b2) {
        final Matrix matrix = new Matrix();
        float n = 1.0f;
        float n2;
        if (b) {
            n2 = -1.0f;
        } else {
            n2 = 1.0f;
        }
        if (b2) {
            n = -1.0f;
        }
        matrix.preScale(n2, n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static Bitmap modifyOrientation(final Bitmap bitmap, final String s) throws IOException {
        final int attributeInt = new ExifInterface(s).getAttributeInt("Orientation", 1);
        if (attributeInt == 6) {
            return rotate(bitmap, 90.0f);
        }
        if (attributeInt == 8) {
            return rotate(bitmap, 270.0f);
        }
        switch (attributeInt) {
            default: {
                return bitmap;
            }
            case 4: {
                return flip(bitmap, false, true);
            }
            case 3: {
                return rotate(bitmap, 180.0f);
            }
            case 2: {
                return flip(bitmap, true, false);
            }
        }
    }

    public static Bitmap rotate(final Bitmap bitmap, final float n) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static Bitmap tint(final Bitmap bitmap, final int n) {
        final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        final Paint paint = new Paint(-65536);
        paint.setColorFilter((ColorFilter) new LightingColorFilter(n, 1));
        final Canvas canvas = new Canvas();
        canvas.setBitmap(bitmap2);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, paint);
        bitmap.recycle();
        return bitmap2;
    }
}
