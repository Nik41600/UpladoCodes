package com.abcd.photocollage.fragments;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.abcd.photocollage.fragments.FragmentEffect.BitmapReady;
import com.abcd.photocollage.utils.Parameter;
import com.shyamsoft.photoeditor.R;
import java.lang.reflect.Field;

public class FragmentFullEffect extends Fragment {
    Activity activity;
    FullBitmapReady bitmapReadyListener;
    Context context;
    Bitmap currentBitmap;
    FragmentEffect fragmentEffect;
    View header;
    ImageView imageView;
    Bitmap sourceBitmap;

    public interface FullBitmapReady {
        void onBitmapReady(Bitmap bitmap, Parameter parameter);
        void onCancel();
    }

    public interface HideHeaderListener {
        void hide(boolean z);
    }

    public void onSaveInstanceState(Bundle bundle) {
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        boolean z = false;
        View inflate = layoutInflater.inflate(R.layout.full_fragment_effect, viewGroup, false);
        this.imageView = (ImageView) inflate.findViewById(R.id.imageView1);
        this.header = inflate.findViewById(R.id.full_fragment_apply_filter_header);
        StringBuilder stringBuilder = new StringBuilder("imageView is null ");
        if (this.imageView == null) {
            z = true;
        }
        stringBuilder.append(z);
        addFragment();
        return inflate;
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.context = getActivity();
        this.activity = getActivity();
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.imageView.setImageBitmap(this.sourceBitmap);
    }

    public void BitmapParameter(Bitmap bitmap, Parameter parameter) {
        this.sourceBitmap = bitmap;
        if (this.imageView != null) {
            this.imageView.setImageBitmap(bitmap);
        }
        if (this.fragmentEffect != null) {
            if (parameter == null || this.fragmentEffect.parameterGlobal == null || parameter.getId() != this.fragmentEffect.parameterGlobal.id) {
                this.fragmentEffect.setBitmapAndResetBlur(this.sourceBitmap);
            } else {
                this.fragmentEffect.setBitmap(this.sourceBitmap);
            }
            if (parameter != null) {
                this.fragmentEffect.setParameters(parameter);
            }
        }
    }

    public void addFragment() {
        if (this.fragmentEffect == null) {
            this.fragmentEffect = (FragmentEffect) getChildFragmentManager().findFragmentByTag("MY_FRAGMENT");
            if (this.fragmentEffect == null) {
                this.fragmentEffect = new FragmentEffect();
                this.fragmentEffect.setArguments(getArguments());
                getChildFragmentManager().beginTransaction().add(R.id.fragment_container, this.fragmentEffect, "MY_FRAGMENT").commit();
            }
            getChildFragmentManager().beginTransaction().show(this.fragmentEffect).commit();
            this.fragmentEffect.setBitmapReadyListener(new BitmapReady() {
                public void onBitmapReady(Bitmap bitmap) {
                    FragmentFullEffect.this.imageView.setImageBitmap(bitmap);
                    FragmentFullEffect.this.currentBitmap = bitmap;
                }
            });
            this.fragmentEffect.setHideHeaderListener(new HideHeaderListener() {
                public void hide(boolean z) {
                    if (z) {
                        FragmentFullEffect.this.header.setVisibility(View.VISIBLE);
                    } else {
                        FragmentFullEffect.this.header.setVisibility(View.INVISIBLE);
                    }
                }
            });
        }
    }

    public void FullBitmapReadyListener(FullBitmapReady fullBitmapReady) {
        this.bitmapReadyListener = fullBitmapReady;
    }

    public void myClickHandler(View view) {
        if (view.getId() == R.id.button_apply_filter) {
            if (this.currentBitmap == null) {
                this.fragmentEffect.resetParametersWithoutChange();
                this.bitmapReadyListener.onCancel();
                return;
            }
            Parameter parameter = new Parameter(this.fragmentEffect.parameterGlobal);
            this.fragmentEffect.resetParametersWithoutChange();
            this.bitmapReadyListener.onBitmapReady(this.currentBitmap, parameter);
        } else if (view.getId() == R.id.button_cancel_filter) {
            this.fragmentEffect.resetParametersWithoutChange();
            this.bitmapReadyListener.onCancel();
        } else {
            if (this.header == null) {
                this.header = getView().findViewById(R.id.full_fragment_apply_filter_header);
            }
            int id = view.getId();
            if (id == R.id.buttonCancel || id == R.id.buttonOk || id == R.id.buttonReset) {
                this.header.setVisibility(View.VISIBLE);
            } else {
                this.header.setVisibility(View.INVISIBLE);
            }
            this.fragmentEffect.myClickHandler(id);
        }
    }

    public void onDetach() {
        super.onDetach();
        try {
            Field declaredField = Fragment.class.getDeclaredField("mChildFragmentManager");
            declaredField.setAccessible(true);
            declaredField.set(this, null);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e2) {
            throw new RuntimeException(e2);
        }
    }
}