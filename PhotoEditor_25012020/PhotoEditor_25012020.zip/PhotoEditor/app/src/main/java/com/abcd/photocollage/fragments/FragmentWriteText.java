package com.abcd.photocollage.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.TextView.BufferType;
import android.widget.Toast;

import com.abcd.photocollage.adapter.FontStyleAdapter;
import com.abcd.photocollage.utils.canvastextview.FontCache;
import com.abcd.photocollage.utils.canvastextview.TextDataItem;
import com.flask.colorpicker.ColorPickerView.WHEEL_TYPE;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.shyamsoft.photoeditor.R;

public class FragmentWriteText extends Fragment implements OnClickListener {
    private static final String TAG = "FragmentWriteText";
    Activity activity;
    FontStyleAdapter customGridAdapter;
    EditText editText;
    FontChoosedListener fontChoosedListener;
    private String[] fontPathList;
    TextDataItem textData;
    TextView textView;
    private Typeface type;

    public interface FontChoosedListener {
        void onOk(TextDataItem textDataItem);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_write_text, viewGroup, false);
        this.activity = getActivity();
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.textData = (TextDataItem) arguments.getSerializable("text_data");
        }
        this.fontPathList = new String[]{"fonts/MfStillKindaRidiculous.ttf", "fonts/ahundredmiles.ttf", "fonts/Binz.ttf", "fonts/Blunt.ttf", "fonts/FreeUniversal-Bold.ttf", "fonts/gtw.ttf", "fonts/HandTest.ttf", "fonts/Jester.ttf", "fonts/Semplicita_Light.otf", "fonts/OldFolksShuffle.ttf", "fonts/vinque.ttf", "fonts/Primal _ream.otf", "fonts/Junction 02.otf", "fonts/Laine.ttf", "fonts/NotCourierSans.otf", "fonts/OSP-DIN.ttf", "fonts/otfpoc.otf", "fonts/Sofia-Regular.ttf", "fonts/Quicksand-Regular.otf", "fonts/Roboto-Thin.ttf", "fonts/RomanAntique.ttf", "fonts/SerreriaSobria.otf", "fonts/Strato-linked.ttf", "fonts/waltographUI.ttf", "fonts/CaviarDreams.ttf", "fonts/GoodDog.otf", "fonts/Pacifico.ttf", "fonts/Windsong.ttf", "fonts/digiclock.ttf"};
        this.textView = (TextView) inflate.findViewById(R.id.textview_font);
        this.textView.setPaintFlags(this.textView.getPaintFlags() | 128);
        this.textView.setOnClickListener(this);
        this.editText = (EditText) inflate.findViewById(R.id.edittext_font);
        this.editText.setInputType((this.editText.getInputType() | 524288) | 176);
        this.editText.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.toString().compareToIgnoreCase("") != 0) {
                    FragmentWriteText.this.textView.setText(charSequence.toString());
                } else {
                    FragmentWriteText.this.textView.setText(TextDataItem.defaultMessage);
                }
                FragmentWriteText.this.editText.setSelection(FragmentWriteText.this.editText.getText().length());
            }

            public void afterTextChanged(Editable editable) {
                FragmentWriteText.this.editText.setSelection(FragmentWriteText.this.editText.getText().length());
            }
        });
        this.editText.setFocusableInTouchMode(true);
        if (this.textData == null) {
            this.textData = new TextDataItem(this.activity.getResources().getDimension(R.dimen.myFontSize));
            float f = (float) getResources().getDisplayMetrics().widthPixels;
            float f2 = (float) getResources().getDisplayMetrics().heightPixels;
            Rect rect = new Rect();
            this.textData.textPaint.getTextBounds(TextDataItem.defaultMessage, 0, TextDataItem.defaultMessage.length(), rect);
            this.textData.xPos = (f / 2.0f) - ((float) (rect.width() / 2));
            this.textData.yPos = (f2 / 2.0f) - ((float) (rect.height() / 2));
            Log.e(TAG, "textData==null");
            this.editText.setText("");
            this.textView.setText(getString(R.string.preview_text));
        } else {
            if (!this.textData.message.equals(TextDataItem.defaultMessage)) {
                this.editText.setText(this.textData.message, BufferType.EDITABLE);
            }
            Log.e(TAG, this.textData.message);
            this.textView.setTextColor(this.textData.textPaint.getColor());
            this.textView.setText(this.textData.message);
            if (this.textData.getFontPath() != null) {
                Typeface typeface = FontCache.get(this.activity, this.textData.getFontPath());
                if (typeface != null) {
                    this.textView.setTypeface(typeface);
                }
            }
        }
        GridView gridView = (GridView) inflate.findViewById(R.id.gridview_font);
        this.customGridAdapter = new FontStyleAdapter(this.activity, this.fontPathList);
        gridView.setAdapter(this.customGridAdapter);
        gridView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                FragmentWriteText.this.type = Typeface.createFromAsset(
                        getContext().getAssets(),
                        FragmentWriteText.this.fontPathList[i]);
                FragmentWriteText.this.textView
                        .setTypeface(FragmentWriteText.this.type);
                textView.setTypeface(FragmentWriteText.this.type);

                Typeface typeface = FontCache.get(FragmentWriteText.this.activity, FragmentWriteText.this.fontPathList[i]);
                if (type != null) {
                    FragmentWriteText.this.textView.setTypeface(type);
                }
                FragmentWriteText.this.textData.setTextFont(FragmentWriteText.this.fontPathList[i], FragmentWriteText.this.activity);
            }
        });
        inflate.findViewById(R.id.button_text_color).setOnClickListener(this);
        inflate.findViewById(R.id.button_font_ok).setOnClickListener(this);
        return inflate;
    }

    public void setFontChoosedListener(FontChoosedListener fontChoosedListener) {
        this.fontChoosedListener = fontChoosedListener;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.activity = getActivity();
    }

    public void onClick(View view) {
        int id = view.getId();
        String charSequence;
        if (id == R.id.textview_font) {
            this.editText.requestFocusFromTouch();
            ((InputMethodManager) this.activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(this.editText, 0);
            charSequence = this.textView.getText().toString();
            if (charSequence.compareToIgnoreCase(TextDataItem.defaultMessage) != 0) {
                this.editText.setText(charSequence);
                this.editText.setSelection(this.editText.getText().length());
            } else {
                this.editText.setText("");
            }
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    FragmentWriteText.this.editText.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 0, 0.0f, 0.0f, 0));
                    FragmentWriteText.this.editText.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 1, 0.0f, 0.0f, 0));
                    FragmentWriteText.this.editText.setSelection(FragmentWriteText.this.editText.getText().length());
                }
            }, 200);
        } else if (id == R.id.button_font_ok) {
            charSequence = this.textView.getText().toString();
            if (charSequence.compareToIgnoreCase(TextDataItem.defaultMessage) == 0 || charSequence.length() == 0) {
                if (this.activity == null) {
                    this.activity = getActivity();
                }
                Toast makeText = Toast.makeText(this.activity, getString(R.string.canvas_text_enter_text), Toast.LENGTH_SHORT);
                makeText.setGravity(17, makeText.getXOffset() / 2, makeText.getYOffset() / 2);
                makeText.show();
                return;
            }
            if (charSequence.length() == 0) {
                this.textData.message = TextDataItem.defaultMessage;
            } else {
                this.textData.message = charSequence;
            }
            this.editText.setText("");
            this.textView.setText("");
            ((InputMethodManager) this.activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(this.editText.getWindowToken(), 0);
            if (this.fontChoosedListener != null) {
                this.fontChoosedListener.onOk(this.textData);
            } else {
                Toast.makeText(getActivity(), "Null", Toast.LENGTH_SHORT).show();
            }
        } else if (id == R.id.button_text_color) {
            try {
                ColorPickerDialogBuilder.with(getActivity()).setTitle("Choose color").initialColor(this.textView.getCurrentTextColor()).wheelType(WHEEL_TYPE.FLOWER).density(12).setOnColorSelectedListener(new OnColorSelectedListener() {
                    public void onColorSelected(int i) {
                    }
                }).setPositiveButton((CharSequence) "ok", new ColorPickerClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i, Integer[] numArr) {
                        FragmentWriteText.this.textView.setTextColor(i);
                        FragmentWriteText.this.textData.textPaint.setColor(i);
                    }
                }).setNegativeButton((CharSequence) "cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                }).build().show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }
}