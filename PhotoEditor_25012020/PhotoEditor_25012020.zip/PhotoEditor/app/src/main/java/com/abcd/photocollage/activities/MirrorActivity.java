package com.abcd.photocollage.activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.abcd.photocollage.adapter.RecyclerViewAdapter;
import com.abcd.photocollage.fragments.FragmentEffect;
import com.abcd.photocollage.fragments.FragmentWriteText;
import com.abcd.photocollage.kprogresshud.KProgressHUD;
import com.abcd.photocollage.widget.BitmapResizer;
import com.abcd.photocollage.utils.canvastextview.ApplyTextInterface;
import com.abcd.photocollage.utils.canvastextview.CustomRelativeLayout;
import com.abcd.photocollage.utils.canvastextview.SingleTapInterface;
import com.abcd.photocollage.utils.canvastextview.TextDataItem;
import com.abcd.photocollage.utils.sticker.StickerActivity;
import com.abcd.photocollage.utils.Analytics;
import com.abcd.photocollage.utils.LibUtility;
import com.abcd.photocollage.utils.MirrorImageMode;
import com.abcd.photocollage.utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.shyamsoft.photoeditor.R;
import com.xiaopo.flying.sticker.BitmapStickerIcon;
import com.xiaopo.flying.sticker.DeleteIconEvent;
import com.xiaopo.flying.sticker.DrawableSticker;
import com.xiaopo.flying.sticker.FlipHorizontallyEvent;
import com.xiaopo.flying.sticker.Sticker;
import com.xiaopo.flying.sticker.StickerView;
import com.xiaopo.flying.sticker.ZoomIconEvent;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class MirrorActivity extends AppCompatActivity {
    int D3_BUTTON_SIZE;
    int MIRROR_BUTTON_SIZE;
    int RATIO_BUTTON_SIZE;
    int adFlag;
    Analytics analytics;
    int currentSelectedTabIndex;
    CustomRelativeLayout customRelativeLayout;
    ImageView[] d3ButtonArray;
    private int[] d3resList;
    FragmentEffect fragmentEffect;
    Bitmap filterBitmap;
    FragmentWriteText.FontChoosedListener fontChoosedListener;
    int initialYPos;
    RelativeLayout mainLayout;
    Matrix matrix1;
    Matrix matrix2;
    Matrix matrix3;
    Matrix matrix4;
    ImageView[] mirrorButtonArray;
    MirrorView mirrorView;
    float mulX;
    float mulY;
    Button[] ratioButtonArray;
    AlertDialog saveImageAlert;
    int screenHeightPixels;
    int screenWidthPixels;
    boolean showText;
    private Animation slideLeftIn;
    private Animation slideLeftOut;
    private Animation slideRightIn;
    private Animation slideRightOut;
    Bitmap sourceBitmap;
    StickerView stickercontain;
    ArrayList<Sticker> stickerlist;
    ImageView stickerwww;
    View[] tabButtonList;
    ArrayList<TextDataItem> textDataList;
    ViewFlipper viewFlipper;
    FragmentWriteText fragmentWriteText;
    private KProgressHUD hud;

    public MirrorActivity() {
        this.D3_BUTTON_SIZE = 24;
        this.MIRROR_BUTTON_SIZE = 15;
        this.RATIO_BUTTON_SIZE = 11;
        this.adFlag = 0;
        this.currentSelectedTabIndex = -1;
        this.initialYPos = 0;
        this.mulX = 16.0f;
        this.mulY = 16.0f;
        this.showText = false;
        this.textDataList = new ArrayList<TextDataItem>();
        this.matrix1 = new Matrix();
        this.matrix2 = new Matrix();
        this.matrix3 = new Matrix();
        this.matrix4 = new Matrix();
        this.stickerlist = new ArrayList<Sticker>();
        this.fontChoosedListener = new FragmentWriteText.FontChoosedListener() {
            @Override
            public void onOk(final TextDataItem textDataItem) {
                MirrorActivity.this.customRelativeLayout.addTextView(textDataItem);
                MirrorActivity.this.getSupportFragmentManager().beginTransaction().remove(MirrorActivity.this.fragmentWriteText).commit();
            }
        };
        this.d3resList = new int[]{R.drawable.mirror_3d_14, R.drawable.mirror_3d_14, R.drawable.mirror_3d_10, R.drawable.mirror_3d_10, R.drawable.mirror_3d_11, R.drawable.mirror_3d_11, R.drawable.mirror_3d_4, R.drawable.mirror_3d_4, R.drawable.mirror_3d_3, R.drawable.mirror_3d_3, R.drawable.mirror_3d_1, R.drawable.mirror_3d_1, R.drawable.mirror_3d_6, R.drawable.mirror_3d_6, R.drawable.mirror_3d_13, R.drawable.mirror_3d_13, R.drawable.mirror_3d_15, R.drawable.mirror_3d_15, R.drawable.mirror_3d_15, R.drawable.mirror_3d_15, R.drawable.mirror_3d_16, R.drawable.mirror_3d_16, R.drawable.mirror_3d_16, R.drawable.mirror_3d_16};
    }

    private void backButtonAlertBuilder() {
        final AlertDialog.Builder builder = new AlertDialog.Builder((Context) this);
        builder.setMessage("Would you like to save image ?").setCancelable(true).setPositiveButton("Yes", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                stickercontain.setLocked(true);
                new SaveImageTask().execute(new Object[0]);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
            }
        }).setNeutralButton("No", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                MirrorActivity.this.finish();
            }
        });
        (this.saveImageAlert = builder.create()).show();
    }

    private void clearFxAndFrame() {
        final int selectedTabIndex = this.fragmentEffect.getSelectedTabIndex();
        if (this.currentSelectedTabIndex != 3 && this.currentSelectedTabIndex != 4) {
            return;
        }
        if (selectedTabIndex == 0 || selectedTabIndex == 1) {
            this.clearViewFlipper();
        }
    }

    @SuppressLint({"NewApi"})
    private void loadInBitmap(final int n) {
        final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
        if (this.mirrorView.d3Bitmap == null || this.mirrorView.d3Bitmap.isRecycled()) {
            bitmapFactory$Options.inJustDecodeBounds = true;
            bitmapFactory$Options.inMutable = true;
            BitmapFactory.decodeResource(this.getResources(), n, bitmapFactory$Options);
            this.mirrorView.d3Bitmap = Bitmap.createBitmap(bitmapFactory$Options.outWidth, bitmapFactory$Options.outHeight, Bitmap.Config.ARGB_8888);
        }
        bitmapFactory$Options.inJustDecodeBounds = false;
        bitmapFactory$Options.inSampleSize = 1;
        bitmapFactory$Options.inBitmap = this.mirrorView.d3Bitmap;
        try {
            this.mirrorView.d3Bitmap = BitmapFactory.decodeResource(this.getResources(), n, bitmapFactory$Options);
        } catch (Exception ex) {
            if (this.mirrorView.d3Bitmap != null && !this.mirrorView.d3Bitmap.isRecycled()) {
                this.mirrorView.d3Bitmap.recycle();
            }
            this.mirrorView.d3Bitmap = BitmapFactory.decodeResource(this.getResources(), n);
        }
    }

    private void set3dMode(final int d3ButtonBg) {
        this.mirrorView.d3Mode = true;
        if (d3ButtonBg > 15 && d3ButtonBg < 20) {
            this.mirrorView.setCurrentMode(d3ButtonBg);
        } else if (d3ButtonBg > 19) {
            this.mirrorView.setCurrentMode(d3ButtonBg - 4);
        } else if (d3ButtonBg % 2 == 0) {
            this.mirrorView.setCurrentMode(0);
        } else {
            this.mirrorView.setCurrentMode(1);
        }
        this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, false);
        if (Build.VERSION.SDK_INT < 11) {
            if (this.mirrorView.d3Bitmap != null && !this.mirrorView.d3Bitmap.isRecycled()) {
                this.mirrorView.d3Bitmap.recycle();
            }
            this.mirrorView.d3Bitmap = BitmapFactory.decodeResource(this.getResources(), this.d3resList[d3ButtonBg]);
        } else {
            this.loadInBitmap(this.d3resList[d3ButtonBg]);
        }
        this.mirrorView.postInvalidate();
        this.setD3ButtonBg(d3ButtonBg);
    }

    private void setD3ButtonBg(int i) {
        int i2 = 0;
        if (this.d3ButtonArray == null) {
            this.d3ButtonArray = new ImageView[this.D3_BUTTON_SIZE];
            this.d3ButtonArray[0] = (ImageView) findViewById(R.id.button_3d_1);
            this.d3ButtonArray[1] = (ImageView) findViewById(R.id.button_3d_2);
            this.d3ButtonArray[2] = (ImageView) findViewById(R.id.button_3d_3);
            this.d3ButtonArray[3] = (ImageView) findViewById(R.id.button_3d_4);
            this.d3ButtonArray[4] = (ImageView) findViewById(R.id.button_3d_5);
            this.d3ButtonArray[5] = (ImageView) findViewById(R.id.button_3d_6);
            this.d3ButtonArray[6] = (ImageView) findViewById(R.id.button_3d_7);
            this.d3ButtonArray[7] = (ImageView) findViewById(R.id.button_3d_8);
            this.d3ButtonArray[8] = (ImageView) findViewById(R.id.button_3d_9);
            this.d3ButtonArray[9] = (ImageView) findViewById(R.id.button_3d_10);
            this.d3ButtonArray[10] = (ImageView) findViewById(R.id.button_3d_11);
            this.d3ButtonArray[11] = (ImageView) findViewById(R.id.button_3d_12);
            this.d3ButtonArray[12] = (ImageView) findViewById(R.id.button_3d_13);
            this.d3ButtonArray[13] = (ImageView) findViewById(R.id.button_3d_14);
            this.d3ButtonArray[14] = (ImageView) findViewById(R.id.button_3d_15);
            this.d3ButtonArray[15] = (ImageView) findViewById(R.id.button_3d_16);
            this.d3ButtonArray[16] = (ImageView) findViewById(R.id.button_3d_17);
            this.d3ButtonArray[17] = (ImageView) findViewById(R.id.button_3d_18);
            this.d3ButtonArray[18] = (ImageView) findViewById(R.id.button_3d_19);
            this.d3ButtonArray[19] = (ImageView) findViewById(R.id.button_3d_20);
            this.d3ButtonArray[20] = (ImageView) findViewById(R.id.button_3d_21);
            this.d3ButtonArray[21] = (ImageView) findViewById(R.id.button_3d_22);
            this.d3ButtonArray[22] = (ImageView) findViewById(R.id.button_3d_23);
            this.d3ButtonArray[23] = (ImageView) findViewById(R.id.button_3d_24);
        }
        while (i2 < this.D3_BUTTON_SIZE) {
            this.d3ButtonArray[i2].setBackgroundColor(getResources().getColor(R.color.gradient_start));
            i2++;
        }
        this.d3ButtonArray[i].setBackgroundColor(getResources().getColor(R.color.footer_button_color_pressed));
    }

    private void setMirrorButtonBg(int i) {
        int i2 = 0;
        if (this.mirrorButtonArray == null) {
            this.mirrorButtonArray = new ImageView[this.MIRROR_BUTTON_SIZE];
            this.mirrorButtonArray[0] = (ImageView) findViewById(R.id.button_m1);
            this.mirrorButtonArray[1] = (ImageView) findViewById(R.id.button_m2);
            this.mirrorButtonArray[2] = (ImageView) findViewById(R.id.button_m3);
            this.mirrorButtonArray[3] = (ImageView) findViewById(R.id.button_m4);
            this.mirrorButtonArray[4] = (ImageView) findViewById(R.id.button_m5);
            this.mirrorButtonArray[5] = (ImageView) findViewById(R.id.button_m6);
            this.mirrorButtonArray[6] = (ImageView) findViewById(R.id.button_m7);
            this.mirrorButtonArray[7] = (ImageView) findViewById(R.id.button_m8);
            this.mirrorButtonArray[8] = (ImageView) findViewById(R.id.button_m9);
            this.mirrorButtonArray[9] = (ImageView) findViewById(R.id.button_m10);
            this.mirrorButtonArray[10] = (ImageView) findViewById(R.id.button_m11);
            this.mirrorButtonArray[11] = (ImageView) findViewById(R.id.button_m12);
            this.mirrorButtonArray[12] = (ImageView) findViewById(R.id.button_m13);
            this.mirrorButtonArray[13] = (ImageView) findViewById(R.id.button_m14);
            this.mirrorButtonArray[14] = (ImageView) findViewById(R.id.button_m15);
        }
        while (i2 < this.MIRROR_BUTTON_SIZE) {
            this.mirrorButtonArray[i2].setBackgroundResource(R.color.gradient_start);
            i2++;
        }
        this.mirrorButtonArray[i].setBackgroundResource(R.color.mirror_button_color);
    }

    private void setRatioButtonBg(int i) {
        int i2 = 0;
        if (this.ratioButtonArray == null) {
            this.ratioButtonArray = new Button[this.RATIO_BUTTON_SIZE];
            this.ratioButtonArray[0] = (Button) findViewById(R.id.button11);
            this.ratioButtonArray[1] = (Button) findViewById(R.id.button21);
            this.ratioButtonArray[2] = (Button) findViewById(R.id.button12);
            this.ratioButtonArray[3] = (Button) findViewById(R.id.button32);
            this.ratioButtonArray[4] = (Button) findViewById(R.id.button23);
            this.ratioButtonArray[5] = (Button) findViewById(R.id.button43);
            this.ratioButtonArray[6] = (Button) findViewById(R.id.button34);
            this.ratioButtonArray[7] = (Button) findViewById(R.id.button45);
            this.ratioButtonArray[8] = (Button) findViewById(R.id.button57);
            this.ratioButtonArray[9] = (Button) findViewById(R.id.button169);
            this.ratioButtonArray[10] = (Button) findViewById(R.id.button916);
        }
        while (i2 < this.RATIO_BUTTON_SIZE) {
            this.ratioButtonArray[i2].setBackgroundResource(R.drawable.selector_collage_ratio_button);
            i2++;
        }
        this.ratioButtonArray[i].setBackgroundResource(R.drawable.collage_ratio_bg_pressed);
    }

    private void setTabBg(int i) {
        this.currentSelectedTabIndex = i;
        int i2 = 0;
        if (this.tabButtonList == null) {
            this.tabButtonList = new View[6];
            this.tabButtonList[0] = findViewById(R.id.button_mirror);
            this.tabButtonList[1] = findViewById(R.id.button_mirror_3d);
            this.tabButtonList[3] = findViewById(R.id.button_mirror_effect);
            this.tabButtonList[2] = findViewById(R.id.button_mirror_ratio);
            this.tabButtonList[4] = findViewById(R.id.button_mirror_frame);
            this.tabButtonList[5] = findViewById(R.id.button_mirror_adj);
        }
    }

    void CanvasTextView() {
        (this.customRelativeLayout = new CustomRelativeLayout((Context) this, this.textDataList, this.mirrorView.f510I, new SingleTapInterface() {
            @Override
            public void onSingleTap(final TextDataItem textDataItem) {
                MirrorActivity.this.fragmentWriteText = new FragmentWriteText();
                final Bundle arguments = new Bundle();
                arguments.putSerializable("text_data", (Serializable) textDataItem);
                MirrorActivity.this.fragmentWriteText.setArguments(arguments);
                MirrorActivity.this.getSupportFragmentManager().beginTransaction().replace(R.id.text_view_fragment_container, MirrorActivity.this.fragmentWriteText, "FONT_FRAGMENT").commit();
                Log.e("MirrorActivity", "replace fragment");
                MirrorActivity.this.fragmentWriteText.setFontChoosedListener(MirrorActivity.this.fontChoosedListener);
            }
        })).setApplyTextListener(new ApplyTextInterface() {
            @Override
            public void onCancel() {
                MirrorActivity.this.showText = true;
                MirrorActivity.this.mainLayout.removeView((View) MirrorActivity.this.customRelativeLayout);
                MirrorActivity.this.mirrorView.postInvalidate();
            }

            @Override
            public void onOk(final ArrayList<TextDataItem> textDataList) {
                final Iterator<TextDataItem> iterator = textDataList.iterator();
                while (iterator.hasNext()) {
                    iterator.next().setImageSaveMatrix(MirrorActivity.this.mirrorView.f510I);
                }
                MirrorActivity.this.textDataList = textDataList;
                MirrorActivity.this.showText = true;
                if (MirrorActivity.this.mainLayout == null) {
                    MirrorActivity.this.mainLayout = MirrorActivity.this.findViewById(R.id.layout_mirror_activity);
                }
                MirrorActivity.this.mainLayout.removeView((View) MirrorActivity.this.customRelativeLayout);
                MirrorActivity.this.mirrorView.postInvalidate();
            }
        });
        this.showText = false;
        this.mirrorView.invalidate();
        this.mainLayout.addView((View) this.customRelativeLayout);
        this.findViewById(R.id.text_view_fragment_container).bringToFront();
        (this.fragmentWriteText = new FragmentWriteText()).setArguments(new Bundle());
        this.getSupportFragmentManager().beginTransaction().add(R.id.text_view_fragment_container, this.fragmentWriteText, "FONT_FRAGMENT").commit();
        this.fragmentWriteText.setFontChoosedListener(this.fontChoosedListener);
    }

    void EffectFragment() {
        if (this.fragmentEffect == null) {
            this.fragmentEffect = (FragmentEffect) this.getSupportFragmentManager().findFragmentByTag("MY_EFFECT_FRAGMENT");
            if (this.fragmentEffect == null) {
                this.fragmentEffect = new FragmentEffect();
                this.fragmentEffect.setBitmap(this.sourceBitmap);
                this.fragmentEffect.setArguments(this.getIntent().getExtras());
                this.getSupportFragmentManager().beginTransaction().add(R.id.mirror_effect_fragment_container, this.fragmentEffect, "MY_EFFECT_FRAGMENT").commit();
            } else {
                this.fragmentEffect.setBitmap(this.sourceBitmap);
                this.fragmentEffect.setSelectedTabIndex(0);
            }
            this.fragmentEffect.setBitmapReadyListener((FragmentEffect.BitmapReady) new FragmentEffect.BitmapReady() {
                @Override
                public void onBitmapReady(final Bitmap filterBitmap) {
                    MirrorActivity.this.filterBitmap = filterBitmap;
                    MirrorActivity.this.mirrorView.postInvalidate();
                }
            });
            this.fragmentEffect.setBorderIndexChangedListener(new RecyclerViewAdapter.RecyclerAdapterIndexChangedListener() {
                @Override
                public void onIndexChanged(final int frame) {
                    MirrorActivity.this.mirrorView.setFrame(frame);
                }
            });
        }
    }

    protected void clearViewFlipper() {
        this.viewFlipper.setInAnimation((Animation) null);
        this.viewFlipper.setOutAnimation((Animation) null);
        this.viewFlipper.setDisplayedChild(4);
        this.setTabBg(-1);
    }


    public void myClickHandler(final View view) {
        final int id = view.getId();
        this.mirrorView.drawSavedImage = false;
        if (id == R.id.button_save_mirror_image) {
            if (this.analytics != null) {
                this.analytics.logEvent("MIRROR_SAVE_IMAGE", "");
            }
            stickercontain.setLocked(true);
            new SaveImageTask().execute(new Object[0]);
            return;
        }
        if (id == R.id.closeScreen) {
            this.backButtonAlertBuilder();
            return;
        }
        if (id == R.id.button_mirror) {
            if (this.analytics != null) {
                this.SelectedTab(0);
            }
            this.analytics.logEvent(Analytics.Param.MIRROR_MENU[0], "");
            return;
        }
        if (id == R.id.button_mirror_frame) {
            this.SelectedTab(4);
            this.analytics.logEvent(Analytics.Param.MIRROR_MENU[4], "");
            return;
        }
        if (id == R.id.button_mirror_ratio) {
            this.SelectedTab(2);
            this.analytics.logEvent(Analytics.Param.MIRROR_MENU[2], "");
            return;
        }
        if (id == R.id.button_mirror_effect) {
            this.SelectedTab(3);
            this.analytics.logEvent(Analytics.Param.MIRROR_MENU[3], "");
            return;
        }
        if (id == R.id.button_mirror_adj) {
            this.SelectedTab(5);
            this.analytics.logEvent(Analytics.Param.MIRROR_MENU[5], "");
        } else {
            if (id == R.id.button_mirror_3d) {
                this.SelectedTab(1);
                this.analytics.logEvent(Analytics.Param.MIRROR_MENU[1], "");
                return;
            }
            if (id == R.id.button_3d_1) {
                this.set3dMode(0);
                return;
            }
            if (id == R.id.button_3d_2) {
                this.set3dMode(1);
                return;
            }
            if (id == R.id.button_3d_3) {
                this.set3dMode(2);
                return;
            }
            if (id == R.id.button_3d_4) {
                this.set3dMode(3);
                return;
            }
            if (id == R.id.button_3d_5) {
                this.set3dMode(4);
                return;
            }
            if (id == R.id.button_3d_6) {
                this.set3dMode(5);
                return;
            }
            if (id == R.id.button_3d_7) {
                this.set3dMode(6);
                return;
            }
            if (id == R.id.button_3d_8) {
                this.set3dMode(7);
                return;
            }
            if (id == R.id.button_3d_9) {
                this.set3dMode(8);
                return;
            }
            if (id == R.id.button_3d_10) {
                this.set3dMode(9);
                return;
            }
            if (id == R.id.button_3d_11) {
                this.set3dMode(10);
                return;
            }
            if (id == R.id.button_3d_12) {
                this.set3dMode(11);
                return;
            }
            if (id == R.id.button_3d_13) {
                this.set3dMode(12);
                return;
            }
            if (id == R.id.button_3d_14) {
                this.set3dMode(13);
                return;
            }
            if (id == R.id.button_3d_15) {
                this.set3dMode(14);
                return;
            }
            if (id == R.id.button_3d_16) {
                this.set3dMode(15);
                return;
            }
            if (id == R.id.button_3d_17) {
                this.set3dMode(16);
                return;
            }
            if (id == R.id.button_3d_18) {
                this.set3dMode(17);
                return;
            }
            if (id == R.id.button_3d_19) {
                this.set3dMode(18);
                return;
            }
            if (id == R.id.button_3d_20) {
                this.set3dMode(19);
                return;
            }
            if (id == R.id.button_3d_21) {
                this.set3dMode(20);
                return;
            }
            if (id == R.id.button_3d_22) {
                this.set3dMode(21);
                return;
            }
            if (id == R.id.button_3d_23) {
                this.set3dMode(22);
                return;
            }
            if (id == R.id.button_3d_24) {
                this.set3dMode(23);
                return;
            }
            if (id == R.id.button11) {
                this.mulX = 1.0f;
                this.mulY = 1.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(0);
                return;
            }
            if (id == R.id.button21) {
                this.mulX = 2.0f;
                this.mulY = 1.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(1);
                return;
            }
            if (id == R.id.button12) {
                this.mulX = 1.0f;
                this.mulY = 2.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(2);
                return;
            }
            if (id == R.id.button32) {
                this.mulX = 3.0f;
                this.mulY = 2.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(3);
                return;
            }
            if (id == R.id.button23) {
                this.mulX = 2.0f;
                this.mulY = 3.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(4);
                return;
            }
            if (id == R.id.button43) {
                this.mulX = 4.0f;
                this.mulY = 3.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(5);
                return;
            }
            if (id == R.id.button34) {
                this.mulX = 3.0f;
                this.mulY = 4.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(6);
                return;
            }
            if (id == R.id.button45) {
                this.mulX = 4.0f;
                this.mulY = 5.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(7);
                return;
            }
            if (id == R.id.button57) {
                this.mulX = 5.0f;
                this.mulY = 7.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(8);
                return;
            }
            if (id == R.id.button169) {
                this.mulX = 16.0f;
                this.mulY = 9.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(9);
                return;
            }
            if (id == R.id.button916) {
                this.mulX = 9.0f;
                this.mulY = 16.0f;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setRatioButtonBg(10);
                return;
            }
            if (id == R.id.button_m1) {
                this.mirrorView.setCurrentMode(0);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(0);
                return;
            }
            if (id == R.id.button_m2) {
                this.mirrorView.setCurrentMode(1);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(1);
                return;
            }
            if (id == R.id.button_m3) {
                this.mirrorView.setCurrentMode(2);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(2);
                return;
            }
            if (id == R.id.button_m4) {
                this.mirrorView.setCurrentMode(3);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(3);
                return;
            }
            if (id == R.id.button_m5) {
                this.mirrorView.setCurrentMode(4);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(4);
                return;
            }
            if (id == R.id.button_m6) {
                this.mirrorView.setCurrentMode(5);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(5);
                return;
            }
            if (id == R.id.button_m7) {
                this.mirrorView.setCurrentMode(6);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(6);
                return;
            }
            if (id == R.id.button_m8) {
                this.mirrorView.setCurrentMode(7);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(7);
                return;
            }
            if (id == R.id.button_m9) {
                this.mirrorView.setCurrentMode(8);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(8);
                return;
            }
            if (id == R.id.button_m10) {
                this.mirrorView.setCurrentMode(9);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(9);
                return;
            }
            if (id == R.id.button_m11) {
                this.mirrorView.setCurrentMode(10);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(10);
                return;
            }
            if (id == R.id.button_m12) {
                this.mirrorView.setCurrentMode(11);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(11);
                return;
            }
            if (id == R.id.button_m13) {
                this.mirrorView.setCurrentMode(12);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(12);
                return;
            }
            if (id == R.id.button_m14) {
                this.mirrorView.setCurrentMode(13);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(13);
                return;
            }
            if (id == R.id.button_m15) {
                this.mirrorView.setCurrentMode(14);
                this.mirrorView.d3Mode = false;
                this.mirrorView.reset(this.screenWidthPixels, this.screenHeightPixels, true);
                this.setMirrorButtonBg(14);
                return;
            }
            if (id == R.id.button_mirror_text) {
                this.CanvasTextView();
                this.clearViewFlipper();
                return;
            }
            this.fragmentEffect.myClickHandler(id);
            if (id == R.id.buttonCancel || id == R.id.buttonOk) {
                this.clearFxAndFrame();
            }
        }
    }

    @Override
    protected void onActivityResult(int i, final int n, final Intent intent) {
        super.onActivityResult(i, n, intent);
        if (i == 112 && n == -1 && intent.getExtras() != null) {
            final Bundle extras = intent.getExtras();
            this.mirrorView.invalidate();
            this.stickercontain.bringToFront();
            final int[] intArray = extras.getIntArray("MyArray");
            BitmapFactory.decodeResource(this.getResources(), R.drawable.sticker_remove_text);
            BitmapFactory.decodeResource(this.getResources(), R.drawable.sticker_scale_text);
            StringBuilder sb;
            DrawableSticker drawableSticker;
            if (this.mainLayout == null) {
                this.mainLayout = this.findViewById(R.id.layout_mirror_activity);
            }
            for (i = 0; i < intArray.length; ++i) {
                sb = new StringBuilder();
                sb.append("");
                sb.append(BitmapFactory.decodeResource(this.getResources(), intArray[i]));

                drawableSticker = new DrawableSticker(ContextCompat.getDrawable((Context) this, intArray[i]));
                this.stickercontain.addSticker(drawableSticker);
                this.stickerlist.add(drawableSticker);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (this.fragmentWriteText != null && this.fragmentWriteText.isVisible()) {
            this.getSupportFragmentManager().beginTransaction().remove(this.fragmentWriteText).commit();
            return;
        }
        if (this.viewFlipper.getDisplayedChild() == 3) {
            this.clearFxAndFrame();
            this.clearViewFlipper();
            return;
        }
        if (!this.showText && this.customRelativeLayout != null) {
            this.showText = true;
            this.mainLayout.removeView((View) this.customRelativeLayout);
            this.mirrorView.postInvalidate();
            this.customRelativeLayout = null;
            Log.e("MirrorActivity", "replace fragment");
            return;
        }
        if (this.viewFlipper.getDisplayedChild() != 4) {
            this.clearViewFlipper();
            return;
        }
        this.backButtonAlertBuilder();
    }

    @SuppressLint({"NewApi"})
    @Override
    protected void onCreate(Bundle extras) {
        super.onCreate(extras);
        this.getWindow().addFlags(1024);
        extras = this.getIntent().getExtras();
        this.sourceBitmap = BitmapResizer.decodeBitmapFromFile(extras.getString("selectedImagePath"), extras.getInt("MAX_SIZE"));
        if (this.sourceBitmap == null) {
            final Toast text = Toast.makeText((Context) this, (CharSequence) "Could not load the photo, please use another GALLERY app!", Toast.LENGTH_SHORT);
            text.setGravity(17, text.getXOffset() / 2, text.getYOffset() / 2);
            text.show();
            this.finish();
            return;
        }
        final DisplayMetrics displayMetrics = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.screenHeightPixels = displayMetrics.heightPixels;
        this.screenWidthPixels = displayMetrics.widthPixels;
        final Display defaultDisplay = this.getWindowManager().getDefaultDisplay();
        final int width = defaultDisplay.getWidth();
        final int height = defaultDisplay.getHeight();
        if (this.screenWidthPixels <= 0) {
            this.screenWidthPixels = width;
        }
        if (this.screenHeightPixels <= 0) {
            this.screenHeightPixels = height;
        }
        this.mirrorView = new MirrorView((Context) this, this.screenWidthPixels, this.screenHeightPixels);
        this.setContentView(R.layout.activity_mirror);
        this.stickercontain = this.findViewById(R.id.stickercontain);
        this.stickerwww = this.findViewById(R.id.buttonSticker);
        @SuppressLint("WrongConstant") final BitmapStickerIcon bitmapStickerIcon = new BitmapStickerIcon(ContextCompat.getDrawable((Context) this, R.drawable.sticker_ic_close_white_18dp), 0);
        bitmapStickerIcon.setIconEvent(new DeleteIconEvent());
        @SuppressLint("WrongConstant") final BitmapStickerIcon bitmapStickerIcon2 = new BitmapStickerIcon(ContextCompat.getDrawable((Context) this, R.drawable.sticker_ic_scale_white_18dp), 3);
        bitmapStickerIcon2.setIconEvent(new ZoomIconEvent());
        @SuppressLint("WrongConstant") final BitmapStickerIcon bitmapStickerIcon3 = new BitmapStickerIcon(ContextCompat.getDrawable((Context) this, R.drawable.sticker_ic_flip_white_18dp), 1);
        bitmapStickerIcon3.setIconEvent(new FlipHorizontallyEvent());
        this.stickercontain.setIcons(Arrays.asList(bitmapStickerIcon, bitmapStickerIcon2, bitmapStickerIcon3));
        this.stickerwww.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                MirrorActivity.this.startActivityForResult(new Intent((Context) MirrorActivity.this, (Class) StickerActivity.class), 112);
            }
        });
        loadAd();
        this.stickercontain.setOnStickerOperationListener((StickerView.OnStickerOperationListener) new StickerView.OnStickerOperationListener() {
            @Override
            public void onStickerAdded(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerClicked(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerDeleted(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerDoubleTapped(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerDragFinished(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerFlipped(@NonNull final Sticker sticker) {
            }

            public void onStickerNotClicked() {
                MirrorActivity.this.stickercontain.invalidate();
            }

            @Override
            public void onStickerZoomFinished(@NonNull final Sticker sticker) {
            }
        });
        final LinearLayout linearLayout = this.findViewById(R.id.linearAds);
        linearLayout.setVisibility(View.GONE);
        (this.mainLayout = this.findViewById(R.id.layout_mirror_activity)).addView((View) this.mirrorView);
        (this.viewFlipper = this.findViewById(R.id.mirror_view_flipper)).bringToFront();
        this.findViewById(R.id.mirror_footer).bringToFront();
        this.slideLeftIn = AnimationUtils.loadAnimation((Context) this, R.anim.slide_in_left);
        this.slideLeftOut = AnimationUtils.loadAnimation((Context) this, R.anim.slide_out_left);
        this.slideRightIn = AnimationUtils.loadAnimation((Context) this, R.anim.slide_in_right);
        this.slideRightOut = AnimationUtils.loadAnimation((Context) this, R.anim.slide_out_right);
        this.analytics = new Analytics((Context) this);
        this.findViewById(R.id.mirror_header).bringToFront();
        this.findViewById(R.id.linearAds).bringToFront();
        this.EffectFragment();
        this.SelectedTab(0);

        final HorizontalScrollView horizontalScrollView = (HorizontalScrollView) this.findViewById(R.id.collage_footer);
        horizontalScrollView.bringToFront();
        horizontalScrollView.postDelayed((Runnable) new Runnable() {
            @Override
            public void run() {
                horizontalScrollView.scrollTo(horizontalScrollView.getChildAt(0).getMeasuredWidth(), 0);
            }
        }, 50L);
        horizontalScrollView.postDelayed((Runnable) new Runnable() {
            @Override
            public void run() {
                horizontalScrollView.fullScroll(17);
            }
        }, 600L);
    }

    private InterstitialAd interstitialAd;
    String resultPathCopy;
    private int id;

    private void loadAd() {
        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {

            public void onAdLoaded() {
                super.onAdLoaded();
            }

            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.closeScreen:
                        final Intent intent = new Intent((Context) MirrorActivity.this, (Class) ShareActivity.class);
                        intent.putExtra("imagePath", resultPathCopy);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        MirrorActivity.this.startActivity(intent);
                        break;
                }
                interstitialAd.loadAd(adRequestfull);
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(MirrorActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.sourceBitmap != null) {
            this.sourceBitmap.recycle();
        }
        if (this.filterBitmap != null) {
            this.filterBitmap.recycle();
        }
    }

    public void onPause() {
        super.onPause();
    }

    public void onRestoreInstanceState(final Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.showText = bundle.getBoolean("show_text");
        this.textDataList = (ArrayList<TextDataItem>) bundle.getSerializable("text_data");
        if (this.textDataList == null) {
            this.textDataList = new ArrayList<TextDataItem>();
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onSaveInstanceState(final Bundle bundle) {
        bundle.putBoolean("show_text", this.showText);
        bundle.putSerializable("text_data", (Serializable) this.textDataList);
        if (this.fragmentWriteText != null && this.fragmentWriteText.isVisible()) {
            this.getSupportFragmentManager().beginTransaction().remove(this.fragmentWriteText).commit();
        }
        super.onSaveInstanceState(bundle);
    }

    protected void SelectedTab(final int n) {
        this.setTabBg(0);
        final int displayedChild = this.viewFlipper.getDisplayedChild();
        if (n == 0) {
            if (displayedChild == 0) {
                return;
            }
            this.viewFlipper.setInAnimation(this.slideLeftIn);
            this.viewFlipper.setOutAnimation(this.slideRightOut);
            this.viewFlipper.setDisplayedChild(0);
        }
        if (n == 1) {
            this.setTabBg(1);
            if (displayedChild == 1) {
                return;
            }
            if (displayedChild == 0) {
                this.viewFlipper.setInAnimation(this.slideRightIn);
                this.viewFlipper.setOutAnimation(this.slideLeftOut);
            } else {
                this.viewFlipper.setInAnimation(this.slideLeftIn);
                this.viewFlipper.setOutAnimation(this.slideRightOut);
            }
            this.viewFlipper.setDisplayedChild(1);
        }
        if (n == 2) {
            this.setTabBg(2);
            if (displayedChild == 2) {
                return;
            }
            if (displayedChild == 0) {
                this.viewFlipper.setInAnimation(this.slideRightIn);
                this.viewFlipper.setOutAnimation(this.slideLeftOut);
            } else {
                this.viewFlipper.setInAnimation(this.slideLeftIn);
                this.viewFlipper.setOutAnimation(this.slideRightOut);
            }
            this.viewFlipper.setDisplayedChild(2);
        }
        if (n == 3) {
            this.setTabBg(3);
            this.fragmentEffect.setSelectedTabIndex(0);
            if (displayedChild == 3) {
                return;
            }
            if (displayedChild != 0 && displayedChild != 2) {
                this.viewFlipper.setInAnimation(this.slideLeftIn);
                this.viewFlipper.setOutAnimation(this.slideRightOut);
            } else {
                this.viewFlipper.setInAnimation(this.slideRightIn);
                this.viewFlipper.setOutAnimation(this.slideLeftOut);
            }
            this.viewFlipper.setDisplayedChild(3);
        }
        if (n == 4) {
            this.setTabBg(4);
            this.fragmentEffect.setSelectedTabIndex(1);
            if (displayedChild == 3) {
                return;
            }
            if (displayedChild == 5) {
                this.viewFlipper.setInAnimation(this.slideLeftIn);
                this.viewFlipper.setOutAnimation(this.slideRightOut);
            } else {
                this.viewFlipper.setInAnimation(this.slideRightIn);
                this.viewFlipper.setOutAnimation(this.slideLeftOut);
            }
            this.viewFlipper.setDisplayedChild(3);
        }
        if (n == 5) {
            this.setTabBg(5);
            this.fragmentEffect.showToolBar();
            if (displayedChild == 3) {
                return;
            }
            this.viewFlipper.setInAnimation(this.slideRightIn);
            this.viewFlipper.setOutAnimation(this.slideLeftOut);
            this.viewFlipper.setDisplayedChild(3);
        }
        if (n == 7) {
            this.setTabBg(-1);
            if (displayedChild != 4) {
                this.viewFlipper.setInAnimation(this.slideRightIn);
                this.viewFlipper.setOutAnimation(this.slideLeftOut);
                this.viewFlipper.setDisplayedChild(4);
            }
        }
    }

    public class MirrorView extends View {
        int currentModeIndex;
        Bitmap d3Bitmap;
        boolean d3Mode;
        int defaultColor;
        RectF destRect1;
        RectF destRect1X;
        RectF destRect1Y;
        RectF destRect2;
        RectF destRect2X;
        RectF destRect2Y;
        RectF destRect3;
        RectF destRect4;
        boolean drawSavedImage;
        RectF dstRectPaper1;
        RectF dstRectPaper2;
        RectF dstRectPaper3;
        RectF dstRectPaper4;
        final Matrix f510I;
        Bitmap frameBitmap;
        Paint framePaint;
        int height;
        boolean isTouchStartedLeft;
        boolean isTouchStartedTop;
        boolean isVerticle;
        Matrix m1;
        Matrix m2;
        Matrix m3;
        MirrorImageMode[] mirrorModeList;
        MirrorImageMode modeX;
        MirrorImageMode modeX10;
        MirrorImageMode modeX11;
        MirrorImageMode modeX12;
        MirrorImageMode modeX13;
        MirrorImageMode modeX14;
        MirrorImageMode modeX15;
        MirrorImageMode modeX16;
        MirrorImageMode modeX17;
        MirrorImageMode modeX18;
        MirrorImageMode modeX19;
        MirrorImageMode modeX2;
        MirrorImageMode modeX20;
        MirrorImageMode modeX3;
        MirrorImageMode modeX4;
        MirrorImageMode modeX5;
        MirrorImageMode modeX6;
        MirrorImageMode modeX7;
        MirrorImageMode modeX8;
        MirrorImageMode modeX9;
        float oldX;
        float oldY;
        RectF srcRect1;
        RectF srcRect2;
        RectF srcRect3;
        RectF srcRectPaper;
        int tMode1;
        int tMode2;
        int tMode3;
        Matrix textMatrix;
        Paint textRectPaint;
        RectF totalArea1;
        RectF totalArea2;
        RectF totalArea3;
        int width;

        public MirrorView(final Context context, final int n, final int n2) {
            super(context);
            this.f510I = new Matrix();
            this.framePaint = new Paint();
            this.isVerticle = false;
            this.defaultColor = R.color.bg;
            this.mirrorModeList = new MirrorImageMode[20];
            this.currentModeIndex = 0;
            this.drawSavedImage = false;
            this.d3Mode = false;
            this.textMatrix = new Matrix();
            this.textRectPaint = new Paint(1);
            this.m1 = new Matrix();
            this.m2 = new Matrix();
            this.m3 = new Matrix();
            this.width = MirrorActivity.this.sourceBitmap.getWidth();
            this.height = MirrorActivity.this.sourceBitmap.getHeight();
            this.createMatrix(n, n2);
            this.createRectX(n, n2);
            this.createRectY(n, n2);
            this.createRectXY(n, n2);
            this.createModes();
            this.framePaint.setAntiAlias(true);
            this.framePaint.setFilterBitmap(true);
            this.framePaint.setDither(true);
            this.textRectPaint.setColor(this.getResources().getColor(R.color.bg));
        }

        private void createMatrix(final int n, final int n2) {
            this.f510I.reset();
            MirrorActivity.this.matrix1.reset();
            MirrorActivity.this.matrix1.postScale(-1.0f, 1.0f);
            final Matrix matrix1 = MirrorActivity.this.matrix1;
            final float n3 = n;
            matrix1.postTranslate(n3, 0.0f);
            MirrorActivity.this.matrix2.reset();
            MirrorActivity.this.matrix2.postScale(1.0f, -1.0f);
            final Matrix matrix2 = MirrorActivity.this.matrix2;
            final float n4 = n2;
            matrix2.postTranslate(0.0f, n4);
            MirrorActivity.this.matrix3.reset();
            MirrorActivity.this.matrix3.postScale(-1.0f, -1.0f);
            MirrorActivity.this.matrix3.postTranslate(n3, n4);
        }

        private void createModes() {
            this.modeX = new MirrorImageMode(4, this.srcRect3, this.destRect1, this.destRect1, this.destRect3, this.destRect3, MirrorActivity.this.matrix1, this.f510I, MirrorActivity.this.matrix1, this.tMode3, this.totalArea3);
            this.modeX2 = new MirrorImageMode(4, this.srcRect3, this.destRect1, this.destRect4, this.destRect1, this.destRect4, MirrorActivity.this.matrix1, MirrorActivity.this.matrix1, this.f510I, this.tMode3, this.totalArea3);
            this.modeX3 = new MirrorImageMode(4, this.srcRect3, this.destRect3, this.destRect2, this.destRect3, this.destRect2, MirrorActivity.this.matrix1, MirrorActivity.this.matrix1, this.f510I, this.tMode3, this.totalArea3);
            this.modeX8 = new MirrorImageMode(4, this.srcRect3, this.destRect1, this.destRect1, this.destRect1, this.destRect1, MirrorActivity.this.matrix1, MirrorActivity.this.matrix2, MirrorActivity.this.matrix3, this.tMode3, this.totalArea3);
            int n;
            if (this.tMode3 == 0) {
                n = 0;
            } else {
                n = 4;
            }
            this.modeX9 = new MirrorImageMode(4, this.srcRect3, this.destRect2, this.destRect2, this.destRect2, this.destRect2, MirrorActivity.this.matrix1, MirrorActivity.this.matrix2, MirrorActivity.this.matrix3, n, this.totalArea3);
            int n2;
            if (this.tMode3 == 1) {
                n2 = 1;
            } else {
                n2 = 3;
            }
            this.modeX10 = new MirrorImageMode(4, this.srcRect3, this.destRect3, this.destRect3, this.destRect3, this.destRect3, MirrorActivity.this.matrix1, MirrorActivity.this.matrix2, MirrorActivity.this.matrix3, n2, this.totalArea3);
            int n3;
            if (this.tMode3 == 0) {
                n3 = 3;
            } else {
                n3 = 4;
            }
            this.modeX11 = new MirrorImageMode(4, this.srcRect3, this.destRect4, this.destRect4, this.destRect4, this.destRect4, MirrorActivity.this.matrix1, MirrorActivity.this.matrix2, MirrorActivity.this.matrix3, n3, this.totalArea3);
            this.modeX4 = new MirrorImageMode(2, this.srcRect1, this.destRect1X, this.destRect1X, MirrorActivity.this.matrix1, this.tMode1, this.totalArea1);
            int n4;
            if (this.tMode1 == 0) {
                n4 = 0;
            } else if (this.tMode1 == 5) {
                n4 = 5;
            } else {
                n4 = 4;
            }
            this.modeX5 = new MirrorImageMode(2, this.srcRect1, this.destRect2X, this.destRect2X, MirrorActivity.this.matrix1, n4, this.totalArea1);
            this.modeX6 = new MirrorImageMode(2, this.srcRect2, this.destRect1Y, this.destRect1Y, MirrorActivity.this.matrix2, this.tMode2, this.totalArea2);
            int n5;
            if (this.tMode2 == 1) {
                n5 = 1;
            } else if (this.tMode2 == 6) {
                n5 = 6;
            } else {
                n5 = 3;
            }
            this.modeX7 = new MirrorImageMode(2, this.srcRect2, this.destRect2Y, this.destRect2Y, MirrorActivity.this.matrix2, n5, this.totalArea2);
            this.modeX12 = new MirrorImageMode(2, this.srcRect1, this.destRect1X, this.destRect2X, MirrorActivity.this.matrix4, this.tMode1, this.totalArea1);
            this.modeX13 = new MirrorImageMode(2, this.srcRect2, this.destRect1Y, this.destRect2Y, MirrorActivity.this.matrix4, this.tMode2, this.totalArea2);
            this.modeX14 = new MirrorImageMode(2, this.srcRect1, this.destRect1X, this.destRect1X, MirrorActivity.this.matrix3, this.tMode1, this.totalArea1);
            this.modeX15 = new MirrorImageMode(2, this.srcRect2, this.destRect1Y, this.destRect1Y, MirrorActivity.this.matrix3, this.tMode2, this.totalArea2);
            this.modeX16 = new MirrorImageMode(4, this.srcRectPaper, this.dstRectPaper1, this.dstRectPaper2, this.dstRectPaper3, this.dstRectPaper4, MirrorActivity.this.matrix1, MirrorActivity.this.matrix1, this.f510I, this.tMode1, this.totalArea1);
            this.modeX17 = new MirrorImageMode(4, this.srcRectPaper, this.dstRectPaper1, this.dstRectPaper3, this.dstRectPaper3, this.dstRectPaper1, this.f510I, MirrorActivity.this.matrix1, MirrorActivity.this.matrix1, this.tMode1, this.totalArea1);
            this.modeX18 = new MirrorImageMode(4, this.srcRectPaper, this.dstRectPaper2, this.dstRectPaper4, this.dstRectPaper2, this.dstRectPaper4, this.f510I, MirrorActivity.this.matrix1, MirrorActivity.this.matrix1, this.tMode1, this.totalArea1);
            this.modeX19 = new MirrorImageMode(4, this.srcRectPaper, this.dstRectPaper1, this.dstRectPaper2, this.dstRectPaper2, this.dstRectPaper1, this.f510I, MirrorActivity.this.matrix1, MirrorActivity.this.matrix1, this.tMode1, this.totalArea1);
            this.modeX20 = new MirrorImageMode(4, this.srcRectPaper, this.dstRectPaper4, this.dstRectPaper3, this.dstRectPaper3, this.dstRectPaper4, this.f510I, MirrorActivity.this.matrix1, MirrorActivity.this.matrix1, this.tMode1, this.totalArea1);
            this.mirrorModeList[0] = this.modeX4;
            this.mirrorModeList[1] = this.modeX5;
            this.mirrorModeList[2] = this.modeX6;
            this.mirrorModeList[3] = this.modeX7;
            this.mirrorModeList[4] = this.modeX8;
            this.mirrorModeList[5] = this.modeX9;
            this.mirrorModeList[6] = this.modeX10;
            this.mirrorModeList[7] = this.modeX11;
            this.mirrorModeList[8] = this.modeX12;
            this.mirrorModeList[9] = this.modeX13;
            this.mirrorModeList[10] = this.modeX14;
            this.mirrorModeList[11] = this.modeX15;
            this.mirrorModeList[12] = this.modeX;
            this.mirrorModeList[13] = this.modeX2;
            this.mirrorModeList[14] = this.modeX3;
            this.mirrorModeList[15] = this.modeX7;
            this.mirrorModeList[16] = this.modeX17;
            this.mirrorModeList[17] = this.modeX18;
            this.mirrorModeList[18] = this.modeX19;
            this.mirrorModeList[19] = this.modeX20;
        }

        private void createRectX(int initialYPos, final int n) {
            final float n2 = initialYPos;
            float n3 = MirrorActivity.this.mulY / MirrorActivity.this.mulX * n2;
            float n4 = n2 / 2.0f;
            initialYPos = MirrorActivity.this.initialYPos;
            final float n5 = n;
            final float n6 = 0.0f;
            float n8;
            if (n3 > n5) {
                final float n7 = MirrorActivity.this.mulX / MirrorActivity.this.mulY * n5 / 2.0f;
                n8 = n4 - n7;
                n4 = n7;
                n3 = n5;
            } else {
                n8 = 0.0f;
            }
            final float n9 = MirrorActivity.this.initialYPos + (n5 - n3) / 2.0f;
            final float n10 = this.width;
            final float n11 = this.height;
            final float n12 = n4 + n8;
            final float n13 = n3 + n9;
            this.destRect1X = new RectF(n8, n9, n12, n13);
            final float n14 = n4 + n12;
            this.destRect2X = new RectF(n12, n9, n14, n13);
            this.totalArea1 = new RectF(n8, n9, n14, n13);
            this.tMode1 = 1;
            float n16;
            float n17;
            float n18;
            float n19;
            if (MirrorActivity.this.mulX * this.height <= MirrorActivity.this.mulY * 2.0f * this.width) {
                final float n15 = (this.width - MirrorActivity.this.mulX / MirrorActivity.this.mulY * this.height / 2.0f) / 2.0f;
                n16 = MirrorActivity.this.mulX / MirrorActivity.this.mulY * this.height / 2.0f + n15;
                n17 = n6;
                n18 = n11;
                n19 = n15;
            } else {
                final float n20 = (this.height - this.width * 2 * (MirrorActivity.this.mulY / MirrorActivity.this.mulX)) / 2.0f;
                final float n21 = this.width * 2;
                final float n22 = MirrorActivity.this.mulY / MirrorActivity.this.mulX;
                this.tMode1 = 5;
                final float n23 = n10;
                final float n24 = 0.0f;
                n17 = n20;
                final float n25 = n21 * n22 + n20;
                n19 = n24;
                n16 = n23;
                n18 = n25;
            }
            this.srcRect1 = new RectF(n19, n17, n16, n18);
            this.srcRectPaper = new RectF(n19, n17, (n16 - n19) / 2.0f + n19, n18);
            final float n26 = n4 / 2.0f;
            final float n27 = n26 + n8;
            this.dstRectPaper1 = new RectF(n8, n9, n27, n13);
            final float n28 = n26 + n27;
            this.dstRectPaper2 = new RectF(n27, n9, n28, n13);
            final float n29 = n26 + n28;
            this.dstRectPaper3 = new RectF(n28, n9, n29, n13);
            this.dstRectPaper4 = new RectF(n29, n9, n26 + n29, n13);
        }

        private void createRectXY(int initialYPos, final int n) {
            final float n2 = initialYPos;
            float n3 = MirrorActivity.this.mulY / MirrorActivity.this.mulX * n2 / 2.0f;
            float n4 = n2 / 2.0f;
            initialYPos = MirrorActivity.this.initialYPos;
            final float n5 = n;
            final float n6 = 0.0f;
            float n8;
            if (n3 > n5) {
                final float n7 = MirrorActivity.this.mulX / MirrorActivity.this.mulY * n5 / 2.0f;
                n8 = n4 - n7;
                n4 = n7;
                n3 = n5;
            } else {
                n8 = 0.0f;
            }
            final float n9 = MirrorActivity.this.initialYPos + (n5 - 2.0f * n3) / 2.0f;
            final float n10 = this.width;
            final float n11 = this.height;
            final float n12 = n4 + n8;
            final float n13 = n3 + n9;
            this.destRect1 = new RectF(n8, n9, n12, n13);
            final float n14 = n4 + n12;
            this.destRect2 = new RectF(n12, n9, n14, n13);
            final float n15 = n3 + n13;
            this.destRect3 = new RectF(n8, n13, n12, n15);
            this.destRect4 = new RectF(n12, n13, n14, n15);
            this.totalArea3 = new RectF(n8, n9, n14, n15);
            float n16;
            float n18;
            float n19;
            float n20;
            if (MirrorActivity.this.mulX * this.height <= MirrorActivity.this.mulY * this.width) {
                n16 = (this.width - MirrorActivity.this.mulX / MirrorActivity.this.mulY * this.height) / 2.0f;
                final float n17 = MirrorActivity.this.mulX / MirrorActivity.this.mulY * this.height + n16;
                this.tMode3 = 1;
                n18 = n6;
                n19 = n11;
                n20 = n17;
            } else {
                n18 = (this.height - this.width * (MirrorActivity.this.mulY / MirrorActivity.this.mulX)) / 2.0f;
                n19 = n18 + this.width * (MirrorActivity.this.mulY / MirrorActivity.this.mulX);
                this.tMode3 = 0;
                n16 = 0.0f;
                n20 = n10;
            }
            this.srcRect3 = new RectF(n16, n18, n20, n19);
        }

        private void createRectY(int initialYPos, final int n) {
            float n2 = initialYPos;
            float n3 = MirrorActivity.this.mulY / MirrorActivity.this.mulX * n2 / 2.0f;
            initialYPos = MirrorActivity.this.initialYPos;
            final float n4 = n;
            float n6;
            if (n3 > n4) {
                final float n5 = MirrorActivity.this.mulX / MirrorActivity.this.mulY * n4 / 2.0f;
                n6 = n2 / 2.0f - n5;
                n2 = n5;
                n3 = n4;
            } else {
                n6 = 0.0f;
            }
            final float n7 = MirrorActivity.this.initialYPos + (n4 - 2.0f * n3) / 2.0f;
            final float n8 = n2 + n6;
            final float n9 = n3 + n7;
            this.destRect1Y = new RectF(n6, n7, n8, n9);
            final float n10 = n3 + n9;
            this.destRect2Y = new RectF(n6, n9, n8, n10);
            this.totalArea2 = new RectF(n6, n7, n8, n10);
            float n11 = this.width;
            float n12 = this.height;
            this.tMode2 = 0;
            float n13;
            float n14;
            if (MirrorActivity.this.mulX * 2.0f * this.height > MirrorActivity.this.mulY * this.width) {
                n13 = (this.height - MirrorActivity.this.mulY / MirrorActivity.this.mulX * this.width / 2.0f) / 2.0f;
                n12 = MirrorActivity.this.mulY / MirrorActivity.this.mulX * this.width / 2.0f + n13;
                n14 = 0.0f;
            } else {
                n14 = (this.width - this.height * 2 * (MirrorActivity.this.mulX / MirrorActivity.this.mulY)) / 2.0f;
                n11 = this.height * 2 * (MirrorActivity.this.mulX / MirrorActivity.this.mulY) + n14;
                this.tMode2 = 6;
                n13 = 0.0f;
            }
            this.srcRect2 = new RectF(n14, n13, n11, n12);
        }

        private void drawMode(final Canvas canvas, final Bitmap bitmap, final MirrorImageMode mirrorImageMode, final Matrix matrix) {
            canvas.setMatrix(matrix);
            canvas.drawBitmap(bitmap, mirrorImageMode.getDrawBitmapSrc(), mirrorImageMode.rect1, this.framePaint);
            this.m1.set(mirrorImageMode.matrix1);
            this.m1.postConcat(matrix);
            canvas.setMatrix(this.m1);
            if (bitmap != null && !bitmap.isRecycled()) {
                canvas.drawBitmap(bitmap, mirrorImageMode.getDrawBitmapSrc(), mirrorImageMode.rect2, this.framePaint);
            }
            if (mirrorImageMode.count == 4) {
                this.m2.set(mirrorImageMode.matrix2);
                this.m2.postConcat(matrix);
                canvas.setMatrix(this.m2);
                if (bitmap != null && !bitmap.isRecycled()) {
                    canvas.drawBitmap(bitmap, mirrorImageMode.getDrawBitmapSrc(), mirrorImageMode.rect3, this.framePaint);
                }
                this.m3.set(mirrorImageMode.matrix3);
                this.m3.postConcat(matrix);
                canvas.setMatrix(this.m3);
                if (bitmap != null && !bitmap.isRecycled()) {
                    canvas.drawBitmap(bitmap, mirrorImageMode.getDrawBitmapSrc(), mirrorImageMode.rect4, this.framePaint);
                }
            }
        }

        private void reset(final int n, final int n2, final boolean b) {
            this.createMatrix(n, n2);
            this.createRectX(n, n2);
            this.createRectY(n, n2);
            this.createRectXY(n, n2);
            this.createModes();
            if (b) {
                this.postInvalidate();
            }
        }

        private String saveBitmap(final boolean b, final int n, final int n2) {
            final float n3 = Math.min(n, n2);
            final float n4 = Utils.maxSizeForSave();
            final float n5 = n4 / n3;
            final StringBuilder sb = new StringBuilder();
            sb.append("upperScale");
            sb.append(n4);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("scale");
            sb2.append(n5);
            float n6 = n5;
            if (MirrorActivity.this.mulY > MirrorActivity.this.mulX) {
                final float mulX = MirrorActivity.this.mulX;
                n6 = n5 * 1.0f / MirrorActivity.this.mulY;
            }
            float n7 = n6;
            if (n6 <= 0.0f) {
                n7 = 1.0f;
            }
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("scale");
            sb3.append(n7);
            final int round = Math.round(n * n7);
            final int round2 = Math.round(n2 * n7);
            final RectF srcRect = this.mirrorModeList[this.currentModeIndex].getSrcRect();
            this.reset(round, round2, false);
            final int round3 = Math.round(MirrorActivity.this.mirrorView.getCurrentMirrorMode().rectTotalArea.width());
            final int round4 = Math.round(MirrorActivity.this.mirrorView.getCurrentMirrorMode().rectTotalArea.height());
            int n8 = round3;
            if (round3 % 2 == 1) {
                n8 = round3 - 1;
            }
            int n9 = round4;
            if (round4 % 2 == 1) {
                n9 = round4 - 1;
            }
            final Bitmap bitmap = Bitmap.createBitmap(n8, n9, Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap);
            final Matrix matrix = new Matrix();
            matrix.reset();
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("btmWidth ");
            sb4.append(n8);
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("btmHeight ");
            sb5.append(n9);
            final float n10 = -(round - n8) / 2.0f;
            final float n11 = -(round2 - n9) / 2.0f;
            matrix.postTranslate(n10, n11);
            final MirrorImageMode mirrorImageMode = this.mirrorModeList[this.currentModeIndex];
            mirrorImageMode.setSrcRect(srcRect);
            if (MirrorActivity.this.filterBitmap == null) {
                this.drawMode(canvas, MirrorActivity.this.sourceBitmap, mirrorImageMode, matrix);
            } else {
                this.drawMode(canvas, MirrorActivity.this.filterBitmap, mirrorImageMode, matrix);
            }
            if (this.d3Mode && this.d3Bitmap != null && !this.d3Bitmap.isRecycled()) {
                canvas.setMatrix(matrix);
                canvas.drawBitmap(this.d3Bitmap, (Rect) null, this.mirrorModeList[this.currentModeIndex].rectTotalArea, this.framePaint);
            }
            if (MirrorActivity.this.textDataList != null) {
                for (int i = 0; i < MirrorActivity.this.textDataList.size(); ++i) {
                    final Matrix matrix2 = new Matrix();
                    matrix2.set((Matrix) MirrorActivity.this.textDataList.get(i).imageSaveMatrix);
                    matrix2.postScale(n7, n7);
                    matrix2.postTranslate(n10, n11);
                    canvas.setMatrix(matrix2);
                    canvas.drawText(MirrorActivity.this.textDataList.get(i).message, MirrorActivity.this.textDataList.get(i).xPos, MirrorActivity.this.textDataList.get(i).yPos, (Paint) MirrorActivity.this.textDataList.get(i).textPaint);
                }
            }
            if (this.frameBitmap != null && !this.frameBitmap.isRecycled()) {
                canvas.setMatrix(matrix);
                canvas.drawBitmap(this.frameBitmap, (Rect) null, this.mirrorModeList[this.currentModeIndex].rectTotalArea, this.framePaint);
            }
            String string = null;
            if (MirrorActivity.this.stickerlist != null) {
                MirrorActivity.this.stickercontain.setDrawingCacheEnabled(true);
                MirrorActivity.this.stickercontain.buildDrawingCache(true);
                canvas.drawBitmap(MirrorActivity.this.stickercontain.getDrawingCache(), MirrorActivity.this.stickercontain.getX(), MirrorActivity.this.stickercontain.getY(), this.framePaint);
            }
            if (b) {
                final long currentTimeMillis = System.currentTimeMillis();
                final StringBuilder sb6 = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().toString()));
                sb6.append(MirrorActivity.this.getString(R.string.directory));
                sb6.append(String.valueOf(currentTimeMillis));
                sb6.append(".jpg");
                string = sb6.toString();
                new File(string).getParentFile().mkdirs();
                try {
                    final FileOutputStream fileOutputStream = new FileOutputStream(string);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, (OutputStream) fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            bitmap.recycle();
            this.reset(n, n2, false);
            this.mirrorModeList[this.currentModeIndex].setSrcRect(srcRect);
            return string;
        }

        private void setCurrentMode(final int currentModeIndex) {
            this.currentModeIndex = currentModeIndex;
        }

        public Bitmap getBitmap() {
            this.setDrawingCacheEnabled(true);
            this.buildDrawingCache();
            final Bitmap bitmap = Bitmap.createBitmap(this.getDrawingCache());
            this.setDrawingCacheEnabled(false);
            return bitmap;
        }

        public MirrorImageMode getCurrentMirrorMode() {
            return this.mirrorModeList[this.currentModeIndex];
        }

        void moveGrid(final RectF rectF, float n, float n2) {
            if (this.mirrorModeList[this.currentModeIndex].touchMode != 1 && this.mirrorModeList[this.currentModeIndex].touchMode != 4 && this.mirrorModeList[this.currentModeIndex].touchMode != 6) {
                if (this.mirrorModeList[this.currentModeIndex].touchMode == 0 || this.mirrorModeList[this.currentModeIndex].touchMode == 3 || this.mirrorModeList[this.currentModeIndex].touchMode == 5) {
                    n = n2;
                    if (this.mirrorModeList[this.currentModeIndex].touchMode == 3) {
                        n = n2 * -1.0f;
                    }
                    n2 = n;
                    if (this.isTouchStartedTop) {
                        n2 = n;
                        if (this.mirrorModeList[this.currentModeIndex].touchMode != 5) {
                            n2 = n * -1.0f;
                        }
                    }
                    n = n2;
                    if (rectF.top + n2 < 0.0f) {
                        n = -rectF.top;
                    }
                    n2 = n;
                    if (rectF.bottom + n >= this.height) {
                        n2 = this.height - rectF.bottom;
                    }
                    rectF.top += n2;
                    rectF.bottom += n2;
                }
            } else {
                n2 = n;
                if (this.mirrorModeList[this.currentModeIndex].touchMode == 4) {
                    n2 = n * -1.0f;
                }
                n = n2;
                if (this.isTouchStartedLeft) {
                    n = n2;
                    if (this.mirrorModeList[this.currentModeIndex].touchMode != 6) {
                        n = n2 * -1.0f;
                    }
                }
                n2 = n;
                if (rectF.left + n < 0.0f) {
                    n2 = -rectF.left;
                }
                n = n2;
                if (rectF.right + n2 >= this.width) {
                    n = this.width - rectF.right;
                }
                rectF.left += n;
                rectF.right += n;
            }
        }

        public void onDraw(final Canvas canvas) {
            canvas.drawColor(this.defaultColor);
            if (MirrorActivity.this.filterBitmap == null) {
                this.drawMode(canvas, MirrorActivity.this.sourceBitmap, this.mirrorModeList[this.currentModeIndex], this.f510I);
            } else {
                this.drawMode(canvas, MirrorActivity.this.filterBitmap, this.mirrorModeList[this.currentModeIndex], this.f510I);
            }
            if (this.d3Mode && this.d3Bitmap != null && !this.d3Bitmap.isRecycled()) {
                canvas.setMatrix(this.f510I);
                canvas.drawBitmap(this.d3Bitmap, (Rect) null, this.mirrorModeList[this.currentModeIndex].rectTotalArea, this.framePaint);
            }
            if (MirrorActivity.this.showText) {
                for (int i = 0; i < MirrorActivity.this.textDataList.size(); ++i) {
                    this.textMatrix.set((Matrix) MirrorActivity.this.textDataList.get(i).imageSaveMatrix);
                    this.textMatrix.postConcat(this.f510I);
                    canvas.setMatrix(this.textMatrix);
                    canvas.drawText(MirrorActivity.this.textDataList.get(i).message, MirrorActivity.this.textDataList.get(i).xPos, MirrorActivity.this.textDataList.get(i).yPos, (Paint) MirrorActivity.this.textDataList.get(i).textPaint);
                    canvas.setMatrix(this.f510I);
                    canvas.drawRect(0.0f, 0.0f, this.mirrorModeList[this.currentModeIndex].rectTotalArea.left, (float) MirrorActivity.this.screenHeightPixels, this.textRectPaint);
                    canvas.drawRect(0.0f, 0.0f, (float) MirrorActivity.this.screenWidthPixels, this.mirrorModeList[this.currentModeIndex].rectTotalArea.top, this.textRectPaint);
                    canvas.drawRect(this.mirrorModeList[this.currentModeIndex].rectTotalArea.right, 0.0f, (float) MirrorActivity.this.screenWidthPixels, (float) MirrorActivity.this.screenHeightPixels, this.textRectPaint);
                    canvas.drawRect(0.0f, this.mirrorModeList[this.currentModeIndex].rectTotalArea.bottom, (float) MirrorActivity.this.screenWidthPixels, (float) MirrorActivity.this.screenHeightPixels, this.textRectPaint);
                }
            }
            if (this.frameBitmap != null && !this.frameBitmap.isRecycled()) {
                canvas.setMatrix(this.f510I);
                canvas.drawBitmap(this.frameBitmap, (Rect) null, this.mirrorModeList[this.currentModeIndex].rectTotalArea, this.framePaint);
            }
            super.onDraw(canvas);
        }

        public boolean onTouchEvent(final MotionEvent motionEvent) {
            final float x = motionEvent.getX();
            final float y = motionEvent.getY();
            final int action = motionEvent.getAction();
            if (action != 0) {
                if (action == 2) {
                    this.moveGrid(this.mirrorModeList[this.currentModeIndex].getSrcRect(), x - this.oldX, y - this.oldY);
                    this.mirrorModeList[this.currentModeIndex].updateBitmapSrc();
                    this.oldX = x;
                    this.oldY = y;
                }
            } else {
                if (x < MirrorActivity.this.screenWidthPixels / 2) {
                    this.isTouchStartedLeft = true;
                } else {
                    this.isTouchStartedLeft = false;
                }
                if (y < MirrorActivity.this.screenHeightPixels / 2) {
                    this.isTouchStartedTop = true;
                } else {
                    this.isTouchStartedTop = false;
                }
                this.oldX = x;
                this.oldY = y;
            }
            this.postInvalidate();
            return true;
        }

        public void setFrame(final int n) {
            if (this.frameBitmap != null && !this.frameBitmap.isRecycled()) {
                this.frameBitmap.recycle();
                this.frameBitmap = null;
            }
            if (n == 0) {
                this.postInvalidate();
                return;
            }
            this.frameBitmap = BitmapFactory.decodeResource(this.getResources(), LibUtility.borderRes[n]);
            this.postInvalidate();
        }
    }

    final class MyMediaScannerConnectionClient implements MediaScannerConnection.MediaScannerConnectionClient {
        private MediaScannerConnection mConn;
        private String mFilename;
        private String mMimetype;

        public MyMediaScannerConnectionClient(final Context context, final File file, final String s) {
            this.mFilename = file.getAbsolutePath();
            (this.mConn = new MediaScannerConnection(context, (MediaScannerConnection.MediaScannerConnectionClient) this)).connect();
        }

        public void onMediaScannerConnected() {
            this.mConn.scanFile(this.mFilename, this.mMimetype);
        }

        public void onScanCompleted(final String s, final Uri uri) {
            this.mConn.disconnect();
        }
    }

    private class SaveImageTask extends AsyncTask<Object, Object, Object> {
        ProgressDialog progressDialog;
        String resultPath;

        private SaveImageTask() {
            this.resultPath = null;
        }

        protected Object doInBackground(final Object... array) {
            this.resultPath = MirrorActivity.this.mirrorView.saveBitmap(true, MirrorActivity.this.screenWidthPixels, MirrorActivity.this.screenHeightPixels);
            return null;
        }

        protected void onPostExecute(final Object o) {
            super.onPostExecute(o);
            if (this.progressDialog != null && this.progressDialog.isShowing()) {
                this.progressDialog.cancel();
            }
            resultPathCopy = this.resultPath;
            if (this.resultPath != null) {
                MirrorActivity.this.stickercontain.setLocked(false);
                id = R.id.closeScreen;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    final Intent intent = new Intent((Context) MirrorActivity.this, (Class) ShareActivity.class);
                    intent.putExtra("imagePath", this.resultPath);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    MirrorActivity.this.startActivity(intent);
                }
            }
            new MyMediaScannerConnectionClient(MirrorActivity.this.getApplicationContext(), new File(this.resultPath), null);
        }

        protected void onPreExecute() {
            MirrorActivity.this.stickercontain.setLocked(true);
            (this.progressDialog = new ProgressDialog((Context) MirrorActivity.this)).setMessage((CharSequence) "Saving image ...");
            this.progressDialog.show();
        }
    }
}
