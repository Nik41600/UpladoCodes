package com.abcd.photocollage.utils;

public interface OnItemSelected
{
  void itemSelected(final int p0);
}
