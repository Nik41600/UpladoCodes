package com.abcd.photocollage.widget;

import android.support.v7.widget.*;
import android.graphics.drawable.*;
import android.content.*;
import android.util.*;

public class SeekBarHint extends AppCompatSeekBar
{
  Drawable mThumb;

  public SeekBarHint(final Context context) {
    super(context);
  }

  public SeekBarHint(final Context context, final AttributeSet set) {
    super(context, set);
  }

  public SeekBarHint(final Context context, final AttributeSet set, final int n) {
    super(context, set, n);
  }

  public Drawable getSeekBarThumb() {
    return this.mThumb;
  }

  public void setThumb(final Drawable drawable) {
    super.setThumb(drawable);
    this.mThumb = drawable;
  }
}
