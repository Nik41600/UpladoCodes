package com.abcd.photocollage.adapter;

import android.annotation.SuppressLint;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.shyamsoft.photoeditor.R;

@SuppressLint({"InflateParams"})
public class CollageAdapter extends RecylceAdapterBase<CollageAdapter.ViewHolder> implements View.OnClickListener {
    private static final String TAG = "Adapter";
    int colorDefault;
    int colorSelected;
    CurrentCollageIndexChangedListener currentIndexlistener;
    public int[] iconList;
    boolean isPattern;
    RecyclerView recylceView;
    View selectedListItem;
    public int selectedPosition;
    boolean setSelectedView;

    public CollageAdapter(final int[] iconList, final int colorDefault, final int colorSelected, final boolean isPattern, final boolean setSelectedView) {
        this.isPattern = false;
        this.setSelectedView = true;
        this.iconList = iconList;
        this.colorDefault = colorDefault;
        this.colorSelected = colorSelected;
        this.isPattern = isPattern;
        this.setSelectedView = setSelectedView;
    }

    public CollageAdapter(final int[] iconList, final CurrentCollageIndexChangedListener currentIndexlistener, final int colorDefault, final int colorSelected, final boolean isPattern, final boolean setSelectedView) {
        this.isPattern = false;
        this.setSelectedView = true;
        this.iconList = iconList;
        this.currentIndexlistener = currentIndexlistener;
        this.colorDefault = colorDefault;
        this.colorSelected = colorSelected;
        this.isPattern = isPattern;
        this.setSelectedView = setSelectedView;
    }

    @Override
    public int getItemCount() {
        return this.iconList.length;
    }

    public void onAttachedToRecyclerView(final RecyclerView recylceView) {
        this.recylceView = recylceView;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int n) {
        viewHolder.setItem(this.iconList[n]);
        if (this.selectedPosition == n) {
            viewHolder.itemView.setBackgroundColor(this.colorSelected);
            return;
        }
        viewHolder.itemView.setBackgroundColor(this.colorDefault);
    }

    public void onClick(final View selectedListItem) {
        final int childPosition = this.recylceView.getChildPosition(selectedListItem);
        final RecyclerView.ViewHolder viewHolderForPosition = this.recylceView.findViewHolderForPosition(this.selectedPosition);
        if (viewHolderForPosition != null) {
            final View itemView = viewHolderForPosition.itemView;
            if (itemView != null) {
                itemView.setBackgroundColor(this.colorDefault);
            }
        }
        if (this.selectedListItem != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("selectedListItem ");
            sb.append(childPosition);
        }
        if (this.isPattern) {
            this.currentIndexlistener.onIndexChanged(this.iconList[childPosition]);
        } else {
            this.currentIndexlistener.onIndexChanged(childPosition);
        }
        if (this.setSelectedView) {
            this.selectedPosition = childPosition;
            selectedListItem.setBackgroundColor(this.colorSelected);
            this.selectedListItem = selectedListItem;
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(final ViewGroup viewGroup, final int n) {
        final View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_view_item, (ViewGroup) null);
        final ViewHolder viewHolder = new ViewHolder(inflate, this.isPattern);
        inflate.setOnClickListener((View.OnClickListener) this);
        return viewHolder;
    }

    public void setData(final int[] iconList) {
        this.iconList = iconList;
    }

    @Override
    public void setSelectedPositinVoid() {
        this.selectedListItem = null;
        this.selectedPosition = -1;
    }

    public interface CurrentCollageIndexChangedListener {
        void onIndexChanged(final int p0);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private static final String TAG = "ViewHolder";
        public ImageView imageView;
        private int item;

        public ViewHolder(final View view, final boolean b) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.image_view_collage_icon);
            this.imageView = (ImageView) view.findViewById(R.id.image_view_collage_icon);
            if (b) {
                this.imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            }
        }

        public void setItem(final int item) {
            this.item = item;
            this.imageView.setImageResource(this.item);
        }
    }
}
