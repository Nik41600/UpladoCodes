package com.abcd.photocollage.activities;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.abcd.photocollage.adapter.MoreAppAdapter;
import com.abcd.photocollage.kprogresshud.KProgressHUD;
import com.abcd.photocollage.model.App_data;
import com.abcd.photocollage.widget.BitmapResizer;
import com.abcd.photocollage.fragments.FragmentSelectImage;
import com.abcd.photocollage.utils.image.ImageLoader;
import com.abcd.photocollage.myStudio.ActivityStudio;
import com.abcd.photocollage.utils.Analytics;
import com.abcd.photocollage.utils.CollageHelper;
import com.abcd.photocollage.utils.Utility;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.gson.Gson;
import com.shyamsoft.photoeditor.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    private static String selected_option = "";
    int CAMERA_CAPTURE_IMAGE_REQUEST_CODE;
    String IMAGE_DIRECTORY_NAME;
    int MEDIA_TYPE_IMAGE;
    int PERMISSION_CAMERA_EDITOR;
    int PERMISSION_COLLAGE_EDITOR;
    int PERMISSION_MIRROR_EDITOR;
    int PERMISSION_SCRAPBOOK_EDITOR;
    int PERMISSION_SINGLE_EDITOR;
    int REQUEST_MIRROR;
    Analytics analytics;
    Uri fileUri;
    FragmentSelectImage galleryFragment;
    ImageLoader imageLoader;
    LinearLayout linearAdsBanner;
    ImageView iv_Camera;
    ImageView iv_Collage;
    ImageView iv_Mirror;
    ImageView iv_Scrapbook;
    ImageView iv_SingleEditor;
    ImageView iv_MyCreation;
    TextView txtHeading;
    TextView txtHeading1;
    private AdView adView;
    private com.google.android.gms.ads.InterstitialAd mInterstitialAd;
    private UnifiedNativeAd nativeAd;
    private KProgressHUD hud;
    private SharedPreferences ePreferences;
    private ArrayList<App_data> array_appdata;
    private MoreAppAdapter moreAppAdapter;
    private RecyclerView recyclerView;

    public HomeActivity() {
        this.CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100;
        this.MEDIA_TYPE_IMAGE = 1;
        this.IMAGE_DIRECTORY_NAME = "Photo Editor";
        this.REQUEST_MIRROR = 3;
        this.PERMISSION_COLLAGE_EDITOR = 11;
        this.PERMISSION_SINGLE_EDITOR = 22;
        this.PERMISSION_SCRAPBOOK_EDITOR = 33;
        this.PERMISSION_CAMERA_EDITOR = 44;
        this.PERMISSION_MIRROR_EDITOR = 55;
    }

    private boolean checkAndRequestCameraPermissions() {
        final int checkSelfPermission = ContextCompat.checkSelfPermission((Context) this, "android.permission.CAMERA");
        final int checkSelfPermission2 = ContextCompat.checkSelfPermission((Context) this, "android.permission.READ_EXTERNAL_STORAGE");
        final int checkSelfPermission3 = ContextCompat.checkSelfPermission((Context) this, "android.permission.WRITE_EXTERNAL_STORAGE");
        final ArrayList<String> list = new ArrayList<String>();
        if (checkSelfPermission2 != 0) {
            list.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission3 != 0) {
            list.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission != 0) {
            list.add("android.permission.CAMERA");
        }
        if (!list.isEmpty()) {
            ActivityCompat.requestPermissions(this, list.toArray(new String[list.size()]), this.PERMISSION_CAMERA_EDITOR);
            return false;
        }
        return true;
    }

    private boolean checkAndRequestCollagePermissions() {
        final int checkSelfPermission = ContextCompat.checkSelfPermission((Context) this, "android.permission.CAMERA");
        final int checkSelfPermission2 = ContextCompat.checkSelfPermission((Context) this, "android.permission.READ_EXTERNAL_STORAGE");
        final int checkSelfPermission3 = ContextCompat.checkSelfPermission((Context) this, "android.permission.WRITE_EXTERNAL_STORAGE");
        final ArrayList<String> list = new ArrayList<String>();
        if (checkSelfPermission2 != 0) {
            list.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission3 != 0) {
            list.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission != 0) {
            list.add("android.permission.CAMERA");
        }
        if (!list.isEmpty()) {
            ActivityCompat.requestPermissions(this, list.toArray(new String[list.size()]), this.PERMISSION_COLLAGE_EDITOR);
            return false;
        }
        return true;
    }

    private boolean checkAndRequestMirrorPermissions() {
        final int checkSelfPermission = ContextCompat.checkSelfPermission((Context) this, "android.permission.CAMERA");
        final int checkSelfPermission2 = ContextCompat.checkSelfPermission((Context) this, "android.permission.READ_EXTERNAL_STORAGE");
        final int checkSelfPermission3 = ContextCompat.checkSelfPermission((Context) this, "android.permission.WRITE_EXTERNAL_STORAGE");
        final ArrayList<String> list = new ArrayList<String>();
        if (checkSelfPermission2 != 0) {
            list.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission3 != 0) {
            list.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission != 0) {
            list.add("android.permission.CAMERA");
        }
        if (!list.isEmpty()) {
            ActivityCompat.requestPermissions(this, list.toArray(new String[list.size()]), this.PERMISSION_MIRROR_EDITOR);
            return false;
        }
        return true;
    }

    private boolean checkAndRequestScrapbookPermissions() {
        final int checkSelfPermission = ContextCompat.checkSelfPermission((Context) this, "android.permission.CAMERA");
        final int checkSelfPermission2 = ContextCompat.checkSelfPermission((Context) this, "android.permission.READ_EXTERNAL_STORAGE");
        final int checkSelfPermission3 = ContextCompat.checkSelfPermission((Context) this, "android.permission.WRITE_EXTERNAL_STORAGE");
        final ArrayList<String> list = new ArrayList<String>();
        if (checkSelfPermission2 != 0) {
            list.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission3 != 0) {
            list.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission != 0) {
            list.add("android.permission.CAMERA");
        }
        if (!list.isEmpty()) {
            ActivityCompat.requestPermissions(this, list.toArray(new String[list.size()]), this.PERMISSION_SCRAPBOOK_EDITOR);
            return false;
        }
        return true;
    }

    private boolean checkAndRequestSinglePermissions() {
        final int checkSelfPermission = ContextCompat.checkSelfPermission((Context) this, "android.permission.CAMERA");
        final int checkSelfPermission2 = ContextCompat.checkSelfPermission((Context) this, "android.permission.READ_EXTERNAL_STORAGE");
        final int checkSelfPermission3 = ContextCompat.checkSelfPermission((Context) this, "android.permission.WRITE_EXTERNAL_STORAGE");
        final ArrayList<String> list = new ArrayList<String>();
        if (checkSelfPermission2 != 0) {
            list.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission3 != 0) {
            list.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission != 0) {
            list.add("android.permission.CAMERA");
        }
        if (!list.isEmpty()) {
            ActivityCompat.requestPermissions(this, list.toArray(new String[list.size()]), this.PERMISSION_SINGLE_EDITOR);
            return false;
        }
        return true;
    }

    private void fileSizeAlertDialogBuilder() {
        final Point decodeFileSize = BitmapResizer.decodeFileSize(new File(this.imageLoader.selectedImagePath), Utility.maxSizeForDimension((Context) this, 1, 1500.0f));
        if (decodeFileSize != null && decodeFileSize.x == -1) {
            final int maxSizeForDimension = Utility.maxSizeForDimension((Context) this, 1, 1500.0f);
            final Intent intent = new Intent(this.getApplicationContext(), (Class) MirrorActivity.class);
            intent.putExtra("selectedImagePath", this.imageLoader.selectedImagePath);
            intent.putExtra("isSession", false);
            intent.putExtra("MAX_SIZE", maxSizeForDimension);
            Utility.logFreeMemory(this);
            this.startActivity(intent);
            finish();
            return;
        }
        final int maxSizeForDimension = Utility.maxSizeForDimension((Context) this, 1, 1500.0f);
        final Intent intent = new Intent(this.getApplicationContext(), (Class) MirrorActivity.class);
        intent.putExtra("selectedImagePath", this.imageLoader.selectedImagePath);
        intent.putExtra("isSession", false);
        intent.putExtra("MAX_SIZE", maxSizeForDimension);
        Utility.logFreeMemory(this);
        this.startActivity(intent);
        finish();
    }

    private void BindView() {
        this.iv_SingleEditor = (ImageView) findViewById(R.id.iv_SingleEditor);
        this.iv_MyCreation = (ImageView) findViewById(R.id.iv_MyCreation);
        this.iv_Camera = (ImageView) findViewById(R.id.iv_Camera);
        this.iv_Collage = (ImageView) findViewById(R.id.iv_Collage);
        this.iv_Mirror = (ImageView) findViewById(R.id.iv_Mirror);
        this.iv_Scrapbook = (ImageView) findViewById(R.id.iv_Scrapbook);

        this.iv_SingleEditor.setOnClickListener(this);
        this.iv_MyCreation.setOnClickListener(this);
        this.iv_Camera.setOnClickListener(this);
        this.iv_Collage.setOnClickListener(this);
        this.iv_Mirror.setOnClickListener(this);
        this.iv_Scrapbook.setOnClickListener(this);

    }

    public File getOutputMediaFile(final int n) {
        final File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), this.IMAGE_DIRECTORY_NAME);
        if (!file.exists() && !file.mkdirs()) {
            final String image_DIRECTORY_NAME = this.IMAGE_DIRECTORY_NAME;
            final StringBuilder sb = new StringBuilder();
            sb.append("Oops! Failed create ");
            sb.append(this.IMAGE_DIRECTORY_NAME);
            sb.append(" directory");
            Log.d(image_DIRECTORY_NAME, sb.toString());
            return null;
        }
        final String format = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        if (n == this.MEDIA_TYPE_IMAGE) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(file.getPath());
            sb2.append(File.separator);
            sb2.append("IMG_");
            sb2.append(format);
            sb2.append(".jpg");
            return new File(sb2.toString());
        }
        return null;
    }

    public Uri getOutputMediaFileUri(final int n) {
        return Uri.fromFile(this.getOutputMediaFile(n));
    }

    protected void onActivityResult(final int n, int request_MIRROR, Intent intent) {
        try {
            if (n == this.CAMERA_CAPTURE_IMAGE_REQUEST_CODE) {
                if (request_MIRROR == -1) {
                    intent = new Intent((Context) this, (Class) CollageActivity.class);
                    final PrintStream out = System.out;
                    final StringBuilder sb = new StringBuilder();
                    sb.append("CAMERA IMAGE PATH");
                    sb.append(this.fileUri.getPath());
                    out.println(sb.toString());
                    intent.putExtra("selected_image_path", this.fileUri.getPath());
                    this.startActivity(intent);
                    finish();
                    return;
                }
                if (request_MIRROR == 0) {
                    Toast.makeText(this.getApplicationContext(), (CharSequence) "User cancelled image capture", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(this.getApplicationContext(), (CharSequence) "Sorry! Failed to capture image", Toast.LENGTH_SHORT).show();
            } else if (request_MIRROR == -1) {
                request_MIRROR = this.REQUEST_MIRROR;
                if (n == request_MIRROR) {
                    try {
                        this.imageLoader.getImageFromIntent(intent);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append("");
                        sb2.append(this.getString(R.string.error_img_not_found));
                        Toast.makeText((Context) this, (CharSequence) sb2.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } catch (NullPointerException ex2) {
            ex2.printStackTrace();
        }
    }

    public void onBackPressed()
    {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    public void onClick(View view) {
        Intent intent;
        if (this.iv_Collage == view) {
            if (this.analytics != null) {
                this.analytics.logEvent(Analytics.Param.MENU_COLLAGE, "");
            }
            id = 101;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                if (Build.VERSION.SDK_INT < 23) {
                    openCollage(false, false, false);

                } else if (checkAndRequestCollagePermissions()) {

                    openCollage(false, false, false);
                }
            }
        }
        if (this.iv_SingleEditor == view) {
            if (this.analytics != null) {
                this.analytics.logEvent(Analytics.Param.MENU_EDITOR, "");
            }
            selected_option = Analytics.Param.MENU_EDITOR;

            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                openEditor();
            }
        }
        if (this.iv_MyCreation == view) {
            id = 108;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                mycreations();
            }
        }
        if (this.iv_Scrapbook == view) {
            if (this.analytics != null) {
                this.analytics.logEvent(Analytics.Param.MENU_SCRAPBOOK, "");
            }
            id = 102;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                if (Build.VERSION.SDK_INT < 23) {
                    openCollage(false, true, false);
                } else if (checkAndRequestScrapbookPermissions()) {
                    openCollage(false, true, false);
                }
            }
        }
        if (this.iv_Camera == view) {
            if (this.analytics != null) {
                this.analytics.logEvent(Analytics.Param.MENU_CAMERA, "");
            }
            if (Build.VERSION.SDK_INT < 23) {
                intent = new Intent("android.media.action.IMAGE_CAPTURE");
                this.fileUri = getOutputMediaFileUri(this.MEDIA_TYPE_IMAGE);
                intent.putExtra("output", this.fileUri);
                startActivityForResult(intent, this.CAMERA_CAPTURE_IMAGE_REQUEST_CODE);
            } else if (checkAndRequestCameraPermissions()) {
                intent = new Intent("android.media.action.IMAGE_CAPTURE");
                this.fileUri = getOutputMediaFileUri(this.MEDIA_TYPE_IMAGE);
                intent.putExtra("output", this.fileUri);
                startActivityForResult(intent, this.CAMERA_CAPTURE_IMAGE_REQUEST_CODE);
            }
        }
        if (this.iv_Mirror == view) {
            if (this.analytics != null) {
                this.analytics.logEvent(Analytics.Param.MENU_MIRROR, "");
            }
            selected_option = Analytics.Param.MENU_MIRROR;
            id = 107;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                openMirror();
            }
        }
    }

    private void mycreations() {
        startActivity(new Intent(HomeActivity.this, ActivityStudio.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.requestWindowFeature(1);
        this.getWindow().addFlags(1024);
        setContentView(R.layout.activity_home);
        array_appdata = new ArrayList<>();
        makeJsonRequest(getResources().getString(R.string.more_appurl));
        recyclerView = (RecyclerView) findViewById(R.id.ad_inter_recycle_view);
        final GridLayoutManager layoutManager = new GridLayoutManager(this, 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.analytics = new Analytics((Context) this);
        this.txtHeading = (TextView) findViewById(R.id.txtHeading);
        this.linearAdsBanner = (LinearLayout) findViewById(R.id.linearAds);
        ePreferences = getSharedPreferences("pref_key_rate", 0);
        this.BindView();
        loadAds();
        nativeAd();

        (this.imageLoader = new ImageLoader((Context) this)).setListener((ImageLoader.ImageLoaded) new ImageLoader.ImageLoaded() {
            @Override
            public void callFileSizeAlertDialogBuilder() {
                HomeActivity.this.fileSizeAlertDialogBuilder();
            }
        });
    }

    private void makeJsonRequest(String url) {
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("application_detail");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                App_data app_data = new Gson().fromJson(jsonArray.get(i).toString(), App_data.class);
                                if (!app_data.getApplication_name().equalsIgnoreCase(getString(R.string.app_name))) {
                                    array_appdata.add(app_data);
                                    moreAppAdapter = new MoreAppAdapter(HomeActivity.this, array_appdata);
                                    recyclerView.setAdapter(moreAppAdapter);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Error", "Error: " + error.getMessage());
            }
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq, "");
    }

    int id;

    private void loadAds() {
        //Banner Ad
        adView = findViewById(R.id.AdView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(adRequestfull);
        mInterstitialAd.setAdListener(new AdListener(){
            public void onAdLoaded() {
                super.onAdLoaded();
            }
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case 101:
                        if (Build.VERSION.SDK_INT < 23) {
                            openCollage(false, false, false);

                        } else if (checkAndRequestCollagePermissions()) {

                            openCollage(false, false, false);
                        }
                        break;
                    case 102:
                        if (Build.VERSION.SDK_INT < 23) {

                            openCollage(false, true, false);

                        } else if (checkAndRequestScrapbookPermissions()) {

                            openCollage(false, true, false);
                        }
                        break;

                    case 106:
                        if (Build.VERSION.SDK_INT < 23) {
                            openCollage(true, false, false);
                        } else if (checkAndRequestSinglePermissions()) {
                            openCollage(true, false, false);
                        }
                        break;
                    case 107:
                        openMirror();
                        break;
                    case 108:
                        mycreations();
                        break;

                }
                mInterstitialAd.loadAd(adRequestfull);
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        mInterstitialAd.loadAd(adRequestfull);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(HomeActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                mInterstitialAd.show();
            }
        }, 2000);
    }

    private void RateDialog(){
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(HomeActivity.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    final SharedPreferences.Editor edit = ePreferences.edit();
                    edit.putBoolean("pref_key_rate", true);
                    edit.apply();
                    dialog.dismiss();
                    if (isRate[0]) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    public void ExitDialog() {
        final Dialog dialog = new Dialog(HomeActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }

    public void onPause() {
        super.onPause();
    }

    public void onRequestPermissionsResult(final int n, @NonNull final String[] array, @NonNull final int[] array2) {
        super.onRequestPermissionsResult(n, array, array2);
        if (n == this.PERMISSION_COLLAGE_EDITOR) {
            if (ContextCompat.checkSelfPermission((Context) this, array[0]) == 0) {

                this.openCollage(false, false, false);
                Toast.makeText((Context) this, (CharSequence) "Permission granted", Toast.LENGTH_SHORT).show();

                return;
            }
            Toast.makeText((Context) this, (CharSequence) "Permission denied", Toast.LENGTH_SHORT).show();
        } else if (n == this.PERMISSION_SINGLE_EDITOR) {
            if (ContextCompat.checkSelfPermission((Context) this, array[0]) == 0) {

                this.openCollage(true, false, false);
                Toast.makeText((Context) this, (CharSequence) "Permission granted", Toast.LENGTH_SHORT).show();

                return;
            }
            Toast.makeText((Context) this, (CharSequence) "Permission denied", Toast.LENGTH_SHORT).show();
        } else if (n == this.PERMISSION_SCRAPBOOK_EDITOR) {
            if (ContextCompat.checkSelfPermission((Context) this, array[0]) == 0) {

                this.openCollage(false, true, false);
                Toast.makeText((Context) this, (CharSequence) "Permission granted", Toast.LENGTH_SHORT).show();

                return;
            }
            Toast.makeText((Context) this, (CharSequence) "Permission denied", Toast.LENGTH_SHORT).show();
        } else {
            if (n != this.PERMISSION_CAMERA_EDITOR) {
                if (n == this.PERMISSION_MIRROR_EDITOR) {
                    if (ContextCompat.checkSelfPermission((Context) this, array[0]) == 0) {
                        final Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction("android.intent.action.GET_CONTENT");
                        this.startActivityForResult(Intent.createChooser(intent, (CharSequence) "Select Picture"), this.REQUEST_MIRROR);
                        Toast.makeText((Context) this, (CharSequence) "Permission granted", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText((Context) this, (CharSequence) "Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            if (ContextCompat.checkSelfPermission((Context) this, array[0]) == 0) {
                final Intent intent2 = new Intent("android.media.action.IMAGE_CAPTURE");
                intent2.putExtra("output", (Parcelable) (this.fileUri = this.getOutputMediaFileUri(this.MEDIA_TYPE_IMAGE)));
                this.startActivityForResult(intent2, this.CAMERA_CAPTURE_IMAGE_REQUEST_CODE);
                Toast.makeText((Context) this, (CharSequence) "Permission granted", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText((Context) this, (CharSequence) "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    protected void onRestoreInstanceState(final Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.fileUri = (Uri) bundle.getParcelable("file_uri");
    }

    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putParcelable("file_uri", (Parcelable) this.fileUri);
    }

    public void openCollage(final boolean collageSingleMode, final boolean isScrapbook, final boolean isShape) {

        (this.galleryFragment = CollageHelper.addGalleryFragment(this, R.id.gallery_fragment_container, null, true, null)).CollageSingleMode(collageSingleMode);
        this.galleryFragment.setIsScrapbook(isScrapbook);
        this.galleryFragment.setIsShape(isShape);
        if (!isScrapbook) {
            this.galleryFragment.setLimitMax(FragmentSelectImage.MAX_COLLAGE);
        }
    }

    public void openEditor() {
        id = 106;
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            hud.show();
            AdsDialogShow();
        } else {
            if (Build.VERSION.SDK_INT < 23) {
                this.openCollage(true, false, false);
                return;
            }
            if (this.checkAndRequestSinglePermissions()) {
                this.openCollage(true, false, false);
            }
        }
    }

    public void openMirror() {
        if (Build.VERSION.SDK_INT < 23) {
            final Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction("android.intent.action.GET_CONTENT");
            this.startActivityForResult(Intent.createChooser(intent, (CharSequence) "Select Picture"), this.REQUEST_MIRROR);
            return;
        }
        if (this.checkAndRequestMirrorPermissions()) {
            this.startActivityForResult(new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI), this.REQUEST_MIRROR);
        }
    }

    private void nativeAd() {
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Toast.makeText(HomeActivity.this, "Failed to load native ad: "
                        + errorCode, Toast.LENGTH_SHORT).show();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        super.onDestroy();
    }
}
