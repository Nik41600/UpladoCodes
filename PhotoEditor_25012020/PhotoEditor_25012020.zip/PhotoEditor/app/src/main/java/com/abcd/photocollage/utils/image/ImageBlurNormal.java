package com.abcd.photocollage.utils.image;

import android.graphics.*;

public class ImageBlurNormal
{
  int lastBlurRadius;
  Matrix matrixBlur;
  Paint paintBlur;

  public ImageBlurNormal() {
    this.lastBlurRadius = -1;
    this.paintBlur = new Paint(2);
    this.matrixBlur = new Matrix();
  }
}
