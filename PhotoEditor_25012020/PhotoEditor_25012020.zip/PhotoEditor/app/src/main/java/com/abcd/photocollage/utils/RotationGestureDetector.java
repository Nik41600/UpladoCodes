package com.abcd.photocollage.utils;

import android.view.*;

public class RotationGestureDetector
{
  private static final int INVALID_POINTER_ID = -1;
  private float fX;
  private float fY;
  private float mAngle;
  private OnRotationGestureListener mListener;
  private int ptrID1;
  private int ptrID2;
  private float sX;
  private float sY;

  public RotationGestureDetector(final OnRotationGestureListener mListener) {
    this.mListener = mListener;
    this.ptrID1 = -1;
    this.ptrID2 = -1;
  }

  private float angleBetweenLines(float n, float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
    n2 = (n = (float)Math.toDegrees((float)Math.atan2(n2 - n4, n - n3) - (float)Math.atan2(n6 - n8, n5 - n7)) % 360.0f);
    if (n2 < -180.0f) {
      n = n2 + 360.0f;
    }
    if (n > 180.0f) {
      return n - 360.0f;
    }
    return n;
  }

  public float getAngle() {
    return this.mAngle;
  }

  public boolean onTouchEvent(final MotionEvent motionEvent) {
    switch (motionEvent.getActionMasked()) {
      case 5: {
        this.ptrID2 = motionEvent.getPointerId(motionEvent.getActionIndex());
        final int pointerIndex = motionEvent.findPointerIndex(this.ptrID1);
        final int pointerIndex2 = motionEvent.findPointerIndex(this.ptrID2);
        final int pointerCount = motionEvent.getPointerCount();
        if (pointerIndex >= 0 && pointerIndex < pointerCount && pointerIndex2 >= 0 && pointerIndex2 < pointerCount) {
          this.sX = motionEvent.getX(pointerIndex);
          this.sY = motionEvent.getY(pointerIndex);
          this.fX = motionEvent.getX(pointerIndex2);
          this.fY = motionEvent.getY(pointerIndex2);
          break;
        }
      }
      case 6: {
        this.ptrID2 = -1;
        break;
      }
      case 3: {
        this.ptrID1 = -1;
        this.ptrID2 = -1;
        break;
      }
      case 2: {
        if (this.ptrID1 == -1 || this.ptrID2 == -1) {
          break;
        }
        final int pointerIndex3 = motionEvent.findPointerIndex(this.ptrID1);
        final int pointerIndex4 = motionEvent.findPointerIndex(this.ptrID2);
        final int pointerCount2 = motionEvent.getPointerCount();
        if (pointerIndex3 < 0 || pointerIndex3 >= pointerCount2 || pointerIndex4 < 0 || pointerIndex4 >= pointerCount2) {
          break;
        }
        this.mAngle = this.angleBetweenLines(this.fX, this.fY, this.sX, this.sY, motionEvent.getX(motionEvent.findPointerIndex(this.ptrID2)), motionEvent.getY(motionEvent.findPointerIndex(this.ptrID2)), motionEvent.getX(motionEvent.findPointerIndex(this.ptrID1)), motionEvent.getY(motionEvent.findPointerIndex(this.ptrID1)));
        if (this.mListener != null) {
          this.mListener.OnRotation(this);
          break;
        }
        break;
      }
      case 1: {
        this.ptrID1 = -1;
        break;
      }
      case 0: {
        this.ptrID1 = motionEvent.getPointerId(motionEvent.getActionIndex());
        break;
      }
    }
    return true;
  }

  public interface OnRotationGestureListener
  {
    void OnRotation(final RotationGestureDetector p0);
  }
}
