package com.abcd.photocollage.utils.canvastextview;

import android.graphics.*;
import java.io.*;

public class CustomMatrix extends Matrix implements Serializable
{
  private static final long serialVersionUID = 6346371585195628612L;

  public CustomMatrix() {
  }

  public CustomMatrix(final Matrix matrix) {
    super(matrix);
  }

  private void readObject(final ObjectInputStream objectInputStream) throws Exception, ClassNotFoundException {
    objectInputStream.defaultReadObject();
    final float[] array = new float[9];
    super.setValues((float[])objectInputStream.readObject());
  }

  private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
    objectOutputStream.defaultWriteObject();
    final float[] array = new float[9];
    super.getValues(array);
    objectOutputStream.writeObject(array);
  }
}
