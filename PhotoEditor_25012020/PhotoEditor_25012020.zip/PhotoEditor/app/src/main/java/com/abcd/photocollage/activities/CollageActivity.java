package com.abcd.photocollage.activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.NinePatchDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Display;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.abcd.photocollage.fragments.FragmentWriteText;
import com.abcd.photocollage.kprogresshud.KProgressHUD;
import com.commit451.nativestackblur.NativeStackBlur;
import com.abcd.photocollage.adapter.CollageAdapter;
import com.abcd.photocollage.adapter.ColorPickerAdapter;
import com.abcd.photocollage.adapter.RecylceAdapterBase;
import com.abcd.photocollage.utils.canvastextview.ApplyTextInterface;
import com.abcd.photocollage.utils.canvastextview.CustomRelativeLayout;
import com.abcd.photocollage.utils.canvastextview.SingleTapInterface;
import com.abcd.photocollage.utils.canvastextview.TextDataItem;
import com.abcd.photocollage.collagelist.Collage;
import com.abcd.photocollage.collagelist.CollageLayout;
import com.abcd.photocollage.collagelist.MaskPair;
import com.abcd.photocollage.fragments.FragmentFullEffect;
import com.abcd.photocollage.utils.image.ImageBlurNormal;
import com.abcd.photocollage.utils.sticker.StickerActivity;
import com.abcd.photocollage.utils.Analytics;
import com.abcd.photocollage.utils.Parameter;
import com.abcd.photocollage.utils.RotationGestureDetector;
import com.abcd.photocollage.utils.Shape;
import com.abcd.photocollage.utils.ShapeLayout;
import com.abcd.photocollage.utils.Utility;
import com.abcd.photocollage.utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.shyamsoft.photoeditor.R;
import com.xiaopo.flying.sticker.BitmapStickerIcon;
import com.xiaopo.flying.sticker.DeleteIconEvent;
import com.xiaopo.flying.sticker.DrawableSticker;
import com.xiaopo.flying.sticker.FlipHorizontallyEvent;
import com.xiaopo.flying.sticker.Sticker;
import com.xiaopo.flying.sticker.StickerView;
import com.xiaopo.flying.sticker.ZoomIconEvent;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@SuppressLint({"NewApi"})
public class CollageActivity extends FragmentActivity {
    private static final String TAG = "CollageActivity";
    public static String selected_item = "";
    private boolean IS_BACK_CLICKED;
    int RATIO_BUTTON_SIZE;
    Analytics analytics;
    Bitmap[] bitmapList;
    Bitmap btmDelete;
    Bitmap btmScale;
    CustomRelativeLayout canvasText;
    CollageAdapter collageAdapter;
    CollageView collageView;
    LinearLayout colorContainer;
    ViewGroup contextFooter;
    FragmentWriteText.FontChoosedListener fontChoosedListener;
    FragmentWriteText fontFragment;
    FragmentFullEffect fragmentFullEffect;
    int height;
    boolean isScrapBook;
    private RotationGestureDetector mRotationDetector;
    SeekBar.OnSeekBarChangeListener mSeekBarListener;
    RelativeLayout mainLayout;
    float mulX;
    float mulY;
    NinePatchDrawable npd;
    Parameter[] parameterList;
    ArrayList<RecylceAdapterBase> patternAdapterList;
    Button[] ratioButtonArray;
    RecyclerView recyclerViewCollage;
    AlertDialog saveImageAlert;
    SeekBar seekBarPadding;
    SeekBar seekBarRound;
    SeekBar seekbarBlur;
    SeekBar seekbarSize;
    View selectFilterTextView;
    boolean selectImageForAdj;
    View selectSwapTextView;
    boolean showText;
    private Animation slideLeftIn;
    private Animation slideLeftOut;
    private Animation slideRightIn;
    private Animation slideRightOut;
    StickerView stickercontain;
    private HorizontalScrollView horizontalScrollView;
    ArrayList<Sticker> stickerlist;
    ImageView stickerwww;
    boolean swapMode;
    View[] tabButtonList;
    ArrayList<TextDataItem> textDataList;
    ViewFlipper viewFlipper;
    int width;
    private KProgressHUD hud;
    private InterstitialAd interstitialAd;
    private AdView adView;

    public CollageActivity() {
        this.RATIO_BUTTON_SIZE = 11;
        this.isScrapBook = false;
        this.stickerlist = new ArrayList<Sticker>();
        this.mulX = 1.0f;
        this.mulY = 1.0f;
        this.patternAdapterList = new ArrayList<RecylceAdapterBase>();
        this.selectImageForAdj = false;
        this.showText = false;
        this.swapMode = false;
        this.textDataList = new ArrayList<TextDataItem>();
        this.fontChoosedListener = new FragmentWriteText.FontChoosedListener() {
            @Override
            public void onOk(final TextDataItem textDataItem) {
                if (CollageActivity.this.canvasText == null) {
                    CollageActivity.this.CanvasTextView();
                }
                CollageActivity.this.canvasText.addTextView(textDataItem);
                CollageActivity.this.getSupportFragmentManager().beginTransaction().remove(CollageActivity.this.fontFragment).commit();
            }
        };
        this.mSeekBarListener = (SeekBar.OnSeekBarChangeListener) new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                final int id = seekBar.getId();
                if (id == R.id.seekbar_round) {
                    if (CollageActivity.this.collageView != null) {
                        CollageActivity.this.collageView.setCornerRadius(n);
                    }
                } else if (id == R.id.seekbar_padding) {
                    if (CollageActivity.this.collageView != null) {
                        CollageActivity.this.collageView.setPathPadding(CollageActivity.this.collageView.currentCollageIndex, n);
                    }
                } else if (id == R.id.seekbar_size && CollageActivity.this.collageView != null) {
                    CollageActivity.this.collageView.setCollageSize(CollageActivity.this.collageView.sizeMatrix, n);
                }
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
                if (seekBar.getId() == R.id.seekbar_collage_blur) {
                    float n;
                    if ((n = seekBar.getProgress() / 4.0f) > 25.0f) {
                        n = 25.0f;
                    }
                    float n2 = n;
                    if (n < 0.0f) {
                        n2 = 0.0f;
                    }
                    final StringBuilder sb = new StringBuilder();
                    sb.append("blur radius ");
                    sb.append(n2);
                    CollageActivity.this.collageView.setBlurBitmap((int) n2, false);
                }
            }
        };
        this.IS_BACK_CLICKED = false;
    }

    private void backButtonAlertBuilder() {
        final AlertDialog.Builder builder = new AlertDialog.Builder((Context) this);
        builder.setMessage("Would you like to save image ?").setCancelable(true).setPositiveButton("Yes", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                if (CollageActivity.this.analytics != null) {
                    CollageActivity.this.analytics.logEvent("IMAGE_SAVE", "");
                }
                stickercontain.setLocked(true);
                new SaveImageTask().execute(new Object[0]);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
            }
        }).setNeutralButton("No", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                CollageActivity.this.IS_BACK_CLICKED = true;
                CollageActivity.this.finish();
            }
        });
        (this.saveImageAlert = builder.create()).show();
    }

    private void createAdapterList(final int n, final int n2) {
        final int[][] patternResIdList2 = Utils.patternResIdList2;
        int i = 0;
        final int length = patternResIdList2.length;
        this.patternAdapterList.clear();
        this.patternAdapterList.add(new ColorPickerAdapter(new CollageAdapter.CurrentCollageIndexChangedListener() {
            @Override
            public void onIndexChanged(final int patternPaintColor) {
                CollageActivity.this.collageView.setPatternPaintColor(patternPaintColor);
            }
        }, n, n2));
        while (i < length) {
            this.patternAdapterList.add(new CollageAdapter(Utils.patternResIdList2[i], (CollageAdapter.CurrentCollageIndexChangedListener) new CollageAdapter.CurrentCollageIndexChangedListener() {
                @Override
                public void onIndexChanged(final int patternPaint) {
                    CollageActivity.this.collageView.setPatternPaint(patternPaint);
                }
            }, n, n2, true, true));
            ++i;
        }
    }

    private void hideColorContainer() {
        if (this.colorContainer == null) {
            this.colorContainer = (LinearLayout) this.findViewById(R.id.color_container);
        }
        this.colorContainer.setVisibility(View.INVISIBLE);
    }

    private void RatioButtonBg(int i) {
        int i2 = 0;
        if (this.ratioButtonArray == null) {
            this.ratioButtonArray = new Button[this.RATIO_BUTTON_SIZE];
            this.ratioButtonArray[0] = (Button) findViewById(R.id.button11);
            this.ratioButtonArray[1] = (Button) findViewById(R.id.button21);
            this.ratioButtonArray[2] = (Button) findViewById(R.id.button12);
            this.ratioButtonArray[3] = (Button) findViewById(R.id.button32);
            this.ratioButtonArray[4] = (Button) findViewById(R.id.button23);
            this.ratioButtonArray[5] = (Button) findViewById(R.id.button43);
            this.ratioButtonArray[6] = (Button) findViewById(R.id.button34);
            this.ratioButtonArray[7] = (Button) findViewById(R.id.button45);
            this.ratioButtonArray[8] = (Button) findViewById(R.id.button57);
            this.ratioButtonArray[9] = (Button) findViewById(R.id.button169);
            this.ratioButtonArray[10] = (Button) findViewById(R.id.button916);
        }
        while (i2 < this.RATIO_BUTTON_SIZE) {
            this.ratioButtonArray[i2].setBackgroundResource(R.drawable.selector_collage_ratio_button);
            i2++;
        }
        this.ratioButtonArray[i].setBackgroundResource(R.drawable.collage_ratio_bg_pressed);
    }


    private void TabBg(int i) {
        int i2 = 0;
        if (this.tabButtonList == null) {
            this.tabButtonList = new View[8];
            this.tabButtonList[0] = findViewById(R.id.buttonCollageLayout);
            this.tabButtonList[2] = findViewById(R.id.buttonSpace);
            this.tabButtonList[4] = findViewById(R.id.buttonBlur);
            this.tabButtonList[1] = findViewById(R.id.buttonBackground);
            this.tabButtonList[3] = findViewById(R.id.buttonRatio);
            this.tabButtonList[5] = findViewById(R.id.buttonAdjustment);
            this.tabButtonList[6] = findViewById(R.id.buttonSticker);
            this.tabButtonList[7] = findViewById(R.id.buttonText);
        }
    }

    private void Scrapbook() {
        findViewById(R.id.ll_layout).setVisibility(View.GONE);
        findViewById(R.id.ll_space).setVisibility(View.GONE);
        findViewById(R.id.ll_swap).setVisibility(View.GONE);
        findViewById(R.id.ll_fit).setVisibility(View.GONE);
        findViewById(R.id.ll_fill).setVisibility(View.GONE);
        findViewById(R.id.ll_delete).setVisibility(View.VISIBLE);
    }

    private void SingleImage() {
        findViewById(R.id.seekbar_corner_container).setVisibility(View.GONE);
        findViewById(R.id.seekbar_space_container).setVisibility(View.GONE);
        findViewById(R.id.ll_blur).setVisibility(View.VISIBLE);
        findViewById(R.id.ll_delete).setVisibility(View.GONE);
        findViewById(R.id.ll_swap).setVisibility(View.GONE);
        if (!this.isScrapBook) {
            this.collageView.setCollageSize(this.collageView.sizeMatrix, 45);
            if (this.seekbarSize != null) {
                this.seekbarSize.setProgress(45);
            }
        }
        this.collageView.setBlurBitmap(this.collageView.blurRadius, false);
        if (!this.isScrapBook) {
            SelectedTab(2);
        }
    }

    public void CanvasTextView() {
        (this.canvasText = new CustomRelativeLayout((Context) this, this.textDataList, this.collageView.identityMatrix, new SingleTapInterface() {
            @Override
            public void onSingleTap(final TextDataItem textDataItem) {
                CollageActivity.this.fontFragment = new FragmentWriteText();
                final Bundle arguments = new Bundle();
                arguments.putSerializable("text_data", (Serializable) textDataItem);
                CollageActivity.this.fontFragment.setArguments(arguments);
                CollageActivity.this.getSupportFragmentManager().beginTransaction().replace(R.id.collage_text_view_fragment_container, CollageActivity.this.fontFragment, "FONT_FRAGMENT").commit();
                CollageActivity.this.fontFragment.setFontChoosedListener(CollageActivity.this.fontChoosedListener);
            }
        })).setApplyTextListener(new ApplyTextInterface() {
            @Override
            public void onCancel() {
                CollageActivity.this.showText = true;
                CollageActivity.this.mainLayout.removeView((View) CollageActivity.this.canvasText);
                CollageActivity.this.collageView.postInvalidate();
            }

            @Override
            public void onOk(final ArrayList<TextDataItem> textDataList) {
                final Iterator<TextDataItem> iterator = textDataList.iterator();
                while (iterator.hasNext()) {
                    iterator.next().setImageSaveMatrix(CollageActivity.this.collageView.identityMatrix);
                }
                CollageActivity.this.textDataList = textDataList;
                CollageActivity.this.showText = true;
                if (CollageActivity.this.mainLayout == null) {
                    CollageActivity.this.mainLayout = (RelativeLayout) CollageActivity.this.findViewById(R.id.collage_main_layout);
                }
                CollageActivity.this.mainLayout.removeView((View) CollageActivity.this.canvasText);
                CollageActivity.this.collageView.postInvalidate();
            }
        });
        this.showText = false;
        this.collageView.invalidate();
        this.mainLayout.addView((View) this.canvasText);
        this.findViewById(R.id.collage_text_view_fragment_container).bringToFront();
        (this.fontFragment = new FragmentWriteText()).setArguments(new Bundle());
        this.getSupportFragmentManager().beginTransaction().add(R.id.collage_text_view_fragment_container, this.fontFragment, "FONT_FRAGMENT").commit();
        this.fontFragment.setFontChoosedListener(this.fontChoosedListener);
    }

    void EffectFragment() {
        if (this.fragmentFullEffect == null) {
            this.fragmentFullEffect = (FragmentFullEffect) this.getSupportFragmentManager().findFragmentByTag("FULL_FRAGMENT");
            if (this.fragmentFullEffect == null) {
                this.fragmentFullEffect = new FragmentFullEffect();
                this.fragmentFullEffect.setArguments(this.getIntent().getExtras());
                this.getSupportFragmentManager().beginTransaction().add(R.id.collage_effect_fragment_container, this.fragmentFullEffect, "FULL_FRAGMENT").commitAllowingStateLoss();
            } else {
                if (this.collageView.shapeIndex >= 0) {
                    this.fragmentFullEffect.BitmapParameter(this.bitmapList[this.collageView.shapeIndex], this.parameterList[this.collageView.shapeIndex]);
                }
            }
            this.getSupportFragmentManager().beginTransaction().hide(this.fragmentFullEffect).commitAllowingStateLoss();
            this.fragmentFullEffect.FullBitmapReadyListener((FragmentFullEffect.FullBitmapReady) new FragmentFullEffect.FullBitmapReady() {
                @Override
                public void onBitmapReady(final Bitmap bitmap, final Parameter parameter) {
                    CollageActivity.this.collageView.updateShapeListForFilterBitmap(bitmap);
                    CollageActivity.this.collageView.updateParamList(parameter);
                    CollageActivity.this.collageView.postInvalidate();
                    CollageActivity.this.getSupportFragmentManager().beginTransaction().hide(CollageActivity.this.fragmentFullEffect).commit();
                    CollageActivity.this.collageView.postInvalidate();
                }

                @Override
                public void onCancel() {
                    CollageActivity.this.setVisibilityOfFilterHorizontalListview(false);
                    CollageActivity.this.collageView.postInvalidate();
                }
            });
            this.findViewById(R.id.collage_effect_fragment_container).bringToFront();
        }
    }

    void DeleteDialog() {
        if (this.collageView.shapeLayoutList.get(0).shapeArr.length == 1) {
            @SuppressLint("WrongConstant") final Toast text = Toast.makeText((Context) this, (CharSequence) "You can't delete last image!", 0);
            text.setGravity(17, text.getXOffset() / 2, text.getYOffset() / 2);
            text.show();
            return;
        }
        final AlertDialog.Builder builder = new AlertDialog.Builder((Context) this);
        builder.setMessage("Do you want to delete it?").setCancelable(true).setPositiveButton("Yes", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                CollageActivity.this.collageView.deleteBitmap(CollageActivity.this.collageView.shapeIndex, CollageActivity.this.width, CollageActivity.this.height);
            }
        }).setNegativeButton("No", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
            }
        });
        (this.saveImageAlert = builder.create()).show();
    }

    int getCollageSize(final Bundle bundle) {
        final long[] longArray = bundle.getLongArray("photo_id_list");
        if (longArray == null) {
            return 1;
        }
        return longArray.length;
    }

    public void myClickHandler(final View view) {
        final int id = view.getId();
        if (id == R.id.buttonCollageLayout) {
            this.SelectedTab(0);
        } else if (id == R.id.buttonRatio) {
            if (this.analytics != null) {
                this.analytics.logEvent("EDITOR_RATIO", "");
            }
            this.SelectedTab(3);
        } else if (id == R.id.buttonBlur) {
            if (this.analytics != null) {
                this.analytics.logEvent("EDITOR_FILTER_BLUR", "");
            }
            this.collageView.setBlurBitmap(this.collageView.blurRadius, false);
            this.SelectedTab(4);
            this.collageView.startAnimator();
        } else if (id == R.id.buttonBackground) {
            if (this.analytics != null) {
                this.analytics.logEvent("EDITOR_BACKGROUND", "");
            }
            this.SelectedTab(1);
        } else if (id == R.id.buttonSpace) {
            if (this.analytics != null) {
                this.analytics.logEvent("EDITOR_SPACE", "");
            }
            this.SelectedTab(2);
        } else if (id == R.id.buttonAdjustment) {
            if (this.analytics != null) {
                this.analytics.logEvent("EDITOR_FILTER", "");
            }
            if (this.collageView.shapeLayoutList.get(0).shapeArr.length == 1) {
                this.collageView.shapeIndex = 0;
                this.collageView.openFilterFragment();
            } else if (this.collageView.shapeIndex >= 0) {
                this.collageView.openFilterFragment();
            } else {
                this.SelectedTab(5);
                this.selectFilterTextView.setVisibility(View.VISIBLE);
                this.selectImageForAdj = true;
            }
        } else if (id == R.id.buttonSwap) {
            if (this.collageView.shapeLayoutList.get(this.collageView.currentCollageIndex).shapeArr.length == 2) {
                this.collageView.swapBitmaps(0, 1);
            } else {
                this.selectSwapTextView.setVisibility(View.VISIBLE);
                this.swapMode = true;
            }
        } else if (id == R.id.buttonDelete) {
            this.DeleteDialog();
        } else if (id == R.id.button_collage_context_filter) {
            this.collageView.openFilterFragment();
        } else if (id == R.id.button_save_collage_image) {
            if (this.analytics != null) {
                this.analytics.logEvent("IMAGE_SAVE", "");
            }
            Id = R.id.button_save_collage_image;
            if (interstitialAd != null && interstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                stickercontain.setLocked(true);
                new SaveImageTask().execute(new Object[0]);
                return;
            }
        } else if (id == R.id.button_cancel_collage_image) {
            this.backButtonAlertBuilder();
        } else if (id == R.id.button11) {
            this.mulX = 1.0f;
            this.mulY = 1.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(0);
        } else if (id == R.id.button21) {
            this.mulX = 2.0f;
            this.mulY = 1.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(1);
        } else if (id == R.id.button12) {
            this.mulX = 1.0f;
            this.mulY = 2.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(2);
        } else if (id == R.id.button32) {
            this.mulX = 3.0f;
            this.mulY = 2.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(3);
        } else if (id == R.id.button23) {
            this.mulX = 2.0f;
            this.mulY = 3.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(4);
        } else if (id == R.id.button43) {
            this.mulX = 4.0f;
            this.mulY = 3.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(5);
        } else if (id == R.id.button34) {
            this.mulX = 3.0f;
            this.mulY = 4.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(6);
        } else if (id == R.id.button45) {
            this.mulX = 4.0f;
            this.mulY = 5.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(7);
        } else if (id == R.id.button57) {
            this.mulX = 5.0f;
            this.mulY = 7.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(8);
        } else if (id == R.id.button169) {
            this.mulX = 16.0f;
            this.mulY = 9.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(9);
        } else if (id == R.id.button916) {
            this.mulX = 9.0f;
            this.mulY = 16.0f;
            this.collageView.updateShapeListForRatio(this.width, this.height);
            this.RatioButtonBg(10);
        } else if (id == R.id.hide_select_image_warning) {
            this.selectSwapTextView.setVisibility(View.INVISIBLE);
            this.swapMode = false;
        } else if (id == R.id.hide_select_image_warning_filter) {
            this.selectFilterTextView.setVisibility(View.INVISIBLE);
            this.selectImageForAdj = false;
        } else if (id == R.id.hide_color_container) {
            this.hideColorContainer();
        } else if (id == R.id.buttonText) {
            if (this.analytics != null) {
                this.analytics.logEvent("EDITOR_TEXT", "");
            }
            this.CanvasTextView();
            this.viewFlipper.setDisplayedChild(5);
            this.TabBg(-1);
        }
        if (id == R.id.buttonFit) {
            this.collageView.setShapeScaleMatrix(0);
            return;
        }
        if (id == R.id.buttonCenter) {
            this.collageView.setShapeScaleMatrix(1);
            return;
        }
        if (id == R.id.button_collage_context_rotate_left) {
            this.collageView.setShapeScaleMatrix(3);
            return;
        }
        if (id == R.id.button_collage_context_rotate_right) {
            this.collageView.setShapeScaleMatrix(2);
            return;
        }
        if (id == R.id.button_collage_context_flip_horizontal) {
            this.collageView.setShapeScaleMatrix(4);
            return;
        }
        if (id == R.id.button_collage_context_flip_vertical) {
            this.collageView.setShapeScaleMatrix(5);
            return;
        }
        if (id == R.id.button_collage_context_rotate_negative) {
            this.collageView.setShapeScaleMatrix(6);
            return;
        }
        if (id == R.id.button_collage_context_rotate_positive) {
            this.collageView.setShapeScaleMatrix(7);
            return;
        }
        if (id == R.id.button_collage_context_zoom_in) {
            this.toastMatrixMessage(this.collageView.setShapeScaleMatrix(8));
            return;
        }
        if (id == R.id.button_collage_context_zoom_out) {
            this.toastMatrixMessage(this.collageView.setShapeScaleMatrix(9));
            return;
        }
        if (id == R.id.button_collage_context_move_left) {
            this.toastMatrixMessage(this.collageView.setShapeScaleMatrix(10));
            return;
        }
        if (id == R.id.button_collage_context_move_right) {
            this.toastMatrixMessage(this.collageView.setShapeScaleMatrix(11));
            return;
        }
        if (id == R.id.button_collage_context_move_up) {
            this.toastMatrixMessage(this.collageView.setShapeScaleMatrix(12));
            return;
        }
        if (id == R.id.button_collage_context_move_down) {
            this.toastMatrixMessage(this.collageView.setShapeScaleMatrix(13));
            return;
        }
        if (this.fragmentFullEffect != null && this.fragmentFullEffect.isVisible()) {
            this.fragmentFullEffect.myClickHandler(view);
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 112 && i2 == -1 && intent.getExtras() != null) {
            Bundle extras = intent.getExtras();
            this.collageView.invalidate();
            this.stickercontain.bringToFront();
            int[] intArray = extras.getIntArray("MyArray");
            BitmapFactory.decodeResource(getResources(), R.drawable.sticker_remove_text);
            BitmapFactory.decodeResource(getResources(), R.drawable.sticker_scale_text);
            DrawableSticker drawableSticker;
            for (i = 0; i < intArray.length; ++i) {
                if (this.mainLayout == null) {
                    this.mainLayout = (RelativeLayout) this.findViewById(R.id.collage_main_layout);
                }
                drawableSticker = new DrawableSticker(ContextCompat.getDrawable((Context) this, intArray[i]));
                this.stickercontain.addSticker(drawableSticker);
                this.stickerlist.add(drawableSticker);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (this.fontFragment != null && this.fontFragment.isVisible()) {
            this.getSupportFragmentManager().beginTransaction().remove(this.fontFragment).commit();
            return;
        }
        if (!this.showText && this.canvasText != null) {
            this.showText = true;
            this.mainLayout.removeView((View) this.canvasText);
            this.collageView.postInvalidate();
            this.canvasText = null;
            return;
        }
        if (this.fragmentFullEffect == null || !this.fragmentFullEffect.isVisible()) {
            if (this.colorContainer.getVisibility() == View.VISIBLE) {
                this.hideColorContainer();
                return;
            }
            if (this.swapMode) {
                this.selectSwapTextView.setVisibility(View.INVISIBLE);
                this.swapMode = false;
                return;
            }
            if (this.collageView != null && this.collageView.shapeIndex >= 0) {
                this.collageView.unselectShapes();
                return;
            }
            if (this.selectImageForAdj) {
                this.selectFilterTextView.setVisibility(View.INVISIBLE);
                this.selectImageForAdj = false;
                return;
            }
            if (this.viewFlipper != null && this.viewFlipper.getDisplayedChild() != 5) {
                this.SelectedTab(5);
                return;
            }
            this.backButtonAlertBuilder();
        }
    }

    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.requestWindowFeature(1);
        this.getWindow().addFlags(1024);
        final Display defaultDisplay = this.getWindowManager().getDefaultDisplay();
        this.width = defaultDisplay.getWidth();
        this.height = defaultDisplay.getHeight();
        this.setContentView(R.layout.create_collage_activity);
        loadAd();
        this.stickercontain = (StickerView) this.findViewById(R.id.stickercontain);
        this.mainLayout = (RelativeLayout) this.findViewById(R.id.collage_main_layout);
        @SuppressLint("WrongConstant") final BitmapStickerIcon bitmapStickerIcon = new BitmapStickerIcon(ContextCompat.getDrawable((Context) this, R.drawable.sticker_ic_close_white_18dp), 0);
        bitmapStickerIcon.setIconEvent(new DeleteIconEvent());
        @SuppressLint("WrongConstant") final BitmapStickerIcon bitmapStickerIcon2 = new BitmapStickerIcon(ContextCompat.getDrawable((Context) this, R.drawable.sticker_ic_scale_white_18dp), 3);
        bitmapStickerIcon2.setIconEvent(new ZoomIconEvent());
        @SuppressLint("WrongConstant") final BitmapStickerIcon bitmapStickerIcon3 = new BitmapStickerIcon(ContextCompat.getDrawable((Context) this, R.drawable.sticker_ic_flip_white_18dp), 1);
        bitmapStickerIcon3.setIconEvent(new FlipHorizontallyEvent());
        this.stickercontain.setIcons(Arrays.asList(bitmapStickerIcon, bitmapStickerIcon2, bitmapStickerIcon3));
        (this.stickerwww = (ImageView) this.findViewById(R.id.buttonSticker)).setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public void onClick(final View view) {
                CollageActivity.selected_item = "EDITOR_STICKER";
                CollageActivity.this.startActivityForResult(new Intent((Context) CollageActivity.this, (Class) StickerActivity.class), 112);
            }
        });

        this.analytics = new Analytics((Context) this);
        this.stickercontain.setOnStickerOperationListener((StickerView.OnStickerOperationListener) new StickerView.OnStickerOperationListener() {
            public void onStickerAdded(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerClicked(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerDeleted(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerDoubleTapped(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerDragFinished(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerFlipped(@NonNull final Sticker sticker) {
            }

            public void onStickerNotClicked() {
                CollageActivity.this.stickercontain.invalidate();
            }

            public void onStickerTouchedDown(@NonNull final Sticker sticker) {
            }

            @Override
            public void onStickerZoomFinished(@NonNull final Sticker sticker) {
            }
        });
        final Bundle extras = this.getIntent().getExtras();
        final int collageSize = this.getCollageSize(extras);
        (this.seekBarRound = (SeekBar) this.findViewById(R.id.seekbar_round)).setOnSeekBarChangeListener(this.mSeekBarListener);
        (this.seekBarPadding = (SeekBar) this.findViewById(R.id.seekbar_padding)).setOnSeekBarChangeListener(this.mSeekBarListener);
        (this.seekbarSize = (SeekBar) this.findViewById(R.id.seekbar_size)).setOnSeekBarChangeListener(this.mSeekBarListener);
        (this.seekbarBlur = (SeekBar) this.findViewById(R.id.seekbar_collage_blur)).setOnSeekBarChangeListener(this.mSeekBarListener);
        final RecyclerView recyclerView = (RecyclerView) this.findViewById(R.id.recyclerViewColor);
        this.recyclerViewCollage = (RecyclerView) this.findViewById(R.id.recyclerViewCollage);
        final int color = this.getResources().getColor(R.color.background_color);
        final int color2 = this.getResources().getColor(R.color.footer_button_color_pressed);
        final LinearLayoutManager layoutManager = new LinearLayoutManager((Context) this);
        layoutManager.setOrientation(0);
        this.recyclerViewCollage.setLayoutManager((RecyclerView.LayoutManager) layoutManager);

        this.collageAdapter = new CollageAdapter(Collage.collageIconArray[collageSize - 1], (CollageAdapter.CurrentCollageIndexChangedListener) new CollageAdapter.CurrentCollageIndexChangedListener() {
            @Override
            public void onIndexChanged(final int currentCollageIndex) {
                CollageActivity.this.collageView.setCurrentCollageIndex(currentCollageIndex);
            }
        }, color, color2, false, true);
        this.recyclerViewCollage.setAdapter((RecyclerView.Adapter) this.collageAdapter);
        this.recyclerViewCollage.setItemAnimator((RecyclerView.ItemAnimator) new DefaultItemAnimator());
        (this.viewFlipper = (ViewFlipper) this.findViewById(R.id.collage_view_flipper)).setDisplayedChild(5);
        this.createAdapterList(color, color2);
        final RecyclerView recyclerView2 = (RecyclerView) this.findViewById(R.id.recyclerViewPattern);
        final LinearLayoutManager layoutManager2 = new LinearLayoutManager((Context) this);
        layoutManager2.setOrientation(0);
        this.colorContainer = (LinearLayout) this.findViewById(R.id.color_container);
        recyclerView2.setLayoutManager((RecyclerView.LayoutManager) layoutManager2);
        recyclerView2.setAdapter((RecyclerView.Adapter) new CollageAdapter(Utils.patternResIdList3, (CollageAdapter.CurrentCollageIndexChangedListener) new CollageAdapter.CurrentCollageIndexChangedListener() {
            @Override
            public void onIndexChanged(int n) {
                CollageActivity.this.collageView.backgroundMode = 0;
                if (n == 0) {
                    CollageActivity.this.collageView.setPatternPaint(-1);
                    return;
                }
                --n;
                if (CollageActivity.this.patternAdapterList.get(n) != recyclerView.getAdapter()) {
                    recyclerView.setAdapter((RecyclerView.Adapter) CollageActivity.this.patternAdapterList.get(n));
                    CollageActivity.this.patternAdapterList.get(n).setSelectedPositinVoid();
                } else {
                    CollageActivity.this.patternAdapterList.get(n).setSelectedPositinVoid();
                    ((RecyclerView.Adapter) CollageActivity.this.patternAdapterList.get(n)).notifyDataSetChanged();
                }
                CollageActivity.this.colorContainer.setVisibility(View.VISIBLE);
            }
        }, color, color2, false, false));
        recyclerView2.setItemAnimator((RecyclerView.ItemAnimator) new DefaultItemAnimator());
        final LinearLayoutManager layoutManager3 = new LinearLayoutManager((Context) this);
        layoutManager3.setOrientation(0);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager) layoutManager3);
        recyclerView.setAdapter((RecyclerView.Adapter) new ColorPickerAdapter(new CollageAdapter.CurrentCollageIndexChangedListener() {
            @Override
            public void onIndexChanged(final int patternPaintColor) {
                CollageActivity.this.collageView.setPatternPaintColor(patternPaintColor);
            }
        }, color, color2));
        recyclerView.setItemAnimator((RecyclerView.ItemAnimator) new DefaultItemAnimator());
        horizontalScrollView = (HorizontalScrollView) this.findViewById(R.id.collage_footer);
        horizontalScrollView.bringToFront();
        horizontalScrollView.postDelayed((Runnable) new Runnable() {
            @Override
            public void run() {
                horizontalScrollView.scrollTo(horizontalScrollView.getChildAt(0).getMeasuredWidth(), 0);
            }
        }, 50L);
        horizontalScrollView.postDelayed((Runnable) new Runnable() {
            @Override
            public void run() {
                horizontalScrollView.fullScroll(17);
            }
        }, 600L);
        new BitmapWorkerTask().execute(new Bundle[]{extras, bundle});
    }

    String resultPathCopy;
    private int Id;

    private void loadAd() {

        //Banner Ad
        adView = findViewById(R.id.AdView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        Log.i("TAG", "LodingAd==>" + adRequest);
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {

            public void onAdLoaded() {
                super.onAdLoaded();
                Log.e("TAG", "Ad Load ");
            }

            public void onAdClosed() {
                hud.dismiss();
                switch (Id) {
                    case R.id.button_save_collage_image:
                        stickercontain.setLocked(true);
                        new SaveImageTask().execute(new Object[0]);
                        return;
                }
                interstitialAd.loadAd(adRequestfull);
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(CollageActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }


    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    //@Override
    protected void onDestroy() {
        super.onDestroy();
        final Bitmap[] bitmapList = this.bitmapList;
        final int n = 0;
        if (bitmapList != null) {
            for (int i = 0; i < this.bitmapList.length; ++i) {
                if (this.bitmapList[i] != null) {
                    this.bitmapList[i].recycle();
                }
            }
        }
        if (this.collageView != null) {
            if (this.collageView.shapeLayoutList != null) {
                for (int j = 0; j < this.collageView.shapeLayoutList.size(); ++j) {
                    for (int k = 0; k < this.collageView.shapeLayoutList.get(j).shapeArr.length; ++k) {
                        if (this.collageView.shapeLayoutList.get(j).shapeArr[k] != null) {
                            this.collageView.shapeLayoutList.get(j).shapeArr[k].freeBitmaps();
                        }
                    }
                }
            }
            if (this.collageView.maskBitmapArray != null) {
                for (int l = n; l < this.collageView.maskBitmapArray.length; ++l) {
                    if (this.collageView.maskBitmapArray[l] != null) {
                        if (!this.collageView.maskBitmapArray[l].isRecycled()) {
                            this.collageView.maskBitmapArray[l].recycle();
                        }
                        this.collageView.maskBitmapArray[l] = null;
                    }
                }
            }
        }
    }

    public void onPause() {
        super.onPause();
    }

    protected void onRestoreInstanceState(final Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.showText = bundle.getBoolean("show_text");
        this.textDataList = (ArrayList<TextDataItem>) bundle.getSerializable("text_data");
        if (this.textDataList == null) {
            this.textDataList = new ArrayList<TextDataItem>();
        }
        if (this.contextFooter == null) {
            this.contextFooter = (ViewGroup) this.findViewById(R.id.collage_context_menu);
        }
        if (this.contextFooter != null) {
            this.contextFooter.bringToFront();
        }
    }

    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onSaveInstanceState(final Bundle bundle) {
        bundle.putBoolean("show_text", this.showText);
        bundle.putSerializable("text_data", (Serializable) this.textDataList);
        if (this.fontFragment != null && this.fontFragment.isVisible()) {
            this.getSupportFragmentManager().beginTransaction().remove(this.fontFragment).commit();
        }
        super.onSaveInstanceState(bundle);
    }

    protected void SelectedTab(final int n) {
        if (this.viewFlipper != null) {
            this.TabBg(0);
            final int displayedChild = this.viewFlipper.getDisplayedChild();
            if (displayedChild != 1) {
                this.hideColorContainer();
            }
            if (n == 0) {
                if (displayedChild == 0) {
                    return;
                }
                this.viewFlipper.setInAnimation(this.slideLeftIn);
                this.viewFlipper.setOutAnimation(this.slideRightOut);
                this.viewFlipper.setDisplayedChild(0);
            }
            if (n == 1) {
                this.TabBg(1);
                if (displayedChild == 1) {
                    return;
                }
                if (displayedChild == 0) {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                } else {
                    this.viewFlipper.setInAnimation(this.slideLeftIn);
                    this.viewFlipper.setOutAnimation(this.slideRightOut);
                }
                this.viewFlipper.setDisplayedChild(1);
            }
            if (n == 4) {
                this.TabBg(4);
                if (displayedChild == 4) {
                    return;
                }
                if (displayedChild == 0) {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                } else {
                    this.viewFlipper.setInAnimation(this.slideLeftIn);
                    this.viewFlipper.setOutAnimation(this.slideRightOut);
                }
                this.viewFlipper.setDisplayedChild(4);
            }
            if (n == 2) {
                this.TabBg(2);
                if (displayedChild == 2) {
                    return;
                }
                if (displayedChild != 0 && displayedChild != 1) {
                    this.viewFlipper.setInAnimation(this.slideLeftIn);
                    this.viewFlipper.setOutAnimation(this.slideRightOut);
                } else {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                }
                this.viewFlipper.setDisplayedChild(2);
            }
            if (n == 3) {
                this.TabBg(3);
                if (displayedChild == 3) {
                    return;
                }
                if (displayedChild == 5) {
                    this.viewFlipper.setInAnimation(this.slideLeftIn);
                    this.viewFlipper.setOutAnimation(this.slideRightOut);
                } else {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                }
                this.viewFlipper.setDisplayedChild(3);
            }
            if (n == 5) {
                this.TabBg(-1);
                if (displayedChild != 5) {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                    this.viewFlipper.setDisplayedChild(5);
                }
            }
        }
    }

    void setVisibilityOfFilterHorizontalListview(final boolean b) {
        if (b && this.fragmentFullEffect.isHidden()) {
            this.getSupportFragmentManager().beginTransaction().show(this.fragmentFullEffect).commit();
        }
        if (!b && this.fragmentFullEffect.isVisible()) {
            this.getSupportFragmentManager().beginTransaction().hide(this.fragmentFullEffect).commit();
        }
        this.findViewById(R.id.collage_effect_fragment_container).bringToFront();
    }

    void toastMatrixMessage(final int n) {
        String s;
        if (n == 1) {
            s = "You reached maximum zoom!";
        } else if (n == 2) {
            s = "You reached minimum zoom!";
        } else if (n == 6) {
            s = "You reached max bottom!";
        } else if (n == 5) {
            s = "You reached max top!";
        } else if (n == 4) {
            s = "You reached max right!";
        } else if (n == 3) {
            s = "You reached max left!";
        } else {
            s = null;
        }
        if (s != null) {
            @SuppressLint("WrongConstant") final Toast text = Toast.makeText((Context) this, (CharSequence) s, 0);
            text.setGravity(17, text.getXOffset() / 2, text.getYOffset() / 2);
            text.show();
        }
    }

    class BitmapWorkerTask extends AsyncTask<Bundle, Void, Void> {
        int arraySize;
        Bundle data;
        ProgressDialog progressDialog;
        Bundle savedInstanceState;

        protected Void doInBackground(final Bundle... array) {
            final int n = 0;
            this.data = array[0];
            this.savedInstanceState = array[1];
            CollageActivity.this.isScrapBook = this.data.getBoolean("is_scrap_book", false);
            final long[] longArray = this.data.getLongArray("photo_id_list");
            final int[] intArray = this.data.getIntArray("photo_orientation_list");
            this.arraySize = 0;
            if (longArray == null) {
                final String string = this.data.getString("selected_image_path");
                if (string != null) {
                    this.arraySize = 1;
                    CollageActivity.this.bitmapList = new Bitmap[this.arraySize];
                    int arraySize;
                    if ((arraySize = this.arraySize) < 3) {
                        arraySize = 3;
                    }
                    CollageActivity.this.bitmapList[0] = Utils.decodeFile(string, Utility.maxSizeForDimension((Context) CollageActivity.this, arraySize, 1500.0f), CollageActivity.this.isScrapBook);
                }
            } else {
                this.arraySize = longArray.length;
                CollageActivity.this.bitmapList = new Bitmap[this.arraySize];
                int arraySize2;
                if ((arraySize2 = this.arraySize) < 3) {
                    arraySize2 = 3;
                }
                final int maxSizeForDimension = Utility.maxSizeForDimension((Context) CollageActivity.this, arraySize2, 1500.0f);
                int n2;
                for (int i = n2 = 0; i < this.arraySize; ++i) {
                    final Bitmap scaledBitmapFromId = Utils.getScaledBitmapFromId((Context) CollageActivity.this, longArray[i], intArray[i], maxSizeForDimension, CollageActivity.this.isScrapBook);
                    if (scaledBitmapFromId != null) {
                        CollageActivity.this.bitmapList[i] = scaledBitmapFromId;
                    } else {
                        ++n2;
                    }
                }
                if (n2 > 0) {
                    final int arraySize3 = this.arraySize - n2;
                    final Bitmap[] bitmapList = new Bitmap[arraySize3];
                    int n3;
                    int n4;
                    for (int j = n3 = 0; j < this.arraySize; ++j, n3 = n4) {
                        n4 = n3;
                        if (CollageActivity.this.bitmapList[j] != null) {
                            bitmapList[n3] = CollageActivity.this.bitmapList[j];
                            n4 = n3 + 1;
                        }
                    }
                    this.arraySize = arraySize3;
                    CollageActivity.this.bitmapList = bitmapList;
                }
            }
            CollageActivity.this.parameterList = new Parameter[this.arraySize];
            for (int k = n; k < CollageActivity.this.parameterList.length; ++k) {
                CollageActivity.this.parameterList[k] = new Parameter();
            }
            return null;
        }

        protected void onPostExecute(final Void void1) {
            try {
                this.progressDialog.dismiss();
                if (this.arraySize <= 0) {
                    @SuppressLint("WrongConstant") final Toast text = Toast.makeText((Context) CollageActivity.this, (CharSequence) "Couldn't load images!", 0);
                    text.setGravity(17, text.getXOffset() / 2, text.getYOffset() / 2);
                    text.show();
                    CollageActivity.this.finish();
                    return;
                }
                if (Collage.collageIconArray[CollageActivity.this.bitmapList.length - 1] != CollageActivity.this.collageAdapter.iconList) {
                    CollageActivity.this.collageAdapter.setData(Collage.collageIconArray[CollageActivity.this.bitmapList.length - 1]);
                    ((RecyclerView.Adapter) CollageActivity.this.collageAdapter).notifyDataSetChanged();
                }
                if (CollageActivity.this.isScrapBook) {
                    CollageActivity.this.btmDelete = BitmapFactory.decodeResource(CollageActivity.this.getResources(), R.drawable.ic_cancel);
                    CollageActivity.this.btmScale = BitmapFactory.decodeResource(CollageActivity.this.getResources(), R.drawable.scrapbook_scale);
                }
                if (CollageActivity.this.isScrapBook) {
                    CollageActivity.this.npd = (NinePatchDrawable) ContextCompat.getDrawable((Context) CollageActivity.this, R.drawable.shadow_7);
                    final StringBuilder sb = new StringBuilder();
                    sb.append("ndp width ");
                    sb.append(CollageActivity.this.npd.getMinimumHeight());
                }
                CollageActivity.this.collageView = new CollageView((Context) CollageActivity.this, CollageActivity.this.width, CollageActivity.this.height);
                (CollageActivity.this.mainLayout = (RelativeLayout) CollageActivity.this.findViewById(R.id.collage_main_layout)).addView((View) CollageActivity.this.collageView);
                CollageActivity.this.viewFlipper.bringToFront();
                CollageActivity.this.slideLeftIn = AnimationUtils.loadAnimation((Context) CollageActivity.this, R.anim.slide_in_left);
                CollageActivity.this.slideLeftOut = AnimationUtils.loadAnimation((Context) CollageActivity.this, R.anim.slide_out_left);
                CollageActivity.this.slideRightIn = AnimationUtils.loadAnimation((Context) CollageActivity.this, R.anim.slide_in_right);
                CollageActivity.this.slideRightOut = AnimationUtils.loadAnimation((Context) CollageActivity.this, R.anim.slide_out_right);
                CollageActivity.this.EffectFragment();
                if (this.arraySize == 1) {
                    CollageActivity.this.SingleImage();
                }
                if (CollageActivity.this.isScrapBook) {
                    CollageActivity.this.Scrapbook();
                }
                (CollageActivity.this.viewFlipper = (ViewFlipper) CollageActivity.this.findViewById(R.id.collage_view_flipper)).bringToFront();
                CollageActivity.this.findViewById(R.id.collage_footer).bringToFront();
                CollageActivity.this.findViewById(R.id.collage_header).bringToFront();
                (CollageActivity.this.contextFooter = (ViewGroup) CollageActivity.this.findViewById(R.id.collage_context_menu)).bringToFront();
                (CollageActivity.this.selectSwapTextView = CollageActivity.this.findViewById(R.id.select_image_swap)).bringToFront();
                CollageActivity.this.selectSwapTextView.setVisibility(View.INVISIBLE);
                (CollageActivity.this.selectFilterTextView = CollageActivity.this.findViewById(R.id.select_image_filter)).bringToFront();
                CollageActivity.this.selectFilterTextView.setVisibility(View.INVISIBLE);
            } catch (Exception ex) {
            }
        }

        protected void onPreExecute() {
            (this.progressDialog = new ProgressDialog((Context) CollageActivity.this)).setCancelable(false);
            this.progressDialog.setMessage((CharSequence) "loading images!");
            this.progressDialog.show();
        }
    }

    class CollageView extends View {
        public static final int BACKGROUND_BLUR = 1;
        public static final int BACKGROUND_PATTERN = 0;
        private static final int INVALID_POINTER_ID = 1;
        public static final int PATTERN_SENTINEL = -1;
        static final float RATIO_CONSTANT = 1.25f;
        private static final int UPPER_SIZE_LIMIT = 2048;
        float MIN_ZOOM;
        RectF above;
        int animEpsilon;
        int animHalfTime;
        int animSizeSeekbarProgress;
        boolean animate;
        int animationCount;
        int animationDurationLimit;
        int animationLimit;
        private Runnable animator;
        int backgroundMode;
        Bitmap blurBitmap;
        ImageBlurNormal blurBuilderNormal;
        int blurRadius;
        RectF blurRectDst;
        Rect blurRectSrc;
        Paint borderPaint;
        RectF bottom;
        RectF bottomLeft;
        RectF bottomRight;
        Paint circlePaint;
        float cornerRadius;
        int currentCollageIndex;
        RectF drawingAreaRect;
        final float epsilon;
        float finalAngle;
        Bitmap frameBitmap;
        int frameDuration;
        RectF frameRect;
        Matrix identityMatrix;
        boolean isInCircle;
        boolean isOnCross;
        RectF left;
        private int mActivePointerId;
        float mLastTouchX;
        float mLastTouchY;
        private ScaleGestureDetector mScaleDetector;
        float mScaleFactor;
        private GestureDetectorCompat mTouchDetector;
        Bitmap[] maskBitmapArray;
        int[] maskResIdList;
        float[] matrixValues;
        boolean move;
        int offsetX;
        int offsetY;
        boolean orthogonal;
        float paddingDistance;
        Paint paint;
        Paint paintGray;
        Bitmap patternBitmap;
        Paint patternPaint;
        int previousIndex;
        float[] pts;
        Rect rectAnim;
        RectF right;
        RotationGestureDetector.OnRotationGestureListener rotateListener;
        Shape scaleShape;
        int screenHeight;
        int screenWidth;
        int shapeIndex;
        List<ShapeLayout> shapeLayoutList;
        Matrix sizeMatrix;
        Matrix sizeMatrixSaved;
        float sizeScale;
        ArrayList<Float> smallestDistanceList;
        private float startAngle;
        Matrix startMatrix;
        long startTime;
        Matrix textMatrix;
        RectF topLeft;
        RectF topRight;
        float[] values;
        float xscale;
        float yscale;
        PointF zoomStart;

        public CollageView(final Context context, final int screenWidth, final int screenHeight) {
            super(context);
            this.blurRadius = 14;
            this.paint = new Paint();
            this.paddingDistance = 0.0f;
            this.cornerRadius = 0.0f;
            this.currentCollageIndex = 0;
            this.shapeIndex = -1;
            this.patternPaint = new Paint(1);
            this.shapeLayoutList = new ArrayList<ShapeLayout>();
            this.identityMatrix = new Matrix();
            this.maskResIdList = new int[]{R.drawable.mask_butterfly, R.drawable.mask_cloud, R.drawable.mask_clover, R.drawable.mask_leaf, R.drawable.mask_left_foot, R.drawable.mask_diamond, R.drawable.mask_santa, R.drawable.mask_snowman, R.drawable.mask_paw, R.drawable.mask_egg, R.drawable.mask_twitter, R.drawable.mask_circle, R.drawable.mask_hexagon, R.drawable.mask_heart};
            this.smallestDistanceList = new ArrayList<Float>();
            this.yscale = 1.0f;
            this.xscale = 1.0f;
            this.sizeScale = 1.0f;
            this.sizeMatrix = new Matrix();
            this.animSizeSeekbarProgress = 0;
            this.animate = false;
            this.animationCount = 0;
            this.animationLimit = 31;
            this.animHalfTime = this.animationLimit / 2 + 1;
            this.frameDuration = 10;
            this.animEpsilon = 20;
            this.animationDurationLimit = 50;
            this.startTime = System.nanoTime();
            this.animator = new Runnable() {
                @Override
                public void run() {
                    final int n = (int) ((System.nanoTime() - CollageView.this.startTime) / 1000000.0f) / CollageView.this.animationDurationLimit;
                    final boolean b = true;
                    int n2 = n;
                    if (n <= 0) {
                        n2 = 1;
                    }
                    if (CollageView.this.animationCount == 0) {
                        final CollageView collageView = CollageActivity.this.collageView;
                        ++collageView.animationCount;
                    } else {
                        final CollageView collageView2 = CollageActivity.this.collageView;
                        collageView2.animationCount += n2;
                    }
                    CollageView.this.setCollageSize(CollageView.this.sizeMatrix, CollageView.this.animSize(CollageView.this.animationCount));
                    boolean b2;
                    if (CollageView.this.animationCount < CollageView.this.animationLimit) {
                        b2 = b;
                    } else {
                        CollageView.this.animate = false;
                        b2 = false;
                    }
                    if (b2) {
                        CollageView.this.postDelayed((Runnable) this, (long) CollageView.this.frameDuration);
                    } else {
                        CollageView.this.sizeMatrix.set(CollageView.this.sizeMatrixSaved);
                    }
                    CollageView.this.shapeLayoutList.get(CollageView.this.currentCollageIndex).shapeArr[0].f508r.roundOut(CollageView.this.rectAnim);
                    CollageView.this.invalidate(CollageView.this.rectAnim);
                    CollageView.this.startTime = System.nanoTime();
                }
            };
            this.rectAnim = new Rect();
            this.textMatrix = new Matrix();
            this.blurRectDst = new RectF();
            this.drawingAreaRect = new RectF();
            this.above = new RectF();
            this.left = new RectF();
            this.right = new RectF();
            this.bottom = new RectF();
            this.move = false;
            this.paintGray = new Paint(1);
            this.mActivePointerId = 1;
            this.zoomStart = new PointF();
            this.startMatrix = new Matrix();
            this.startAngle = 0.0f;
            this.MIN_ZOOM = 0.1f;
            this.isInCircle = false;
            this.isOnCross = false;
            this.orthogonal = false;
            this.mScaleFactor = 1.0f;
            this.matrixValues = new float[9];
            this.finalAngle = 0.0f;
            this.epsilon = 4.0f;
            this.rotateListener = new RotationGestureDetector.OnRotationGestureListener() {
                @Override
                public void OnRotation(final RotationGestureDetector rotationGestureDetector) {
                    if (CollageView.this.shapeIndex >= 0) {
                        final float angle = rotationGestureDetector.getAngle();
                        CollageView.this.scaleShape = CollageView.this.shapeLayoutList.get(CollageView.this.currentCollageIndex).shapeArr[CollageView.this.shapeIndex];
                        final float matrixRotation = CollageView.this.getMatrixRotation(CollageView.this.scaleShape.bitmapMatrix);
                        if ((matrixRotation == 0.0f || matrixRotation == 90.0f || matrixRotation == 180.0f || matrixRotation == -180.0f || matrixRotation == -90.0f) && Math.abs(CollageView.this.finalAngle - angle) < 4.0f) {
                            CollageView.this.orthogonal = true;
                            return;
                        }
                        float n = angle;
                        if (Math.abs(matrixRotation - CollageView.this.finalAngle + angle) < 4.0f) {
                            n = CollageView.this.finalAngle - matrixRotation;
                            CollageView.this.orthogonal = true;
                        }
                        float n2 = n;
                        if (Math.abs(90.0f - (matrixRotation - CollageView.this.finalAngle + n)) < 4.0f) {
                            n2 = CollageView.this.finalAngle + 90.0f - matrixRotation;
                            CollageView.this.orthogonal = true;
                        }
                        float n3 = n2;
                        if (Math.abs(180.0f - (matrixRotation - CollageView.this.finalAngle + n2)) < 4.0f) {
                            n3 = 180.0f + CollageView.this.finalAngle - matrixRotation;
                            CollageView.this.orthogonal = true;
                        }
                        float finalAngle = n3;
                        if (Math.abs(-180.0f - (matrixRotation - CollageView.this.finalAngle + n3)) < 4.0f) {
                            finalAngle = CollageView.this.finalAngle - 0.024902344f - matrixRotation;
                            CollageView.this.orthogonal = true;
                        }
                        if (Math.abs(-90.0f - (matrixRotation - CollageView.this.finalAngle + finalAngle)) < 4.0f) {
                            finalAngle = CollageView.this.finalAngle - 0.049804688f - matrixRotation;
                            CollageView.this.orthogonal = true;
                        } else {
                            CollageView.this.orthogonal = false;
                        }
                        CollageView.this.scaleShape.bitmapMatrixRotate(CollageView.this.finalAngle - finalAngle);
                        CollageView.this.finalAngle = finalAngle;
                        CollageView.this.invalidate();
                        CollageView.this.requestLayout();
                    }
                }
            };
            this.values = new float[9];
            this.backgroundMode = 0;
            this.blurRectSrc = new Rect();
            this.maskBitmapArray = new Bitmap[this.maskResIdList.length];
            (this.borderPaint = new Paint(1)).setColor(this.getResources().getColor(R.color.blue));
            this.borderPaint.setStyle(Paint.Style.STROKE);
            this.borderPaint.setStrokeWidth(10.0f);
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            (this.circlePaint = new Paint()).setColor(-65536);
            this.identityMatrix.reset();
            final float n = screenWidth * 0;
            final float n2 = screenHeight * 0;
            final float n3 = screenWidth;
            final float n4 = 0.5f * n3;
            final float n5 = screenHeight;
            final float n6 = 0.5f * n5;
            this.topLeft = new RectF(n, n2, n4, n6);
            final float n7 = n3 * 1.0f;
            this.topRight = new RectF(n4, 0.0f * n5, n7, n6);
            final float n8 = 1.0f * n5;
            this.bottomLeft = new RectF(n, n6, n4, n8);
            this.bottomRight = new RectF(n4, n6, n7, n8);
            final Path path = new Path();
            final Path path2 = new Path();
            final Path path3 = new Path();
            final Path path4 = new Path();
            path.addRect(this.topLeft, Path.Direction.CCW);
            path2.addRect(this.topRight, Path.Direction.CCW);
            path3.addRect(this.bottomLeft, Path.Direction.CCW);
            path4.addRect(this.bottomRight, Path.Direction.CCW);
            this.mTouchDetector = new GestureDetectorCompat(context, (GestureDetector.OnGestureListener) new MyGestureListener());
            this.mScaleDetector = new ScaleGestureDetector(context, (ScaleGestureDetector.OnScaleGestureListener) new ScaleListener());
            CollageActivity.this.mRotationDetector = new RotationGestureDetector(this.rotateListener);
            this.calculateOffset();
            (this.patternPaint = new Paint(1)).setColor(-1);
            this.createShapeList(CollageActivity.this.bitmapList.length, screenWidth, screenHeight);
            this.paintGray.setColor(-12303292);
        }

        private void calculateOffset() {
            final PointF ratio = this.getRatio();
            this.offsetX = (int) ((CollageActivity.this.width - ratio.x * CollageActivity.this.width) / 2.0f);
            this.offsetY = (int) ((CollageActivity.this.height - ratio.y * CollageActivity.this.width) / 2.0f);
        }

        private Bitmap convertToAlphaMask(final Bitmap bitmap) {
            final Bitmap bitmap2 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ALPHA_8);
            new Canvas(bitmap2).drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
            bitmap.recycle();
            return bitmap2;
        }

        private void createShapeList(int i, int i2, int i3) {
            int i4 = i;
            this.shapeLayoutList.clear();
            this.smallestDistanceList.clear();
            int i5 = i2;
            Collage CreateCollage = Collage.CreateCollage(i4, i5, i5, isScrapBook);
            int i6 = 0;
            i5 = ((CollageLayout) CreateCollage.collageLayoutList.get(0)).shapeList.size();
            String str = CollageActivity.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("bitmapList.length ");
            stringBuilder.append(bitmapList.length);
            Log.e(str, stringBuilder.toString());
            int i7 = 0;
            while (i7 < CreateCollage.collageLayoutList.size()) {
                int i8;
                Shape[] shapeArr = new Shape[i5];
                int i9 = i6;
                while (i9 < i4) {
                    int i10;
                    int i11;
                    if (((CollageLayout) CreateCollage.collageLayoutList.get(i7)).maskPairList == null || ((CollageLayout) CreateCollage.collageLayoutList.get(i7)).maskPairList.isEmpty()) {
                        i10 = i6;
                        i11 = i10;
                    } else {
                        i10 = i6;
                        i11 = i10;
                        for (MaskPair maskPair : ((CollageLayout) CreateCollage.collageLayoutList.get(i7)).maskPairList) {
                            if (i9 == maskPair.index) {
                                i11 = maskPair.id;
                                i10 = 1;
                            }
                        }
                    }
                    if (i10 != 0) {
                        Bitmap bitmap = null;
                        i10 = getMaskIndex(i11);
                        if (i10 >= 0) {
                            if (this.maskBitmapArray == null) {
                                this.maskBitmapArray = new Bitmap[this.maskResIdList.length];
                            }
                            if (this.maskBitmapArray[i10] == null) {
                                this.maskBitmapArray[i10] = loadMaskBitmap2(i11);
                                Log.e(CollageActivity.TAG, "load mask bitmap from factory");
                            } else {
                                Log.e(CollageActivity.TAG, "load mask bitmap from pool");
                            }
                            bitmap = this.maskBitmapArray[i10];
                        }
                        Bitmap bitmap2 = bitmap;
                        int i12 = i9;
                        i6 = i12;
                        shapeArr[i6] = new Shape((PointF[]) ((CollageLayout) CreateCollage.collageLayoutList.get(i7)).shapeList.get(i9), bitmapList[i9], null, this.offsetX, this.offsetY, bitmap2, isScrapBook, i12, false, btmDelete, btmScale, this.screenWidth);
                        if (isScrapBook) {
                            shapeArr[i6].initScrapBook(npd);
                        }
                        i8 = i5;
                    } else {
                        i6 = i9;
                        PointF[] pointFArr = (PointF[]) ((CollageLayout) CreateCollage.collageLayoutList.get(i7)).shapeList.get(i6);
                        Bitmap bitmap3 = bitmapList[i6];
                        int[] iArr = ((CollageLayout) CreateCollage.collageLayoutList.get(i7)).getexceptionIndex(i6);
                        int i13 = this.offsetX;
                        int i14 = this.offsetY;
                        boolean z = isScrapBook;
                        i8 = i5;
                        Bitmap bitmap4 = btmDelete;
                        shapeArr[i6] = new Shape(pointFArr, bitmap3, iArr, i13, i14, z, i6, false, bitmap4, btmScale, this.screenWidth);
                        if (isScrapBook) {
                            shapeArr[i6].initScrapBook(npd);
                        }
                    }
                    i9 = i6 + 1;
                    i5 = i8;
                    i6 = 0;
                }
                i8 = i5;
                this.smallestDistanceList.add(Float.valueOf(smallestDistance(shapeArr)));
                ShapeLayout shapeLayout = new ShapeLayout(shapeArr);
                shapeLayout.setClearIndex(((CollageLayout) CreateCollage.collageLayoutList.get(i7)).getClearIndex());
                this.shapeLayoutList.add(shapeLayout);
                i7++;
                i5 = i8;
                i6 = 0;
            }
            if (!isScrapBook) {
                if (i4 != 1) {
                    for (i4 = 0; i4 < this.shapeLayoutList.size(); i4++) {
                        setPathPadding(i4, (float) getResources().getInteger(R.integer.default_space_value));
                        for (Shape scaleMatrix : ((ShapeLayout) this.shapeLayoutList.get(i4)).shapeArr) {
                            scaleMatrix.setScaleMatrix(1);
                        }
                    }
                    setCollageSize(this.sizeMatrix, getResources().getInteger(R.integer.default_ssize_value));
                } else if (bitmapList.length == 1) {
                    setCollageSize(this.sizeMatrix, getResources().getInteger(R.integer.default_ssize_value));
                }
            }
        }

        private void deleteBitmap(int i, int i2, int i3) {
            int i4 = i;
            int i5 = i2;
            String str = CollageActivity.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Index");
            stringBuilder.append(i4);
            Log.e(str, stringBuilder.toString());
            int i6 = 0;
            Shape[] shapeArr = ((ShapeLayout) this.shapeLayoutList.get(0)).shapeArr;
            if (i4 >= 0 && i4 < ((ShapeLayout) this.shapeLayoutList.get(0)).shapeArr.length) {
                Bitmap[] bitmapArr;
                int length = ((ShapeLayout) this.shapeLayoutList.get(0)).shapeArr.length - 1;
                Bitmap[] bitmapArr2 = new Bitmap[length];
                Bitmap[] bitmapArr3 = new Bitmap[length];
                int i7 = 0;
                int i8 = i7;
                while (i7 < bitmapArr2.length + 1) {
                    if (i7 != i4) {
                        bitmapArr2[i8] = ((ShapeLayout) this.shapeLayoutList.get(0)).shapeArr[i7].getBitmap();
                        bitmapArr3[i8] = bitmapList[i7];
                        i8++;
                    }
                    i7++;
                }
                bitmapList[i4].recycle();
                ((ShapeLayout) this.shapeLayoutList.get(0)).shapeArr[i4].getBitmap().recycle();
                this.shapeLayoutList.clear();
                this.smallestDistanceList.clear();
                Collage CreateCollage = Collage.CreateCollage(length, i5, i5, isScrapBook);
                i8 = ((CollageLayout) CreateCollage.collageLayoutList.get(0)).shapeList.size();
                bitmapList = bitmapArr3;
                int i9 = 0;
                while (i9 < CreateCollage.collageLayoutList.size()) {
                    int i10;
                    Shape[] shapeArr2 = new Shape[i8];
                    int i11 = i6;
                    while (i11 < bitmapArr2.length) {
                        int i12;
                        int i13;
                        if (((CollageLayout) CreateCollage.collageLayoutList.get(i9)).maskPairList == null || ((CollageLayout) CreateCollage.collageLayoutList.get(i9)).maskPairList.isEmpty()) {
                            i12 = 0;
                            i13 = 0;
                        } else {
                            i12 = i6;
                            i13 = i12;
                            for (MaskPair maskPair : ((CollageLayout) CreateCollage.collageLayoutList.get(i9)).maskPairList) {
                                if (i11 == maskPair.index) {
                                    i13 = maskPair.id;
                                    i12 = 1;
                                }
                            }
                        }
                        int maskIndex;
                        PointF[] pointFArr;
                        Bitmap bitmap;
                        int i14;
                        int i15;
                        if (i12 != 0) {
                            Bitmap bitmap2 = null;
                            maskIndex = getMaskIndex(i13);
                            if (maskIndex >= 0) {
                                if (this.maskBitmapArray == null) {
                                    this.maskBitmapArray = new Bitmap[this.maskResIdList.length];
                                }
                                if (this.maskBitmapArray[maskIndex] == null) {
                                    this.maskBitmapArray[maskIndex] = loadMaskBitmap2(i13);
                                    Log.e(CollageActivity.TAG, "load mask bitmap from factory");
                                } else {
                                    Log.e(CollageActivity.TAG, "load mask bitmap from pool");
                                }
                                bitmap2 = this.maskBitmapArray[maskIndex];
                            }
                            Bitmap bitmap3 = bitmap2;
                            pointFArr = (PointF[]) ((CollageLayout) CreateCollage.collageLayoutList.get(i9)).shapeList.get(i11);
                            bitmap = bitmapArr2[i11];
                            int i16 = this.offsetX;
                            maskIndex = this.offsetY;
                            i10 = i8;
                            boolean z = isScrapBook;
                            int i17 = i16;
                            Bitmap bitmap4 = btmDelete;
                            i14 = i17;
                            Bitmap bitmap5 = bitmap4;
                            int i18 = i11;
                            i15 = maskIndex;
                            boolean z2 = z;
                            int i19 = i18;
                            i8 = i18;
                            shapeArr2[i8] = new Shape(pointFArr, bitmap, null, i14, i15, bitmap3, z2, i19, true, bitmap5, btmScale, this.screenWidth);
                            if (isScrapBook) {
                                shapeArr2[i8].initScrapBook(npd);
                            }
                            bitmapArr = bitmapArr2;
                        } else {
                            i10 = i8;
                            i8 = i11;
                            pointFArr = (PointF[]) ((CollageLayout) CreateCollage.collageLayoutList.get(i9)).shapeList.get(i8);
                            bitmap = bitmapArr2[i8];
                            int[] iArr = ((CollageLayout) CreateCollage.collageLayoutList.get(i9)).getexceptionIndex(i8);
                            maskIndex = this.offsetX;
                            int i20 = this.offsetY;
                            boolean z3 = isScrapBook;
                            Bitmap bitmap6 = btmDelete;
                            bitmapArr = bitmapArr2;
                            i15 = i20;
                            boolean z4 = z3;
                            Bitmap bitmap7 = bitmap6;
                            i14 = maskIndex;
                            int i21 = i8;
                            shapeArr2[i8] = new Shape(pointFArr, bitmap, iArr, i14, i15, z4, i21, true, bitmap7, btmScale, this.screenWidth);
                            if (isScrapBook) {
                                shapeArr2[i8].initScrapBook(npd);
                            }
                        }
                        i11 = i8 + 1;
                        i8 = i10;
                        bitmapArr2 = bitmapArr;
                        i6 = 0;
                    }
                    bitmapArr = bitmapArr2;
                    i10 = i8;
                    if (isScrapBook) {
                        for (i6 = 0; i6 < shapeArr.length; i6++) {
                            if (i6 < i4) {
                                shapeArr2[i6].bitmapMatrix.set(shapeArr[i6].bitmapMatrix);
                            }
                            if (i6 > i4) {
                                shapeArr2[i6 - 1].bitmapMatrix.set(shapeArr[i6].bitmapMatrix);
                            }
                        }
                    }
                    ShapeLayout shapeLayout = new ShapeLayout(shapeArr2);
                    shapeLayout.setClearIndex(((CollageLayout) CreateCollage.collageLayoutList.get(i9)).getClearIndex());
                    this.shapeLayoutList.add(shapeLayout);
                    this.smallestDistanceList.add(Float.valueOf(smallestDistance(shapeArr2)));
                    i9++;
                    i8 = i10;
                    bitmapArr2 = bitmapArr;
                    i6 = 0;
                }
                bitmapArr = bitmapArr2;
                this.currentCollageIndex = i6;
                collageAdapter.selectedPosition = i6;
                collageAdapter.setData(Collage.collageIconArray[length - 1]);
                collageAdapter.notifyDataSetChanged();
                if (!isScrapBook) {
                    updateShapeListForRatio(i5, i3);
                }
                unselectShapes();
                for (i4 = 0; i4 < ((ShapeLayout) this.shapeLayoutList.get(0)).shapeArr.length; i4++) {
                    String str2 = CollageActivity.TAG;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("i ");
                    stringBuilder2.append(i4);
                    stringBuilder2.append("is recylced ");
                    stringBuilder2.append(((ShapeLayout) this.shapeLayoutList.get(0)).shapeArr[i4].getBitmap().isRecycled());
                    Log.e(str2, stringBuilder2.toString());
                }
                invalidate();
                if (bitmapArr.length == 1) {
                    SingleImage();
                }
                if (length == 1) {
                    setPathPadding(0, 0.0f);
                    if (this.sizeScale == 1.0f && !isScrapBook) {
                        setCollageSize(this.sizeMatrix, getResources().getInteger(R.integer.default_ssize_value));
                    }
                }
            }
        }

        private void CurrentShape(final float n, final float n2, final boolean b) {
            if (CollageActivity.this.isScrapBook) {
                this.selectCurrentShapeScrapBook(n, n2, b);
                return;
            }
            this.selectCurrentShapeCollage(n, n2, b);
        }

        private void selectCurrentShapeCollage(final float n, final float n2, final boolean b) {
            final int shapeIndex = this.shapeIndex;
            for (int i = 0; i < this.shapeLayoutList.get(this.currentCollageIndex).shapeArr.length; ++i) {
                if (this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[i].region.contains((int) n, (int) n2)) {
                    this.shapeIndex = i;
                }
            }
            if (CollageActivity.this.selectImageForAdj) {
                this.openFilterFragment();
            } else if (CollageActivity.this.swapMode) {
                if (shapeIndex != this.shapeIndex && shapeIndex > -1 && this.shapeIndex > -1) {
                    this.swapBitmaps(this.shapeIndex, shapeIndex);
                    CollageActivity.this.swapMode = false;
                }
            } else if (this.previousIndex == this.shapeIndex && b) {
                this.unselectShapes();
            } else if (this.shapeLayoutList.get(0).shapeArr.length > 0) {
                CollageActivity.this.contextFooter.setVisibility(View.VISIBLE);
                CollageActivity.this.SelectedTab(5);
                stickercontain.invalidate();
            }
            if (this.shapeIndex >= 0) {
                this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].bitmapMatrixgGetValues(this.matrixValues);
                this.mScaleFactor = this.matrixValues[0];
            }
            this.postInvalidate();
        }

        private void selectCurrentShapeScrapBook(final float n, final float n2, final boolean b) {
            final int length = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr.length;
            int i;
            for (int n3 = i = length - 1; i >= 0; --i) {
                if (this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[i].isScrapBookSelected(n, n2)) {
                    this.shapeIndex = i;
                    final boolean b2 = true;
                    if (this.previousIndex == this.shapeIndex && b) {
                        this.unselectShapes();
                    } else if (!b2) {
                        this.unselectShapes();
                    } else if (CollageActivity.this.selectImageForAdj) {
                        this.openFilterFragment();
                    } else if (this.shapeIndex >= 0 && this.shapeIndex < length) {
                        final Shape shape = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex];
                        final Bitmap bitmap = CollageActivity.this.bitmapList[this.shapeIndex];
                        final Parameter parameter = CollageActivity.this.parameterList[this.shapeIndex];
                        for (int j = 0; j < length; ++j) {
                            if (j >= this.shapeIndex) {
                                if (j < n3) {
                                    final Shape[] shapeArr = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr;
                                    final Shape[] shapeArr2 = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr;
                                    final int n4 = j + 1;
                                    shapeArr[j] = shapeArr2[n4];
                                    CollageActivity.this.bitmapList[j] = CollageActivity.this.bitmapList[n4];
                                    CollageActivity.this.parameterList[j] = CollageActivity.this.parameterList[n4];
                                } else {
                                    this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[j] = shape;
                                    CollageActivity.this.bitmapList[j] = bitmap;
                                    CollageActivity.this.parameterList[j] = parameter;
                                }
                            }
                        }
                        if (this.previousIndex == this.shapeIndex) {
                            this.previousIndex = n3;
                        } else if (this.previousIndex > this.shapeIndex) {
                            --this.previousIndex;
                        }
                        this.shapeIndex = n3;
                        if (this.shapeLayoutList.get(0).shapeArr.length > 0) {
                            CollageActivity.this.contextFooter.setVisibility(View.VISIBLE);
                            CollageActivity.this.SelectedTab(5);
                        }
                    }
                    if (this.shapeIndex >= 0) {
                        this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].bitmapMatrixgGetValues(this.matrixValues);
                        this.mScaleFactor = this.matrixValues[0];
                    }
                    this.postInvalidate();
                    CollageActivity.this.stickercontain.invalidate();
                    return;
                }
            }
            final boolean b2 = false;
        }

        private void setCollageSize(final Matrix matrix, final int n) {
            matrix.reset();
            matrix.postScale(this.sizeScale = this.calculateSize(n), this.sizeScale, (this.offsetX + this.offsetX + CollageActivity.this.width * this.xscale) / 2.0f, (this.offsetY + this.offsetY + CollageActivity.this.width * this.yscale) / 2.0f);
            this.invalidate();
        }

        private void setCornerRadius(final float cornerRadius) {
            this.cornerRadius = cornerRadius;
            final CornerPathEffect radius = new CornerPathEffect(cornerRadius);
            for (int i = 0; i < this.shapeLayoutList.get(this.currentCollageIndex).shapeArr.length; ++i) {
                this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[i].setRadius(radius);
            }
            this.postInvalidate();
        }

        private void setPathPadding(final int n, final float paddingDistance) {
            this.paddingDistance = paddingDistance;
            for (int i = 0; i < this.shapeLayoutList.get(n).shapeArr.length; ++i) {
                this.shapeLayoutList.get(n).shapeArr[i].scalePath(this.smallestDistanceList.get(n) / 250.0f * paddingDistance, this.screenWidth, this.screenWidth);
                if (!CollageActivity.this.isScrapBook) {
                    this.shapeLayoutList.get(n).shapeArr[i].checkScaleBounds();
                    this.shapeLayoutList.get(n).shapeArr[i].checkBoundries();
                }
            }
            this.postInvalidate();
        }

        private int setShapeScaleMatrix(int setScaleMatrix) {
            if (this.shapeIndex < 0) {
                return -1;
            }
            setScaleMatrix = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].setScaleMatrix(setScaleMatrix);
            this.invalidate();
            return setScaleMatrix;
        }

        private void swapBitmaps(final int n, final int n2) {
            final Bitmap bitmap = this.shapeLayoutList.get(0).shapeArr[n].getBitmap();
            final Bitmap bitmap2 = this.shapeLayoutList.get(0).shapeArr[n2].getBitmap();
            for (int i = 0; i < this.shapeLayoutList.size(); ++i) {
                this.shapeLayoutList.get(i).shapeArr[n].setBitmap(bitmap2, false);
                this.shapeLayoutList.get(i).shapeArr[n2].setBitmap(bitmap, false);
            }
            final Bitmap bitmap3 = CollageActivity.this.bitmapList[n];
            CollageActivity.this.bitmapList[n] = CollageActivity.this.bitmapList[n2];
            CollageActivity.this.bitmapList[n2] = bitmap3;
            final Parameter parameter = CollageActivity.this.parameterList[n];
            CollageActivity.this.parameterList[n] = CollageActivity.this.parameterList[n2];
            CollageActivity.this.parameterList[n2] = parameter;
            final float floatValue = this.smallestDistanceList.get(n);
            this.smallestDistanceList.set(n, this.smallestDistanceList.get(n2));
            this.smallestDistanceList.set(n2, floatValue);
            CollageActivity.this.selectSwapTextView.setVisibility(View.INVISIBLE);
            this.unselectShapes();
        }

        private void updateShapeListForFilterBitmap(final Bitmap bitmap) {
            if (this.shapeIndex >= 0) {
                for (int i = 0; i < this.shapeLayoutList.size(); ++i) {
                    this.shapeLayoutList.get(i).shapeArr[this.shapeIndex].setBitmap(bitmap, true);
                }
            }
        }

        private void updateShapeListForRatio(int i, int j) {
            final int length = this.shapeLayoutList.get(0).shapeArr.length;
            final PointF ratio = this.getRatio();
            this.calculateOffset();
            final float x = ratio.x;
            final float n = i;
            final Collage createCollage = Collage.CreateCollage(length, (int) (x * n), (int) (ratio.y * n), CollageActivity.this.isScrapBook);
            this.smallestDistanceList.clear();
            for (i = 0; i < this.shapeLayoutList.size(); ++i) {
                if (length == 1) {
                    this.shapeLayoutList.get(i).shapeArr[0].changeRatio((PointF[]) ((CollageLayout) createCollage.collageLayoutList.get(i)).shapeList.get(0), null, this.offsetX, this.offsetY, CollageActivity.this.isScrapBook, 0, (int) (ratio.x * n), (int) (ratio.y * n));
                } else {
                    for (j = 0; j < length; ++j) {
                        this.shapeLayoutList.get(i).shapeArr[j].changeRatio((PointF[]) ((CollageLayout) createCollage.collageLayoutList.get(i)).shapeList.get(j), null, this.offsetX, this.offsetY, CollageActivity.this.isScrapBook, j, (int) (ratio.x * n), (int) (ratio.y * n));
                    }
                }
                this.smallestDistanceList.add(this.smallestDistance(this.shapeLayoutList.get(i).shapeArr));
                this.setPathPadding(i, this.paddingDistance);
                if (!CollageActivity.this.isScrapBook) {
                    for (j = 0; j < this.shapeLayoutList.get(i).shapeArr.length; ++j) {
                        this.shapeLayoutList.get(i).shapeArr[j].setScaleMatrix(1);
                    }
                }
            }
            this.setCornerRadius(this.cornerRadius);
            if (this.blurBitmap != null) {
                this.setBlurRect2(this.blurBitmap.getWidth(), this.blurBitmap.getHeight());
            }
            this.postInvalidate();
        }

        int animSize(int n) {
            if (n >= this.animHalfTime) {
                n = this.animationLimit - n;
            }
            return this.animSizeSeekbarProgress + Math.round(n * 2);
        }

        float calculateSize(final float n) {
            return 1.0f - n / 200.0f;
        }

        int getMaskIndex(final int n) {
            for (int i = 0; i < this.maskResIdList.length; ++i) {
                if (n == this.maskResIdList[i]) {
                    return i;
                }
            }
            return -1;
        }

        float getMatrixRotation(final Matrix matrix) {
            matrix.getValues(this.values);
            return Math.round(Math.atan2(this.values[1], this.values[0]) * 57.29577951308232);
        }

        PointF getRatio() {
            this.yscale = 1.0f;
            this.xscale = 1.0f;
            this.yscale = CollageActivity.this.mulY / CollageActivity.this.mulX;
            if (!CollageActivity.this.isScrapBook && this.yscale > 1.25f) {
                this.xscale = 1.25f / this.yscale;
                this.yscale = 1.25f;
            }
            return new PointF(this.xscale, this.yscale);
        }

        Bitmap loadMaskBitmap2(final int n) {
            return this.convertToAlphaMask(BitmapFactory.decodeResource(this.getResources(), n));
        }

        @SuppressLint("WrongConstant")
        public void onDraw(final Canvas canvas) {
            final int width = this.getWidth();
            final int height = this.getHeight();
            canvas.save();
            final RectF drawingAreaRect = this.drawingAreaRect;
            final float n = this.offsetX;
            final float n2 = this.offsetY;
            final float n3 = this.offsetX;
            final float n4 = width;
            drawingAreaRect.set(n, n2, n3 + this.xscale * n4, this.offsetY + this.yscale * n4);
            canvas.drawPaint(this.paintGray);
            if (this.backgroundMode == 0) {
                canvas.drawRect(this.drawingAreaRect, this.patternPaint);
            }
            if (this.blurBitmap != null && !this.blurBitmap.isRecycled() && this.backgroundMode == 1) {
                this.blurRectDst.set(this.drawingAreaRect);
                canvas.drawBitmap(this.blurBitmap, this.blurRectSrc, this.blurRectDst, this.paint);
            }
            if (!CollageActivity.this.isScrapBook) {
                canvas.setMatrix(this.sizeMatrix);
            }
            final boolean isScrapBook = CollageActivity.this.isScrapBook;
            final int n5 = 0;
            int saveLayer;
            if (isScrapBook && !CollageActivity.this.showText) {
                saveLayer = 0;
            } else {
                saveLayer = canvas.saveLayer(0.0f, 0.0f, n4 / this.sizeScale, height / this.sizeScale, (Paint) null, 31);
            }
            for (int i = 0; i < this.shapeLayoutList.get(this.currentCollageIndex).shapeArr.length; ++i) {
                final boolean b = i == this.shapeLayoutList.get(this.currentCollageIndex).getClearIndex();
                if (CollageActivity.this.isScrapBook) {
                    this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[i].drawShapeForScrapBook(canvas, width, height, i == this.shapeIndex, this.orthogonal);
                } else {
                    this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[i].drawShape(canvas, width, height, saveLayer, b);
                }
            }
            if (!CollageActivity.this.isScrapBook && this.shapeIndex >= 0 && this.shapeLayoutList.get(0).shapeArr.length > 1) {
                canvas.drawRect(this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].bounds, this.borderPaint);
            }
            if (CollageActivity.this.showText) {
                canvas.restoreToCount(saveLayer);
                for (int j = n5; j < CollageActivity.this.textDataList.size(); ++j) {
                    this.textMatrix.set((Matrix) CollageActivity.this.textDataList.get(j).imageSaveMatrix);
                    canvas.setMatrix(this.textMatrix);
                    canvas.drawText(CollageActivity.this.textDataList.get(j).message, CollageActivity.this.textDataList.get(j).xPos, CollageActivity.this.textDataList.get(j).yPos, (Paint) CollageActivity.this.textDataList.get(j).textPaint);
                    canvas.setMatrix(this.identityMatrix);
                }
            }
            if (this.frameBitmap != null && !this.frameBitmap.isRecycled()) {
                canvas.drawBitmap(this.frameBitmap, (Rect) null, this.frameRect, this.paint);
            }
            if (CollageActivity.this.isScrapBook) {
                canvas.restore();
                this.above.set(0.0f, 0.0f, (float) canvas.getWidth(), this.drawingAreaRect.top);
                this.left.set(0.0f, this.drawingAreaRect.top, this.drawingAreaRect.left, this.drawingAreaRect.bottom);
                this.right.set(this.drawingAreaRect.right, this.drawingAreaRect.top, (float) canvas.getWidth(), this.drawingAreaRect.bottom);
                this.bottom.set(0.0f, this.drawingAreaRect.bottom, (float) canvas.getWidth(), (float) canvas.getHeight());
                canvas.drawRect(this.above, this.paintGray);
                canvas.drawRect(this.left, this.paintGray);
                canvas.drawRect(this.right, this.paintGray);
                canvas.drawRect(this.bottom, this.paintGray);
            }
        }

        public boolean onTouchEvent(final MotionEvent motionEvent) {
            this.mScaleDetector.onTouchEvent(motionEvent);
            this.mTouchDetector.onTouchEvent(motionEvent);
            if (CollageActivity.this.isScrapBook) {
                CollageActivity.this.mRotationDetector.onTouchEvent(motionEvent);
            }
            final int action = motionEvent.getAction();
            final int n = action & 0xFF;
            int n2 = 0;
            if (n != 6) {
                switch (n) {
                    default: {
                        return true;
                    }
                    case 3: {
                        this.mActivePointerId = 1;
                        this.isInCircle = false;
                        this.isOnCross = false;
                        return true;
                    }
                    case 2: {
                        if (this.isOnCross) {
                            break;
                        }
                        final int pointerIndex = motionEvent.findPointerIndex(this.mActivePointerId);
                        final float x = motionEvent.getX(pointerIndex);
                        final float y = motionEvent.getY(pointerIndex);
                        if (this.shapeIndex < 0) {
                            this.CurrentShape(x, y, false);
                        }
                        if (this.shapeIndex < 0) {
                            break;
                        }
                        if (CollageActivity.this.isScrapBook && this.isInCircle) {
                            this.pts = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].getMappedCenter();
                            float startAngle = -Utils.pointToAngle(x, y, this.pts[0], this.pts[1]);
                            final StringBuilder sb = new StringBuilder();
                            sb.append("currentAngle ");
                            sb.append(Float.toString(startAngle));
                            final float matrixRotation = this.getMatrixRotation(this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].bitmapMatrix);
                            if ((matrixRotation == 0.0f || matrixRotation == 90.0f || matrixRotation == 180.0f || matrixRotation == -180.0f || matrixRotation == -90.0f) && Math.abs(this.startAngle - startAngle) < 4.0f) {
                                this.orthogonal = true;
                            } else {
                                if (Math.abs(matrixRotation - this.startAngle + startAngle) < 4.0f) {
                                    startAngle = this.startAngle - matrixRotation;
                                    this.orthogonal = true;
                                    final StringBuilder sb2 = new StringBuilder();
                                    sb2.append("aaaaa ");
                                    sb2.append(Float.toString(matrixRotation));
                                } else if (Math.abs(90.0f - (matrixRotation - this.startAngle + startAngle)) < 4.0f) {
                                    startAngle = 90.0f + this.startAngle - matrixRotation;
                                    this.orthogonal = true;
                                    final StringBuilder sb3 = new StringBuilder();
                                    sb3.append("bbbbb ");
                                    sb3.append(Float.toString(matrixRotation));
                                } else if (Math.abs(180.0f - (matrixRotation - this.startAngle + startAngle)) < 4.0f) {
                                    startAngle = 180.0f + this.startAngle - matrixRotation;
                                    this.orthogonal = true;
                                    final StringBuilder sb4 = new StringBuilder();
                                    sb4.append("cccc ");
                                    sb4.append(Float.toString(matrixRotation));
                                } else if (Math.abs(-180.0f - (matrixRotation - this.startAngle + startAngle)) < 4.0f) {
                                    startAngle = -180.0f + this.startAngle - matrixRotation;
                                    this.orthogonal = true;
                                } else if (Math.abs(-90.0f - (matrixRotation - this.startAngle + startAngle)) < 4.0f) {
                                    startAngle = -90.0f + this.startAngle - matrixRotation;
                                    this.orthogonal = true;
                                    final StringBuilder sb5 = new StringBuilder();
                                    sb5.append("dddd ");
                                    sb5.append(Float.toString(matrixRotation));
                                    Log.d("CollageActivity", sb5.toString());
                                } else {
                                    this.orthogonal = false;
                                }
                                this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].bitmapMatrixRotate(this.startAngle - startAngle);
                                this.startAngle = startAngle;
                            }
                            final float n3 = (float) Math.sqrt((x - this.pts[0]) * (x - this.pts[0]) + (y - this.pts[1]) * (y - this.pts[1])) / (float) Math.sqrt((this.zoomStart.x - this.pts[0]) * (this.zoomStart.x - this.pts[0]) + (this.zoomStart.y - this.pts[1]) * (this.zoomStart.y - this.pts[1]));
                            final float scale = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].getScale();
                            if (scale >= this.MIN_ZOOM || (scale < this.MIN_ZOOM && n3 > 1.0f)) {
                                this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].bitmapMatrixScaleScrapBook(n3, n3);
                                this.zoomStart.set(x, y);
                            }
                            this.invalidate();
                            return true;
                        }
                        this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].bitmapMatrixTranslate(x - this.mLastTouchX, y - this.mLastTouchY);
                        this.mLastTouchX = x;
                        this.mLastTouchY = y;
                        this.invalidate();
                        return true;
                    }
                    case 1: {
                        this.orthogonal = false;
                        this.mActivePointerId = 1;
                        if (this.isOnCross) {
                            CollageActivity.this.DeleteDialog();
                        }
                        this.isInCircle = false;
                        this.isOnCross = false;
                        this.invalidate();
                        return true;
                    }
                    case 0: {
                        this.previousIndex = this.shapeIndex;
                        final float x2 = motionEvent.getX();
                        final float y2 = motionEvent.getY();
                        this.mLastTouchX = x2;
                        this.mLastTouchY = y2;
                        this.orthogonal = false;
                        this.mActivePointerId = motionEvent.getPointerId(0);
                        if (CollageActivity.this.isScrapBook && this.shapeIndex >= 0) {
                            this.zoomStart.set(x2, y2);
                            this.pts = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].getMappedCenter();
                            if (this.pts != null) {
                                this.startAngle = -Utils.pointToAngle(x2, y2, this.pts[0], this.pts[1]);
                            }
                            this.isInCircle = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].isInCircle(x2, y2);
                            this.isOnCross = this.shapeLayoutList.get(this.currentCollageIndex).shapeArr[this.shapeIndex].isOnCross(x2, y2);
                            return true;
                        }
                        this.CurrentShape(x2, y2, false);
                        return true;
                    }
                }
            } else {
                this.finalAngle = 0.0f;
                final int n4 = (action & 0xFF00) >> 8;
                if (motionEvent.getPointerId(n4) == this.mActivePointerId) {
                    if (n4 == 0) {
                        n2 = 1;
                    }
                    this.mLastTouchX = motionEvent.getX(n2);
                    this.mLastTouchY = motionEvent.getY(n2);
                    this.mActivePointerId = motionEvent.getPointerId(n2);
                }
            }
            return true;
        }

        public void openFilterFragment() {
            CollageActivity.this.selectFilterTextView.setVisibility(View.INVISIBLE);
            CollageActivity.this.selectImageForAdj = false;
            if (this.shapeIndex >= 0) {
                CollageActivity.this.fragmentFullEffect.BitmapParameter(CollageActivity.this.bitmapList[this.shapeIndex], CollageActivity.this.parameterList[this.shapeIndex]);
                CollageActivity.this.setVisibilityOfFilterHorizontalListview(true);
            }
        }

        public String saveBitmap(int i, int n) {
            final float n2 = i;
            int n3 = (int) (CollageActivity.this.collageView.xscale * n2);
            int n4 = (int) (CollageActivity.this.collageView.yscale * n2);
            final float n5 = Utils.maxSizeForSave((Context) CollageActivity.this, 2048.0f) / Math.max(n3, n4);
            final float n6 = n3;
            final int n7 = (int) (n6 * n5);
            final float n8 = n4;
            final int n9 = (int) (n8 * n5);
            if (n7 <= 0) {
            } else {
                n3 = n7;
            }
            if (n9 <= 0) {
            } else {
                n4 = n9;
            }
            final Bitmap bitmap = Bitmap.createBitmap(n3, n4, Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap);
            final ShapeLayout shapeLayout = this.shapeLayoutList.get(this.currentCollageIndex);
            final Matrix matrix = new Matrix();
            matrix.reset();
            matrix.preScale(n5, n5);
            canvas.setMatrix(matrix);
            if (this.backgroundMode == 0) {
                canvas.drawRect(0.0f, 0.0f, n6, n8, this.patternPaint);
            }
            if (this.blurBitmap != null && !this.blurBitmap.isRecycled() && this.backgroundMode == 1) {
                canvas.drawBitmap(this.blurBitmap, this.blurRectSrc, new RectF(0.0f, 0.0f, n6, n8), this.paint);
            }
            matrix.postScale(this.sizeScale, this.sizeScale, n3 / 2.0f, n4 / 2.0f);
            matrix.preTranslate((float) (-this.offsetX), (float) (-this.offsetY));
            canvas.setMatrix(matrix);
            @SuppressLint("WrongConstant") final int saveLayer = canvas.saveLayer(-i / this.sizeScale, -n / this.sizeScale, this.offsetX + n2 / this.sizeScale, this.offsetY + n / this.sizeScale, (Paint) null, 31);
            n = 0;
            boolean b;
            StringBuilder sb;
            for (i = 0; i < shapeLayout.shapeArr.length; ++i) {
                b = (i == shapeLayout.getClearIndex());
                sb = new StringBuilder();
                sb.append("drawPorterClear ");
                sb.append(b);
                if (CollageActivity.this.isScrapBook) {
                    shapeLayout.shapeArr[i].drawShapeForScrapBook(canvas, n3, n4, false, false);
                } else {
                    shapeLayout.shapeArr[i].drawShapeForSave(canvas, n3, n4, saveLayer, b);
                }
            }
            if (CollageActivity.this.textDataList != null) {
                Matrix matrix2;
                for (i = n; i < CollageActivity.this.textDataList.size(); ++i) {
                    matrix2 = new Matrix();
                    matrix2.set((Matrix) CollageActivity.this.textDataList.get(i).imageSaveMatrix);
                    matrix2.postTranslate((float) (-this.offsetX), (float) (-this.offsetY));
                    matrix2.postScale(n5, n5);
                    canvas.setMatrix(matrix2);
                    canvas.drawText(CollageActivity.this.textDataList.get(i).message, CollageActivity.this.textDataList.get(i).xPos, CollageActivity.this.textDataList.get(i).yPos, (Paint) CollageActivity.this.textDataList.get(i).textPaint);
                }
            }
            if (CollageActivity.this.stickerlist != null) {
                CollageActivity.this.stickercontain.setDrawingCacheEnabled(true);
                CollageActivity.this.stickercontain.buildDrawingCache(true);
                canvas.drawBitmap(CollageActivity.this.stickercontain.getDrawingCache(), CollageActivity.this.stickercontain.getX(), CollageActivity.this.stickercontain.getY(), this.paint);
            }
            canvas.restoreToCount(saveLayer);
            Object o = new StringBuilder();
            ((StringBuilder) o).append(String.valueOf(Environment.getExternalStorageDirectory().toString()));
            ((StringBuilder) o).append(CollageActivity.this.getString(R.string.directory));
            ((StringBuilder) o).append(String.valueOf(System.currentTimeMillis()));
            ((StringBuilder) o).append(".jpg");
            final String string = ((StringBuilder) o).toString();
            new File(string).getParentFile().mkdirs();
            try {
                o = new FileOutputStream(string);
                final Bitmap.CompressFormat jpeg = Bitmap.CompressFormat.JPEG;
                try {
                    bitmap.compress(jpeg, 90, (OutputStream) o);
                    ((OutputStream) o).flush();
                    ((OutputStream) o).close();
                } catch (IOException ee) {
                }
            } catch (IOException ex) {
            }
            bitmap.recycle();
            return string;
        }

        public void setBlurBitmap(final int n, final boolean b) {
            if (this.blurBuilderNormal == null) {
                this.blurBuilderNormal = new ImageBlurNormal();
            }
            if (b) {
                this.backgroundMode = 2;
                if (!CollageActivity.this.isScrapBook) {
                    CollageActivity.this.seekbarSize.setProgress(CollageActivity.this.seekbarSize.getMax());
                }
            } else {
                this.backgroundMode = 1;
            }
            this.blurBitmap = NativeStackBlur.process(CollageActivity.this.bitmapList[0].copy(CollageActivity.this.bitmapList[0].getConfig(), true), n);
            if (this.blurBitmap != null) {
                this.setBlurRect2(this.blurBitmap.getWidth(), this.blurBitmap.getHeight());
            }
            this.postInvalidate();
        }

        void setBlurRect2(final float n, final float n2) {
            float n3;
            float n4;
            if (CollageActivity.this.mulY * n / CollageActivity.this.mulX < n2) {
                n3 = (int) n;
                n4 = CollageActivity.this.mulY * n / CollageActivity.this.mulX;
            } else {
                n3 = (int) CollageActivity.this.mulX * n2 / CollageActivity.this.mulY;
                n4 = (int) n2;
            }
            final int n5 = (int) ((n - n3) / 2.0f);
            final int n6 = (int) ((n2 - n4) / 2.0f);
            this.blurRectSrc.set(n5, n6, (int) (n5 + n3), (int) (n6 + n4));
        }

        void setCurrentCollageIndex(final int currentCollageIndex) {
            this.currentCollageIndex = currentCollageIndex;
            if (this.currentCollageIndex >= this.shapeLayoutList.size()) {
                this.currentCollageIndex = 0;
            }
            if (this.currentCollageIndex < 0) {
                this.currentCollageIndex = this.shapeLayoutList.size() - 1;
            }
            this.setCornerRadius(this.cornerRadius);
            this.setPathPadding(this.currentCollageIndex, this.paddingDistance);
        }

        void setPatternPaint(final int n) {
            if (this.patternPaint == null) {
                (this.patternPaint = new Paint(1)).setColor(-1);
            }
            if (n == -1) {
                this.patternPaint.setShader((Shader) null);
                this.patternPaint.setColor(-1);
                this.postInvalidate();
                return;
            }
            this.patternBitmap = BitmapFactory.decodeResource(this.getResources(), n);
            this.patternPaint.setShader((Shader) new BitmapShader(this.patternBitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
            this.postInvalidate();
        }

        void setPatternPaintColor(final int color) {
            if (this.patternPaint == null) {
                this.patternPaint = new Paint(1);
            }
            this.patternPaint.setShader((Shader) null);
            this.patternPaint.setColor(color);
            this.postInvalidate();
        }

        public float smallestDistance(final Shape[] array) {
            int i = 0;
            float smallestDistance = array[0].smallestDistance();
            while (i < array.length) {
                final float smallestDistance2 = array[i].smallestDistance();
                float n = smallestDistance;
                if (smallestDistance2 < smallestDistance) {
                    n = smallestDistance2;
                }
                ++i;
                smallestDistance = n;
            }
            return smallestDistance;
        }

        public void startAnimator() {
            if (CollageActivity.this.seekbarSize != null) {
                this.animSizeSeekbarProgress = CollageActivity.this.seekbarSize.getProgress();
            } else {
                this.animSizeSeekbarProgress = 0;
            }
            this.sizeMatrixSaved = new Matrix(this.sizeMatrix);
            this.animationCount = 0;
            this.animate = true;
            this.removeCallbacks(this.animator);
            this.postDelayed(this.animator, 150L);
        }

        void unselectShapes() {
            CollageActivity.this.contextFooter.setVisibility(View.INVISIBLE);
            this.shapeIndex = -1;
            CollageActivity.this.stickercontain.invalidate();
            this.postInvalidate();
        }

        void updateParamList(final Parameter parameter) {
            if (this.shapeIndex >= 0) {
                CollageActivity.this.parameterList[this.shapeIndex] = new Parameter(parameter);
            }
        }

        class MyGestureListener extends GestureDetector.SimpleOnGestureListener {
            private static final String DEBUG_TAG = "Gestures";

            public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
                return true;
            }

            public boolean onSingleTapUp(final MotionEvent motionEvent) {
                if (!CollageView.this.isOnCross) {
                    CollageActivity.this.collageView.CurrentShape(motionEvent.getX(), motionEvent.getY(), true);
                }
                return true;
            }
        }

        private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
            public boolean onScale(final ScaleGestureDetector scaleGestureDetector) {
                if (CollageView.this.shapeIndex >= 0) {
                    CollageView.this.mScaleFactor = scaleGestureDetector.getScaleFactor();
                    scaleGestureDetector.isInProgress();
                    CollageView.this.mScaleFactor = Math.max(0.1f, Math.min(CollageView.this.mScaleFactor, 5.0f));
                    CollageView.this.scaleShape = CollageView.this.shapeLayoutList.get(CollageView.this.currentCollageIndex).shapeArr[CollageView.this.shapeIndex];
                    if (CollageActivity.this.isScrapBook) {
                        CollageView.this.scaleShape.bitmapMatrixScaleScrapBook(CollageView.this.mScaleFactor, CollageView.this.mScaleFactor);
                    } else {
                        CollageView.this.scaleShape.bitmapMatrixScale(CollageView.this.mScaleFactor, CollageView.this.mScaleFactor, CollageView.this.scaleShape.bounds.centerX(), CollageView.this.scaleShape.bounds.centerY());
                    }
                    CollageView.this.invalidate();
                    CollageView.this.requestLayout();
                }
                return true;
            }
        }
    }

    private final class MyMediaScannerConnectionClient implements MediaScannerConnection.MediaScannerConnectionClient {
        private MediaScannerConnection mConn;
        private String mFilename;
        private String mMimetype;

        MyMediaScannerConnectionClient(final Context context, final File file, final String s) {
            this.mFilename = file.getAbsolutePath();
            (this.mConn = new MediaScannerConnection(context, (MediaScannerConnection.MediaScannerConnectionClient) this)).connect();
        }

        public void onMediaScannerConnected() {
            this.mConn.scanFile(this.mFilename, this.mMimetype);
        }

        public void onScanCompleted(final String s, final Uri uri) {
            this.mConn.disconnect();
        }
    }

    private class SaveImageTask extends AsyncTask<Object, Object, Object> {
        ProgressDialog progressDialog;
        String resultPath;

        private SaveImageTask() {
            this.resultPath = null;
        }

        protected Object doInBackground(final Object... array) {
            this.resultPath = CollageActivity.this.collageView.saveBitmap(CollageActivity.this.width, CollageActivity.this.height);
            return null;
        }

        protected void onPostExecute(final Object o) {
            super.onPostExecute(o);
            if (this.progressDialog != null && this.progressDialog.isShowing()) {
                this.progressDialog.cancel();
            }
            if (this.resultPath != null) {
                CollageActivity.this.stickercontain.setLocked(false);
                resultPathCopy = this.resultPath;
                final Intent intent = new Intent((Context) CollageActivity.this, (Class) ShareActivity.class);
                intent.putExtra("imagePath", this.resultPath);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                CollageActivity.this.startActivity(intent);
            }
            new MyMediaScannerConnectionClient(CollageActivity.this.getApplicationContext(), new File(this.resultPath), null);
        }

        protected void onPreExecute() {
            stickercontain.setLocked(true);
            (this.progressDialog = new ProgressDialog((Context) CollageActivity.this)).setMessage((CharSequence) "Saving image...");
            this.progressDialog.show();
        }
    }
}
