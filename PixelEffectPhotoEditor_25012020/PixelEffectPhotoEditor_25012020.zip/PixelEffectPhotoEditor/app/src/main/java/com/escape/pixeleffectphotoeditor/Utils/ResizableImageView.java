package com.escape.pixeleffectphotoeditor.Utils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;

public class ResizableImageView extends ImageView {
	public ResizableImageView(final Context context) {
		super(context);
	}

	public ResizableImageView(final Context context, final AttributeSet set) {
		super(context, set);
	}

	protected void onMeasure(int size, int n) {
		final Drawable drawable = this.getDrawable();
		if (drawable != null) {
			size = MeasureSpec.getSize(size);
			n = (int) Math.ceil(size * drawable.getIntrinsicHeight()
					/ drawable.getIntrinsicWidth());
			this.setMeasuredDimension(size, size);
			return;
		}
		super.onMeasure(size, size);
	}
}
