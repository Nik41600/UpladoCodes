package com.escape.pixeleffectphotoeditor.Touch;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class SquareImageView extends ImageView {
	public SquareImageView(final Context context) {
		super(context);
	}

	public SquareImageView(final Context context, final AttributeSet set) {
		super(context, set);
	}

	public SquareImageView(final Context context, final AttributeSet set,
                           final int n) {
		super(context, set, n);
	}

	protected void onMeasure(int measuredWidth, final int n) {
		super.onMeasure(measuredWidth, n);
		measuredWidth = this.getMeasuredWidth();
		this.setMeasuredDimension(measuredWidth, measuredWidth);
	}

	public void setWidthHeight(final int n) {
		this.setMeasuredDimension(n, n);
	}
}
