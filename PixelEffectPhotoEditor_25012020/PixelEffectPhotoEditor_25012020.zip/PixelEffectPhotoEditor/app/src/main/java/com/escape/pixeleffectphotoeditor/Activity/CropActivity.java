package com.escape.pixeleffectphotoeditor.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.escape.pixeleffectphotoeditor.Fragment.ActivityFragment;
import com.escape.pixeleffectphotoeditor.R;
import com.escape.pixeleffectphotoeditor.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.IOException;

public class CropActivity extends AppCompatActivity {
    private Bitmap bitmap;
    private CropImageView cropImageView;
    public static Bitmap bitmapCropped;
    ImageView ivSave;
    private KProgressHUD hud;
    private InterstitialAd interstitialAd;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_crop);

        try {
            this.bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),
                    ActivityFragment.imageUri);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.cropImageView = (CropImageView) findViewById(R.id.cropImageView);
        this.cropImageView.setImageUriAsync(ActivityFragment.imageUri);
        this.cropImageView.setCropShape(CropImageView.CropShape.RECTANGLE);
        this.ivSave = (ImageView) findViewById(R.id.ivSave);
        this.ivSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivSave;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    CropActivity.bitmapCropped = CropActivity.this.cropImageView
                            .getCroppedImage();
                    startActivity(new Intent(CropActivity.this,
                            ActivityEditingImage.class));
                    finish();
                }
            }
        });

        ImageView ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBack;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                }else {
                    startActivity(new Intent(CropActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));

                }
            }
        });

        loadAd();
    }

    private int id;

    private void loadAd() {

        //Banner Ad
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        this.interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.ivSave:
                        CropActivity.bitmapCropped = CropActivity.this.cropImageView
                                .getCroppedImage();
                        startActivity(new Intent(CropActivity.this,
                                ActivityEditingImage.class));
                        finish();
                        break;

                    case R.id.ivBack:
                        startActivity(new Intent(CropActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        break;

                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(CropActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    protected void onResume() {
        super.onResume();
    }
}
