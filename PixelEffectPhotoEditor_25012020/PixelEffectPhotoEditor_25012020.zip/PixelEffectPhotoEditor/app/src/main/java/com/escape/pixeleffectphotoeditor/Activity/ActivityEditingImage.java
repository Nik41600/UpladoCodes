package com.escape.pixeleffectphotoeditor.Activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.escape.pixeleffectphotoeditor.Adapter.FontStyleAdapter;
import com.escape.pixeleffectphotoeditor.Adapter.FrameAdapter;
import com.escape.pixeleffectphotoeditor.Adapter.StickerAdapter;
import com.escape.pixeleffectphotoeditor.R;
import com.escape.pixeleffectphotoeditor.Stickers.StickerView;
import com.escape.pixeleffectphotoeditor.Touch.SquareImageView;
import com.escape.pixeleffectphotoeditor.Utils.Effects;
import com.escape.pixeleffectphotoeditor.Utils.HorizontalListView;
import com.escape.pixeleffectphotoeditor.Utils.Utils;
import com.escape.pixeleffectphotoeditor.kprogresshud.KProgressHUD;
import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ActivityEditingImage extends AppCompatActivity implements View.OnClickListener {
    private ImageView ivEffect1;
    private ImageView ivEffect10;
    private ImageView ivEffect11;
    private ImageView ivEffect12;
    private ImageView ivEffect13;
    private ImageView ivEffect14;
    private ImageView ivEffect15;
    private ImageView ivEffect16;
    private ImageView ivEffect17;
    private ImageView ivEffect18;
    private ImageView ivEffect19;
    private ImageView ivEffect2;
    private ImageView ivEffect20;
    private ImageView ivEffect21;
    private ImageView ivEffect22;
    private ImageView ivEffect3;
    private ImageView ivEffect4;
    private EditText edittext;
    private ImageView iv_threeD;
    private ImageView iv_effects;
    private ImageView iv_color;
    private ImageView iv_text;
    private ImageView iv_sticker;
    private LinearLayout llDetail;
    private LinearLayout llEffectList;
    private StickerView stickerView;
    private LinearLayout llColorlist;
    private LinearLayout llFontlist;
    GridView gridColorlist;
    GridView gridFontlist;
    private static final int REQUEST_CODE_GALLERY = 1;
    private static Bitmap bitmap;
    private static Canvas canvas;
    public static Bitmap finalImage;
    public static String ShareImageURI;
    private ImageView ivFrame;
    private SquareImageView squareImageView;
    private ImageView ivBack;
    final Context context = this;
    private static int columnWidth = 80;
    private int mPickedColor = -1;
    ImageView ivColor;
    ImageView ivDone;
    ImageView ivFontstyle;
    private ImageView ivGravity;
    ImageView ivkeyboard;
    private int width = 0;
    private ProgressDialog progressDialog;
    int flag = 0;
    private ImageView ivEffect5;
    private ImageView ivEffect6;
    private ImageView ivEffect7;
    private ImageView ivEffect8;
    private ImageView ivEffect9;
    private ImageView ivEffectOriginal;
    private FrameLayout framely_Sticker;
    String[] fonts = new String[]{"font1.ttf", "font2.ttf", "font3.ttf",
            "font4.TTF", "font5.ttf", "font6.TTF", "font7.ttf", "font8.ttf",
            "font9.ttf", "font10.TTF", "font11.ttf", "font12.ttf",
            "font14.TTF", "font16.TTF", "font17.ttf", "font18.ttf",
            "font19.ttf", "font20.ttf", "font21.ttf"};
    private BaseAdapter frameAdapter;
    private ArrayList<Integer> frmList;
    FrameLayout frameLayout;
    private HorizontalListView horizontalListView;
    private int initColor;
    private boolean isLight = false;
    Dialog dialog;
    private ArrayList<View> viewArrayList;
    private ImageView orgImage;
    private ImageView ivSave;
    private StickerAdapter stickerAdapter;
    private int stickerId;
    private ArrayList<Integer> stickerlist;
    Typeface typeface;
    InputMethodManager methodManager;
    private KProgressHUD hud;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.initColor = getResources().getColor(R.color.white);
        setContentView(R.layout.activity_editing_image);
        loadAd();
        this.viewArrayList = new ArrayList();
        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        this.ivBack.setOnClickListener(this);
        this.ivSave = (ImageView) findViewById(R.id.ivSave);
        this.ivSave.setOnClickListener(this);
        this.llDetail = (LinearLayout) findViewById(R.id.ll_horizontal);
        this.llDetail.setVisibility(View.GONE);
        this.llEffectList = (LinearLayout) findViewById(R.id.ll_effect_list);
        this.llEffectList.setVisibility(View.GONE);
        this.iv_effects = (ImageView) findViewById(R.id.iv_effects);
        this.iv_effects.setOnClickListener(this);
        this.iv_text = (ImageView) findViewById(R.id.iv_text);
        this.iv_text.setOnClickListener(this);
        this.iv_color = (ImageView) findViewById(R.id.iv_color);
        this.iv_color.setOnClickListener(this);
        this.iv_threeD = (ImageView) findViewById(R.id.iv_threeD);
        this.iv_threeD.setOnClickListener(this);
        this.frameLayout = (FrameLayout) findViewById(R.id.MainFrame);
        this.iv_sticker = (ImageView) findViewById(R.id.iv_sticker);
        this.iv_sticker.setOnClickListener(this);
        this.horizontalListView = (HorizontalListView) findViewById(R.id.hlFrame);
        this.orgImage = (ImageView) findViewById(R.id.orange_Img);
        this.orgImage.setImageBitmap(CropActivity.bitmapCropped);
        this.framely_Sticker = (FrameLayout) findViewById(R.id.frameStickersLayout);
        this.ivFrame = (ImageView) findViewById(R.id.ivFrame);
        this.squareImageView = (SquareImageView) findViewById(R.id.squareImageView);
        this.squareImageView.setWidthHeight(this.orgImage.getMeasuredWidth());
        this.ivFrame.setImageBitmap(CropActivity.bitmapCropped);
        this.horizontalListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                flag = 1;
                if (ActivityEditingImage.this.isLight) {
                    ActivityEditingImage.this.squareImageView.setImageResource(((Integer) ActivityEditingImage.this.frmList
                            .get(position)).intValue());
                    return;
                }
                ActivityEditingImage.this.ivFrame.setImageResource(((Integer) ActivityEditingImage.this.frmList
                        .get(position)).intValue());
                ActivityEditingImage.this.ivFrame.setColorFilter(ContextCompat
                        .getColor(ActivityEditingImage.this.context, R.color.white));
            }
        });
        ArrayList3DFrm();
        this.frameAdapter = new FrameAdapter(this, this.frmList);
        this.horizontalListView.setAdapter(this.frameAdapter);
        this.ivEffectOriginal = (ImageView) findViewById(R.id.ef_original);
        this.ivEffectOriginal.setOnClickListener(this);
        this.ivEffect1 = (ImageView) findViewById(R.id.effect1);
        this.ivEffect1.setOnClickListener(this);
        this.ivEffect2 = (ImageView) findViewById(R.id.effect2);
        this.ivEffect2.setOnClickListener(this);
        this.ivEffect3 = (ImageView) findViewById(R.id.effect3);
        this.ivEffect3.setOnClickListener(this);
        this.ivEffect4 = (ImageView) findViewById(R.id.effect4);
        this.ivEffect4.setOnClickListener(this);
        this.ivEffect5 = (ImageView) findViewById(R.id.effect5);
        this.ivEffect5.setOnClickListener(this);
        this.ivEffect6 = (ImageView) findViewById(R.id.effect6);
        this.ivEffect6.setOnClickListener(this);
        this.ivEffect7 = (ImageView) findViewById(R.id.effect7);
        this.ivEffect7.setOnClickListener(this);
        this.ivEffect8 = (ImageView) findViewById(R.id.effect8);
        this.ivEffect8.setOnClickListener(this);
        this.ivEffect9 = (ImageView) findViewById(R.id.effect9);
        this.ivEffect9.setOnClickListener(this);
        this.ivEffect10 = (ImageView) findViewById(R.id.effect10);
        this.ivEffect10.setOnClickListener(this);
        this.ivEffect11 = (ImageView) findViewById(R.id.effect11);
        this.ivEffect11.setOnClickListener(this);
        this.ivEffect12 = (ImageView) findViewById(R.id.effect12);
        this.ivEffect12.setOnClickListener(this);
        this.ivEffect13 = (ImageView) findViewById(R.id.effect13);
        this.ivEffect13.setOnClickListener(this);
        this.ivEffect14 = (ImageView) findViewById(R.id.effect14);
        this.ivEffect14.setOnClickListener(this);
        this.ivEffect15 = (ImageView) findViewById(R.id.effect15);
        this.ivEffect15.setOnClickListener(this);
        this.ivEffect16 = (ImageView) findViewById(R.id.effect16);
        this.ivEffect16.setOnClickListener(this);
        this.ivEffect17 = (ImageView) findViewById(R.id.effect17);
        this.ivEffect17.setOnClickListener(this);
        this.ivEffect18 = (ImageView) findViewById(R.id.effect18);
        this.ivEffect18.setOnClickListener(this);
        this.ivEffect19 = (ImageView) findViewById(R.id.effect19);
        this.ivEffect19.setOnClickListener(this);
        this.ivEffect20 = (ImageView) findViewById(R.id.effect20);
        this.ivEffect20.setOnClickListener(this);
        this.ivEffect21 = (ImageView) findViewById(R.id.effect21);
        this.ivEffect21.setOnClickListener(this);
        this.ivEffect22 = (ImageView) findViewById(R.id.effect22);
        this.ivEffect22.setOnClickListener(this);
        Effects.applyEffectNone(this.ivEffectOriginal);
        Effects.applyEffect1(this.ivEffect1);
        Effects.applyEffect2(this.ivEffect2);
        Effects.applyEffect3(this.ivEffect3);
        Effects.applyEffect4(this.ivEffect4);
        Effects.applyEffect5(this.ivEffect5);
        Effects.applyEffect6(this.ivEffect6);
        Effects.applyEffect7(this.ivEffect7);
        Effects.applyEffect8(this.ivEffect8);
        Effects.applyEffect9(this.ivEffect9);
        Effects.applyEffect10(this.ivEffect10);
        Effects.applyEffect11(this.ivEffect11);
        Effects.applyEffect12(this.ivEffect12);
        Effects.applyEffect13(this.ivEffect13);
        Effects.applyEffect14(this.ivEffect14);
        Effects.applyEffect15(this.ivEffect15);
        Effects.applyEffect16(this.ivEffect16);
        Effects.applyEffect17(this.ivEffect17);
        Effects.applyEffect18(this.ivEffect18);
        Effects.applyEffect19(this.ivEffect19);
        Effects.applyEffect20(this.ivEffect20);
        Effects.applyEffect21(this.ivEffect21);
        Effects.applyEffect22(this.ivEffect22);
    }

    void openDetail() {
        this.llDetail.setVisibility(View.VISIBLE);
        TranslateAnimation anim = new TranslateAnimation(0.0f, 0.0f,
                this.iv_effects.getY() + 70.0f, this.iv_effects.getY());
        anim.setDuration(300);
        anim.setFillAfter(true);
        this.llDetail.startAnimation(anim);
    }

    private void ArrayList3DFrm() {
        this.frmList = new ArrayList();
        this.frmList.add(Integer.valueOf(R.drawable.frm_3d_1));
        this.frmList.add(Integer.valueOf(R.drawable.frm_3d_2_));
        this.frmList.add(Integer.valueOf(R.drawable.frm_3d_3));
        this.frmList.add(Integer.valueOf(R.drawable.frm_3d_4_));
        this.frmList.add(Integer.valueOf(R.drawable.frm_3d_5));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_34));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_35));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_42));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_36));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_37));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_38));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_39));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_40));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_14));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_24));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_1));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_2));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_3));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_29));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_30));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_31));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_32));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_4));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_5));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_6));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_33));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_7));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_8));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_9));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_10));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_11));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_12));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_13));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_15));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_16));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_17));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_18));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_19));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_20));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_21));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_22));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_23));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_25));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_26));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_27));
        this.frmList.add(Integer.valueOf(R.drawable.frm_2d_28));
    }

    public void onClick(View v) {
        this.isLight = false;
        switch (v.getId()) {
            case R.id.ivBack:
                id = R.id.ivBack;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    finish();
                }
                return;
            case R.id.ivSave:
                if (this.stickerView != null) {
                    this.stickerView.setInEdit(false);
                }
                id = R.id.ivSave;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    progressDialog = ProgressDialog.show(ActivityEditingImage.this, "", "Loading...");
                    new Thread() {
                        public void run() {
                            try {
                                saveImage(getMainFrameBitmap());
                                startActivity(new Intent(ActivityEditingImage.this, ActivityShare.class));
                                finish();
                            } catch (Exception e) {
                            }
                            progressDialog.dismiss();
                        }
                    }.start();
                }
                return;
            case R.id.MainFrame:
                if (this.stickerView != null) {
                    this.stickerView.setInEdit(false);
                    return;
                }
                return;
            case R.id.ef_original:
                Effects.applyEffectNone(this.orgImage);
                return;
            case R.id.effect1:
                Effects.applyEffect1(this.orgImage);
                return;
            case R.id.effect2:
                Effects.applyEffect2(this.orgImage);
                return;
            case R.id.effect3:
                Effects.applyEffect3(this.orgImage);
                return;
            case R.id.effect4:
                Effects.applyEffect4(this.orgImage);
                return;
            case R.id.effect5:
                Effects.applyEffect5(this.orgImage);
                return;
            case R.id.effect6:
                Effects.applyEffect6(this.orgImage);
                return;
            case R.id.effect7:
                Effects.applyEffect7(this.orgImage);
                return;
            case R.id.effect8:
                Effects.applyEffect8(this.orgImage);
                return;
            case R.id.effect9:
                Effects.applyEffect9(this.orgImage);
                return;
            case R.id.effect10:
                Effects.applyEffect10(this.orgImage);
                return;
            case R.id.effect11:
                Effects.applyEffect11(this.orgImage);
                return;
            case R.id.effect12:
                Effects.applyEffect12(this.orgImage);
                return;
            case R.id.effect13:
                Effects.applyEffect13(this.orgImage);
                return;
            case R.id.effect14:
                Effects.applyEffect14(this.orgImage);
                return;
            case R.id.effect15:
                Effects.applyEffect15(this.orgImage);
                return;
            case R.id.effect16:
                Effects.applyEffect16(this.orgImage);
                return;
            case R.id.effect17:
                Effects.applyEffect17(this.orgImage);
                return;
            case R.id.effect18:
                Effects.applyEffect18(this.orgImage);
                return;
            case R.id.effect19:
                Effects.applyEffect19(this.orgImage);
                return;
            case R.id.effect20:
                Effects.applyEffect20(this.orgImage);
                return;
            case R.id.effect21:
                Effects.applyEffect21(this.orgImage);
                return;
            case R.id.effect22:
                Effects.applyEffect22(this.orgImage);
                return;
            case R.id.iv_threeD:
                if (this.horizontalListView.getVisibility() == View.VISIBLE) {
                    horizontalListView.setVisibility(View.GONE);
                } else {
                    ArrayList3DFrm();
                    this.frameAdapter = new FrameAdapter(this, this.frmList);
                    this.horizontalListView.setAdapter(this.frameAdapter);
                    this.horizontalListView.setVisibility(View.VISIBLE);
                    this.llEffectList.setVisibility(View.GONE);
                    openDetail();
                }
                return;
            case R.id.iv_effects:
                if (flag == 1) {
                    if (llEffectList.getVisibility() == View.VISIBLE) {
                        llEffectList.setVisibility(View.GONE);
                    } else {
                        this.horizontalListView.setVisibility(View.GONE);
                        this.llEffectList.setVisibility(View.VISIBLE);
                        openDetail();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select 3D Frame", Toast.LENGTH_SHORT).show();
                }
                return;
            case R.id.iv_color:
                ColorPickerDialogBuilder
                        .with(this)
                        .setTitle("Choose Background color")
                        .initialColor(this.initColor)
                        .wheelType(ColorPickerView.WHEEL_TYPE.CIRCLE)
                        .density(12)
                        .setOnColorSelectedListener(new OnColorSelectedListener() {
                            @Override
                            public void onColorSelected(int i) {
                            }
                        })
                        .setPositiveButton((CharSequence) "ok",
                                new ColorPickerClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int selectedColor,
                                                        Integer[] allColors) {
                                        initColor = selectedColor;
                                        if (flag == 1) {
                                            ivFrame.setColorFilter(initColor);
                                        } else {
                                            Toast.makeText(getApplicationContext(), "Please Select 3D Frame", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                })
                        .setNegativeButton((CharSequence) "cancel",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                }).build()
                        .show();
                return;
            case R.id.iv_text:
                AddText();
                return;
            case R.id.iv_sticker:
                final Dialog dial = new Dialog((Context) this, R.style.AppTheme1);
                dial.requestWindowFeature(this.REQUEST_CODE_GALLERY);
                dial.setContentView(R.layout.sticker_dialog);
                dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dial.setCanceledOnTouchOutside(true);
                ((ImageView) dial.findViewById(R.id.ivBack))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                dial.dismiss();
                            }
                        });
                this.stickerlist = new ArrayList();
                final GridView grid_sticker = (GridView) dial
                        .findViewById(R.id.gridStickerList);
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker1));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker2));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker3));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker4));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker5));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker6));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker7));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker8));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker9));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker10));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker11));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker12));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker13));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker14));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker15));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker16));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker17));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker18));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker19));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker20));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker21));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker22));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker23));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker24));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker25));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker26));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker27));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker28));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker29));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker30));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker31));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker32));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker33));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker34));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker35));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker36));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker37));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker38));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker39));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker40));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker41));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker42));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker43));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker44));
                this.stickerlist.add(Integer.valueOf(R.drawable.sticker45));
                this.stickerAdapter = new StickerAdapter(getApplicationContext(),
                        this.stickerlist);
                grid_sticker.setAdapter(this.stickerAdapter);
                grid_sticker.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> adapterView, View view,
                                            int i, long l) {
                        ActivityEditingImage.this.stickerId = ((Integer) ActivityEditingImage.this.stickerlist
                                .get(i)).intValue();
                        ActivityEditingImage.this.StickerView(ActivityEditingImage.this.stickerId);
                        dial.dismiss();
                    }
                });
                dial.show();
                return;
            default:
                return;
        }
    }

    private InterstitialAd interstitial;
    private int id;

    private void loadAd() {
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ivSave:
                        if (stickerView != null) {
                            stickerView.setInEdit(false);
                        }
                        progressDialog = ProgressDialog.show(ActivityEditingImage.this, "",
                                "Loading...");
                        new Thread() {
                            public void run() {
                                try {
                                    saveImage(getMainFrameBitmap());
                                    startActivity(new Intent(ActivityEditingImage.this, ActivityShare.class));
                                    finish();
                                } catch (Exception e) {
                                }
                                progressDialog.dismiss();
                            }
                        }.start();
                        break;
                    case R.id.ivBack:
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityEditingImage.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    private Bitmap getMainFrameBitmap() {
        this.frameLayout.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(this.frameLayout.getDrawingCache());
        if (Build.VERSION.SDK_INT >= 19) {
            bitmap.setConfig(Bitmap.Config.ARGB_8888);
        }
        this.frameLayout.setDrawingCacheEnabled(false);
        finalImage = bitmap;
        Bitmap bmp = bitmap;
        int imgHeight = bmp.getHeight();
        int imgWidth = bmp.getWidth();
        int largeX = imgWidth;
        int largeY = imgHeight;
        int left = imgWidth;
        int right = imgWidth;
        int top = imgHeight;
        int bottom = imgHeight;
        for (int i = 0; i < imgWidth; i++) {
            for (int j = 0; j < imgHeight; j++) {
                if (bmp.getPixel(i, j) != 0) {
                    if (i - 0 < left) {
                        left = i - 0;
                    }
                    if (largeX - i < right) {
                        right = largeX - i;
                    }
                    if (j - 0 < top) {
                        top = j - 0;
                    }
                    if (largeY - j < bottom) {
                        bottom = largeY - j;
                    }
                }
            }
        }
        return Bitmap.createBitmap(bmp, left, top, (imgWidth - left) - right,
                (imgHeight - top) - bottom);
    }

    private void saveImage(Bitmap bitmap2) {
        Bitmap bitmap = bitmap2;
        File filepath = Environment.getExternalStorageDirectory();
        File dir = new File(filepath.getAbsolutePath() + "/"
                + getString(R.string.app_name));
        dir.mkdirs();
        String FileName = new SimpleDateFormat("yyyyMMdd_HHmmss")
                .format(new Date()) + ".jpeg";
        File file = new File(dir, FileName);
        file.renameTo(file);
        String _uri = "file://" + filepath.getAbsolutePath() + "/"
                + getString(R.string.app_name) + "/" + FileName;
        ShareImageURI = filepath.getAbsolutePath() + "/"
                + getString(R.string.app_name) + "/" + FileName;
        Log.d("cache uri=", _uri);
        try {
            OutputStream output = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output);
            output.flush();
            output.close();
            sendBroadcast(new Intent(
                    "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                    Uri.fromFile(new File(_uri))));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Bitmap loadBitmapFromView(View v) {
        if (v.getMeasuredHeight() <= 0) {
            v.measure(-2, -2);
            bitmap = Bitmap.createBitmap(v.getMeasuredWidth(),
                    v.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
            v.layout(0, 0, v.getMeasuredWidth(), v.getMeasuredHeight());
            v.draw(canvas);
            return bitmap;
        }
        bitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(),
                Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
        v.draw(canvas);
        return bitmap;
    }

    Bitmap CropBitmapTransparency(Bitmap sourceBitmap) {
        int minX = sourceBitmap.getWidth();
        int minY = sourceBitmap.getHeight();
        int maxX = -1;
        int maxY = -1;
        for (int y = 0; y < sourceBitmap.getHeight(); y++) {
            for (int x = 0; x < sourceBitmap.getWidth(); x++) {
                if (((sourceBitmap.getPixel(x, y) >> 24) & 255) > 0) {
                    if (x < minX) {
                        minX = x;
                    }
                    if (x > maxX) {
                        maxX = x;
                    }
                    if (y < minY) {
                        minY = y;
                    }
                    if (y > maxY) {
                        maxY = y;
                    }
                }
            }
        }
        if (maxX < minX || maxY < minY) {
            return null;
        }
        return Bitmap.createBitmap(sourceBitmap, minX, minY, (maxX - minX) + 1,
                (maxY - minY) + 1);
    }

    public static ArrayList HSVColors() {
        int h;
        ArrayList<Integer> colors = new ArrayList();
        for (h = 0; h <= 360; h += 20) {
            colors.add(Integer.valueOf(HSVColor((float) h, 1.0f, 1.0f)));
        }
        for (h = 0; h <= 360; h += 20) {
            colors.add(Integer.valueOf(HSVColor((float) h, 0.25f, 1.0f)));
            colors.add(Integer.valueOf(HSVColor((float) h, 0.5f, 1.0f)));
            colors.add(Integer.valueOf(HSVColor((float) h, 0.75f, 1.0f)));
        }
        for (h = 0; h <= 360; h += 20) {
            colors.add(Integer.valueOf(HSVColor((float) h, 1.0f, 0.5f)));
            colors.add(Integer.valueOf(HSVColor((float) h, 1.0f, 0.75f)));
        }
        for (float b = 0.0f; b <= 1.0f; b += 0.1f) {
            colors.add(Integer.valueOf(HSVColor(0.0f, 0.0f, b)));
        }
        return colors;
    }

    public static int HSVColor(float hue, float saturation, float black) {
        return Color.HSVToColor(255, new float[]{hue, saturation, black});
    }

    protected void AddText() {
        this.llEffectList.setVisibility(View.GONE);
        this.horizontalListView.setVisibility(View.GONE);
        this.dialog = new Dialog(this);
        this.dialog.requestWindowFeature(1);
        this.dialog.setContentView(R.layout.activity_text);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        this.methodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        this.methodManager.toggleSoftInput(2, 0);
        final TextView textView = new TextView(this);
        this.edittext = (EditText) this.dialog.findViewById(R.id.edittext);
        this.edittext.requestFocus();
        this.llDetail.setVisibility(View.GONE);
        this.llFontlist = (LinearLayout) this.dialog.findViewById(R.id.lyfontlist);
        this.llFontlist.setVisibility(View.GONE);
        this.gridFontlist = (GridView) this.dialog.findViewById(R.id.gvfontlist);
        this.gridFontlist.setAdapter(new FontStyleAdapter(ActivityEditingImage.this,
                ActivityEditingImage.this.fonts));
        this.gridFontlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                ActivityEditingImage.this.typeface = Typeface.createFromAsset(
                        ActivityEditingImage.this.getAssets(),
                        ActivityEditingImage.this.fonts[i]);
                ActivityEditingImage.this.edittext
                        .setTypeface(ActivityEditingImage.this.typeface);
                textView.setTypeface(ActivityEditingImage.this.typeface);
            }
        });
        this.llColorlist = (LinearLayout) this.dialog.findViewById(R.id.lycolorlist);
        this.llColorlist.setVisibility(View.GONE);
        this.gridColorlist = (GridView) this.dialog.findViewById(R.id.gvcolorlist);
        ArrayList colors = HSVColors();
        final ArrayList arrayList = colors;
        this.gridColorlist.setAdapter(new ArrayAdapter<Integer>(getApplicationContext(), 17367043, colors) {
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setBackgroundColor(((Integer) arrayList.get(position)).intValue());
                view.setText("");
                view.setLayoutParams(new AbsListView.LayoutParams(-1, -1));
                AbsListView.LayoutParams params = (AbsListView.LayoutParams) view.getLayoutParams();
                params.width = ActivityEditingImage.columnWidth;
                params.height = ActivityEditingImage.columnWidth;
                view.setLayoutParams(params);
                view.requestLayout();
                return view;
            }
        });
        this.gridColorlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int i, long l) {
                ActivityEditingImage.this.mPickedColor = ((Integer) adapterView.getItemAtPosition(i)).intValue();
                ActivityEditingImage.this.edittext.setTextColor(ActivityEditingImage.this.mPickedColor);
                textView.setTextColor(ActivityEditingImage.this.mPickedColor);
            }
        });
        this.ivkeyboard = (ImageView) this.dialog.findViewById(R.id.iv_keyboard);
        this.ivkeyboard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) ActivityEditingImage.this.getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(ActivityEditingImage.this.edittext, 2);
                ActivityEditingImage.this.llFontlist.setVisibility(View.GONE);
                ActivityEditingImage.this.llColorlist.setVisibility(View.GONE);
            }
        });
        this.ivFontstyle = (ImageView) this.dialog
                .findViewById(R.id.iv_fontstyle);
        this.ivFontstyle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityEditingImage.this.llFontlist.setVisibility(View.VISIBLE);
                ActivityEditingImage.this.llColorlist.setVisibility(View.GONE);
                ((InputMethodManager) ActivityEditingImage.this.getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(ActivityEditingImage.this.edittext.getWindowToken(), 0);
            }
        });
        this.ivColor = (ImageView) this.dialog.findViewById(R.id.iv_color);
        this.ivColor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) ActivityEditingImage.this.getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(ActivityEditingImage.this.edittext.getWindowToken(), 0);
                ActivityEditingImage.this.llColorlist.setVisibility(View.VISIBLE);
                ActivityEditingImage.this.llFontlist.setVisibility(View.GONE);
            }
        });
        this.ivGravity = (ImageView) this.dialog.findViewById(R.id.iv_gravity);
        this.ivGravity.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (ActivityEditingImage.this.width == 0) {
                    ActivityEditingImage.this.width = 1;
                    ActivityEditingImage.this.ivGravity
                            .setImageDrawable(ActivityEditingImage.this
                                    .getResources().getDrawable(R.drawable.ic_alignright));
                    ActivityEditingImage.this.edittext.setGravity(5);
                    textView.setGravity(5);
                } else{
                    if (ActivityEditingImage.this.width == 1) {
                        ActivityEditingImage.this.ivGravity.setImageDrawable(ActivityEditingImage.this.getResources().getDrawable(R.drawable.alignleft));
                        ActivityEditingImage.this.edittext.setGravity(3);
                        textView.setGravity(3);
                        ActivityEditingImage.this.width = 2;
                        return;
                    }
                    if (ActivityEditingImage.this.width == 2) {
                        ActivityEditingImage.this.width = 0;
                        ActivityEditingImage.this.ivGravity
                                .setImageDrawable(ActivityEditingImage.this
                                        .getResources().getDrawable(
                                                R.drawable.ic_aligncenter));
                        ActivityEditingImage.this.edittext.setGravity(17);
                        textView.setGravity(17);
                    }
                }
            }
        });
        this.ivDone = (ImageView) this.dialog.findViewById(R.id.iv_done);
        final TextView txtEnteredText = (TextView) this.dialog.findViewById(R.id.txtEnteredText);
        txtEnteredText.setDrawingCacheEnabled(true);
        this.ivDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view)
            {
                ActivityEditingImage.this.methodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                if (ActivityEditingImage.this.edittext.getText().toString().equals("")) {
                    Toast.makeText(ActivityEditingImage.this.context,
                            "add text first to continue", Toast.LENGTH_SHORT).show();
                    return;
                }
                txtEnteredText.setText(ActivityEditingImage.this.edittext.getText().toString());
                txtEnteredText.setTypeface(ActivityEditingImage.this.typeface);
                txtEnteredText.setTextColor(ActivityEditingImage.this.mPickedColor);
                txtEnteredText.setGravity(17);
                ImageView img = new ImageView(ActivityEditingImage.this.getApplicationContext());
                txtEnteredText.buildDrawingCache();
                img.setImageBitmap(txtEnteredText.getDrawingCache());
                img.setVisibility(View.GONE);
                Utils.txtBitmap = ActivityEditingImage.loadBitmapFromView(img);
                Utils.txtBitmap = ActivityEditingImage.this.CropBitmapTransparency(Utils.txtBitmap);
                txtEnteredText.setDrawingCacheEnabled(false);
                ((InputMethodManager) ActivityEditingImage.this
                        .getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(
                                ActivityEditingImage.this.edittext.getWindowToken(),
                                0);
                ActivityEditingImage.this.StickerViewText(Utils.txtBitmap);
                ActivityEditingImage.this.dialog.dismiss();

            }
        });
        this.dialog.show();
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        Window window2 = this.dialog.getWindow();
        layoutParams.copyFrom(window2.getAttributes());
        layoutParams.width = -1;
        layoutParams.height = -1;
        window2.setAttributes(layoutParams);
    }

    private void StickerViewText(Bitmap bitmap) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setBitmap(bitmap);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                ActivityEditingImage.this.viewArrayList.remove(stickerView);
                ActivityEditingImage.this.framely_Sticker.removeView(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                ActivityEditingImage.this.stickerView.setInEdit(false);
                ActivityEditingImage.this.stickerView = stickerView;
                ActivityEditingImage.this.stickerView.setInEdit(true);
            }

            public void onTop(StickerView stickerView) {
                int position = ActivityEditingImage.this.viewArrayList.indexOf(stickerView);
                if (position != ActivityEditingImage.this.viewArrayList.size() - 1) {
                    ActivityEditingImage.this.viewArrayList.add(ActivityEditingImage.this.viewArrayList
                            .size(), (StickerView) ActivityEditingImage.this.viewArrayList
                            .remove(position));
                }
            }
        });
        this.framely_Sticker.addView(stickerView, new AbsListView.LayoutParams(-1, -1));
        this.viewArrayList.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void StickerView(int id) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setImageResource(id);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                ActivityEditingImage.this.viewArrayList.remove(stickerView);
                ActivityEditingImage.this.framely_Sticker.removeView(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                ActivityEditingImage.this.stickerView.setInEdit(false);
                ActivityEditingImage.this.stickerView = stickerView;
                ActivityEditingImage.this.stickerView.setInEdit(true);
            }

            public void onTop(StickerView stickerView) {
                int position = ActivityEditingImage.this.viewArrayList.indexOf(stickerView);
                if (position != ActivityEditingImage.this.viewArrayList.size() - 1) {
                    ActivityEditingImage.this.viewArrayList.add(ActivityEditingImage.this.viewArrayList
                            .size(), (StickerView) ActivityEditingImage.this.viewArrayList
                            .remove(position));
                }
            }
        });
        this.framely_Sticker.addView(stickerView, new AbsListView.LayoutParams(-1, -1));
        this.viewArrayList.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void setCurrentEdit(StickerView stickerView) {
        if (this.stickerView != null) {
            this.stickerView.setInEdit(false);
        }
        this.stickerView = stickerView;
        stickerView.setInEdit(true);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
