package com.imagetovideomoviemaker.photoslideshowwithmusic.util;

public class ProgressModel {
    public float Progress = 0.0f;
    public String Uri;
    public boolean isAvailableOffline = false;
    public boolean isDownloading = false;
}
