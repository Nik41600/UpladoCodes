package com.imagetovideomoviemaker.photoslideshowwithmusic.util;


import com.SlideshowSolutions.photoslideshowwithmusic.R;

import java.util.ArrayList;

public class StickersAndFontsUtils {
    public static String[] fonts = new String[]{"font1.ttf", "font2.ttf", "font3.ttf", "font4.ttf", "font5.ttf", "font6.ttf", "font7.otf", "font8.otf", "font9.otf", "font10.ttf", "font11.TTF", "font12.ttf", "font13.ttf", "font14.ttf"};
    public static ArrayList<Integer> stickerTextlist = new ArrayList();
    public static ArrayList<Integer> stickerlist = new ArrayList();

    public static void loadStickers() {
        stickerlist.clear();

        stickerlist.add(Integer.valueOf(R.drawable.s1));
        stickerlist.add(Integer.valueOf(R.drawable.s2));
        stickerlist.add(Integer.valueOf(R.drawable.s3));
        stickerlist.add(Integer.valueOf(R.drawable.s4));
        stickerlist.add(Integer.valueOf(R.drawable.s5));
        stickerlist.add(Integer.valueOf(R.drawable.s6));
        stickerlist.add(Integer.valueOf(R.drawable.s7));
        stickerlist.add(Integer.valueOf(R.drawable.s8));
        stickerlist.add(Integer.valueOf(R.drawable.s9));
        stickerlist.add(Integer.valueOf(R.drawable.s10));
        stickerlist.add(Integer.valueOf(R.drawable.s11));
        stickerlist.add(Integer.valueOf(R.drawable.s12));
        stickerlist.add(Integer.valueOf(R.drawable.s13));
        stickerlist.add(Integer.valueOf(R.drawable.s14));
        stickerlist.add(Integer.valueOf(R.drawable.s15));
        stickerlist.add(Integer.valueOf(R.drawable.s16));
        stickerlist.add(Integer.valueOf(R.drawable.s17));
        stickerlist.add(Integer.valueOf(R.drawable.s18));
        stickerlist.add(Integer.valueOf(R.drawable.s19));
        stickerlist.add(Integer.valueOf(R.drawable.s20));
        stickerlist.add(Integer.valueOf(R.drawable.s21));
        stickerlist.add(Integer.valueOf(R.drawable.s22));
        stickerlist.add(Integer.valueOf(R.drawable.s23));
        stickerlist.add(Integer.valueOf(R.drawable.s24));
        stickerlist.add(Integer.valueOf(R.drawable.s25));
        stickerlist.add(Integer.valueOf(R.drawable.s26));
        stickerlist.add(Integer.valueOf(R.drawable.s27));
        stickerlist.add(Integer.valueOf(R.drawable.s28));
        stickerlist.add(Integer.valueOf(R.drawable.s29));
        stickerlist.add(Integer.valueOf(R.drawable.s30));
        stickerlist.add(Integer.valueOf(R.drawable.s31));
        stickerlist.add(Integer.valueOf(R.drawable.s33));
        stickerlist.add(Integer.valueOf(R.drawable.s34));
        stickerlist.add(Integer.valueOf(R.drawable.s35));
        stickerlist.add(Integer.valueOf(R.drawable.s36));

        stickerlist.add(Integer.valueOf(R.drawable.b1));
        stickerlist.add(Integer.valueOf(R.drawable.b3));
        stickerlist.add(Integer.valueOf(R.drawable.b4));
        stickerlist.add(Integer.valueOf(R.drawable.b6));
        stickerlist.add(Integer.valueOf(R.drawable.b7));
        stickerlist.add(Integer.valueOf(R.drawable.b8));
        stickerlist.add(Integer.valueOf(R.drawable.b9));
        stickerlist.add(Integer.valueOf(R.drawable.b20));
        stickerlist.add(Integer.valueOf(R.drawable.b21));
        stickerlist.add(Integer.valueOf(R.drawable.b22));
        stickerlist.add(Integer.valueOf(R.drawable.b23));
        stickerlist.add(Integer.valueOf(R.drawable.b24));
        stickerlist.add(Integer.valueOf(R.drawable.s37));
        stickerlist.add(Integer.valueOf(R.drawable.s39));
        stickerlist.add(Integer.valueOf(R.drawable.s45));
        stickerlist.add(Integer.valueOf(R.drawable.s46));
        stickerlist.add(Integer.valueOf(R.drawable.s47));
        stickerlist.add(Integer.valueOf(R.drawable.s48));
        stickerlist.add(Integer.valueOf(R.drawable.s49));
        stickerlist.add(Integer.valueOf(R.drawable.s50));
        stickerlist.add(Integer.valueOf(R.drawable.s51));
        stickerlist.add(Integer.valueOf(R.drawable.s57));
        stickerlist.add(Integer.valueOf(R.drawable.s58));
        stickerlist.add(Integer.valueOf(R.drawable.s59));

        stickerlist.add(Integer.valueOf(R.drawable.s60));
        stickerlist.add(Integer.valueOf(R.drawable.s61));
        stickerlist.add(Integer.valueOf(R.drawable.s62));
        stickerlist.add(Integer.valueOf(R.drawable.s63));
        stickerlist.add(Integer.valueOf(R.drawable.s64));
        stickerlist.add(Integer.valueOf(R.drawable.s65));
        stickerlist.add(Integer.valueOf(R.drawable.s66));
        stickerlist.add(Integer.valueOf(R.drawable.s67));
        stickerlist.add(Integer.valueOf(R.drawable.s68));
        stickerlist.add(Integer.valueOf(R.drawable.s69));
        stickerlist.add(Integer.valueOf(R.drawable.s70));
        stickerlist.add(Integer.valueOf(R.drawable.s71));
        stickerlist.add(Integer.valueOf(R.drawable.s72));
        stickerlist.add(Integer.valueOf(R.drawable.s73));
        stickerlist.add(Integer.valueOf(R.drawable.s74));
        stickerlist.add(Integer.valueOf(R.drawable.s75));
        stickerlist.add(Integer.valueOf(R.drawable.s76));
        stickerlist.add(Integer.valueOf(R.drawable.s77));
        stickerlist.add(Integer.valueOf(R.drawable.s78));
        stickerlist.add(Integer.valueOf(R.drawable.s79));
        stickerlist.add(Integer.valueOf(R.drawable.s80));
        stickerlist.add(Integer.valueOf(R.drawable.s81));
        stickerlist.add(Integer.valueOf(R.drawable.s82));
        stickerlist.add(Integer.valueOf(R.drawable.s83));
        stickerlist.add(Integer.valueOf(R.drawable.s84));
        stickerlist.add(Integer.valueOf(R.drawable.s85));
        stickerlist.add(Integer.valueOf(R.drawable.s86));
        stickerlist.add(Integer.valueOf(R.drawable.s87));
        stickerlist.add(Integer.valueOf(R.drawable.s88));
        stickerlist.add(Integer.valueOf(R.drawable.s89));
        stickerlist.add(Integer.valueOf(R.drawable.s90));
        stickerlist.add(Integer.valueOf(R.drawable.s91));
        stickerlist.add(Integer.valueOf(R.drawable.s92));
        stickerlist.add(Integer.valueOf(R.drawable.s93));
        stickerlist.add(Integer.valueOf(R.drawable.s94));
        stickerlist.add(Integer.valueOf(R.drawable.s95));
        stickerlist.add(Integer.valueOf(R.drawable.s96));
        stickerlist.add(Integer.valueOf(R.drawable.s97));
        stickerlist.add(Integer.valueOf(R.drawable.s98));
    }
}
