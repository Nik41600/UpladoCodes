package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.SlideshowSolutions.photoslideshowwithmusic.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;
import com.squareup.picasso.Picasso;

public class SettingsActivity extends AppCompatActivity  {
    private Toolbar toolbar;
    ImageView ivAppIcon1, ivAppIcon2, ivAppIcon3, ivAppIcon4, main_banner;
    private void addListener() {
        if (Utils.Utility.listName != null && Utils.Utility.listIcon != null && Utils.Utility.isNetworkAvailable(SettingsActivity.this)) {
            if (Utils.Utility.listIcon.size() >= 6 && Utils.Utility.listName.size() >= 6 && Utils.Utility.listUrl.size() >= 6) {
                main_banner.setTag(Utils.Utility.listUrl.get(1));
                ivAppIcon1.setTag(Utils.Utility.listUrl.get(2));
                ivAppIcon2.setTag(Utils.Utility.listUrl.get(3));
                ivAppIcon3.setTag(Utils.Utility.listUrl.get(4));
                ivAppIcon4.setTag(Utils.Utility.listUrl.get(5));
                Picasso.with(SettingsActivity.this).load(Utils.Utility.listIcon.get(1)).into(main_banner);
                Picasso.with(SettingsActivity.this).load(Utils.Utility.listIcon.get(2)).into(ivAppIcon1);
                Picasso.with(SettingsActivity.this).load(Utils.Utility.listIcon.get(3)).into(ivAppIcon2);
                Picasso.with(SettingsActivity.this).load(Utils.Utility.listIcon.get(4)).into(ivAppIcon3);
                Picasso.with(SettingsActivity.this).load(Utils.Utility.listIcon.get(5)).into(ivAppIcon4);

            }
        }
    }

    public void openApp(View v) {
        try {
            startActivity(new Intent(
                    "android.intent.action.VIEW",
                    Uri.parse(v.getTag().toString())));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(SettingsActivity.this, "You don't have Google Play installed",
                    Toast.LENGTH_SHORT).show();
        }
    }
    private void bindView() {
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        main_banner = (ImageView) findViewById(R.id.main_banner);
        ivAppIcon1 = (ImageView) findViewById(R.id.imgApp1);
        ivAppIcon2 = (ImageView) findViewById(R.id.imgApp2);
        ivAppIcon3 = (ImageView) findViewById(R.id.imgApp3);
        ivAppIcon4 = (ImageView) findViewById(R.id.imgApp4);
        Animation animation = AnimationUtils.loadAnimation((Context) this, R.anim.rotate_my);
        ivAppIcon1.startAnimation(animation);
        ivAppIcon2.startAnimation(animation);
        ivAppIcon3.startAnimation(animation);
        ivAppIcon4.startAnimation(animation);
    }

    private void init() {
        this.setSupportActionBar(this.toolbar);
        final TextView textView = (TextView) this.toolbar.findViewById(R.id.toolbar_title);
        this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        textView.setText((CharSequence) this.getString(R.string.settings));
        Utils.setFont(this, textView);
    }

    private void loadPolicy() {
        final Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(""));
        this.startActivity(intent);
    }

    private void loadRate() {
        final Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("market://details?id=" + getPackageName()));
        this.startActivity(intent);
    }

    public void onBackPressed() {
        this.getWindow().clearFlags(128);
        super.onBackPressed();
    }


    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_settings);
        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SettingsActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        this.bindView();
        this.init();
        this.addListener();
    }

    public boolean onOptionsItemSelected(final MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            this.onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
