package com.imagetovideomoviemaker.photoslideshowwithmusic.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.Toolbar.OnMenuItemClickListener;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.SlideshowSolutions.photoslideshowwithmusic.R;
import com.bumptech.glide.Glide;
import com.imagetovideomoviemaker.photoslideshowwithmusic.activity.Activity_VideoPlay;
import com.imagetovideomoviemaker.photoslideshowwithmusic.data.VideoData;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.ActivityAnimUtil;
import com.videolib.libffmpeg.FileUtils;
import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;

public class VideoAlbumAdapter extends Adapter<VideoAlbumAdapter.Holder> {
    public static ArrayList<VideoData> mVideoDatas;
    private Context mContext;
    View view;


    public class Holder extends ViewHolder {
        private View clickable;
        private ImageView ivPreview;
        private Toolbar toolbar;
        private TextView tvDuration;
        private TextView tvFileName;
        private TextView tvVideoDate;

        public Holder(View view) {
            super(view);
            this.clickable = view.findViewById(R.id.list_item_video_clicker);
            this.ivPreview = (ImageView) view.findViewById(R.id.list_item_video_thumb);
            this.tvDuration = (TextView) view.findViewById(R.id.list_item_video_duration);
            this.tvFileName = (TextView) view.findViewById(R.id.list_item_video_title);
            this.tvVideoDate = (TextView) view.findViewById(R.id.list_item_video_date);
            this.toolbar = (Toolbar) view.findViewById(R.id.list_item_video_toolbar);
        }
    }

    private class MenuItemClickListener implements OnMenuItemClickListener {
        VideoData videoData;

        public MenuItemClickListener(VideoData videoData) {
            this.videoData = videoData;
        }


        public boolean onMenuItemClick(final MenuItem menuItem) {
            final int index = VideoAlbumAdapter.mVideoDatas.indexOf(this.videoData);
            final int itemId = menuItem.getItemId();
            if (itemId != R.id.action_delete) {
                if (itemId == R.id.action_share_native) {
                    final File file = new File(VideoAlbumAdapter.mVideoDatas.get(index).videoFullPath);
                    final Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("video/*");
                    intent.putExtra("android.intent.extra.SUBJECT", VideoAlbumAdapter.mVideoDatas.get(index).videoName);
                    intent.putExtra("android.intent.extra.TITLE", VideoAlbumAdapter.mVideoDatas.get(index).videoName);
                    intent.putExtra("android.intent.extra.STREAM", (Parcelable) Uri.fromFile(file));
                    VideoAlbumAdapter.this.mContext.startActivity(Intent.createChooser(intent, (CharSequence) "Share Video"));
                }
            } else {
                final AlertDialog.Builder alertDialog$Builder = new AlertDialog.Builder(VideoAlbumAdapter.this.mContext, R.style.Theme_MovieMaker_AlertDialog);
                alertDialog$Builder.setTitle(R.string.delete_video_);
                final StringBuilder sb = new StringBuilder();
                sb.append(VideoAlbumAdapter.this.mContext.getResources().getString(R.string.are_you_sure_to_delete_));
                sb.append(VideoAlbumAdapter.mVideoDatas.get(index).videoName);
                sb.append(".mp4 ?");
                alertDialog$Builder.setMessage((CharSequence) sb.toString());
                alertDialog$Builder.setPositiveButton((CharSequence) "Delete", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialogInterface, final int n) {
                        FileUtils.deleteFile(new File(VideoAlbumAdapter.mVideoDatas.remove(index).videoFullPath));
                        VideoAlbumAdapter.this.notifyDataSetChanged();
                    }
                });
                alertDialog$Builder.setNegativeButton((CharSequence) "Cancel", (DialogInterface.OnClickListener) null);
                alertDialog$Builder.show();
            }
            return false;
        }
    }

    public VideoAlbumAdapter(Context context, ArrayList<VideoData> arrayList) {
        mVideoDatas = arrayList;
        this.mContext = context;
        //loadAd();
    }

    public int getItemCount() {
        return mVideoDatas.size();
    }

    public void onBindViewHolder(Holder holder, final int i) {
        holder.tvDuration.setText(FileUtils.getDuration(((VideoData) mVideoDatas.get(i)).videoDuration));
        Glide.with(this.mContext).load(((VideoData) mVideoDatas.get(i)).videoFullPath).into(holder.ivPreview);
        TextView access$200 = holder.tvFileName;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(((VideoData) mVideoDatas.get(i)).videoName);
        stringBuilder.append(".mp4");
        access$200.setText(stringBuilder.toString());
        holder.tvVideoDate.setText(DateFormat.getDateInstance().format(Long.valueOf(((VideoData) mVideoDatas.get(i)).dateTaken)));
        holder.tvDuration.setVisibility(View.INVISIBLE);
        holder.tvFileName.setVisibility(View.INVISIBLE);
        holder.tvVideoDate.setVisibility(View.INVISIBLE);
        holder.clickable.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                VideoAlbumAdapter.this.id = i;
                VideoAlbumAdapter.this.view = view;
//                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
//                    interstitialAd.show();
//                } else {
                VideoAlbumAdapter.this.loadVideoPlayer(view);
//                }

            }
        });
        menu(holder.toolbar, R.menu.home_item_exported_video_local_menu, new MenuItemClickListener((VideoData) mVideoDatas.get(i)));
    }


    private int id;
//    private InterstitialAd interstitialAd;

//    private void loadAd() {
//
//        interstitialAd = new InterstitialAd(mContext, mContext.getResources().getString(R.string.FB_inter));
//        interstitialAd.setAdListener(new InterstitialAdListener() {
//            @Override
//            public void onInterstitialDisplayed(Ad ad) {
//            }
//
//            @Override
//            public void onInterstitialDismissed(Ad ad) {
//                VideoAlbumAdapter.this.loadVideoPlayer(view);
//                requestNewInterstitial();
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//            }
//        });
//        interstitialAd.loadAd();
//
//    }

//    private void requestNewInterstitial() {
//        interstitialAd.loadAd();
//    }

    private void loadVideoPlayer(View view) {
        Intent intent = new Intent(this.mContext, Activity_VideoPlay.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("KEY", "FromVideoAlbum");
        intent.putExtra("android.intent.extra.TEXT", ((VideoData) mVideoDatas.get(this.id)).videoFullPath);
        intent.putExtra(this.mContext.getResources().getString(R.string.video_position_key), this.id);
        ActivityAnimUtil.startActivitySafely(view, intent);
    }

    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(this.mContext).inflate(R.layout.list_item_published_video, viewGroup, false));
    }

    public static void menu(Toolbar toolbar, int i, OnMenuItemClickListener onMenuItemClickListener) {
        toolbar.getMenu().clear();
        toolbar.inflateMenu(i);
        toolbar.setOnMenuItemClickListener(onMenuItemClickListener);
    }
}
