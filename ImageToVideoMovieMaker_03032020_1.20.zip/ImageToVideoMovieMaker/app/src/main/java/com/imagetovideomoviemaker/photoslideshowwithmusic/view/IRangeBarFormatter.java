package com.imagetovideomoviemaker.photoslideshowwithmusic.view;

public interface IRangeBarFormatter {
    String format(String str);
}
