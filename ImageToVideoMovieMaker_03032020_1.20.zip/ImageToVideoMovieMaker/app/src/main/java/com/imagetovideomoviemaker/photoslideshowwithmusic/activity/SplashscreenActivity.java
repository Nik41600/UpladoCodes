package com.imagetovideomoviemaker.photoslideshowwithmusic.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.SlideshowSolutions.photoslideshowwithmusic.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.imagetovideomoviemaker.photoslideshowwithmusic.util.Utils;


public class SplashscreenActivity extends Activity {
    TextView imgReady;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen_copy);

        FirebaseAnalytics mFirebaseAnalytics;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "SplashscreenActivity");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        bindView();
        init();
        addListener();
//        loadAd();
    }

    private void bindView() {
        imgReady = (TextView) findViewById(R.id.tvLetsStart);
    }

    private void init() {
        Utils.setFont((Activity) this, (int) R.id.tvCreateAccurateFastVideo);
    }

    private void addListener() {
        this.imgReady.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
//                id = R.id.tvLetsStart;
//                if (interstitialAd != null && interstitialAd.isAdLoaded()) {
//                    interstitialAd.show();
//                } else {
                SplashscreenActivity.this.startActivity(new Intent(SplashscreenActivity.this.getApplicationContext(), LauncherActivity.class));
                SplashscreenActivity.this.finish();
//                }
            }
        });
    }
}