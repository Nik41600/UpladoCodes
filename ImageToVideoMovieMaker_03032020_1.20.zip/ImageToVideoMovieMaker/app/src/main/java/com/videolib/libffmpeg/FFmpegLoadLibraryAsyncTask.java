package com.videolib.libffmpeg;

import android.content.Context;
import android.os.AsyncTask;

import com.videolib.libffmpeg.FFmpegLoadBinaryResponseHandler;

import java.io.File;

class FFmpegLoadLibraryAsyncTask extends AsyncTask<Void, Void, Boolean> {
    private final Context context;
    private final String cpu_nameAssets;
    private final FFmpegLoadBinaryResponseHandler abcLoadBinaryResponse;

    FFmpegLoadLibraryAsyncTask(Context context, String cpuArchNameFromAssets,
                               FFmpegLoadBinaryResponseHandler ffmpegLoadBinaryResponseHandler) {
        this.context = context;
        this.cpu_nameAssets = cpuArchNameFromAssets;
        this.abcLoadBinaryResponse = ffmpegLoadBinaryResponseHandler;
    }

    protected Boolean doInBackground(Void... params) {
        File ffmpegFile = new File(FileUtils.getFFmpeg(this.context));
        if (ffmpegFile.exists() && isDeviceFFmpegVersionOld()
                && !ffmpegFile.delete()) {
            return Boolean.valueOf(false);
        }
        if (!ffmpegFile.exists()
                && FileUtils.copyBinaryFromAssetsToData(this.context,
                this.cpu_nameAssets + File.separator + "ffmpeg",
                "ffmpeg")) {
            if (ffmpegFile.canExecute()) {
                return Boolean.valueOf(true);
            }
            if (ffmpegFile.setExecutable(true)) {
                return Boolean.valueOf(true);
            }
        }
        return (ffmpegFile.exists() && ffmpegFile.canExecute()) ? Boolean
                .valueOf(true) : Boolean.valueOf(false);
    }

    protected void onPostExecute(Boolean isSuccess) {
        super.onPostExecute(isSuccess);
        if (this.abcLoadBinaryResponse != null) {
            if (isSuccess.booleanValue()) {
                this.abcLoadBinaryResponse.onSuccess();
                this.abcLoadBinaryResponse
                        .onSuccess(this.cpu_nameAssets);
            } else {
                this.abcLoadBinaryResponse.onFailure();
                this.abcLoadBinaryResponse
                        .onFailure(this.cpu_nameAssets);
            }
            this.abcLoadBinaryResponse.onFinish();
        }
    }

    private boolean isDeviceFFmpegVersionOld() {
        return CpuAr.fromString(
                FileUtils.SHA1(FileUtils.getFFmpeg(this.context))).equals(
                CpuAr.NONE);
    }
}
