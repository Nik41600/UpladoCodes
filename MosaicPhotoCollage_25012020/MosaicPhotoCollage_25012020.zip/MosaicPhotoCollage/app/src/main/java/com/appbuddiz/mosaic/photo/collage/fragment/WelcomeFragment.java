package com.appbuddiz.mosaic.photo.collage.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.appbuddiz.mosaic.photo.collage.HomeScreen;
import com.appbuddiz.mosaic.photo.collage.MyApplication;
import com.appbuddiz.mosaic.photo.collage.R;
import com.appbuddiz.mosaic.photo.collage.adapter.MoreAppAdapter;
import com.appbuddiz.mosaic.photo.collage.kprogresshud.KProgressHUD;
import com.appbuddiz.mosaic.photo.collage.model.App_data;
import com.appbuddiz.mosaic.photo.collage.picker.ImagePickerMainActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class WelcomeFragment extends Fragment implements View.OnClickListener
{
    private View v;
    private InterstitialAd mInterstitialAd;
    private KProgressHUD hud;
    private UnifiedNativeAd nativeAd;
    private ArrayList<App_data> array_appdata;
    private MoreAppAdapter moreAppAdapter;
    private RecyclerView recyclerView;

    public void onClick(final View paramView) {

        switch (paramView.getId()) {
            default:
                break;
        }
        id = 101;
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            DialogShow();
            AdsDialogShow();
        } else
        {
            if (Build.VERSION.SDK_INT >= 23) {
                if (ContextCompat.checkSelfPermission(getActivity(),
                        "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                            "android.permission.READ_EXTERNAL_STORAGE")) {
                        @SuppressLint("ResourceType") final Dialog dialog = new Dialog(getActivity(),
                                R.layout.custom_alert_dialog);
                        dialog.requestWindowFeature(1);
                        dialog.setContentView(R.layout.custom_alert_dialog);
                        dialog.setCancelable(false);
                        dialog.findViewById(R.id.btn_permission_dialog_setting)
                                .setOnClickListener(new View.OnClickListener() {
                                    public final void onClick(
                                            View paramAnonymousView) {
                                        dialog.cancel();
                                    }
                                });
                        dialog.findViewById(R.id.btn_permission_dialog_cancel)
                                .setOnClickListener(new View.OnClickListener() {
                                    public final void onClick(
                                            View paramAnonymousView) {
                                        dialog.cancel();
                                    }
                                });
                        dialog.show();
                        return;
                    }
                    ActivityCompat
                            .requestPermissions(
                                    getActivity(),
                                    new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                                    112);
                    return;
                }
                startActivity(new Intent(getActivity(), ImagePickerMainActivity.class));
                return;
            }
            startActivity(new Intent(getActivity(), ImagePickerMainActivity.class));
        }
    }

    public WelcomeFragment()
    {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        v = inflater.inflate(R.layout.fragment_welcome, container, false);

        array_appdata = new ArrayList<>();
        makeJsonRequest(getResources().getString(R.string.more_appurl));
        recyclerView = (RecyclerView) v.findViewById(R.id.ad_inter_recycle_view);
        final GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        v.findViewById(R.id.btn_start).setOnClickListener(this);

        loadAds();
        return v;
    }

    private void makeJsonRequest(String url) {
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("application_detail");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                App_data app_data = new Gson().fromJson(jsonArray.get(i).toString(), App_data.class);
                                if (!app_data.getApplication_name().equalsIgnoreCase(getString(R.string.app_name))) {
                                    array_appdata.add(app_data);
                                    moreAppAdapter = new MoreAppAdapter(getActivity(), array_appdata);
                                    recyclerView.setAdapter(moreAppAdapter);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Error", "Error: " + error.getMessage());
            }
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq, "");
    }

    private int id;
    private void loadAds()
    {
        //NativeAdvanceAds
        AdLoader.Builder builder = new AdLoader.Builder(getActivity(), getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = v.findViewById(R.id.fl_adplaceholder);
                v.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Toast.makeText(getActivity(), "Failed to load native ad: "
                        + errorCode, Toast.LENGTH_SHORT).show();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(adRequestfull);
        mInterstitialAd.setAdListener(new AdListener()
        {
            public void onAdLoaded()
            {
                super.onAdLoaded();
            }

            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case 101:
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (ContextCompat.checkSelfPermission(getActivity(),
                                    "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                                if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                                        "android.permission.READ_EXTERNAL_STORAGE")) {
                                    @SuppressLint("ResourceType") final Dialog dialog = new Dialog(getActivity(),
                                            R.layout.custom_alert_dialog);
                                    dialog.requestWindowFeature(1);
                                    dialog.setContentView(R.layout.custom_alert_dialog);
                                    dialog.setCancelable(false);
                                    dialog.findViewById(R.id.btn_permission_dialog_setting)
                                            .setOnClickListener(new View.OnClickListener() {
                                                public final void onClick(
                                                        View paramAnonymousView) {
                                                    dialog.cancel();
                                                }
                                            });
                                    dialog.findViewById(R.id.btn_permission_dialog_cancel)
                                            .setOnClickListener(new View.OnClickListener() {
                                                public final void onClick(
                                                        View paramAnonymousView) {
                                                    dialog.cancel();
                                                }
                                            });
                                    dialog.show();
                                    return;
                                }
                                ActivityCompat
                                        .requestPermissions(
                                                getActivity(),
                                                new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                                                112);
                                return;
                            }
                            startActivity(new Intent(getActivity(), ImagePickerMainActivity.class));
                            return;
                        }
                        startActivity(new Intent(getActivity(), ImagePickerMainActivity.class));
                        break;
                }
                mInterstitialAd.loadAd(adRequestfull);
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        mInterstitialAd.loadAd(adRequestfull);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(getActivity())
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                mInterstitialAd.show();
            }
        }, 2000);
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getVideoController();
        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

    public void onStart() {
        super.onStart();
    }

    public void onStop() {
        super.onStop();
    }
}
