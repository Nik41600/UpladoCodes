package com.appbuddiz.mosaic.photo.collage.picker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.ViewSwitcher;
import com.appbuddiz.mosaic.photo.collage.MainActivity;
import com.appbuddiz.mosaic.photo.collage.R;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

public class ImagePickerMainActivity extends Activity {
	GridView gridview;
	Handler handler;
	b c;
	ViewSwitcher viewswitcher;
	ImageLoader imageloader;
	a f;

	protected void onActivityResult(final int n, final int n2,
			final Intent intent) {
		super.onActivityResult(n, n2, intent);
		if (n == 200 && n2 == -1) {
			final String[] stringArrayExtra = intent
					.getStringArrayExtra("all_path");
			final Intent intent2 = new Intent((Context) this,
					MainActivity.class);
			intent2.putExtra("all_path", stringArrayExtra);
			this.startActivity(intent2);
			this.finish();
		}
	}

	public void onCreate(final Bundle bundle) {
		super.onCreate(bundle);
		this.requestWindowFeature(1);
		this.setContentView(R.layout.image_piker_main);
		(this.imageloader = ImageLoader.getInstance())
				.init(new ImageLoaderConfiguration.Builder((Context) this)
						.defaultDisplayImageOptions(
								new DisplayImageOptions.Builder()
										.cacheOnDisc()
										.imageScaleType(
												ImageScaleType.EXACTLY_STRETCHED)
										.bitmapConfig(Bitmap.Config.RGB_565)
										.build())
						.memoryCache(new WeakMemoryCache()).build());
		this.handler = new Handler();
		(this.gridview = (GridView) this.findViewById(R.id.gridGallery))
				.setFastScrollEnabled(true);
		(this.c = new b(this.getApplicationContext(), this.imageloader))
				.a(false);
		this.gridview.setAdapter((ListAdapter) this.c);
		(this.viewswitcher = (ViewSwitcher) this
				.findViewById(R.id.viewSwitcher)).setDisplayedChild(1);
		this.startActivityForResult(
				new Intent("luminous.ACTION_MULTIPLE_PICK"), 200);
	}
}
