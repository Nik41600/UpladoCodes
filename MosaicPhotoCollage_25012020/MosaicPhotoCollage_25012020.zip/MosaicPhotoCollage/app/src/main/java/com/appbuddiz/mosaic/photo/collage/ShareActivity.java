package com.appbuddiz.mosaic.photo.collage;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;

import com.appbuddiz.mosaic.photo.collage.kprogresshud.KProgressHUD;
import com.appbuddiz.mosaic.photo.collage.picker.ImagePickerMainActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class ShareActivity extends Activity implements View.OnClickListener {
	String imageuri = null;
	private int c;
	private Point point;
	private Display display;
	private AdView adView;
	private KProgressHUD hud;
	private InterstitialAd mInterstitialAd;

	public void onBackPressed() {
		super.onBackPressed();
	}

	@SuppressLint("WrongConstant")
	public void onClick(View paramView)
	{
		id = R.id.ivBack;

		switch (paramView.getId())
		{
		default:
			break;
		case R.id.ivBack:
			if (mInterstitialAd != null && mInterstitialAd.isLoaded()){
				DialogShow();
				AdsDialogShow();
			}else {
				super.onBackPressed();
			}
			break;

		case R.id.btn_facebook:
			try {
				final Intent intent = new Intent("android.intent.action.SEND");
				intent.setType("image/*");
				intent.putExtra("android.intent.extra.STREAM",
						Uri.parse(this.imageuri));
				intent.setPackage("com.facebook.katana");
				startActivity(Intent.createChooser(intent, "..."));

			} catch (Exception ee) {
				Toast.makeText(this,
						"facebook is not installed in your device !", 0).show();
			}
			break;
		case R.id.btn_whatapp:
			try {
				final Intent intent = new Intent("android.intent.action.SEND");
				intent.setType("image/*");
				intent.putExtra("android.intent.extra.STREAM",
						Uri.parse(this.imageuri));
				intent.setPackage("com.whatsapp");
				startActivity(Intent.createChooser(intent,
						"Your Awesome Text and Pic..."));

			} catch (Exception ee) {
				Toast.makeText(this,
						"whatsapp is not installed in your device !", 0).show();
			}
			break;
		case R.id.btn_instagram:
			try {
				final Intent intent = new Intent("android.intent.action.SEND");
				intent.setType("image/*");
				intent.putExtra("android.intent.extra.STREAM",
						Uri.parse(this.imageuri));
				intent.setPackage("com.instagram.android");
				startActivity(Intent.createChooser(intent,
						"Your Awesome Text and Pic..."));

			} catch (Exception ee) {
				Toast.makeText(this,
						"instagram is not installed in your device !", 0)
						.show();
			}
			break;
		case R.id.btn_other:
			final Intent intent = new Intent("android.intent.action.SEND");
			intent.setType("image/*");
			intent.putExtra("android.intent.extra.STREAM",
					Uri.parse(this.imageuri));
			startActivity(Intent.createChooser(intent, "Share image using"));
			break;
		}
	}

	@SuppressLint({"NewApi", "WrongConstant"})
	protected void onCreate(Bundle paramBundle) {
		super.onCreate(paramBundle);
		setContentView(R.layout.activity_share);

		this.display = ((WindowManager) getBaseContext().getSystemService(
				"window")).getDefaultDisplay();
		this.point = new Point();
		loadAds();

		if (Build.VERSION.SDK_INT > 12) {
			this.display.getSize(this.point);
		}
		for (this.c = this.point.x;; this.c = this.display.getWidth()) {
			this.imageuri = getIntent().getExtras().getString("ImageUri");

			findViewById(R.id.image).setBackgroundDrawable(
					new BitmapDrawable(this.imageuri));
			LayoutParams layoutparams = new LayoutParams(this.c
					- this.c / 10, this.c - this.c / 10);
			layoutparams.addRule(13, -1);
			findViewById(R.id.image).setLayoutParams(layoutparams);
			findViewById(R.id.btn_facebook).setOnClickListener(this);
			findViewById(R.id.btn_whatapp).setOnClickListener(this);
			findViewById(R.id.btn_instagram).setOnClickListener(this);
			findViewById(R.id.ivBack).setOnClickListener(this);
			findViewById(R.id.btn_other).setOnClickListener(this);

			return;
		}
	}

	private int id;
	private void loadAds() {
		//Banner Ad
		adView = findViewById(R.id.AdView);
		final AdRequest adRequest = new AdRequest.Builder().build();
		adView.loadAd(adRequest);

		//interstitial FullScreenAd
		final AdRequest adRequestfull = new AdRequest.Builder().build();
		mInterstitialAd = new InterstitialAd(this);
		mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
		mInterstitialAd.loadAd(adRequestfull);
		mInterstitialAd.setAdListener(new AdListener() {
			public void onAdLoaded() {
				super.onAdLoaded();
			}

			public void onAdClosed() {
				hud.dismiss();
				switch (id) {
					case R.id.ivBack:
						ShareActivity.super.onBackPressed();
						break;
				}
				mInterstitialAd.loadAd(adRequestfull);
			}

			public void onAdFailedToLoad(int errorCode) {
				super.onAdFailedToLoad(errorCode);
				Log.i("TAG", "Ad Load failed" + errorCode);
			}
		});
		mInterstitialAd.loadAd(adRequestfull);
	}

	public void DialogShow() {
		try {
			hud = KProgressHUD.create(ShareActivity.this)
					.setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
					.setLabel("Showing Ads")
					.setDetailsLabel("Please Wait...");
			hud.show();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (NullPointerException e2) {
			e2.printStackTrace();
		} catch (Exception e3) {
			e3.printStackTrace();
		}
	}

	public void AdsDialogShow() {
		Handler mHandler = new Handler();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				hud.dismiss();
				mInterstitialAd.show();
			}
		}, 2000);
	}

	protected void onDestroy() {
		super.onDestroy();
	}

	public void onPause() {
		super.onPause();
	}

	protected void onResume() {
		super.onResume();
	}

	protected void onStart() {
		super.onStart();
	}

	protected void onStop() {
		super.onStop();
	}
}
