package com.esc.sketchartphoto.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.esc.sketchartphoto.R;

public class BubbleEffectAdapter extends ArrayAdapter<String> {
    Integer[] int_ids;
    private LayoutInflater layoutInflater;

    private static class Holder {
        public ImageView textView;

        private Holder() {
        }
    }

    public BubbleEffectAdapter(Context context, String[] values) {
        super(context, R.layout.custom_data_view, values);
        this.int_ids = new Integer[]{Integer.valueOf(R.drawable.bg_overlay1), Integer.valueOf(R.drawable.bg_overlay2), Integer.valueOf(R.drawable.bg_overlay3), Integer.valueOf(R.drawable.bg_overlay4), Integer.valueOf(R.drawable.bg_overlay5), Integer.valueOf(R.drawable.bg_overlay6), Integer.valueOf(R.drawable.bg_overlay7), Integer.valueOf(R.drawable.bg_overlay8), Integer.valueOf(R.drawable.bg_overlay9), Integer.valueOf(R.drawable.bg_overlay10), Integer.valueOf(R.drawable.bg_overlay11), Integer.valueOf(R.drawable.bg_overlay12), Integer.valueOf(R.drawable.bg_overlay13), Integer.valueOf(R.drawable.bg_overlay14), Integer.valueOf(R.drawable.bg_overlay15), Integer.valueOf(R.drawable.bg_overlay16), Integer.valueOf(R.drawable.bg_overlay17), Integer.valueOf(R.drawable.bg_overlay18), Integer.valueOf(R.drawable.bg_overlay19), Integer.valueOf(R.drawable.bg_overlay20), Integer.valueOf(R.drawable.bg_overlay21), Integer.valueOf(R.drawable.bg_overlay22), Integer.valueOf(R.drawable.bg_overlay23), Integer.valueOf(R.drawable.bg_overlay24), Integer.valueOf(R.drawable.bg_overlay25), Integer.valueOf(R.drawable.pic1), Integer.valueOf(R.drawable.pic2), Integer.valueOf(R.drawable.pic3), Integer.valueOf(R.drawable.pic4), Integer.valueOf(R.drawable.pic5), Integer.valueOf(R.drawable.pic6), Integer.valueOf(R.drawable.pic7), Integer.valueOf(R.drawable.pic8), Integer.valueOf(R.drawable.pic9), Integer.valueOf(R.drawable.pic10), Integer.valueOf(R.drawable.pic11), Integer.valueOf(R.drawable.pic12), Integer.valueOf(R.drawable.pic13), Integer.valueOf(R.drawable.pic14)};
        this.layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = this.layoutInflater.inflate(R.layout.custom_data_view, parent, false);
            holder = new Holder();
            holder.textView = (ImageView) convertView.findViewById(R.id.textView);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        holder.textView.setBackgroundResource(this.int_ids[position].intValue());
        return convertView;
    }
}
