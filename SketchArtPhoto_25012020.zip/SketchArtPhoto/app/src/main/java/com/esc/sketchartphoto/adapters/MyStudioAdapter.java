package com.esc.sketchartphoto.adapters;

import android.app.Activity;
import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.esc.sketchartphoto.R;

import java.util.ArrayList;

public class MyStudioAdapter extends BaseAdapter {
	private static LayoutInflater inflater;
	private Activity activity;
	ArrayList<String> stringArrayList;
	SparseBooleanArray sparseBooleanArray;
	View view;

	static {
		MyStudioAdapter.inflater = null;
	}

	public MyStudioAdapter(final Activity dactivity,
                           final ArrayList<String> imagegallary) {
		this.stringArrayList = new ArrayList<String>();
		this.activity = dactivity;
		this.stringArrayList = imagegallary;
		MyStudioAdapter.inflater = (LayoutInflater) this.activity
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.sparseBooleanArray = new SparseBooleanArray(
				this.stringArrayList.size());
	}

	public int getCount() {
		return this.stringArrayList.size();
	}

	public Object getItem(final int n) {
		return n;
	}

	public long getItemId(final int n) {
		return n;
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		View row = convertView;
		int width = this.activity.getResources().getDisplayMetrics().widthPixels;
		if (row == null) {
			row = LayoutInflater.from(this.activity).inflate(R.layout.gallary_list, parent, false);
			holder = new ViewHolder();
			holder.frameLayout = (FrameLayout) row.findViewById(R.id.frame);
			holder.ivIcon = (ImageView) row.findViewById(R.id.imgIcon);
			row.setTag(holder);
		} else {
			holder = (ViewHolder) row.getTag();
		}
		Glide.with(this.activity).load((String) this.stringArrayList.get(position)).into(holder.ivIcon);
		System.gc();
		return row;
	}
	static class ViewHolder {
		public FrameLayout frameLayout;
		ImageView ivIcon;
	}
}
