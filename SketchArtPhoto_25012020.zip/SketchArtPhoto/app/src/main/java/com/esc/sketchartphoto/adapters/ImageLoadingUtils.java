package com.esc.sketchartphoto.adapters;

import android.content.Context;
import android.graphics.BitmapFactory.Options;

public class ImageLoadingUtils {
	private Context context;

	public ImageLoadingUtils(Context context) {
		this.context = context;
	}


	public static int calculateInSampleSize(Options options, int reqWidth,
			int reqHeight) {
		int height = options.outHeight;
		int width = options.outWidth;
		int inSampleSize = 1;
		if (height > reqHeight || width > reqWidth) {
			int heightRatio = Math
					.round(((float) height) / ((float) reqHeight));
			int widthRatio = Math.round(((float) width) / ((float) reqWidth));
			if (heightRatio < widthRatio) {
				inSampleSize = heightRatio;
			} else {
				inSampleSize = widthRatio;
			}
		}
		while (((float) (width * height))
				/ ((float) (inSampleSize * inSampleSize)) > ((float) ((reqWidth * reqHeight) * 2))) {
			inSampleSize++;
		}
		return inSampleSize;
	}

}
