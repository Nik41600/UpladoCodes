package com.esc.sketchartphoto.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.esc.sketchartphoto.R;
import com.esc.sketchartphoto.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.IOException;

public class ActivityCropImage extends AppCompatActivity implements View.OnClickListener {
    private Bitmap bitmap;
    private CropImageView cropImageView;
    public static Bitmap bitmapCropped;
    private int angle = 0;
    ImageView ivSave, ivBack;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_crop_);
        try {
            this.bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),
                    HomeScreen.imageUri);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.cropImageView = (CropImageView) findViewById(R.id.cropImageView);
        this.cropImageView.setImageUriAsync(HomeScreen.imageUri);
        this.cropImageView.setCropShape(CropImageView.CropShape.RECTANGLE);

        this.ivSave = (ImageView) findViewById(R.id.img_save);
        this.ivSave.setOnClickListener(this);

        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        this.ivBack.setOnClickListener(this);

        loadAd();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.img_save:
                id = R.id.img_save;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    progressDialog = ProgressDialog.show(ActivityCropImage.this, "",
                            "Image Cropping...");
                    new Thread() {
                        public void run() {
                            try {
                                ActivityCropImage.bitmapCropped = ActivityCropImage.this.cropImageView
                                        .getCroppedImage();
                                ActivityCropImage.this.startActivity(new Intent(ActivityCropImage.this,
                                        ActivityImageEditing.class));
                                finish();
                            } catch (Exception e) {
                            }
                            progressDialog.dismiss();
                        }
                    }.start();
                }
                return;

            case R.id.ivBack:
                id = R.id.ivBack;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(ActivityCropImage.this, HomeScreen.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                }
                return;
        }
    }

    private InterstitialAd interstitial;
    private AdView adView;
    private int id;
    private KProgressHUD hud;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(ActivityCropImage.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.img_save:
                        progressDialog = ProgressDialog.show(ActivityCropImage.this, "",
                                "Image Cropping...");
                        new Thread() {
                            public void run() {
                                try {

                                    ActivityCropImage.bitmapCropped = ActivityCropImage.this.cropImageView
                                            .getCroppedImage();
                                    ActivityCropImage.this.startActivity(new Intent(ActivityCropImage.this,
                                            ActivityImageEditing.class));
                                    finish();
                                } catch (Exception e) {
                                }
                                progressDialog.dismiss();
                            }
                        }.start();
                        break;

                    case R.id.ivBack:
                        startActivity(new Intent(ActivityCropImage.this, HomeScreen.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityCropImage.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    protected void onResume() {
        super.onResume();
    }
}
