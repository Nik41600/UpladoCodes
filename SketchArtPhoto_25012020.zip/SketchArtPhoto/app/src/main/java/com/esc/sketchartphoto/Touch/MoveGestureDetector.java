package com.esc.sketchartphoto.Touch;

import android.content.Context;
import android.graphics.PointF;
import android.view.MotionEvent;

public class MoveGestureDetector extends BaseGestureDetector {
	private static final PointF FOCUS_DELTA_ZERO;
	private PointF mCurrFocusInternal;
	private PointF mFocusDeltaExternal;
	private PointF mFocusExternal;
	private final OnMoveGestureListener mListener;
	private PointF mPrevFocusInternal;

	static {
		FOCUS_DELTA_ZERO = new PointF();
	}

	public MoveGestureDetector(final Context context,
                               final OnMoveGestureListener mListener) {
		super(context);
		this.mFocusExternal = new PointF();
		this.mFocusDeltaExternal = new PointF();
		this.mListener = mListener;
	}

	private PointF determineFocalPoint(final MotionEvent motionEvent) {
		final int pointerCount = motionEvent.getPointerCount();
		float n = 0.0f;
		float n2 = 0.0f;
		for (int i = 0; i < pointerCount; ++i) {
			n += motionEvent.getX(i);
			n2 += motionEvent.getY(i);
		}
		return new PointF(n / pointerCount, n2 / pointerCount);
	}

	public PointF getFocusDelta() {
		return this.mFocusDeltaExternal;
	}

	public float getFocusX() {
		return this.mFocusExternal.x;
	}

	public float getFocusY() {
		return this.mFocusExternal.y;
	}

	@Override
	protected void handleInProgressEvent(final int n,
			final MotionEvent motionEvent) {
		switch (n) {
		case 1:
		case 3: {
			this.mListener.onMoveEnd(this);
			this.resetState();
		}
		case 2: {
			this.updateStateByEvent(motionEvent);
			if (this.mCurrPressure / this.mPrevPressure > 0.67f
					&& this.mListener.onMove(this)) {
				this.mPrevEvent.recycle();
				this.mPrevEvent = MotionEvent.obtain(motionEvent);
				return;
			}
			break;
		}
		}
	}

	@Override
	protected void handleStartProgressEvent(final int n,
			final MotionEvent motionEvent) {
		switch (n) {
		default: {
		}
		case 0: {
			this.resetState();
			this.mPrevEvent = MotionEvent.obtain(motionEvent);
			this.mTimeDelta = 0L;
			this.updateStateByEvent(motionEvent);
		}
		case 2: {
			this.mGestureInProgress = this.mListener.onMoveBegin(this);
		}
		}
	}

	@Override
	protected void updateStateByEvent(final MotionEvent motionEvent) {
		super.updateStateByEvent(motionEvent);
		final MotionEvent mPrevEvent = this.mPrevEvent;
		this.mCurrFocusInternal = this.determineFocalPoint(motionEvent);
		this.mPrevFocusInternal = this.determineFocalPoint(mPrevEvent);
		int n;
		if (mPrevEvent.getPointerCount() != motionEvent.getPointerCount()) {
			n = 1;
		} else {
			n = 0;
		}
		PointF focus_DELTA_ZERO;
		if (n != 0) {
			focus_DELTA_ZERO = MoveGestureDetector.FOCUS_DELTA_ZERO;
		} else {
			focus_DELTA_ZERO = new PointF(this.mCurrFocusInternal.x
					- this.mPrevFocusInternal.x, this.mCurrFocusInternal.y
					- this.mPrevFocusInternal.y);
		}
		this.mFocusDeltaExternal = focus_DELTA_ZERO;
		final PointF mFocusExternal = this.mFocusExternal;
		mFocusExternal.x += this.mFocusDeltaExternal.x;
		final PointF mFocusExternal2 = this.mFocusExternal;
		mFocusExternal2.y += this.mFocusDeltaExternal.y;
	}

	public interface OnMoveGestureListener {
		boolean onMove(final MoveGestureDetector p0);

		boolean onMoveBegin(final MoveGestureDetector p0);

		void onMoveEnd(final MoveGestureDetector p0);
	}

	public static class SimpleOnMoveGestureListener implements
			OnMoveGestureListener {
		@Override
		public boolean onMove(final MoveGestureDetector moveGestureDetector) {
			return false;
		}

		@Override
		public boolean onMoveBegin(final MoveGestureDetector moveGestureDetector) {
			return true;
		}

		@Override
		public void onMoveEnd(final MoveGestureDetector moveGestureDetector) {
		}
	}
}
