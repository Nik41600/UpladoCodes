package com.esc.sketchartphoto.Touch;

import android.content.Context;
import android.view.MotionEvent;

public abstract class BaseGestureDetector {
	protected static final float PRESSURE_THRESHOLD = 0.67f;
	protected final Context mContext;
	protected MotionEvent mCurrEvent;
	protected float mCurrPressure;
	protected boolean mGestureInProgress;
	protected MotionEvent mPrevEvent;
	protected float mPrevPressure;
	protected long mTimeDelta;

	public BaseGestureDetector(final Context mContext) {
		this.mContext = mContext;
	}

	public long getEventTime() {
		return this.mCurrEvent.getEventTime();
	}

	public long getTimeDelta() {
		return this.mTimeDelta;
	}

	protected abstract void handleInProgressEvent(final int p0,
			final MotionEvent p1);

	protected abstract void handleStartProgressEvent(final int p0,
			final MotionEvent p1);

	public boolean isInProgress() {
		return this.mGestureInProgress;
	}

	public boolean onTouchEvent(final MotionEvent motionEvent) {
		final int n = motionEvent.getAction() & 0xFF;
		if (!this.mGestureInProgress) {
			this.handleStartProgressEvent(n, motionEvent);
		} else {
			this.handleInProgressEvent(n, motionEvent);
		}
		return true;
	}

	protected void resetState() {
		if (this.mPrevEvent != null) {
			this.mPrevEvent.recycle();
			this.mPrevEvent = null;
		}
		if (this.mCurrEvent != null) {
			this.mCurrEvent.recycle();
			this.mCurrEvent = null;
		}
		this.mGestureInProgress = false;
	}

	protected void updateStateByEvent(final MotionEvent motionEvent) {
		final MotionEvent mPrevEvent = this.mPrevEvent;
		if (this.mCurrEvent != null) {
			this.mCurrEvent.recycle();
			this.mCurrEvent = null;
		}
		this.mCurrEvent = MotionEvent.obtain(motionEvent);
		this.mTimeDelta = motionEvent.getEventTime()
				- mPrevEvent.getEventTime();
		this.mCurrPressure = motionEvent.getPressure(motionEvent
				.getActionIndex());
		this.mPrevPressure = mPrevEvent
				.getPressure(mPrevEvent.getActionIndex());
	}
}
