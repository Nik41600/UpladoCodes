package com.esc.sketchartphoto.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.esc.sketchartphoto.R;

public class MaskCustomAdapter extends ArrayAdapter<String> {
	Integer[] int_ids;
	private LayoutInflater layoutInflater;

	private static class Holder {
		public ImageView textView;

		private Holder() {
		}
	}

	public MaskCustomAdapter(Context context, String[] values) {
		super(context, R.layout.custom_data_view1, values);
		this.int_ids = new Integer[] { Integer.valueOf(R.drawable.thumb1),
				Integer.valueOf(R.drawable.thumb), Integer.valueOf(R.drawable.thumb3),
				Integer.valueOf(R.drawable.thumb4), Integer.valueOf(R.drawable.thumb5),
				Integer.valueOf(R.drawable.thumb6), Integer.valueOf(R.drawable.thumb7),
				Integer.valueOf(R.drawable.thumb8), Integer.valueOf(R.drawable.thumb9),
				Integer.valueOf(R.drawable.thumb10),
				Integer.valueOf(R.drawable.thumb11),
				Integer.valueOf(R.drawable.thumb12),
				Integer.valueOf(R.drawable.thumb13),
				Integer.valueOf(R.drawable.thumb14),
				Integer.valueOf(R.drawable.thumb15),
				Integer.valueOf(R.drawable.thumb16),
				Integer.valueOf(R.drawable.thumb17) };
		this.layoutInflater = (LayoutInflater) getContext().getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		Holder holder;
		if (convertView == null) {
			convertView = this.layoutInflater.inflate(R.layout.custom_data_view1,
					parent, false);
			holder = new Holder();
			holder.textView = (ImageView) convertView
					.findViewById(R.id.textView);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		holder.textView.setBackgroundResource(this.int_ids[position].intValue());
		return convertView;
	}
}
