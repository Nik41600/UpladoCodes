package com.esc.sketchartphoto.Touch;

import android.content.Context;
import android.view.MotionEvent;

public class RotateGestureDetector extends TwoFingerGestureDetector {
	private final OnRotateGestureListener mListener;
	private boolean mSloppyGesture;

	public RotateGestureDetector(final Context context,
			final OnRotateGestureListener mListener) {
		super(context);
		this.mListener = mListener;
	}

	public float getRotationDegreesDelta() {
		return (float) (180.0 * (Math.atan2(this.mPrevFingerDiffY,
				this.mPrevFingerDiffX) - Math.atan2(this.mCurrFingerDiffY,
				this.mCurrFingerDiffX)) / 3.141592653589793);
	}

	@Override
	protected void handleInProgressEvent(final int n,
			final MotionEvent motionEvent) {
		switch (n) {
		case 6: {
			this.updateStateByEvent(motionEvent);
			if (!this.mSloppyGesture) {
				this.mListener.onRotateEnd(this);
			}
			this.resetState();
		}
		case 3: {
			if (!this.mSloppyGesture) {
				this.mListener.onRotateEnd(this);
			}
			this.resetState();
		}
		case 2: {
			this.updateStateByEvent(motionEvent);
			if (this.mCurrPressure / this.mPrevPressure > 0.67f
					&& this.mListener.onRotate(this)) {
				this.mPrevEvent.recycle();
				this.mPrevEvent = MotionEvent.obtain(motionEvent);
				return;
			}
			break;
		}
		}
	}

	@Override
	protected void handleStartProgressEvent(final int n,
			final MotionEvent motionEvent) {
		switch (n) {
		case 5: {
			this.resetState();
			this.mPrevEvent = MotionEvent.obtain(motionEvent);
			this.mTimeDelta = 0L;
			this.updateStateByEvent(motionEvent);
			if (!(this.mSloppyGesture = this.isSloppyGesture(motionEvent))) {
				this.mGestureInProgress = this.mListener.onRotateBegin(this);
				return;
			}
			break;
		}
		case 2: {
			if (this.mSloppyGesture
					&& !(this.mSloppyGesture = this
							.isSloppyGesture(motionEvent))) {
				this.mGestureInProgress = this.mListener.onRotateBegin(this);
				return;
			}
			break;
		}
		case 6: {
			if (!this.mSloppyGesture) {
				return;
			}
			break;
		}
		}
	}

	@Override
	protected void resetState() {
		super.resetState();
		this.mSloppyGesture = false;
	}

	public interface OnRotateGestureListener {
		boolean onRotate(final RotateGestureDetector p0);

		boolean onRotateBegin(final RotateGestureDetector p0);

		void onRotateEnd(final RotateGestureDetector p0);
	}

	public static class SimpleOnRotateGestureListener implements
			OnRotateGestureListener {
		@Override
		public boolean onRotate(
				final RotateGestureDetector rotateGestureDetector) {
			return false;
		}

		@Override
		public boolean onRotateBegin(
				final RotateGestureDetector rotateGestureDetector) {
			return true;
		}

		@Override
		public void onRotateEnd(
				final RotateGestureDetector rotateGestureDetector) {
		}
	}
}
