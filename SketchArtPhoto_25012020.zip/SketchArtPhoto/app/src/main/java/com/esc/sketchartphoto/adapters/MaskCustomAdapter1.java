package com.esc.sketchartphoto.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.esc.sketchartphoto.R;

public class MaskCustomAdapter1 extends ArrayAdapter<String> {
    public static Integer[] integers;
    private LayoutInflater layoutInflater;

    private static class Holder {
        public ImageView textView;

        private Holder() {
        }
    }

    public MaskCustomAdapter1(Context context, String[] values) {
        super(context, R.layout.custom_data_view1, values);
        this.layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    static {
        integers = new Integer[]{Integer.valueOf(R.drawable.image1), Integer.valueOf(R.drawable.image2), Integer.valueOf(R.drawable.image3), Integer.valueOf(R.drawable.image4), Integer.valueOf(R.drawable.image5), Integer.valueOf(R.drawable.image6), Integer.valueOf(R.drawable.image7), Integer.valueOf(R.drawable.image8), Integer.valueOf(R.drawable.image9), Integer.valueOf(R.drawable.image10), Integer.valueOf(R.drawable.image11), Integer.valueOf(R.drawable.image12), Integer.valueOf(R.drawable.image13), Integer.valueOf(R.drawable.image14), Integer.valueOf(R.drawable.image15), Integer.valueOf(R.drawable.image16), Integer.valueOf(R.drawable.image17)};
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = this.layoutInflater.inflate(R.layout.custom_data_view1, parent, false);
            holder = new Holder();
            holder.textView = (ImageView) convertView
                    .findViewById(R.id.textView);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        holder.textView.setBackgroundResource(integers[position].intValue());
        return convertView;
    }
}
