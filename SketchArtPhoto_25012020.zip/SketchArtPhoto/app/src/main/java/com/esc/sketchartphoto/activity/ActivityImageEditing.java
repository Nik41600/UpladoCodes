package com.esc.sketchartphoto.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v4.view.MotionEventCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.esc.sketchartphoto.adapters.BubbleEffectAdapter;
import com.esc.sketchartphoto.adapters.ImageLoadingUtils;
import com.esc.sketchartphoto.adapters.MaskCustomAdapter;
import com.esc.sketchartphoto.adapters.MaskCustomAdapter1;
import com.esc.sketchartphoto.R;
import com.esc.sketchartphoto.Touch.MoveGestureDetector;
import com.esc.sketchartphoto.Touch.RotateGestureDetector;
import com.esc.sketchartphoto.adapters.CustomAdapter;
import com.esc.sketchartphoto.adapters.PaperEffectAdapter;
import com.esc.sketchartphoto.kprogresshud.KProgressHUD;
import com.esc.sketchartphoto.utils.HorizontalListView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ActivityImageEditing extends AppCompatActivity implements View.OnTouchListener {
    int style;
    int style1;
    int style2;
    int style3;
    int toast;
    Uri uri;
    boolean vari;
    private String[] Str_waterArry;
    private HorizontalListView HL_waterEffects;
    Integer[] Array_waterEffects;
    static Uri imageUri;
    public static String str_urlShareimg;
    ImageView thereshincrease;
    ImageView resetThresh;
    ImageView backFlip;
    private HorizontalListView hl_BubbleEffects;
    private HorizontalListView hlGalaxyeffects;
    int i;
    private HorizontalListView horizontalListView;
    private int PICK_IMAGE_REQUEST;
    Integer[] paperIntarray;
    private String[] strarrayPaperarray;
    String[] strarrayBack;
    private float scaleFactor;
    int mask;
    String[] masking;
    Integer[] maskingImages;
    private HorizontalListView hlEffects;
    private HorizontalListView hlPapereffects;
    PopupWindow popupWindow;
    private float radius;
    float rate;
    RelativeLayout mainRelatively;
    private final int requestCode;
    int flipperBack;
    Bitmap bitmapBackgallary;
    int btnChecker;
    int Check_backGround;
    private HorizontalListView hlBackimagesarray;
    ImageView ivBackground;
    ImageView btnSave;
    int intGallarycamera;
    int check;
    String[] strarrayColor;
    Integer[] intarrayColored;
    int coloredArrayy;
    private HorizontalListView HL_colors;
    Drawable drawable;
    int dilogColor;
    File file1;
    private ProgressDialog progressDialog;
    int int_flipper;
    Integer[] intIds;
    Integer[] ids;
    int imageCroper;
    ImageView iView1;
    ImageView iView11;
    ImageView iView2;
    ImageView iView3;
    ImageView iView4;
    ImageView iView5;
    ImageView iView6;
    ImageView iView7;
    private static final int constant = 1;
    private static final int TEXT_ID = 0;
    public static final int dismiss = 3;
    static int flipperFront = 0;
    static Bitmap bitmapMaskcolor = null;
    public static final int TYPE_PROGRESSBAR = 5;
    static int threshholdValue;
    private String[] BubbleArry;
    Integer[] bubbleArrys;
    ImageView iView8;
    ImageView iView9;
    private int alpha;
    private String[] mCustomData;
    private float focusX;
    private float focusY;
    private HorizontalListView hlCustomlist;
    private int intImageheight;
    private int intImagewidth;
    private Matrix matrix;
    private MoveGestureDetector moveGestureDetector;
    private RotateGestureDetector rotateGestureDetector;
    private float rotationDegrees;
    private ScaleGestureDetector scaleGestureDetector;


    public ActivityImageEditing() {
        this.matrix = new Matrix();
        this.scaleFactor = 0.4F;
        this.rotationDegrees = 0.0f;
        this.focusX = 0.0f;
        this.focusY = 0.0f;
        this.radius = 1.5f;
        this.alpha = MotionEventCompat.ACTION_MASK;
        this.intImageheight = 10;
        this.intImagewidth = 10;
        this.i = constant;
        this.vari = false;
        this.check = TEXT_ID;
        this.style = constant;
        this.style1 = constant;
        this.style2 = constant;
        this.style3 = constant;
        this.dilogColor = -1;
        this.PICK_IMAGE_REQUEST = constant;
        this.requestCode = 20;
        this.btnChecker = constant;
        this.mask = 25;
        this.coloredArrayy = constant;
        this.flipperBack = constant;
        this.rate = 1.0f;
        this.toast = constant;
        this.file1 = null;
        this.mCustomData = new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
        this.Str_waterArry = new String[]{"", "", "", "", "", "", "", "", "", ""};
        this.strarrayPaperarray = new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
        this.BubbleArry = new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
        this.strarrayBack = new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
        this.masking = new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
        this.strarrayColor = new String[]{"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
        this.Array_waterEffects = new Integer[TEXT_ID];
        this.paperIntarray = new Integer[]{Integer.valueOf(R.drawable.paper_effect1), Integer.valueOf(R.drawable.paper_effect2), Integer.valueOf(R.drawable.paper_effect3), Integer.valueOf(R.drawable.paper_effect5), Integer.valueOf(R.drawable.paper_effect6), Integer.valueOf(R.drawable.paper_effect8), Integer.valueOf(R.drawable.paper_effect10), Integer.valueOf(R.drawable.paper_effect11), Integer.valueOf(R.drawable.paper_effect12), Integer.valueOf(R.drawable.paper_effect13), Integer.valueOf(R.drawable.paper_effect14), Integer.valueOf(R.drawable.paper_effect16), Integer.valueOf(R.drawable.paper_effect17), Integer.valueOf(R.drawable.paper_effect18), Integer.valueOf(R.drawable.paper_effect23)};
        this.intIds = new Integer[TEXT_ID];
        this.intarrayColored = new Integer[TEXT_ID];
        this.ids = new Integer[TEXT_ID];
        this.maskingImages = new Integer[]{Integer.valueOf(R.drawable.thumb1), Integer.valueOf(R.drawable.thumb), Integer.valueOf(R.drawable.thumb3), Integer.valueOf(R.drawable.thumb4), Integer.valueOf(R.drawable.thumb5), Integer.valueOf(R.drawable.thumb6), Integer.valueOf(R.drawable.thumb7), Integer.valueOf(R.drawable.thumb8), Integer.valueOf(R.drawable.thumb9), Integer.valueOf(R.drawable.thumb10), Integer.valueOf(R.drawable.thumb11), Integer.valueOf(R.drawable.thumb12), Integer.valueOf(R.drawable.thumb13), Integer.valueOf(R.drawable.thumb14), Integer.valueOf(R.drawable.thumb15), Integer.valueOf(R.drawable.thumb16), Integer.valueOf(R.drawable.thumb17)};
        this.bubbleArrys = new Integer[]{Integer.valueOf(R.drawable.bg_overlay1), Integer.valueOf(R.drawable.bg_overlay2), Integer.valueOf(R.drawable.bg_overlay3), Integer.valueOf(R.drawable.bg_overlay4), Integer.valueOf(R.drawable.bg_overlay5), Integer.valueOf(R.drawable.bg_overlay6), Integer.valueOf(R.drawable.bg_overlay7), Integer.valueOf(R.drawable.bg_overlay8), Integer.valueOf(R.drawable.bg_overlay9), Integer.valueOf(R.drawable.bg_overlay10), Integer.valueOf(R.drawable.bg_overlay11), Integer.valueOf(R.drawable.bg_overlay12), Integer.valueOf(R.drawable.bg_overlay13), Integer.valueOf(R.drawable.bg_overlay14), Integer.valueOf(R.drawable.bg_overlay15), Integer.valueOf(R.drawable.bg_overlay16), Integer.valueOf(R.drawable.bg_overlay17), Integer.valueOf(R.drawable.bg_overlay18), Integer.valueOf(R.drawable.bg_overlay19), Integer.valueOf(R.drawable.bg_overlay20), Integer.valueOf(R.drawable.bg_overlay21), Integer.valueOf(R.drawable.bg_overlay22), Integer.valueOf(R.drawable.bg_overlay23), Integer.valueOf(R.drawable.bg_overlay24), Integer.valueOf(R.drawable.bg_overlay25), Integer.valueOf(R.drawable.pic1), Integer.valueOf(R.drawable.pic2), Integer.valueOf(R.drawable.pic3), Integer.valueOf(R.drawable.pic4), Integer.valueOf(R.drawable.pic5), Integer.valueOf(R.drawable.pic6), Integer.valueOf(R.drawable.pic7), Integer.valueOf(R.drawable.pic8), Integer.valueOf(R.drawable.pic9), Integer.valueOf(R.drawable.pic10), Integer.valueOf(R.drawable.pic11), Integer.valueOf(R.drawable.pic12), Integer.valueOf(R.drawable.pic13), Integer.valueOf(R.drawable.pic14)};
    }

    static {
        threshholdValue = 70;
        flipperFront = constant;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_image_edit);
        Display display = getWindowManager().getDefaultDisplay();
        loadAd();
        this.focusX = ((float) display.getWidth()) / 2.0f;
        this.focusY = ((float) display.getHeight()) / 2.0f;
        this.iView2 = (ImageView) findViewById(R.id.imageView2);
        this.iView3 = (ImageView) findViewById(R.id.imageView3);
        this.iView4 = (ImageView) findViewById(R.id.imageView4);
        this.iView5 = (ImageView) findViewById(R.id.imageView5);
        this.iView6 = (ImageView) findViewById(R.id.imageView6);
        this.iView7 = (ImageView) findViewById(R.id.imageView7);
        this.iView8 = (ImageView) findViewById(R.id.imageView8);
        this.iView9 = (ImageView) findViewById(R.id.imageView9);
        this.iView1 = (ImageView) findViewById(R.id.imageView10);
        this.iView11 = (ImageView) findViewById(R.id.imageView11);
        this.ivBackground = (ImageView) findViewById(R.id.ivBackgroundImage);
        this.iView2.setVisibility(View.GONE);
        this.iView3.setVisibility(View.GONE);
        this.iView4.setVisibility(View.GONE);
        this.iView5.setVisibility(View.GONE);
        this.iView6.setVisibility(View.GONE);
        this.iView7.setVisibility(View.GONE);
        this.iView8.setVisibility(View.GONE);
        this.iView9.setVisibility(View.GONE);
        this.iView1.setVisibility(View.GONE);
        ImageView img_back = (ImageView) findViewById(R.id.ivBack);
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBack;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent i = new Intent(ActivityImageEditing.this, HomeScreen.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }
            }
        });
        this.mainRelatively = (RelativeLayout) findViewById(R.id.RL_Canvas);
        this.iView2.setOnTouchListener(this);
        this.btnSave = (ImageView) findViewById(R.id.Save);
        this.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.Save;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    progressDialog = ProgressDialog.show(ActivityImageEditing.this, "",
                            "Loading...");
                    new Thread() {

                        public void run() {

                            try {
                                saveImage(getMainFrameBitmap());
                                startActivity(new Intent(ActivityImageEditing.this, ActivityShare.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                                finish();
                            } catch (Exception e) {
                            }
                            progressDialog.dismiss();
                        }

                    }.start();
                }
            }
        });

        this.intGallarycamera = dismiss;
        this.Check_backGround = dismiss;
        this.int_flipper = constant;
        this.imageCroper = constant;
        this.ivBackground.setImageBitmap(FilterEffect(ActivityCropImage.bitmapCropped));
        this.hlCustomlist = (HorizontalListView) findViewById(R.id.hlvCustomList);
        this.HL_waterEffects = (HorizontalListView) findViewById(R.id.hlvCustomList1);
        this.hlPapereffects = (HorizontalListView) findViewById(R.id.hlvCustomList2);
        this.hlEffects = (HorizontalListView) findViewById(R.id.hlvCustomList6);
        this.hl_BubbleEffects = (HorizontalListView) findViewById(R.id.hlvCustomList3);
        this.hlBackimagesarray = (HorizontalListView) findViewById(R.id.backImagesArray);
        this.horizontalListView = (HorizontalListView) findViewById(R.id.masking);
        this.hlGalaxyeffects = (HorizontalListView) findViewById(R.id.galaxy);
        this.HL_colors = (HorizontalListView) findViewById(R.id.colors);
        PaperEffectAdapter customArrayAdapter2 = new PaperEffectAdapter(this, this.strarrayPaperarray);
        CustomAdapter customArrayAdapter4 = new CustomAdapter(this, this.strarrayPaperarray);
        BubbleEffectAdapter customArrayAdapter3 = new BubbleEffectAdapter(this, this.BubbleArry);
        MaskCustomAdapter maskCustomArrayAdapter = new MaskCustomAdapter(this, this.masking);
        MaskCustomAdapter1 maskCustomArrayAdapter1 = new MaskCustomAdapter1(this, this.masking);
        this.hlPapereffects.setAdapter((ListAdapter) customArrayAdapter2);
        this.hl_BubbleEffects.setAdapter((ListAdapter) customArrayAdapter3);
        this.hlEffects.setAdapter((ListAdapter) customArrayAdapter4);
        this.horizontalListView.setAdapter((ListAdapter) maskCustomArrayAdapter);
        this.hlGalaxyeffects.setAdapter((ListAdapter) maskCustomArrayAdapter1);

        this.hlBackimagesarray.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ActivityImageEditing.this.Check_backGround = ActivityImageEditing.constant;
                ActivityImageEditing.this.ivBackground.setVisibility(View.GONE);
                ActivityImageEditing.this.mainRelatively.setBackgroundResource(ActivityImageEditing.this.ids[position].intValue());
            }
        });

        this.HL_colors.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.Check_backGround = ActivityImageEditing.constant;
                ActivityImageEditing.this.coloredArrayy = position;
                ActivityImageEditing.this.makeMaskImage(ActivityImageEditing.this.ivBackground, ActivityImageEditing.this.mask, ActivityImageEditing.this.coloredArrayy);
            }
        });
        this.horizontalListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.mask = position;
                ActivityImageEditing.this.mainRelatively.setBackgroundResource(ActivityImageEditing.this.maskingImages[position].intValue());
            }
        });
        this.hlGalaxyeffects.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.mask = position;
                ActivityImageEditing.this.mainRelatively.setBackgroundResource(MaskCustomAdapter1.integers[position].intValue());
            }
        });
        this.hlEffects.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.mask = position;
                ActivityImageEditing.this.mainRelatively.setBackgroundResource(CustomAdapter.int_ids[position].intValue());
            }
        });
        this.hlPapereffects.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.mask = position;
                ActivityImageEditing.this.mainRelatively.setBackgroundResource(ActivityImageEditing.this.paperIntarray[position].intValue());
            }
        });
        this.hl_BubbleEffects.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.mask = position;
                ActivityImageEditing.this.mainRelatively.setBackgroundResource(ActivityImageEditing.this.bubbleArrys[position].intValue());
            }
        });
        this.HL_waterEffects.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.iView2.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.iView2.setImageResource(ActivityImageEditing.this.Array_waterEffects[position].intValue());
                ActivityImageEditing.this.drawable = ActivityImageEditing.this.getResources().getDrawable(ActivityImageEditing.this.Array_waterEffects[position].intValue());
                ActivityImageEditing.this.intImageheight = ActivityImageEditing.this.drawable.getIntrinsicHeight();
                ActivityImageEditing.this.intImagewidth = ActivityImageEditing.this.drawable.getIntrinsicWidth();
            }
        });
        this.hlCustomlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ActivityImageEditing.this.iView2.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.iView2.setImageResource(ActivityImageEditing.this.intIds[position].intValue());
                ActivityImageEditing.this.drawable = ActivityImageEditing.this.getResources().getDrawable(ActivityImageEditing.this.intIds[position].intValue());
                ActivityImageEditing.this.intImageheight = ActivityImageEditing.this.drawable.getIntrinsicHeight();
                ActivityImageEditing.this.intImagewidth = ActivityImageEditing.this.drawable.getIntrinsicWidth();
            }
        });
        Button pixelEffect = (Button) findViewById(R.id.BtnEffect4);
        Button glaxyEffects = (Button) findViewById(R.id.btnEffects5);
        Button threshhold = (Button) findViewById(R.id.Btn_threshhold);
        Button changeImage = (Button) findViewById(R.id.BtnchangeImage);
        Button PaperEffect = (Button) findViewById(R.id.BtnEffect2);
        Button newEffects = (Button) findViewById(R.id.BtnEffects1);
        Button BubbleEffect = (Button) findViewById(R.id.BtnEffect3);
        thereshincrease = (ImageView) findViewById(R.id.iv_threseIncrease);
        backFlip = (ImageView) findViewById(R.id.iv_decreaseTheresh);
        resetThresh = (ImageView) findViewById(R.id.iv_ResetThresh);
        this.HL_colors.setVisibility(View.GONE);

        pixelEffect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityImageEditing.this.btnChecker = 2;
                ActivityImageEditing.this.horizontalListView.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.HL_colors.setVisibility(View.INVISIBLE);
                thereshincrease.setVisibility(View.INVISIBLE);
                resetThresh.setVisibility(View.INVISIBLE);
                backFlip.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlGalaxyeffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlCustomlist.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_waterEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlPapereffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hl_BubbleEffects.setVisibility(View.INVISIBLE);
            }
        });

        threshhold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityImageEditing.this.btnChecker = 2;
                ActivityImageEditing.this.horizontalListView.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_colors.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlEffects.setVisibility(View.INVISIBLE);
                thereshincrease.setVisibility(View.VISIBLE);
                resetThresh.setVisibility(View.VISIBLE);
                backFlip.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.hlGalaxyeffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlCustomlist.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_waterEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlPapereffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hl_BubbleEffects.setVisibility(View.INVISIBLE);
            }
        });
        changeImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                ImagePicDialog();

            }

        });
        glaxyEffects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityImageEditing.this.btnChecker = 2;
                ActivityImageEditing.this.horizontalListView.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlGalaxyeffects.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.HL_colors.setVisibility(View.INVISIBLE);
                thereshincrease.setVisibility(View.INVISIBLE);
                resetThresh.setVisibility(View.INVISIBLE);
                backFlip.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlCustomlist.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_waterEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlPapereffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hl_BubbleEffects.setVisibility(View.INVISIBLE);
            }
        });
        BubbleEffect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityImageEditing.this.btnChecker = ActivityImageEditing.constant;
                ActivityImageEditing.this.HL_colors.setVisibility(View.GONE);
                ActivityImageEditing.this.hlCustomlist.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlBackimagesarray.setVisibility(View.GONE);
                ActivityImageEditing.this.horizontalListView.setVisibility(View.INVISIBLE);
                thereshincrease.setVisibility(View.INVISIBLE);
                resetThresh.setVisibility(View.INVISIBLE);
                backFlip.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_colors.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_waterEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlPapereffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hl_BubbleEffects.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.hlEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlGalaxyeffects.setVisibility(View.INVISIBLE);
            }
        });
        PaperEffect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityImageEditing.this.btnChecker = ActivityImageEditing.constant;
                ActivityImageEditing.this.HL_colors.setVisibility(View.GONE);
                ActivityImageEditing.this.hlCustomlist.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlBackimagesarray.setVisibility(View.GONE);
                ActivityImageEditing.this.horizontalListView.setVisibility(View.INVISIBLE);
                thereshincrease.setVisibility(View.INVISIBLE);
                resetThresh.setVisibility(View.INVISIBLE);
                backFlip.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_colors.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_waterEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlPapereffects.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.hl_BubbleEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlGalaxyeffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlEffects.setVisibility(View.INVISIBLE);
            }
        });

        newEffects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ActivityImageEditing.this.btnChecker = ActivityImageEditing.constant;
                ActivityImageEditing.this.HL_colors.setVisibility(View.GONE);
                ActivityImageEditing.this.hlCustomlist.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlBackimagesarray.setVisibility(View.GONE);
                ActivityImageEditing.this.horizontalListView.setVisibility(View.INVISIBLE);
                thereshincrease.setVisibility(View.INVISIBLE);
                resetThresh.setVisibility(View.INVISIBLE);
                backFlip.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_colors.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.HL_waterEffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlEffects.setVisibility(View.VISIBLE);
                ActivityImageEditing.this.hlPapereffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hlGalaxyeffects.setVisibility(View.INVISIBLE);
                ActivityImageEditing.this.hl_BubbleEffects.setVisibility(View.INVISIBLE);

            }
        });
        backFlip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (ActivityImageEditing.threshholdValue == 0) {
                    Toast.makeText(ActivityImageEditing.this, "Minimum Reached", Toast.LENGTH_SHORT).show();
                    return;
                }
                ActivityImageEditing.threshholdValue -= 10;
                ActivityImageEditing.this.ivBackground.setImageBitmap(ActivityImageEditing.FilterEffect(ActivityCropImage.bitmapCropped));
            }
        });
        resetThresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ActivityImageEditing.threshholdValue = 70;
                ActivityImageEditing.this.ivBackground.setImageBitmap(ActivityImageEditing.FilterEffect(ActivityCropImage.bitmapCropped));
            }
        });
        thereshincrease.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (ActivityImageEditing.threshholdValue == 120) {
                    Toast.makeText(ActivityImageEditing.this, "Maximum Reached", Toast.LENGTH_SHORT).show();
                    return;
                }
                ActivityImageEditing.threshholdValue += 10;
                ActivityImageEditing.this.ivBackground.setImageBitmap(ActivityImageEditing.FilterEffect(ActivityCropImage.bitmapCropped));
            }
        });
        float scaledImageCenterX = (((float) this.intImagewidth) * this.scaleFactor) / 2.0f;
        float scaledImageCenterY = (((float) this.intImageheight) * this.scaleFactor) / 2.0f;
        this.matrix.postScale(this.scaleFactor, this.scaleFactor);
        this.matrix.postTranslate(this.focusX - scaledImageCenterX, this.focusY - scaledImageCenterY);
        this.iView2.setImageMatrix(this.matrix);
        this.scaleGestureDetector = new ScaleGestureDetector(getApplicationContext(), new ScaleGestureDetector.OnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                ActivityImageEditing.this.scaleFactor = ActivityImageEditing.this.scaleFactor * detector.getScaleFactor();
                ActivityImageEditing.this.scaleFactor = Math.max(0.1f, Math.min(ActivityImageEditing.this.scaleFactor, 10.0f));
                return true;
            }

            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                return false;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {

            }
        });
        this.rotateGestureDetector = new RotateGestureDetector(getApplicationContext(), new RotateGestureDetector.OnRotateGestureListener() {
            @Override
            public boolean onRotate(RotateGestureDetector detector) {
                ActivityImageEditing.this.rotationDegrees = ActivityImageEditing.this.rotationDegrees - detector.getRotationDegreesDelta();
                return true;
            }

            @Override
            public boolean onRotateBegin(RotateGestureDetector p0) {
                return false;
            }

            @Override
            public void onRotateEnd(RotateGestureDetector p0) {

            }
        });
        this.moveGestureDetector = new MoveGestureDetector(getApplicationContext(), new MoveGestureDetector.OnMoveGestureListener() {
            @Override

            public boolean onMove(MoveGestureDetector detector) {
                PointF d = detector.getFocusDelta();
                ActivityImageEditing.this.focusX = ActivityImageEditing.this.focusX + d.x;
                ActivityImageEditing.this.focusY = ActivityImageEditing.this.focusY + d.y;
                return true;
            }

            @Override
            public boolean onMoveBegin(MoveGestureDetector p0) {
                return false;
            }

            @Override
            public void onMoveEnd(MoveGestureDetector p0) {

            }
        });
    }

    private void ImagePicDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog);
        ImageView btncamara = (ImageView) dialog.findViewById(R.id.camera);
        ImageView btngallery = (ImageView) dialog.findViewById(R.id.gallery);
        btngallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();

            }
        });
        btncamara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CapturePicture();

            }
        });
        dialog.show();


    }

    private void CapturePicture() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, 1235);
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "temp", null);
        return Uri.parse(path);
    }

    private void openGallery() {
        Intent photoPickerIntent = new Intent("android.intent.action.PICK");
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, 1234);

    }

    class ImageCompressionAsyncTask extends AsyncTask<String, Void, Bitmap> {
        private boolean fromGallery;

        public ImageCompressionAsyncTask(boolean fromGallery) {
            this.fromGallery = fromGallery;
        }

        protected Bitmap doInBackground(String... params) {
            return compressImage(params[0]);
        }

        public Bitmap compressImage(String imageUri1) {
            String filePath = getRealPathFromURI(imageUri1);
            Log.e("FILE_PATH", filePath);
            Bitmap scaledBitmap = null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            Bitmap bmp = BitmapFactory.decodeFile(filePath, options);
            int actualHeight = options.outHeight;
            int actualWidth = options.outWidth;
            float imgRatio = (float) (actualWidth / actualHeight);
            if (((float) actualHeight) > 2048.0f
                    || ((float) actualWidth) > 1440.0f) {
                if (imgRatio < 0.703125f) {
                    actualWidth = (int) (((float) actualWidth) * (2048.0f / ((float) actualHeight)));
                    actualHeight = 2048;
                } else if (imgRatio > 0.703125f) {
                    actualHeight = (int) (((float) actualHeight) * (1440.0f / ((float) actualWidth)));
                    actualWidth = 1440;
                } else {
                    actualHeight = 2048;
                    actualWidth = 1440;
                }
            }
            options.inSampleSize = ImageLoadingUtils.calculateInSampleSize(
                    options, actualWidth, actualHeight);
            options.inJustDecodeBounds = false;
            options.inDither = false;
            options.inPurgeable = true;
            options.inInputShareable = true;
            options.inTempStorage = new byte[16384];
            try {
                bmp = BitmapFactory.decodeFile(filePath, options);
            } catch (OutOfMemoryError exception) {
                exception.printStackTrace();
            }
            try {
                scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight,
                        Bitmap.Config.ARGB_8888);
            } catch (OutOfMemoryError exception2) {
                exception2.printStackTrace();
            }
            float ratioX = ((float) actualWidth) / ((float) options.outWidth);
            float ratioY = ((float) actualHeight) / ((float) options.outHeight);
            float middleX = ((float) actualWidth) / 2.0f;
            float middleY = ((float) actualHeight) / 2.0f;
            Matrix scaleMatrix = new Matrix();
            scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
            Canvas canvas = new Canvas(scaledBitmap);
            canvas.setMatrix(scaleMatrix);
            canvas.drawBitmap(bmp, middleX - ((float) (bmp.getWidth() / 2)),
                    middleY - ((float) (bmp.getHeight() / 2)), new Paint(2));
            try {
                int orientation = new ExifInterface(filePath).getAttributeInt(
                        "Orientation", 0);
                Matrix matrix = new Matrix();
                if (orientation == 6) {
                    matrix.postRotate(90.0f);
                } else if (orientation == 3) {
                    matrix.postRotate(180.0f);
                } else if (orientation == 8) {
                    matrix.postRotate(270.0f);
                }
                scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
                        scaledBitmap.getWidth(), scaledBitmap.getHeight(),
                        matrix, true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return scaledBitmap;
        }

        private String getRealPathFromURI(String contentURI) {
            Uri contentUri = Uri.parse(contentURI);
            Cursor cursor = ActivityImageEditing.this.getContentResolver().query(
                    contentUri, null, null, null, null);
            if (cursor == null) {
                return contentUri.getPath();
            }
            cursor.moveToFirst();
            return cursor.getString(cursor.getColumnIndex("_data"));
        }

        protected void onPostExecute(Bitmap result) {
            super.onPostExecute(result);
            HomeScreen.bitmap = result;
            SharedPreferences sPreferences = PreferenceManager
                    .getDefaultSharedPreferences(ActivityImageEditing.this
                            .getApplicationContext());
            Intent cropIntent = new Intent(ActivityImageEditing.this,
                    ActivityCropImage.class);
            if (sPreferences.getBoolean("isHair", false)) {
                cropIntent.putExtra("hair", false);
                ActivityImageEditing.this.startActivity(cropIntent);
                return;
            }
            cropIntent.putExtra("hair", false);
            ActivityImageEditing.this.startActivity(cropIntent);
        }
    }


    private Bitmap getMainFrameBitmap() {
        this.mainRelatively.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(this.mainRelatively.getDrawingCache());
        if (Build.VERSION.SDK_INT >= 19) {
            bitmap.setConfig(Bitmap.Config.ARGB_8888);
        }
        this.mainRelatively.setDrawingCacheEnabled(false);
        Bitmap finalEditedImage = bitmap;
        Bitmap bmp = bitmap;
        int imgHeight = bmp.getHeight();
        int imgWidth = bmp.getWidth();
        int largeX = imgWidth;
        int largeY = imgHeight;
        int left = imgWidth;
        int right = imgWidth;
        int top = imgHeight;
        int bottom = imgHeight;
        for (int i = 0; i < imgWidth; i++) {
            for (int j = 0; j < imgHeight; j++) {
                if (bmp.getPixel(i, j) != 0) {
                    if (i - 0 < left) {
                        left = i - 0;
                    }
                    if (largeX - i < right) {
                        right = largeX - i;
                    }
                    if (j - 0 < top) {
                        top = j - 0;
                    }
                    if (largeY - j < bottom) {
                        bottom = largeY - j;
                    }
                }
            }
        }
        return Bitmap.createBitmap(bmp, left, top, (imgWidth - left) - right,
                (imgHeight - top) - bottom);
    }

    private void saveImage(Bitmap bitmap2) {
        Bitmap bitmap = bitmap2;
        File filepath = Environment.getExternalStorageDirectory();
        File dir = new File(filepath.getAbsolutePath() + "/"
                + getString(R.string.app_name));
        dir.mkdirs();
        String FileName = getString(R.string.app_name)
                + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())
                + ".jpeg";
        File file = new File(dir, FileName);
        file.renameTo(file);
        String _uri = "file://" + filepath.getAbsolutePath() + "/"
                + getString(R.string.app_name) + "/" + FileName;
        str_urlShareimg = filepath.getAbsolutePath() + "/"
                + getString(R.string.app_name) + "/" + FileName;
        Log.d("cache uri=", _uri);
        try {
            OutputStream output = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output);
            output.flush();
            output.close();
            sendBroadcast(new Intent(
                    "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                    Uri.fromFile(new File(_uri))));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1234 && resultCode == -1) {
            this.imageUri = data.getData();
            HomeScreen.imageUri = this.imageUri;
            try {
                new ActivityImageEditing.ImageCompressionAsyncTask(true)
                        .execute(new String[]{this.imageUri.toString()});
                return;
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        } else if (requestCode == 1235 && resultCode == -1) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            this.imageUri = getImageUri(getApplicationContext(), photo);
            HomeScreen.imageUri = this.imageUri;
            try {
                new ActivityImageEditing.ImageCompressionAsyncTask(true)
                        .execute(new String[]{this.imageUri.toString()});
                return;
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }

        } else if (requestCode != 1111) {
            getClass();
            if (20 == requestCode && resultCode == -1) {
                this.intGallarycamera = constant;
                this.ivBackground.setImageBitmap(ActivityCropImage.bitmapCropped);
                this.ivBackground.setVisibility(View.VISIBLE);
                this.mainRelatively.setBackgroundColor(Color.parseColor("#2e2d2d"));
            } else if (requestCode == this.PICK_IMAGE_REQUEST && resultCode == -1 && data != null && data.getData() != null) {
                this.intGallarycamera = 2;
                this.uri = data.getData();
                String[] filePathColumn = new String[constant];
                filePathColumn[TEXT_ID] = "_data";
                Cursor cursor = getContentResolver().query(this.uri, filePathColumn, null, null, null);
                cursor.moveToFirst();
                String filePath = cursor.getString(cursor.getColumnIndex(filePathColumn[TEXT_ID]));
                cursor.close();
                this.bitmapBackgallary = BitmapFactory.decodeFile(filePath);
                this.ivBackground.setImageBitmap(this.bitmapBackgallary);
                this.ivBackground.setVisibility(View.VISIBLE);
                this.mainRelatively.setBackgroundColor(Color.parseColor("#2e2d2d"));
            }
        } else if (resultCode == -1) {
            int position_ = Integer.parseInt(data.getExtras().getString("param_result"));
            if (this.i == constant) {
                this.i = 2;
                this.iView2.setVisibility(View.VISIBLE);
                this.iView2.setImageResource(this.intIds[position_].intValue());
                Toast.makeText(this, "First i", Toast.LENGTH_SHORT).show();
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 2) {
                this.i = dismiss;
                this.iView3.setVisibility(View.VISIBLE);
                this.iView3.setOnTouchListener(this);
                this.iView3.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == dismiss) {
                this.i = 4;
                this.iView4.setVisibility(View.VISIBLE);
                this.iView4.setOnTouchListener(this);
                this.iView4.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 4) {
                this.i = TYPE_PROGRESSBAR;
                this.iView5.setVisibility(View.VISIBLE);
                this.iView5.setOnTouchListener(this);
                this.iView5.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == TYPE_PROGRESSBAR) {
                this.i = 6;
                this.iView6.setVisibility(View.VISIBLE);
                this.iView6.setOnTouchListener(this);
                this.iView6.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 6) {
                this.i = 7;
                this.iView7.setVisibility(View.VISIBLE);
                this.iView7.setOnTouchListener(this);
                this.iView7.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 7) {
                this.i = 8;
                this.iView8.setVisibility(View.VISIBLE);
                this.iView8.setOnTouchListener(this);
                this.iView8.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 8) {
                this.i = 9;
                this.iView9.setVisibility(View.VISIBLE);
                this.iView9.setOnTouchListener(this);
                this.iView9.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 9) {
                this.i = 10;
                this.iView1.setVisibility(View.VISIBLE);
                this.iView1.setOnTouchListener(this);
                this.iView1.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 10) {
                this.i = 11;
                this.iView11.setVisibility(View.VISIBLE);
                this.iView11.setOnTouchListener(this);
                this.iView11.setImageResource(this.intIds[position_].intValue());
                this.drawable = getResources().getDrawable(this.intIds[position_].intValue());
                this.intImageheight = this.drawable.getIntrinsicHeight();
                this.intImagewidth = this.drawable.getIntrinsicWidth();
            } else if (this.i == 11) {
                Toast.makeText(this, "Maximum 10 Stickers", Toast.LENGTH_SHORT).show();
            }
        }

    }

    public boolean onTouch(View v, MotionEvent event) {
        this.scaleGestureDetector.onTouchEvent(event);
        this.rotateGestureDetector.onTouchEvent(event);
        this.moveGestureDetector.onTouchEvent(event);
        float scaledImageCenterX = (((float) this.intImagewidth) * this.scaleFactor) / 2.0f;
        float scaledImageCenterY = (((float) this.intImageheight) * this.scaleFactor) / 2.0f;
        this.matrix.reset();
        this.matrix.postScale(this.scaleFactor, this.scaleFactor);
        this.matrix.postRotate(this.rotationDegrees, scaledImageCenterX, scaledImageCenterY);
        this.matrix.postTranslate(this.focusX - scaledImageCenterX, this.focusY - scaledImageCenterY);
        ImageView view = (ImageView) v;
        view.setImageMatrix(this.matrix);
        view.setAlpha(this.alpha);
        return true;
    }


    public void makeMaskImage(ImageView mImageView, int position, int color) {
        Bitmap mask = BitmapFactory.decodeResource(getResources(), this.maskingImages[position].intValue());
        Bitmap result = Bitmap.createBitmap(mask.getWidth(), mask.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas mCanvas = new Canvas(result);
        Paint paint = new Paint(constant);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DARKEN));
        mCanvas.drawBitmap(ActivityCropImage.bitmapCropped, 0.0f, 0.0f, null);
        mCanvas.drawBitmap(mask, 0.0f, 0.0f, paint);
        paint.setXfermode(null);
        mImageView.setImageBitmap(result);
        bitmapMaskcolor = result;
        mImageView.setScaleType(ImageView.ScaleType.FIT_XY);
    }


    public static Bitmap FilterEffect(Bitmap src) {
        Bitmap bitmap = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        paint.setColorFilter(new ColorMatrixColorFilter(getColorMatrix4()));
        canvas.drawBitmap(src, 0.0f, 0.0f, paint);
        return bitmap;
    }

    private static ColorMatrix getColorMatrix4() {
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0.0f);
        float t = (float) (threshholdValue * -255);
        colorMatrix.postConcat(new ColorMatrix(new float[]{200.0f, 0.0f, 0.0f, 1.0f, t, 0.0f, 200.0f, 0.0f, 1.0f, t, 0.0f, 0.0f, 200.0f, 1.0f, t, 1.0f, 0.4F, 0.4F, 0.0f, 0.0f}));
        return colorMatrix;
    }


    private InterstitialAd interstitial;
    private int id;
    private KProgressHUD hud;

    private void loadAd() {
        //InterstitialAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.Save:
                        progressDialog = ProgressDialog.show(ActivityImageEditing.this, "",
                                "Loading...");

                        new Thread() {

                            public void run() {

                                try {
                                    saveImage(getMainFrameBitmap());
                                    startActivity(new Intent(ActivityImageEditing.this, ActivityShare.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                                    finish();
                                } catch (Exception e) {
                                }

                                progressDialog.dismiss();
                            }
                        }.start();

                        break;
                    case R.id.ivBack:
                        Intent i = new Intent(ActivityImageEditing.this, HomeScreen.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        break;
                }
                requestNewInterstitial();
            }
        });
        interstitial.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityImageEditing.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();

    }

    public void finish() {
        if (this.popupWindow != null) {
            if (this.popupWindow.isShowing()) {
                this.popupWindow.dismiss();
            }
            this.popupWindow = null;
            return;
        }
        id = R.id.ivBack;
        if (interstitial != null && interstitial.isLoaded()) {
            interstitial.show();
        } else {

            Intent i = new Intent(ActivityImageEditing.this, HomeScreen.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }
    }
}
