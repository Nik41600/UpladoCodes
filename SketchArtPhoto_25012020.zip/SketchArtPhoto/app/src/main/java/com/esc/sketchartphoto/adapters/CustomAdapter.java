package com.esc.sketchartphoto.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.esc.sketchartphoto.R;

public class CustomAdapter extends ArrayAdapter<String> {
	public static Integer[] int_ids;
	private LayoutInflater layoutInflater;

	private static class Holder {
		public ImageView textView;

		private Holder() {
		}
	}

	public CustomAdapter(Context context, String[] values) {
		super(context, R.layout.custom_data_view, values);
		this.layoutInflater = (LayoutInflater) getContext().getSystemService(
				 Context.LAYOUT_INFLATER_SERVICE);
	}

	static {
		int_ids = new Integer[] { Integer.valueOf(R.drawable.bg1),
				Integer.valueOf(R.drawable.bg2), Integer.valueOf(R.drawable.bg3),
				Integer.valueOf(R.drawable.bg4), Integer.valueOf(R.drawable.bg5),
				Integer.valueOf(R.drawable.bg6), Integer.valueOf(R.drawable.bg7),
				Integer.valueOf(R.drawable.bg8), Integer.valueOf(R.drawable.bg9),
				Integer.valueOf(R.drawable.bg10),
				Integer.valueOf(R.drawable.bg11),
				Integer.valueOf(R.drawable.bg12),
				Integer.valueOf(R.drawable.bg13),
				Integer.valueOf(R.drawable.bg14),
				Integer.valueOf(R.drawable.bg15) };
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		Holder holder;
		if (convertView == null) {
			convertView = this.layoutInflater.inflate(R.layout.custom_data_view,
					parent, false);
			holder = new Holder();
			holder.textView = (ImageView) convertView
					.findViewById(R.id.textView);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		holder.textView.setBackgroundResource(int_ids[position].intValue());
		return convertView;
	}
}
