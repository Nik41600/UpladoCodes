package com.esc.sketchartphoto.Touch;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.ViewConfiguration;

public abstract class TwoFingerGestureDetector extends BaseGestureDetector {
	private float mBottomSlopEdge;
	protected float mCurrFingerDiffX;
	protected float mCurrFingerDiffY;
	private float mCurrLen;
	private final float mEdgeSlop;
	protected float mPrevFingerDiffX;
	protected float mPrevFingerDiffY;
	private float mPrevLen;
	private float mRightSlopEdge;

	public TwoFingerGestureDetector(final Context context) {
		super(context);
		this.mEdgeSlop = ViewConfiguration.get(context).getScaledEdgeSlop();
	}

	protected static float getRawX(final MotionEvent motionEvent, final int n) {
		final float x = motionEvent.getX();
		final float rawX = motionEvent.getRawX();
		if (n < motionEvent.getPointerCount()) {
			return motionEvent.getX(n) + (x - rawX);
		}
		return 0.0f;
	}

	protected static float getRawY(final MotionEvent motionEvent, final int n) {
		final float y = motionEvent.getY();
		final float rawY = motionEvent.getRawY();
		if (n < motionEvent.getPointerCount()) {
			return motionEvent.getY(n) + (y - rawY);
		}
		return 0.0f;
	}

	public float getCurrentSpan() {
		if (this.mCurrLen == -1.0f) {
			final float mCurrFingerDiffX = this.mCurrFingerDiffX;
			final float mCurrFingerDiffY = this.mCurrFingerDiffY;
			this.mCurrLen = mCurrFingerDiffX * mCurrFingerDiffX
					+ mCurrFingerDiffY * mCurrFingerDiffY;
		}
		return this.mCurrLen;
	}


	@Override
	protected abstract void handleInProgressEvent(final int p0,
			final MotionEvent p1);

	@Override
	protected abstract void handleStartProgressEvent(final int p0,
			final MotionEvent p1);

	protected boolean isSloppyGesture(final MotionEvent motionEvent) {
		final DisplayMetrics displayMetrics = this.mContext.getResources()
				.getDisplayMetrics();
		this.mRightSlopEdge = displayMetrics.widthPixels - this.mEdgeSlop;
		this.mBottomSlopEdge = displayMetrics.heightPixels - this.mEdgeSlop;
		final float mEdgeSlop = this.mEdgeSlop;
		final float mRightSlopEdge = this.mRightSlopEdge;
		final float mBottomSlopEdge = this.mBottomSlopEdge;
		final float rawX = motionEvent.getRawX();
		final float rawY = motionEvent.getRawY();
		final float rawX2 = getRawX(motionEvent, 1);
		final float rawY2 = getRawY(motionEvent, 1);
		boolean b;
		if (rawX < mEdgeSlop || rawY < mEdgeSlop || rawX > mRightSlopEdge
				|| rawY > mBottomSlopEdge) {
			b = true;
		} else {
			b = false;
		}
		boolean b2;
		if (rawX2 < mEdgeSlop || rawY2 < mEdgeSlop || rawX2 > mRightSlopEdge
				|| rawY2 > mBottomSlopEdge) {
			b2 = true;
		} else {
			b2 = false;
		}
		return (b && b2) || b || b2;
	}

	@Override
	protected void updateStateByEvent(final MotionEvent motionEvent) {
		super.updateStateByEvent(motionEvent);
		final MotionEvent mPrevEvent = this.mPrevEvent;
		this.mCurrLen = -1.0f;
		this.mPrevLen = -1.0f;
		final float x = mPrevEvent.getX(0);
		final float y = mPrevEvent.getY(0);
		final float x2 = mPrevEvent.getX(1);
		final float y2 = mPrevEvent.getY(1);
		this.mPrevFingerDiffX = x2 - x;
		this.mPrevFingerDiffY = y2 - y;
		final float x3 = motionEvent.getX(0);
		final float y3 = motionEvent.getY(0);
		final float x4 = motionEvent.getX(1);
		final float y4 = motionEvent.getY(1);
		this.mCurrFingerDiffX = x4 - x3;
		this.mCurrFingerDiffY = y4 - y3;
	}
}
