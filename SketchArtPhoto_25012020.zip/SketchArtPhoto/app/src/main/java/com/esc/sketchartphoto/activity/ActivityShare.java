package com.esc.sketchartphoto.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.esc.sketchartphoto.R;
import com.esc.sketchartphoto.kprogresshud.KProgressHUD;
import com.esc.sketchartphoto.utils.Glob;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;

public class ActivityShare extends AppCompatActivity implements View.OnClickListener {
    private ImageView ivFinalimg;
    private ImageView ivHome;
    private ImageView ivBack;
    private ImageView ivShare;
    private ImageView ivFacebook;
    private ImageView ivInstagram;
    private ImageView ivWhasapp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_share);
        loadAd();
        bindview();
    }

    private void bindview() {
        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        this.ivBack.setOnClickListener(this);
        if (Build.VERSION.SDK_INT >= 21) {
            this.ivFinalimg = (ImageView) findViewById(R.id.finalimg);
            findViewById(R.id.simpleFrame).setVisibility(View.GONE);
            findViewById(R.id.roundFrame).setVisibility(View.VISIBLE);
        } else {
            this.ivFinalimg = (ImageView) findViewById(R.id.imageView);
            findViewById(R.id.roundFrame).setVisibility(View.GONE);
            findViewById(R.id.simpleFrame).setVisibility(View.VISIBLE);
        }
        Glide.with((Activity) this).load(ActivityImageEditing.str_urlShareimg)
                .into(this.ivFinalimg);
        this.ivHome = (ImageView) findViewById(R.id.ivhome);
        this.ivHome.setOnClickListener(this);
        this.ivWhasapp = (ImageView) findViewById(R.id.ivWhatsapp);
        this.ivWhasapp.setOnClickListener(this);
        this.ivInstagram = (ImageView) findViewById(R.id.ivInstagram);
        this.ivInstagram.setOnClickListener(this);
        this.ivFacebook = (ImageView) findViewById(R.id.ivFacebook);
        this.ivFacebook.setOnClickListener(this);
        this.ivShare = (ImageView) findViewById(R.id.ivShare);
        this.ivShare.setOnClickListener(this);
    }

    @SuppressLint("WrongConstant")
    public void onClick(View view) {
        Intent shareIntent = new Intent("android.intent.action.SEND");
        shareIntent.setType("image/*");
        shareIntent.putExtra("android.intent.extra.TEXT", getString(R.string.app_name)
                + " Created By : " + Glob.app_link);
        shareIntent.putExtra("android.intent.extra.STREAM",
                Uri.fromFile(new File(ActivityImageEditing.str_urlShareimg)));
        switch (view.getId()) {
            case R.id.ivhome:
                id = R.id.ivhome;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent = new Intent(this, HomeScreen.class);
                    intent.setFlags(268468224);
                    intent.putExtra("ToHome", true);
                    startActivity(intent);
                    finish();
                }
                return;
            case R.id.ivBack:
                id = R.id.ivBack;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent1 = new Intent(this, ActivityMyStudio.class);
                    intent1.setFlags(268468224);
                    intent1.putExtra("ToHome", true);
                    startActivity(intent1);
                }
                return;
            case R.id.ivWhatsapp:
                try {
                    shareIntent.setPackage("com.whatsapp");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e) {
                    Toast.makeText(this, "WhatsApp doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.ivFacebook:
                try {
                    shareIntent.setPackage("com.facebook.katana");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e2) {
                    Toast.makeText(this, "Facebook doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.ivInstagram:
                try {
                    shareIntent.setPackage("com.ic_instagram.android");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e3) {
                    Toast.makeText(this, "Instagram doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.ivShare:
                Intent sharingIntent = new Intent("android.intent.action.SEND");
                sharingIntent.setType("image/*");
                sharingIntent.putExtra("android.intent.extra.TEXT", getString(R.string.app_name)
                        + " Create By : " + Glob.app_link);
                sharingIntent.putExtra("android.intent.extra.STREAM", Uri
                        .fromFile(new File(ActivityImageEditing.str_urlShareimg)));
                startActivity(Intent.createChooser(sharingIntent,
                        "Share Image using"));
                return;
            default:
                return;
        }
    }

    private InterstitialAd interstitialAd;
    private int id;
    private KProgressHUD hud;
    private AdView adView;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //InterstitialAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ivhome:
                        Intent intent = new Intent(ActivityShare.this, HomeScreen.class);
                        intent.setFlags(268468224);
                        intent.putExtra("ToHome", true);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.ivBack:
                        Intent intent1 = new Intent(ActivityShare.this, ActivityMyStudio.class);
                        intent1.setFlags(268468224);
                        intent1.putExtra("ToHome", true);
                        startActivity(intent1);
                        break;
                }
                requestNewInterstitial();
            }
            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityShare.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onBackPressed() {
        Intent intent1 = new Intent(this, ActivityMyStudio.class);
        intent1.setFlags(268468224);
        intent1.putExtra("ToHome", true);
        startActivity(intent1);
    }
}
