package com.esc.sketchartphoto.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.esc.sketchartphoto.R;

public class PaperEffectAdapter extends ArrayAdapter<String> {
    Integer[] intIds;
    private LayoutInflater layoutInflater;

    private static class Holder {
        public ImageView textView;

        private Holder() {
        }
    }

    public PaperEffectAdapter(Context context, String[] values) {
        super(context, R.layout.custom_data_view, values);
        this.intIds = new Integer[]{Integer.valueOf(R.drawable.paper_effect1), Integer.valueOf(R.drawable.paper_effect2), Integer.valueOf(R.drawable.paper_effect3), Integer.valueOf(R.drawable.paper_effect5), Integer.valueOf(R.drawable.paper_effect6), Integer.valueOf(R.drawable.paper_effect8), Integer.valueOf(R.drawable.paper_effect10), Integer.valueOf(R.drawable.paper_effect11), Integer.valueOf(R.drawable.paper_effect12), Integer.valueOf(R.drawable.paper_effect13), Integer.valueOf(R.drawable.paper_effect14), Integer.valueOf(R.drawable.paper_effect16), Integer.valueOf(R.drawable.paper_effect17), Integer.valueOf(R.drawable.paper_effect18), Integer.valueOf(R.drawable.paper_effect23)};
        this.layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = this.layoutInflater.inflate(R.layout.custom_data_view, parent, false);
            holder = new Holder();
            holder.textView = (ImageView) convertView.findViewById(R.id.textView);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        holder.textView.setBackgroundResource(this.intIds[position].intValue());
        return convertView;
    }
}
