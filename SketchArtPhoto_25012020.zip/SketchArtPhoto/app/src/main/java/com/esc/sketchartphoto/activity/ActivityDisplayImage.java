package com.esc.sketchartphoto.activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.sketchartphoto.R;
import com.esc.sketchartphoto.kprogresshud.KProgressHUD;
import com.esc.sketchartphoto.utils.Glob;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.IOException;

public class ActivityDisplayImage extends AppCompatActivity {
    ImageView ivMainImageView;
    ImageView ivDelete, ivhome, ivback;
    int pos;
    ImageView ivSetas;
    ImageView ivShare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_show_image);
        pos = getIntent().getIntExtra("position", 0);
        loadAd();

        ivback = (ImageView) findViewById(R.id.ivBack);
        ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBack;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent1 = new Intent(ActivityDisplayImage.this, ActivityMyStudio.class);
                    intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent1);
                    finish();
                }
            }
        });

        ivhome = (ImageView) findViewById(R.id.iv_home);
        ivhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.iv_home;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent1 = new Intent(ActivityDisplayImage.this, HomeScreen.class);
                    intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent1);
                    finish();
                }
            }
        });

        ivMainImageView = (ImageView) findViewById(R.id.final_img);
        ivMainImageView.setImageURI(Uri.parse((String) Glob.IMAGEALLARY.get(pos)));
        ivDelete = (ImageView) findViewById(R.id.ivDelete);
        ivDelete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final Dialog dial = new Dialog(ActivityDisplayImage.this,
                        R.style.Theme_AppCompat_Dialog);
                dial.requestWindowFeature(1);
                dial.setContentView(R.layout.delete_confirmation);
                dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dial.setCanceledOnTouchOutside(true);
                ((TextView) dial.findViewById(R.id.tvDelete))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                File fD = new File((String) Glob.IMAGEALLARY
                                        .get(pos));
                                if (fD.exists()) {
                                    fD.delete();
                                }
                                Glob.IMAGEALLARY.remove(pos);
                                ActivityDisplayImage.this
                                        .sendBroadcast(new Intent(
                                                "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                                                Uri.fromFile(new File(String
                                                        .valueOf(fD)))));

                                if (Glob.IMAGEALLARY.size() == 0) {
                                    Toast.makeText(ActivityDisplayImage.this,
                                            "No Image Found..", Toast.LENGTH_SHORT).show();
                                }
                                dial.dismiss();
                                finish();

                            }
                        });
                ((TextView) dial.findViewById(R.id.tvCancle))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                dial.dismiss();
                            }
                        });
                dial.show();

            }
        });

        ivSetas = (ImageView) findViewById(R.id.ivSetas);
        ivSetas.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                ActivityDisplayImage.this.setWallpaper(
                        "",
                        (String) Glob.IMAGEALLARY.get(pos));
            }
        });
        ivShare = (ImageView) findViewById(R.id.ivShare);
        ivShare.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("file://"
                        + ((String) Glob.IMAGEALLARY.get(pos)));
                Intent share = new Intent("android.intent.action.SEND");
                share.putExtra("android.intent.extra.STREAM", uri);
                share.setType("image/*");
                share.addFlags(1);
                share.putExtra("android.intent.extra.TEXT",
                        "created by : "
                                + ActivityDisplayImage.this.getPackageName());
                ActivityDisplayImage.this.startActivity(Intent.createChooser(
                        share, "Share image File"));
            }
        });
    }

    private void setWallpaper(String diversity, String s) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int height = metrics.heightPixels;
        int width = metrics.widthPixels;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            wallpaperManager.setBitmap(BitmapFactory.decodeFile(s, options));
            wallpaperManager.suggestDesiredDimensions(width / 2, height / 2);
            Toast.makeText(this, "Wallpaper Set Sucessfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private InterstitialAd interstitialAd;
    private int id;
    private AdView adView;
    private KProgressHUD hud;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //InterstitialAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ivBack:
                        Intent intent1 = new Intent(ActivityDisplayImage.this, ActivityMyStudio.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent1);
                        finish();
                        break;

                    case R.id.iv_home:
                        Intent intent2 = new Intent(ActivityDisplayImage.this, HomeScreen.class);
                        intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent2);
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    @Override
    public void onBackPressed() {
        Intent intent1 = new Intent(ActivityDisplayImage.this, ActivityMyStudio.class);
        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent1);
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityDisplayImage.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }
}
