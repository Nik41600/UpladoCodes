package com.esc.ecomirrormagiceditor.Activity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Random;

import com.esc.ecomirrormagiceditor.R;
import com.esc.ecomirrormagiceditor.Utils.ImageScale;
import com.esc.ecomirrormagiceditor.kprogresshud.KProgressHUD;

public class BrushEditingActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageButton ivBtnDraw;
    private ImageButton ivBtnZoom;
    Uri Uri_saveImg;
    SeekBar seekBar;
    Uri Uri_selectImg;
    int ingSlidvalue;
    private int img_width;
    static int MAX_IMAGE_DIMENSION;
    public static boolean bFlag;
    private ImageScale ivScaleImg;
    private int img_Height;
    private BroadcastReceiver broadcastReceiver;
    ProgressDialog progressDialog;
    private ImageButton ivBtnRedo;
    Bitmap BitMap_MainImg;
    private ImageButton ivBtnBack, ivDone;
    private TextView txt_done;
    Bitmap bitmap;

    ImageButton imageButton;
    private ImageButton ivBtnundo;

    static {
        BrushEditingActivity.bFlag = true;
    }

    public BrushEditingActivity() {
        this.Uri_selectImg = null;
        this.broadcastReceiver = new BroadcastReceiver() {
            public void onReceive(final Context context, final Intent intent) {
                final boolean boolean1 = intent.getExtras().getBoolean(
                        "adLoaded");
            }
        };
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(1024, 1024);
        }
        setContentView(R.layout.activity_brushimage_editing);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        MAX_IMAGE_DIMENSION = width;
        this.seekBar = findViewById(R.id.brushSeekbar);
        this.seekBar.setVisibility(View.INVISIBLE);
        getWindow().addFlags(1024);
        this.ivBtnDraw = findViewById(R.id.ivZoom);
        this.ivBtnZoom = findViewById(R.id.ivDraw);
        this.ivBtnundo = findViewById(R.id.ivUndo);
        this.ivBtnBack = findViewById(R.id.ivBackbtn);
        this.ivDone = findViewById(R.id.ivDone);
        this.ivBtnRedo = findViewById(R.id.ivRedo);
        this.txt_done = findViewById(R.id.txt_done);

        this.ivBtnundo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BrushEditingActivity.this.ivScaleImg.reDrawUndo();
            }
        });

        this.ivBtnRedo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BrushEditingActivity.this.ivScaleImg.reDrawRedo();
            }
        });

        this.ivBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBackbtn;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    BrushEditingActivity.this.onBackPressed();
                }
            }
        });

        this.ivBtnDraw.setOnClickListener(this);
        this.ivBtnZoom.setOnClickListener(this);
        this.Uri_selectImg = Uri.parse(getIntent().getStringExtra("image_Uri"));
        InputStream image_stream = null;
        try {
            image_stream = getContentResolver().openInputStream(
                    this.Uri_selectImg);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        this.BitMap_MainImg = BitmapFactory.decodeStream(image_stream);
        this.img_Height = this.BitMap_MainImg.getWidth();
        this.img_width = this.BitMap_MainImg.getHeight();
        RelativeLayout paintlayout = findViewById(R.id.paintRellayout);
        getWindow().addFlags(1024);
        imageButton = this.findViewById(R.id.ivBrush);
        DisplayMetrics metrics2 = getResources().getDisplayMetrics();
        int width2 = metrics.widthPixels;
        System.out.println("WIDTH -------" + width);
        DisplayMetrics metrics1 = getResources().getDisplayMetrics();
        int D_width = metrics1.widthPixels;
        int D_height = metrics1.heightPixels
                - ((int) (120.0f * getResources().getDisplayMetrics().density));
        int mImageWidth = this.BitMap_MainImg.getWidth();
        int mImageHeight = this.BitMap_MainImg.getHeight();
        System.out.print("I_width" + mImageWidth + "I_height" + mImageHeight);
        Bitmap bmp1 = scaleToFitWidth(this.BitMap_MainImg, D_width, D_height);
        paintlayout.getViewTreeObserver().addOnPreDrawListener(
                new paintLayoutClass(paintlayout, D_width, D_height));
        this.ivScaleImg = new ImageScale(this, this.BitMap_MainImg);
        paintlayout.addView(this.ivScaleImg, 0);
        this.ivScaleImg.setBackgroundColor(0);
        imageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                showSlider(view);

            }
        });
        loadAd();
    }

    public static Bitmap scaleToFitWidth(final Bitmap bitmap, final int n,
                                         final int n2) {
        if (bitmap.getHeight() > bitmap.getWidth()) {
            return Bitmap.createScaledBitmap(bitmap,
                    (bitmap.getWidth() * (n2 / bitmap.getHeight())), n2,
                    true);
        }
        return Bitmap.createScaledBitmap(bitmap, n,
                (bitmap.getHeight() * (n / bitmap.getWidth())), true);
    }

    @Override
    public void onClick(final View view) {
        if (this.ivBtnDraw.equals(view)) {
            BrushEditingActivity.bFlag = true;
        } else if (this.ivBtnZoom.equals(view)) {
            BrushEditingActivity.bFlag = false;
        }
    }

    class paintLayoutClass implements ViewTreeObserver.OnPreDrawListener {
        int finalHeight;
        int finalWidth;
        final int valheight;
        final int valwidth;
        final RelativeLayout valRelpaintlayout;

        paintLayoutClass(RelativeLayout relativeLayout, int i, int i2) {
            this.valRelpaintlayout = relativeLayout;
            this.valwidth = i;
            this.valheight = i2;
        }

        public boolean onPreDraw() {
            this.valRelpaintlayout.getViewTreeObserver().removeOnPreDrawListener(
                    this);
            this.finalHeight = this.valRelpaintlayout.getMeasuredHeight();
            this.finalWidth = this.valRelpaintlayout.getMeasuredWidth();
            this.valRelpaintlayout.getLayoutParams().width = this.valwidth;
            this.valRelpaintlayout.getLayoutParams().height = this.valheight;
            this.valRelpaintlayout.requestLayout();
            return true;
        }
    }

    public void showSlider(final View view) {
        if (this.seekBar.getVisibility() == View.VISIBLE) {
            this.seekBar.setVisibility(View.INVISIBLE);
            imageButton.setImageResource(R.drawable.ic_brush);
            return;
        }
        this.seekBar.setVisibility(View.VISIBLE);
        imageButton.setImageResource(R.drawable.ic_brush_1);
        this.seekBar.setMax(100);
        this.seekBar.setProgress(30);
        this.seekBar.setVisibility(View.VISIBLE);
        this.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar,
                                          final int slidervalue, final boolean b) {
                BrushEditingActivity.this.ingSlidvalue = slidervalue;
                BrushEditingActivity.this.ivScaleImg
                        .setBrushSize(BrushEditingActivity.this.ingSlidvalue);
                System.out.println(".....333......." + slidervalue);
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(
                this.broadcastReceiver);
        super.onDestroy();
    }

    public void saveBitmap(Bitmap sourceBitmap) {
        ContentValues values;
        Throwable th;
        if (sourceBitmap != null && !sourceBitmap.isRecycled()) {
            File storagePath = new File(Environment.getExternalStorageDirectory() + "/Temp1");
            storagePath.mkdirs();
            FileOutputStream out = null;
            int randomNumber = new Random().nextInt(1);
            File imageFile = new File(storagePath, String.format("%s_%d.png",
                    "Temp1", Integer.valueOf(randomNumber)));
            try {
                FileOutputStream out2 = new FileOutputStream(imageFile);
                try {
                    boolean imageSaved = sourceBitmap.compress(
                            Bitmap.CompressFormat.PNG, 100, out2);
                    if (out2 != null) {
                        out = out2;
                    }
                } catch (Exception e) {
                    out = out2;
                    if (out != null) {
                    }
                    values = new ContentValues(3);
                    values.put("mime_type", "bitmap_image/jpeg");
                    values.put("_data", imageFile.getAbsolutePath());
                    this.Uri_saveImg = Uri.fromFile(imageFile
                            .getAbsoluteFile());
                    getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            values);
                } catch (Throwable th2) {
                    th = th2;
                    out = out2;
                    if (out == null) {
                        throw th;
                    }
                    throw th;
                }
            } catch (Exception e2) {
                if (out != null) {
                }
                values = new ContentValues(3);
                values.put("mime_type", "bitmap_image/jpeg");
                values.put("_data", imageFile.getAbsolutePath());
                this.Uri_saveImg = Uri.fromFile(imageFile.getAbsoluteFile());
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } catch (Throwable th3) {
                th = th3;
                if (out == null) {
                    try {
                        throw th;
                    } catch (Throwable e) {
                        e.printStackTrace();
                    }
                }
            }
            values = new ContentValues(3);
            values.put("mime_type", "bitmap_image/jpeg");
            values.put("_data", imageFile.getAbsolutePath());
            this.Uri_saveImg = Uri.fromFile(imageFile.getAbsoluteFile());
            getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        }
    }

    public void saveImage(final View view)
    {
        ivDone.setImageResource(R.drawable.ic_unpress_done);
        txt_done.setTextColor(getResources().getColor(R.color.color_unpresstext));

        if (this.ivScaleImg.sendvalue()) {
            this.ivScaleImg.ResizeBitmap();
        }
        this.progressDialog = ProgressDialog.show(this,
                "Please Wait", "Image is saving");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                BrushEditingActivity.this.bitmap = BrushEditingActivity.this.ivScaleImg
                        .getBitmap_second();
                if (BrushEditingActivity.this.bitmap == null) {
                    final View child = ((RelativeLayout) BrushEditingActivity.this
                            .findViewById(R.id.paintRellayout)).getChildAt(0);
                    child.setDrawingCacheEnabled(true);
                    BrushEditingActivity.this.bitmap = child.getDrawingCache();
                }
                BrushEditingActivity.this.saveBitmap(BrushEditingActivity.this.bitmap);
                final Intent intent = new Intent();
                intent.putExtra("erase_image",
                        BrushEditingActivity.this.Uri_saveImg.toString());
                BrushEditingActivity.this.setResult(2, intent);
                BrushEditingActivity.this.progressDialog.dismiss();
                BrushEditingActivity.this.finish();
            }
        }, 1000L);
    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.ivBackbtn:
                        BrushEditingActivity.this.onBackPressed();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(BrushEditingActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
