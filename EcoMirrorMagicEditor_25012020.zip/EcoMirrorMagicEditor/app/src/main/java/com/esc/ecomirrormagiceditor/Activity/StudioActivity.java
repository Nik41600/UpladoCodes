package com.esc.ecomirrormagiceditor.Activity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.util.Collections;

import com.esc.ecomirrormagiceditor.Adapter.AdapterMyCreation;
import com.esc.ecomirrormagiceditor.R;
import com.esc.ecomirrormagiceditor.Utils.Utils;
import com.esc.ecomirrormagiceditor.kprogresshud.KProgressHUD;

public class StudioActivity extends AppCompatActivity {
    private ImageView ivBack;
    private AdapterMyCreation galleryAdapter;
    private GridView GridImagelist;
    private ImageView noImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_my_creation);
        loadAd();
    }

    protected void onResume() {
        super.onResume();
        bindView();
    }

    private void bindView() {
        this.noImage = (ImageView) findViewById(R.id.noimg);
        this.GridImagelist = (GridView) findViewById(R.id.crationImageList);
        getImages();
        if (Utils.IMAGEALLARY.size() <= 0) {
            this.noImage.setVisibility(View.VISIBLE);
            this.GridImagelist.setVisibility(View.GONE);
        } else {
            this.noImage.setVisibility(View.GONE);
            this.GridImagelist.setVisibility(View.VISIBLE);
        }
        this.ivBack = (ImageView) findViewById(R.id.ivBackbtn);
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBackbtn;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(StudioActivity.this, HomeScreen.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        });

        Collections.sort(Utils.IMAGEALLARY);
        Collections.reverse(Utils.IMAGEALLARY);
        this.galleryAdapter = new AdapterMyCreation(this, Utils.IMAGEALLARY);
        this.GridImagelist.setAdapter(this.galleryAdapter);
        GridImagelist.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Intent i = new Intent(StudioActivity.this,
                        DisplayImageActivity.class);
                i.putExtra("position", position);
                startActivity(i);
            }
        });
    }

    private void getImages() {
        if (Build.VERSION.SDK_INT < 23) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                    5);
        }
    }

    private void fetchImage() {
        Utils.IMAGEALLARY.clear();
        Utils.listAllImages(new File(Environment.getExternalStorageDirectory() + "/" + getString(R.string.app_name)
                + "/"));
    }

    public void onBackPressed() {
        startActivity(new Intent(StudioActivity.this, HomeScreen.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 5:
                if (grantResults[0] == 0) {
                    fetchImage();
                    return;
                } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                            new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                            5);
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
    }

    private InterstitialAd interstitial;
    private AdView adView;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.ivBackbtn:
                        startActivity(new Intent(StudioActivity.this, HomeScreen.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(StudioActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
