package com.esc.ecomirrormagiceditor.Activity;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Random;

import com.esc.ecomirrormagiceditor.R;
import com.esc.ecomirrormagiceditor.gestureCropView;
import com.esc.ecomirrormagiceditor.kprogresshud.KProgressHUD;

public class CropImageActivity extends AppCompatActivity implements View.OnClickListener {
    static Bitmap OriginalImages;
    ImageButton ivBtnClose;
    RelativeLayout cropRelativeLayout;
    int height;
    int width;
    RelativeLayout relative_closeView;
    ImageView ivComp;
    int rotateValues;
    ImageView ivReset;
    RelativeLayout Relative_Main;
    ImageView ivRotate;
    TextView txt_reset, txt_rotate, txt_done;
    Uri uriSave;
    Uri uriSelectedimg;
    ImageView ivShow;
    ImageView ivDone;
    gestureCropView free_cropView;
    boolean shown;
    int img_height;
    int image_width;
    String str_manufacturer;
    ProgressDialog progressDialog;

    public CropImageActivity() {
        this.shown = false;
        this.rotateValues = 0;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_crop_image1);
        this.uriSelectedimg = Uri.parse(getIntent().getStringExtra("image_Uri"));
        this.str_manufacturer = Build.MANUFACTURER;
        System.out.println("device_manufacturer" + this.str_manufacturer);
        getWindow().addFlags(1024);
        loadAd();

        this.cropRelativeLayout = (RelativeLayout) findViewById(R.id.rl_crop);

        this.ivReset = (ImageView) findViewById(R.id.ivReset);
        this.ivReset.setOnClickListener(this);

        this.ivRotate = (ImageView) findViewById(R.id.ivRotate);
        this.ivRotate.setOnClickListener(this);

        this.ivDone = (ImageView) findViewById(R.id.ivDone);
        this.ivDone.setOnClickListener(this);

        this.relative_closeView = (RelativeLayout) findViewById(R.id.closeView);
        this.ivBtnClose = (ImageButton) findViewById(R.id.imgclose);
        this.ivBtnClose.setOnClickListener(this);

        this.ivShow = (ImageView) findViewById(R.id.show);
        this.ivComp = (ImageView) findViewById(R.id.img);

        this.Relative_Main = (RelativeLayout) findViewById(R.id.rl_root);
        this.Relative_Main.setVisibility(View.INVISIBLE);

        txt_reset = findViewById(R.id.txt_reset);
        txt_rotate = findViewById(R.id.txt_rotate);
        txt_done = findViewById(R.id.txt_done);

        InputStream image_stream = null;
        try {
            image_stream = getContentResolver().openInputStream(
                    this.uriSelectedimg);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        OriginalImages = BitmapFactory.decodeStream(image_stream);
        if (this.str_manufacturer.equals("samsung")) {
            Toast.makeText(this, "Check now Rotation Required or not", Toast.LENGTH_SHORT)
                    .show();
        } else if (this.str_manufacturer.equals("Sony")) {
            Toast.makeText(this, "Check now Rotation Required or not", Toast.LENGTH_SHORT)
                    .show();
        }
        this.image_width = OriginalImages.getWidth();
        this.img_height = OriginalImages.getHeight();
        System.out.println("image_width" + this.image_width + "img_height"
                + this.img_height);
        DisplayMetrics metrics1 = getResources().getDisplayMetrics();
        this.width = metrics1.widthPixels;
        this.height = metrics1.heightPixels;
        float density = getResources().getDisplayMetrics().density;
        int width = this.width - ((int) density);
        int height = this.height - ((int) (60.0f * density));
        if (this.image_width >= width || this.img_height >= height) {
            while (true) {
                if (this.image_width <= width && this.img_height <= height) {
                    break;
                }
                this.image_width = (int) (((double) this.image_width) * 0.9d);
                this.img_height = (int) (((double) this.img_height) * 0.9d);
                System.out.println("image_width" + this.image_width
                        + "img_height" + this.img_height);
            }
            OriginalImages = Bitmap.createScaledBitmap(OriginalImages,
                    this.image_width, this.img_height, true);
            System.out.println("image_width" + this.image_width
                    + "img_height" + this.img_height);
        } else {
            while (this.image_width < width - 20 && this.img_height < height) {
                this.image_width = (int) (((double) this.image_width) * 1.1d);
                this.img_height = (int) (((double) this.img_height) * 1.1d);
                System.out.println("image_width" + this.image_width
                        + "img_height" + this.img_height);
            }
            OriginalImages = Bitmap.createScaledBitmap(OriginalImages,
                    this.image_width, this.img_height, true);
            System.out.println("image_width" + this.image_width
                    + "img_height" + this.img_height);
        }
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) this.cropRelativeLayout.getLayoutParams();
        params.height = OriginalImages.getHeight();
        params.width = OriginalImages.getWidth();
        this.cropRelativeLayout.setLayoutParams(params);
        this.free_cropView = new gestureCropView((Context) this, OriginalImages);
        this.cropRelativeLayout.addView(this.free_cropView);
        Reset();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.ivReset:
                ivReset.setImageResource(R.drawable.ic_reset);
                ivRotate.setImageResource(R.drawable.ic_unpress_rotate);
                ivDone.setImageResource(R.drawable.ic_unpress_done);

                txt_reset.setTextColor(getResources().getColor(R.color.white));
                txt_reset.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_reset.setTextColor(getResources().getColor(R.color.color_unpresstext));
                CropImageActivity.this.Reset();
               break;

            case R.id.ivRotate:
                ivReset.setImageResource(R.drawable.ic_unpress_reset);
                ivRotate.setImageResource(R.drawable.ic_rotate);
                ivDone.setImageResource(R.drawable.ic_unpress_done);

                txt_reset.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.white));
                txt_done.setTextColor(getResources().getColor(R.color.color_unpresstext));

                CropImageActivity.this.rotateValues += 90;
                if (CropImageActivity.this.rotateValues == 360) {
                    CropImageActivity.this.rotateValues = 0;
                }
                CropImageActivity.OriginalImages = CropImageActivity.RotateBitmap(
                        CropImageActivity.OriginalImages, (float) CropImageActivity.this.rotateValues);
                CropImageActivity.this.ivComp.setImageBitmap(null);
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) CropImageActivity.this.cropRelativeLayout
                        .getLayoutParams();
                params.height = CropImageActivity.OriginalImages.getHeight();
                params.width = CropImageActivity.OriginalImages.getWidth();
                CropImageActivity.this.cropRelativeLayout.setLayoutParams(params);
                CropImageActivity.this.free_cropView = new gestureCropView(CropImageActivity.this,
                        CropImageActivity.OriginalImages);
                CropImageActivity.this.cropRelativeLayout.addView(CropImageActivity.this.free_cropView);
                break;

            case R.id.ivDone:
                id = R.id.ivDone;

                ivReset.setImageResource(R.drawable.ic_unpress_reset);
                ivRotate.setImageResource(R.drawable.ic_unpress_rotate);
                ivDone.setImageResource(R.drawable.ic_done);

                txt_reset.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_done.setTextColor(getResources().getColor(R.color.white));

                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    CropImageActivity.this.Relative_Main.setVisibility(View.INVISIBLE);
                    if (gestureCropView.list_point.size() == 0) {
                        Toast.makeText(CropImageActivity.this, "please Crop it", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    boolean bool = gestureCropView.GetValue();
                    System.out.println("boolean_value" + bool);
                    CropImageActivity.this.FinalImage(bool);
                    CropImageActivity.this.saveImage();
                }
                break;

            case R.id.imgclose:
                CropImageActivity.this.relative_closeView.setVisibility(View.INVISIBLE);
                break;
        }
    }

    public void Reset() {
        this.ivComp.setImageBitmap(null);
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) this.cropRelativeLayout.getLayoutParams();
        params.height = OriginalImages.getHeight();
        params.width = OriginalImages.getWidth();
        this.cropRelativeLayout.setLayoutParams(params);
        this.free_cropView = new gestureCropView((Context) this, OriginalImages);
        this.cropRelativeLayout.addView(this.free_cropView);
    }

    public void FinalImage(boolean value) {
        System.out.println("ImageCrop=-=-=-=-=-");
        Bitmap resultingImage = Bitmap.createBitmap(this.width,
                this.height, OriginalImages.getConfig());
        Canvas canvas = new Canvas(resultingImage);
        Paint paint = new Paint();
        paint.setMaskFilter(new BlurMaskFilter(50.0f, BlurMaskFilter.Blur.NORMAL));
        paint.setAntiAlias(true);
        Path path = new Path();
        for (int i = 0; i < gestureCropView.list_point.size(); i++) {
            path.lineTo((float) ((Point) gestureCropView.list_point.get(i)).x,
                    (float) ((Point) gestureCropView.list_point.get(i)).y);
        }
        System.out.println("list_point" + gestureCropView.list_point.size());
        canvas.drawPath(path, paint);
        if (value) {
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        } else {
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
        }
        canvas.drawBitmap(OriginalImages, 0.0f, 0.0f, paint);
        this.ivComp.setImageBitmap(resultingImage);
    }

    public static Bitmap RotateBitmap(final Bitmap bitmap, final float n) {
        final Matrix matrix = new Matrix();
        matrix.postRotate(n);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
                bitmap.getHeight(), matrix, true);
    }

    public Bitmap getScreenShot() {
        Bitmap screenshot = null;
        try {
            View rootRelative = (RelativeLayout) findViewById(R.id.rl_root);
            rootRelative.setBackgroundColor(0);
            View v1 = rootRelative;
            screenshot = Bitmap.createBitmap(v1.getMeasuredWidth(),
                    v1.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            v1.draw(new Canvas(screenshot));
            return screenshot;
        } catch (Exception e) {
            Log.d("ScreenShotActivity", "Failed to capture screenshot because:"
                    + e.getMessage());
            return screenshot;
        }
    }

    public void saveImage() {
        this.progressDialog = ProgressDialog.show(this, "", "Image is saving");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                CropImageActivity.this.saveBitmap(CropImageActivity.this.getScreenShot());
                Intent in = new Intent(CropImageActivity.this, ImageEditingActivity.class);
                in.putExtra("image_Uri", CropImageActivity.this.uriSave.toString());
                CropImageActivity.this.startActivity(in);
                CropImageActivity.this.progressDialog.dismiss();
            }
        }, 1000);
    }
    public void saveBitmap(Bitmap sourceBitmap) {
        ContentValues values;
        Throwable th;
        if (sourceBitmap != null && !sourceBitmap.isRecycled()) {
            File storagePath = new File(
                    Environment.getExternalStorageDirectory() + "/Temp");
            storagePath.mkdirs();
            FileOutputStream out = null;
            int randomNumber = new Random().nextInt();
            File imageFile = new File(storagePath, String.format("%s_%d.png",
                    new Object[]{"Temp", Integer.valueOf(randomNumber)}));
            try {
                FileOutputStream out2 = new FileOutputStream(imageFile);
                try {
                    boolean imageSaved = sourceBitmap.compress(
                            Bitmap.CompressFormat.PNG, 100, out2);
                    if (out2 != null) {
                        out = out2;
                    }
                } catch (Exception e) {
                    out = out2;
                    if (out != null) {
                    }
                    values = new ContentValues(3);
                    values.put("msg", "Temp");
                    values.put("mime_type", "bitmap_image/jpeg");
                    values.put("_data", imageFile.getAbsolutePath());
                    this.uriSave = Uri.fromFile(imageFile
                            .getAbsoluteFile());
                    getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            values);
                } catch (Throwable th2) {
                    th = th2;
                    out = out2;
                    if (out == null) {
                        throw th;
                    }
                    throw th;
                }
            } catch (Exception e2) {
                if (out != null) {
                }
                values = new ContentValues(3);
                values.put("msg", "Temp");
                values.put("mime_type", "bitmap_image/jpeg");
                values.put("_data", imageFile.getAbsolutePath());
                this.uriSave = Uri.fromFile(imageFile.getAbsoluteFile());
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } catch (Throwable th3) {
            }
            values = new ContentValues(3);
            values.put("msg", "Temp");
            values.put("mime_type", "bitmap_image/jpeg");
            values.put("_data", imageFile.getAbsolutePath());
            this.uriSave = Uri.fromFile(imageFile.getAbsoluteFile());
            getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        }
    }

    protected void onDestroy() {
        super.onDestroy();
    }
    private InterstitialAd interstitial;
    private AdView adView;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id)
                {
                    case R.id.ivDone:
                        CropImageActivity.this.Relative_Main.setVisibility(View.INVISIBLE);
                        if (gestureCropView.list_point.size() == 0) {
                            Toast.makeText(CropImageActivity.this, "please Crop it", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        boolean bool = gestureCropView.GetValue();
                        System.out.println("boolean_value" + bool);
                        CropImageActivity.this.FinalImage(bool);
                        CropImageActivity.this.saveImage();
                    break;


                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(CropImageActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
