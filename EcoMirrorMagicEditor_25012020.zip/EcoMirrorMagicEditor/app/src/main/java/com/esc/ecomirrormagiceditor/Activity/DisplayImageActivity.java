package com.esc.ecomirrormagiceditor.Activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.IOException;

import com.esc.ecomirrormagiceditor.R;
import com.esc.ecomirrormagiceditor.Utils.Utils;
import com.esc.ecomirrormagiceditor.kprogresshud.KProgressHUD;

public class DisplayImageActivity extends AppCompatActivity {
    ImageView ivMainImage;
    ImageView ivDelete;
    int pos;
    ImageView ivSetas;
    ImageView ivShare, ivBack, ivhome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_display_image);
        loadAd();
        pos = getIntent().getIntExtra("position", 0);
        ivMainImage = (ImageView) findViewById(R.id.ivMainImage);
        ivMainImage.setImageURI(Uri.parse((String) Utils.IMAGEALLARY.get(pos)));
        ivDelete = (ImageView) findViewById(R.id.ivDelete);
        ivDelete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final Dialog dial = new Dialog(DisplayImageActivity.this,
                        android.R.style.Theme_Translucent);
                dial.requestWindowFeature(1);
                dial.setContentView(R.layout.delete_confirmation);
                dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dial.setCanceledOnTouchOutside(true);
                ((TextView) dial.findViewById(R.id.tvDelete))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                File fD = new File((String) Utils.IMAGEALLARY
                                        .get(pos));
                                if (fD.exists()) {
                                    fD.delete();
                                }
                                Utils.IMAGEALLARY.remove(pos);
                                DisplayImageActivity.this
                                        .sendBroadcast(new Intent(
                                                "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                                                Uri.fromFile(new File(String
                                                        .valueOf(fD)))));

                                if (Utils.IMAGEALLARY.size() == 0) {
                                    Toast.makeText(DisplayImageActivity.this,
                                            "No Image Found..", Toast.LENGTH_SHORT
                                    ).show();
                                }
                                dial.dismiss();
                                finish();

                            }
                        });
                ((TextView) dial.findViewById(R.id.tvCancle))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                dial.dismiss();
                            }
                        });
                dial.show();

            }
        });

        ivBack = (ImageView) findViewById(R.id.ivBackbtn);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBackbtn;
                if (interstitial != null && interstitial.isLoaded()) {
                   DialogShow();
                   AdsDialogShow();
                } else {
                    startActivity(new Intent(DisplayImageActivity.this, StudioActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        });

        ivhome = (ImageView) findViewById(R.id.ivhome);
        ivhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivhome;
                if (interstitial != null && interstitial.isLoaded()) {
                        DialogShow();
                        AdsDialogShow();
                }else {
                    startActivity(new Intent(DisplayImageActivity.this, StudioActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        });

        ivSetas = (ImageView) findViewById(R.id.ivSetas);
        ivSetas.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                DisplayImageActivity.this.setWallpaper(
                        "",
                        (String) Utils.IMAGEALLARY.get(pos));
            }
        });
        ivShare = (ImageView) findViewById(R.id.ivShare);
        ivShare.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("file://"
                        + ((String) Utils.IMAGEALLARY.get(pos)));
                Intent share = new Intent("android.intent.action.SEND");
                share.putExtra("android.intent.extra.STREAM", uri);
                share.setType("image/*");
                share.putExtra("android.intent.extra.TEXT",
                        "created by : "
                                + DisplayImageActivity.this.getPackageName());
                DisplayImageActivity.this.startActivity(Intent.createChooser(
                        share, "Share image File"));
            }
        });
    }

    private void setWallpaper(String diversity, String s) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int height = metrics.heightPixels;
        int width = metrics.widthPixels;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            wallpaperManager.setBitmap(BitmapFactory.decodeFile(s, options));
            wallpaperManager.suggestDesiredDimensions(width / 2, height / 2);
            Toast.makeText(this, "Wallpaper Set Sucessfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(DisplayImageActivity.this, StudioActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {

                    case R.id.ivBackbtn:
                        startActivity(new Intent(DisplayImageActivity.this, StudioActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;

                    case R.id.ivhome:
                        startActivity(new Intent(DisplayImageActivity.this, StudioActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(DisplayImageActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

}
