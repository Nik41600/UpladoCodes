package com.esc.ecomirrormagiceditor.Activity;

import android.Manifest;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.gson.Gson;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;

import com.esc.ecomirrormagiceditor.Adapter.MoreAppAdapter;
import com.esc.ecomirrormagiceditor.R;
import com.esc.ecomirrormagiceditor.kprogresshud.KProgressHUD;
import com.esc.ecomirrormagiceditor.model.App_data;

public class HomeScreen extends AppCompatActivity implements View.OnClickListener {
    private Toolbar toolbar;
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private TextView txt_version;
    private SharedPreferences ePreferences;
    private UnifiedNativeAd nativeAd;
    ImageView btn_gallery;
    private static final int IMAGE_GALLERY_REQUEST = 20;
    private Uri uri_selectedimg;
    String device_manufacturer;
    Bitmap bitmap_orignal;
    String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
    };
    private ArrayList<App_data> array_appdata;
    private MoreAppAdapter moreAppAdapter;
    private RecyclerView recyclerView;
    ImageView mycreation;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnStart:
                id = R.id.btnStart;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    openGallery();
                }
                break;
            case R.id.btnmycreation:
                id = R.id.btnmycreation;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (!hasPermissions(HomeScreen.this, PERMISSIONS)) {
                            ActivityCompat.requestPermissions(HomeScreen.this, PERMISSIONS,
                                    2);
                        } else {
                            Intent i = new Intent(HomeScreen.this, StudioActivity.class);
                            startActivity(i);
                        }
                    } else {
                        Intent i = new Intent(HomeScreen.this, StudioActivity.class);
                        startActivity(i);
                    }
                }
                break;
        }
    }

    class Navigation implements NavigationView.OnNavigationItemSelectedListener {
        Navigation() {
        }

        public boolean onNavigationItemSelected(MenuItem item) {
            HomeScreen.this.drawerLayout.closeDrawers();

            switch (item.getItemId()) {

                case R.id.menu_rate:
                    try {
                        startActivity(new Intent(
                                "android.intent.action.VIEW",
                                Uri.parse(getResources().getString(R.string.rate_us_url)
                                        + getPackageName())));
                        return true;
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(HomeScreen.this, "You don't have Google Play installed",
                                Toast.LENGTH_SHORT).show();
                        return true;
                    }

                case R.id.menu_share:
                    Intent share = new Intent("android.intent.action.SEND");
                    share.setType("text/plain");
                    share.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.share_msg)
                            + getPackageName());
                    startActivity(Intent.createChooser(share, "Share Via"));
                    return true;

                case R.id.menu_more:
                    try {
                        startActivity(new Intent("android.intent.action.VIEW", Uri
                                .parse("https://play.google.com/store/apps/developer?id="
                                        + getString(R.string.more_url))));
                        return true;
                    } catch (ActivityNotFoundException ex) {
                        Toast.makeText(HomeScreen.this, "Google play store not install", Toast.LENGTH_SHORT).show();
                        return true;
                    }

                case R.id.menu_privacy_policy:
                    try {
                        Intent intent1 = new Intent(Intent.ACTION_VIEW);
                        intent1.setData(Uri.parse(getResources().getString(R.string.privacy_policy_url)));
                        startActivity(intent1);
                        return true;
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(HomeScreen.this, "Internet not connect", Toast.LENGTH_SHORT).show();
                        return true;
                    }

                default:
                    return false;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_home);
        array_appdata = new ArrayList<>();
        makeJsonRequest(getResources().getString(R.string.more_appurl));
        recyclerView = (RecyclerView) findViewById(R.id.ad_inter_recycle_view);
        final GridLayoutManager layoutManager = new GridLayoutManager(HomeScreen.this, 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        txt_version = (TextView) findViewById(R.id.txt_version);
        ePreferences = getSharedPreferences("pref_key_rate", 0);
        navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new Navigation());
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        this.device_manufacturer = Build.MANUFACTURER;
        System.out.println("device_manufacturer" + this.device_manufacturer);
        btn_gallery = (ImageView) findViewById(R.id.btnStart);
        btn_gallery.setOnClickListener(this);
        mycreation = (ImageView) findViewById(R.id.btnmycreation);
        mycreation.setOnClickListener(this);

        toggle = new ActionBarDrawerToggle(this, this.drawerLayout, toolbar,
                R.string.drawer_open, R.string.drawer_close);
        toggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
        this.drawerLayout.setDrawerListener(toggle);
        toggle.syncState();
        getVersionInfo();
        loadAd();
    }

    private void makeJsonRequest(String url) {
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("application_detail");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                App_data app_data = new Gson().fromJson(jsonArray.get(i).toString(), App_data.class);
                                if (!app_data.getApplication_name().equalsIgnoreCase(getString(R.string.app_name))) {
                                    array_appdata.add(app_data);
                                    moreAppAdapter = new MoreAppAdapter(HomeScreen.this, array_appdata);
                                    recyclerView.setAdapter(moreAppAdapter);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Error", "Error: " + error.getMessage());
            }
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq, "");
    }

    private void getVersionInfo() {
        String VersionName = "";

        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            VersionName = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        txt_version.setText("v" + VersionName);
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    public HomeScreen() {
        this.uri_selectedimg = null;
    }

    public void openGallery() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!hasPermissions(HomeScreen.this, PERMISSIONS)) {
                ActivityCompat.requestPermissions(HomeScreen.this, PERMISSIONS,
                        1);
            } else {
                Intent imagePickerIntent = new Intent("android.intent.action.PICK");
                imagePickerIntent.setDataAndType(
                        Uri.parse(Environment.getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_PICTURES).getPath()), "image/*");
                startActivityForResult(imagePickerIntent, IMAGE_GALLERY_REQUEST);
            }
        } else {
            Intent imagePickerIntent = new Intent("android.intent.action.PICK");
            imagePickerIntent.setDataAndType(
                    Uri.parse(Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_PICTURES).getPath()), "image/*");
            startActivityForResult(imagePickerIntent, IMAGE_GALLERY_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                HomeScreen.this,
                                "Sorry We cant process ahed due to denied pemission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                Intent imagePickerIntent = new Intent("android.intent.action.PICK");
                imagePickerIntent.setDataAndType(
                        Uri.parse(Environment.getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_PICTURES).getPath()), "image/*");
                startActivityForResult(imagePickerIntent, IMAGE_GALLERY_REQUEST);
                return;
            case 2:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                HomeScreen.this,
                                "Sorry We cant process ahed due to denied pemission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                Intent i = new Intent(HomeScreen.this, StudioActivity.class);
                startActivity(i);
                return;

        }
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("picUri", this.uri_selectedimg);
    }

    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        this.uri_selectedimg = (Uri) savedInstanceState
                .getParcelable("picUri");
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == IMAGE_GALLERY_REQUEST && resultCode == -1) {
            Uri uri = data.getData();
            if (!this.device_manufacturer.equals("samsung")) {
                try {
                    uri = decodeUri(uri);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            Log.d("result", "" + uri);
            com.theartofdev.edmodo.cropper.CropImage.activity(uri).setGuidelines(CropImageView.Guidelines.ON)
                    .setScaleType(CropImageView.ScaleType.CENTER_INSIDE)
                    .setAspectRatio(1080, 1280).setFixAspectRatio(false)
                    .start(this);

        }
        if (requestCode == com.theartofdev.edmodo.cropper.CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = com.theartofdev.edmodo.cropper.CropImage.getActivityResult(data);
            if (resultCode == -1) {
                Uri resultUri = result.getUri();
                Intent in = new Intent(this, CropImageActivity.class);
                in.putExtra("image_Uri", resultUri.toString());
                startActivity(in);
                getWindow().getDecorView().setSystemUiVisibility(4);
            } else if (resultCode == com.theartofdev.edmodo.cropper.CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                result.getError();
            }
        }
    }


    public Uri decodeUri(Uri uri) throws FileNotFoundException {
        InputStream image_stream = null;
        try {
            image_stream = getContentResolver().openInputStream(uri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        this.bitmap_orignal = BitmapFactory.decodeStream(image_stream);
        int mImageWidth = this.bitmap_orignal.getWidth();
        int mImageHeight = this.bitmap_orignal.getHeight();
        DisplayMetrics metrics1 = getResources().getDisplayMetrics();
        int D_width = metrics1.widthPixels;
        int D_height = metrics1.heightPixels;
        if (mImageWidth < D_width && mImageHeight < D_height) {
            while (true) {
                if (mImageWidth <= D_width || mImageHeight <= D_height) {
                    mImageWidth = (int) (((double) mImageWidth) * 1.2d);
                    mImageHeight = (int) (((double) mImageHeight) * 1.2d);
                } else {
                    this.bitmap_orignal = Bitmap.createScaledBitmap(
                            this.bitmap_orignal, mImageWidth, mImageHeight,
                            false);
                    return saveBitmap(this.bitmap_orignal);
                }
            }
        } else if (mImageWidth < D_width && mImageHeight < D_height) {
            return null;
        } else {
            while (true) {
                if (mImageWidth >= D_width + 240
                        || mImageHeight >= D_height + 400) {
                    mImageWidth = (int) (((double) mImageWidth) * 0.9d);
                    mImageHeight = (int) (((double) mImageHeight) * 0.9d);
                } else {
                    this.bitmap_orignal = Bitmap.createScaledBitmap(
                            this.bitmap_orignal, mImageWidth, mImageHeight,
                            false);
                    return saveBitmap(this.bitmap_orignal);
                }
            }
        }
    }

    public Uri saveBitmap(Bitmap sourceBitmap) {
        ContentValues values;
        Uri savedImageUri;
        Throwable th;
        if (sourceBitmap == null || sourceBitmap.isRecycled()) {
            return null;
        }
        File storagePath = new File(Environment.getExternalStorageDirectory()
                + "/Temp");
        if (!storagePath.exists()) {
            storagePath.mkdirs();
        }
        FileOutputStream out = null;
        int randomNumber = new Random().nextInt();
        File imageFile = new File(storagePath, String.format("%s_%d.png",
                new Object[]{"Temp", Integer.valueOf(randomNumber)}));
        if (imageFile.exists() && imageFile.delete()) {
            try {
                imageFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            FileOutputStream out2 = new FileOutputStream(imageFile);
            try {
                boolean imageSaved = sourceBitmap.compress(Bitmap.CompressFormat.PNG,
                        100, out2);
                if (out2 != null) {
                    out = out2;
                }
            } catch (Exception e2) {
                out = out2;
                if (out != null) {
                }
                values = new ContentValues(3);
                values.put("msg", "Temp");
                values.put("mime_type", "image/jpeg");
                values.put("_data", imageFile.getAbsolutePath());
                savedImageUri = Uri.fromFile(imageFile.getAbsoluteFile());
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                return savedImageUri;
            } catch (Throwable th2) {
                th = th2;
                out = out2;
                if (out == null) {
                    throw th;
                }
                throw th;
            }
        } catch (Exception e3) {
            if (out != null) {
            }
            values = new ContentValues(3);
            values.put("msg", "Temp");
            values.put("mime_type", "image/jpeg");
            values.put("_data", imageFile.getAbsolutePath());
            savedImageUri = Uri.fromFile(imageFile.getAbsoluteFile());
            getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            return savedImageUri;
        } catch (Throwable th3) {
        }
        values = new ContentValues(3);
        values.put("msg", "Temp");
        values.put("mime_type", "image/jpeg");
        values.put("_data", imageFile.getAbsolutePath());
        savedImageUri = Uri.fromFile(imageFile.getAbsoluteFile());
        getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        return savedImageUri;
    }

    @Override
    public void onBackPressed() {
        if (this.ePreferences.getBoolean("pref_key_rate", false)) {
            ExitDialog();
        } else {
            RateDialog();
        }
    }

    private void RateDialog() {
        final boolean[] isRate = {false, false};
        final Dialog dialog = new Dialog(HomeScreen.this);
        final ImageView ivStar1, ivStar2, ivStar3, ivStar4, ivStar5;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        ivStar1 = (ImageView) dialog.findViewById(R.id.ivStar1);
        ivStar2 = (ImageView) dialog.findViewById(R.id.ivStar2);
        ivStar3 = (ImageView) dialog.findViewById(R.id.ivStar3);
        ivStar4 = (ImageView) dialog.findViewById(R.id.ivStar4);
        ivStar5 = (ImageView) dialog.findViewById(R.id.ivStar5);
        ivStar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_empty);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_empty);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_empty);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = false;
                isRate[1] = true;
                return false;
            }
        });
        ivStar4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_empty);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        ivStar5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                ivStar1.setImageResource(R.drawable.star_fill);
                ivStar2.setImageResource(R.drawable.star_fill);
                ivStar3.setImageResource(R.drawable.star_fill);
                ivStar4.setImageResource(R.drawable.star_fill);
                ivStar5.setImageResource(R.drawable.star_fill);
                isRate[0] = true;
                isRate[1] = true;
                return false;
            }
        });
        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                System.exit(0);
            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRate[1]) {
                    dialog.dismiss();
                    if (isRate[0]) {
                        final SharedPreferences.Editor edit = ePreferences.edit();
                        edit.putBoolean("pref_key_rate", true);
                        edit.apply();
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.esc/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        } catch (ActivityNotFoundException anfe) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Thank You!", Toast.LENGTH_SHORT).show();
                    }
                    System.exit(0);
                } else {
                    Toast.makeText(getApplicationContext(), "Please Select Your Review Star", Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.show();
    }

    private InterstitialAd interstitial;
    private int id;
    private KProgressHUD hud;

    public void ExitDialog() {
        final Dialog dialog = new Dialog(HomeScreen.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setWindowAnimations(R.style.PauseDialogAnimation1);
        dialog.setContentView(R.layout.dialog_layout_exit);
        dialog.setCanceledOnTouchOutside(false);
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = dialog.findViewById(R.id.fl_adplaceholder);
                dialog.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());

        dialog.findViewById(R.id.btnLater).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        dialog.show();
    }

    public void loadAd() {
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(HomeScreen.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.btnStart:
                        openGallery();
                        break;
                    case R.id.btnmycreation:
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (!hasPermissions(HomeScreen.this, PERMISSIONS)) {
                                ActivityCompat.requestPermissions(HomeScreen.this, PERMISSIONS,
                                        2);
                            } else {
                                Intent i = new Intent(HomeScreen.this, StudioActivity.class);
                                startActivity(i);
                            }
                        } else {
                            Intent i = new Intent(HomeScreen.this, StudioActivity.class);
                            startActivity(i);
                        }
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());

        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(HomeScreen.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    protected void onDestroy() {
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        super.onDestroy();
    }
}
