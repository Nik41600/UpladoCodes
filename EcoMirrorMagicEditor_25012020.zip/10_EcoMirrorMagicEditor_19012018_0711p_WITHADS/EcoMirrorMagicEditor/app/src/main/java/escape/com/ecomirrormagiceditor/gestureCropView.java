package escape.com.ecomirrormagiceditor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.Point;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class gestureCropView extends View implements View.OnTouchListener {
    static Bitmap bitmap;
    public static List<Point> list_point;
    int point;
    int point1;
    int value;
    int height;
    int width;
    boolean button;
    boolean b_firstpoint;
    int canvasHeight;
    int canvasWidth;
    boolean b_PathDraw;
    Bitmap bitmapimg;
    int img_height;
    int img_width;
    ViewGroup.LayoutParams layoutParams;
    Context context;
    private ScaleGestureDetector scaleDetector;
    private float scale;
    Point firstpoint;
    Point lastpoint;
    private Paint paint;
    Paint color;

    public gestureCropView(final Context mContext, final Bitmap bitmap) {
        super(mContext);
        this.value = 2;
        this.b_PathDraw = true;
        this.scale = 1.0f;
        this.firstpoint = null;
        this.b_firstpoint = false;
        this.lastpoint = null;
        this.color = new Paint();
        this.button = false;
        gestureCropView.bitmap = bitmap;
        this.img_width = gestureCropView.bitmap.getWidth();
        this.img_height = gestureCropView.bitmap.getHeight();
        System.out.println("img_width" + this.img_width + "img_height"
                + this.img_height);
        final DisplayMetrics displayMetrics = this.getResources()
                .getDisplayMetrics();
        this.width = displayMetrics.widthPixels;
        this.height = displayMetrics.heightPixels;
        if (this.img_width <= this.width) {
            this.point1 = this.width - this.img_width;
        }
        if (this.img_height <= this.height) {
            this.point = this.height - this.img_height;
        }
        this.context = mContext;
        this.setFocusable(true);
        this.setFocusableInTouchMode(true);
        (this.paint = new Paint(1)).setStyle(Paint.Style.STROKE);
        this.paint.setPathEffect((PathEffect) new DashPathEffect(new float[]{
                10.0f, 20.0f}, 5.0f));
        this.paint.setStrokeWidth(5.0f);
        this.paint.setColor(-1);
        if (Build.VERSION.SDK_INT >= 11) {
            this.setLayerType(1, this.paint);
        }
        this.paint.setShadowLayer(5.5f, 6.0f, 6.0f, Integer.MIN_VALUE);
        this.layoutParams = new ViewGroup.LayoutParams(
                gestureCropView.bitmap.getWidth(), gestureCropView.bitmap.getHeight());
        this.setOnTouchListener((OnTouchListener) this);
        gestureCropView.list_point = new ArrayList<Point>();
        this.b_firstpoint = false;
        this.scaleDetector = new ScaleGestureDetector(mContext, (ScaleGestureDetector.OnScaleGestureListener) new ScaleListener());
    }

    public gestureCropView(final Context mContext, final AttributeSet set) {
        super(mContext, set);
        this.value = 2;
        this.b_PathDraw = true;
        this.scale = 1.0f;
        this.firstpoint = null;
        this.b_firstpoint = false;
        this.lastpoint = null;
        this.color = new Paint();
        this.button = false;
        this.context = mContext;
        this.setFocusable(true);
        this.setFocusableInTouchMode(true);
        (this.paint = new Paint(1)).setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(2.0f);
        this.setOnTouchListener((OnTouchListener) this);
        gestureCropView.list_point = new ArrayList<Point>();
        this.b_firstpoint = false;
    }

    public static boolean GetValue() {
        return true;
    }

    private boolean comparepoint(final Point point, final Point point2) {
        final int x = point2.x;
        final int y = point2.y;
        final int x2 = point2.x;
        final int y2 = point2.y;
        return x - 3 < point.x && point.x < x2 + 3 && y - 3 < point.y
                && point.y < y2 + 3 && gestureCropView.list_point.size() >= 10;
    }

    public void fillinPartofPath() {
        final Point point = new Point();
        point.x = gestureCropView.list_point.get(0).x;
        point.y = gestureCropView.list_point.get(0).y;
        gestureCropView.list_point.add(point);
        this.invalidate();
    }

    public boolean getBooleanValue() {
        return this.button;
    }

    public void onDraw(final Canvas canvas) {
        canvas.scale(this.scale, this.scale);
        canvas.drawBitmap(gestureCropView.bitmap, 0.0f, 0.0f, (Paint) null);
        final Path path = new Path();
        int n = 1;
        for (int i = 0; i < gestureCropView.list_point.size(); i += 2) {
            final Point point = gestureCropView.list_point.get(i);
            if (n != 0) {
                n = 0;
                path.moveTo((float) point.x, (float) point.y);
            } else if (i < gestureCropView.list_point.size() - 1) {
                final Point point2 = gestureCropView.list_point.get(i + 1);
                path.quadTo((float) point.x, (float) point.y, (float) point2.x,
                        (float) point2.y);
            } else {
                this.lastpoint = gestureCropView.list_point.get(i);
                path.lineTo((float) point.x, (float) point.y);
            }
        }
        canvas.drawPath(path, this.paint);
    }

    public boolean onTouch(final View view, final MotionEvent motionEvent) {
        final Point point = new Point();
        point.x = (int) motionEvent.getX();
        point.y = (int) motionEvent.getY();
        if (this.b_PathDraw) {
            if (this.b_firstpoint) {
                if (this.comparepoint(this.firstpoint, point)) {
                    gestureCropView.list_point.add(this.firstpoint);
                    this.b_PathDraw = false;
                    GetValue();
                } else if (point.x <= this.img_width
                        && point.y <= this.img_height) {
                    gestureCropView.list_point.add(point);
                }
            } else if (point.x <= this.img_width && point.y <= this.img_height) {
                gestureCropView.list_point.add(point);
            }
            if (!this.b_firstpoint) {
                this.firstpoint = point;
                this.b_firstpoint = true;
            }
        } else {
            this.scaleDetector.onTouchEvent(motionEvent);
        }
        this.invalidate();
        Log.e("Hi  ==>", "Size: " + point.x + " " + point.y);
        if (motionEvent.getAction() == 1) {
            this.lastpoint = point;
            if (this.b_PathDraw && gestureCropView.list_point.size() > 12
                    && !this.comparepoint(this.firstpoint, this.lastpoint)) {
                this.b_PathDraw = false;
                gestureCropView.list_point.add(this.firstpoint);
                GetValue();
            }
        }
        return true;
    }

    private class ScaleListener extends
            ScaleGestureDetector.SimpleOnScaleGestureListener {
        public boolean onScale(final ScaleGestureDetector scaleGestureDetector) {
            gestureCropView.this.scale *= scaleGestureDetector
                    .getScaleFactor();
            gestureCropView.this.scale = Math.max(0.1f,
                    Math.min(gestureCropView.this.scale, 5.0f));
            gestureCropView.this.invalidate();
            return true;
        }
    }
}
