package escape.com.ecomirrormagiceditor.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import escape.com.ecomirrormagiceditor.R;
import escape.com.ecomirrormagiceditor.Utils.Utils;
import escape.com.ecomirrormagiceditor.kprogresshud.KProgressHUD;

public class ShareActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView ivMainImage;
    private ImageView ivHome;
    private ImageView ivBack;
    private ImageView ivShare;
    private ImageView ivFacebook;
    private ImageView ivInstagram;
    private ImageView ivWhatsapp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_share);
        bindview();
        loadAd();
    }

    private void bindview() {
        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        this.ivBack.setOnClickListener(this);
        if (Build.VERSION.SDK_INT >= 21) {
            this.ivMainImage = (ImageView) findViewById(R.id.finalimg);
            findViewById(R.id.simpleFrame).setVisibility(View.GONE);
            findViewById(R.id.roundFrame).setVisibility(View.VISIBLE);
        } else {
            this.ivMainImage = (ImageView) findViewById(R.id.ivMainImageView);
            findViewById(R.id.roundFrame).setVisibility(View.GONE);
            findViewById(R.id.simpleFrame).setVisibility(View.VISIBLE);
        }
        Glide.with((Activity) this).load(ImageEditingActivity.uriShare).into(this.ivMainImage);
        this.ivHome = (ImageView) findViewById(R.id.ivhome);
        this.ivHome.setOnClickListener(this);
        this.ivWhatsapp = (ImageView) findViewById(R.id.ivWhatsapp);
        this.ivWhatsapp.setOnClickListener(this);
        this.ivInstagram = (ImageView) findViewById(R.id.ivInstagram);
        this.ivInstagram.setOnClickListener(this);
        this.ivFacebook = (ImageView) findViewById(R.id.ivFacebook);
        this.ivFacebook.setOnClickListener(this);
        this.ivShare = (ImageView) findViewById(R.id.ivShare);
        this.ivShare.setOnClickListener(this);
    }

    @SuppressLint("WrongConstant")
    public void onClick(View view) {
        Intent shareIntent = new Intent("android.intent.action.SEND");
        shareIntent.setType("image/*");
        shareIntent.putExtra("android.intent.extra.TEXT", getString(R.string.app_name)
                + " Created By : " + Utils.app_link);
        shareIntent.putExtra("android.intent.extra.STREAM",
                ImageEditingActivity.uriShare);
        switch (view.getId()) {
            case R.id.ivhome:
                id = R.id.ivhome;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent = new Intent(this, HomeScreen.class);
                    intent.setFlags(268468224);
                    intent.putExtra("ToHome", true);
                    startActivity(intent);
                    finish();
                }
                return;
            case R.id.ivBackbtn:
                id = R.id.ivBackbtn;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent1 = new Intent(this, StudioActivity.class);
                    intent1.setFlags(268468224);
                    intent1.putExtra("ToHome", true);
                    startActivity(intent1);
                }
                return;
            case R.id.ivWhatsapp:
                try {
                    shareIntent.setPackage("com.whatsapp");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e) {
                    Toast.makeText(this, "WhatsApp doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.ivFacebook:
                try {
                    shareIntent.setPackage("com.facebook.katana");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e2) {
                    Toast.makeText(this, "Facebook doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.ivInstagram:
                try {
                    shareIntent.setPackage("com.instagram.android");
                    startActivity(shareIntent);
                    return;
                } catch (Exception e3) {
                    Toast.makeText(this, "Instagram doesn't installed", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.ivShare:
                Intent sharingIntent = new Intent("android.intent.action.SEND");
                sharingIntent.setType("image/*");
                sharingIntent.putExtra("android.intent.extra.TEXT", getString(R.string.app_name)
                        + " Create By : " + Utils.app_link);
                sharingIntent.putExtra("android.intent.extra.STREAM", ImageEditingActivity.uriShare);
                startActivity(Intent.createChooser(sharingIntent,
                        "Share Image using"));
                return;
            default:
                return;
        }
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onBackPressed() {
        Intent intent1 = new Intent(this, StudioActivity.class);
        intent1.setFlags(268468224);
        intent1.putExtra("ToHome", true);
        startActivity(intent1);
    }

    private InterstitialAd interstitial;
    private int id;
    private KProgressHUD hud;
    private AdView adView;

    private void loadAd()
    {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(ShareActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ivhome:
                        Intent intent = new Intent(ShareActivity.this, HomeScreen.class);
                        intent.setFlags(268468224);
                        intent.putExtra("ToHome", true);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.ivBack:
                        Intent intent1 = new Intent(ShareActivity.this, StudioActivity.class);
                        intent1.setFlags(268468224);
                        intent1.putExtra("ToHome", true);
                        startActivity(intent1);
                        break;
                }
                requestNewInterstitial();
            }
            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ShareActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
