package escape.com.ecomirrormagiceditor.Utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;


import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import escape.com.ecomirrormagiceditor.Activity.BrushEditingActivity;

public class ImageScale extends View implements View.OnTouchListener {
	public static final int DEFAULT_SCALE_FIT_INSIDE = 0;
	static final int DRAG = 1;
	static final int NONE = 0;
	static final int ZOOM = 2;
	int intPath;
	int intRemovePath;
	Bitmap bitmap_second;
	int maximumImgSize;
	Bitmap bitmap_transparent;
	Paint Paintbackground;
	int intBrushSize;
	Paint Paintcircle;
	Rect clipB;
	private ArrayList<Paint> list_colorPath;
	public ArrayList<Paint> list_color;
	private int container_height;
	private int container_width;
	float cX;
	float cY;
	float cscale;
	private int scale_default;
	private Canvas canvas;
	public Paint paint;
	private Path path;
	private GestureDetector gestureDetector;
	Bitmap bitmap_image;
	int image_height;
	int image_width;
	private Bitmap imgBitmap;
	boolean animating;
	boolean zoomeImage;
	private Handler handler;
	private Runnable update_imagePosition;
	private Runnable update_imagescale;
	Matrix matrix;
	float maximimScale;
	PointF point_mid;
	float min_scale;
	int mode;
	float[] f_mv;
	float f;
	float height_new;
	float width_new;
	float oldDist;
	public ArrayList<Path> list_paths;
	float float_resize;
	Matrix Matrix_save;
	float s_change;
	float dencity_screen;
	PointF point_start;
	float tRatio;
	float tScale;
	float tScaleX;
	float tScaleY;
	float tX;
	float tY;
	private ArrayList<Path> list_undonePaths;

	public ImageScale(final Context context, final Bitmap image) {
		super(context);
		this.intPath = 0;
		this.intRemovePath = 0;
		this.intBrushSize = 30;
		this.imgBitmap = null;
		this.f_mv = new float[9];
		this.matrix = new Matrix();
		this.Matrix_save = new Matrix();
		this.point_start = new PointF();
		this.zoomeImage = false;
		this.mode = 0;
		this.animating = false;
		this.oldDist = 1.0f;
		this.point_mid = new PointF();
		this.handler = new Handler();
		this.min_scale = 0.4f;
		this.maximimScale = 8.0f;
		this.float_resize = 1.0f;
		this.list_paths = new ArrayList<Path>();
		this.list_color = new ArrayList<Paint>();
		this.list_undonePaths = new ArrayList<Path>();
		this.list_colorPath = new ArrayList<Paint>();
		this.update_imagePosition = new Runnable() {
			@Override
			public void run() {
				if (Math.abs(ImageScale.this.tX
						- ImageScale.this.cX) < 5.0f
						&& Math.abs(ImageScale.this.tY
								- ImageScale.this.cY) < 5.0f) {
					ImageScale.this.animating = false;
					ImageScale.this.handler
							.removeCallbacks(ImageScale.this.update_imagePosition);
					final float[] array = new float[9];
					ImageScale.this.matrix.getValues(array);
					ImageScale.this.cscale = array[0];
					ImageScale.this.cX = array[2];
					ImageScale.this.cY = array[5];
					ImageScale.this.matrix.postTranslate(
							ImageScale.this.tX
									- ImageScale.this.cX,
							ImageScale.this.tY
									- ImageScale.this.cY);
				} else {
					ImageScale.this.animating = true;
					final float[] array2 = new float[9];
					ImageScale.this.matrix.getValues(array2);
					ImageScale.this.cscale = array2[0];
					ImageScale.this.cX = array2[2];
					ImageScale.this.cY = array2[5];
					ImageScale.this.matrix
							.postTranslate(
									(ImageScale.this.tX - ImageScale.this.cX) * 0.3f,
									(ImageScale.this.tY - ImageScale.this.cY) * 0.3f);
					ImageScale.this.handler.postDelayed((Runnable) this,
							25L);
				}
				ImageScale.this.invalidate();
				System.out.println("Entered update_imagePosition");
			}
		};
		this.update_imagescale = new Runnable() {
			@Override
			public void run() {
				final float n = ImageScale.this.tScale
						/ ImageScale.this.cscale;
				if (Math.abs(n - 1.0f) > 0.05) {
					ImageScale.this.animating = true;
					if (ImageScale.this.tScale > ImageScale.this.cscale) {
						ImageScale.this.s_change = 0.2f * (n - 1.0f) + 1.0f;
						final ImageScale this$0 = ImageScale.this;
						this$0.cscale *= ImageScale.this.s_change;
						if (ImageScale.this.cscale > ImageScale.this.tScale) {
							ImageScale.this.cscale /= ImageScale.this.s_change;
							ImageScale.this.s_change = 1.0f;
						}
					} else {
						ImageScale.this.s_change = 1.0f - 0.5f * (1.0f - n);
						final ImageScale this$2 = ImageScale.this;
						this$2.cscale *= ImageScale.this.s_change;
						if (ImageScale.this.cscale < ImageScale.this.tScale) {
							ImageScale.this.cscale /= ImageScale.this.s_change;
							ImageScale.this.s_change = 1.0f;
						}
					}
					if (ImageScale.this.s_change != 1.0f) {
						ImageScale.this.matrix.postScale(
								ImageScale.this.s_change,
								ImageScale.this.s_change,
								ImageScale.this.tScaleX,
								ImageScale.this.tScaleY);
						ImageScale.this.handler.postDelayed(
								ImageScale.this.update_imagescale, 15L);
						ImageScale.this.invalidate();
					} else {
						ImageScale.this.animating = false;
						ImageScale.this.s_change = 1.0f;
						ImageScale.this.matrix.postScale(
								ImageScale.this.tScale
										/ ImageScale.this.cscale,
								ImageScale.this.tScale
										/ ImageScale.this.cscale,
								ImageScale.this.tScaleX,
								ImageScale.this.tScaleY);
						ImageScale.this.cscale = ImageScale.this.tScale;
						ImageScale.this.handler
								.removeCallbacks(ImageScale.this.update_imagescale);
						ImageScale.this.invalidate();
						ImageScale.this.checkImageConstraints();
					}
				} else {
					ImageScale.this.animating = false;
					ImageScale.this.s_change = 1.0f;
					ImageScale.this.matrix.postScale(
							ImageScale.this.tScale
									/ ImageScale.this.cscale,
							ImageScale.this.tScale
									/ ImageScale.this.cscale,
							ImageScale.this.tScaleX,
							ImageScale.this.tScaleY);
					ImageScale.this.cscale = ImageScale.this.tScale;
					ImageScale.this.handler
							.removeCallbacks(ImageScale.this.update_imagescale);
					ImageScale.this.invalidate();
					ImageScale.this.checkImageConstraints();
				}
				System.out.println("Entered update_imagescale");
			}
		};
		this.setFocusable(true);
		this.setFocusableInTouchMode(true);
		this.setOnTouchListener((OnTouchListener) this);
		this.setBackgroundColor(0);
		this.bitmap_image = image;
		this.image_width = this.bitmap_image.getWidth();
		this.image_height = this.bitmap_image.getHeight();
		final DisplayMetrics displayMetrics = context.getResources()
				.getDisplayMetrics();
		final int widthPixels = displayMetrics.widthPixels;
		final int heightPixels = displayMetrics.heightPixels;
		this.bitmap_transparent = Bitmap.createBitmap(widthPixels, heightPixels,
				Bitmap.Config.ARGB_8888);
		(this.canvas = new Canvas(Bitmap.createBitmap(widthPixels,
				heightPixels, Bitmap.Config.ARGB_4444))).drawColor(0,
				PorterDuff.Mode.CLEAR);
		this.canvas.drawBitmap(this.bitmap_image, this.matrix, this.Paintbackground);
		this.path = new Path();
		(this.paint = new Paint()).setColor(0);
		this.paint.setAntiAlias(true);
		this.paint.setStrokeWidth((float) this.intBrushSize);
		this.paint.setAlpha(0);
		this.paint.setStyle(Paint.Style.STROKE);
		this.paint.setStrokeJoin(Paint.Join.ROUND);
		this.paint.setStrokeCap(Paint.Cap.ROUND);
		this.paint.setXfermode((Xfermode) new PorterDuffXfermode(
				PorterDuff.Mode.CLEAR));
		System.out
				.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% :-- "
						+ this.bitmap_image);
		this.setFocusable(true);
		this.setFocusableInTouchMode(true);
		this.dencity_screen = context.getResources().getDisplayMetrics().density;
		this.initPaints();
		this.gestureDetector = new GestureDetector(context,
				(GestureDetector.OnGestureListener) new MyGestureDetector());
		this.setDrawingCacheEnabled(true);
	}

	public ImageScale(final Context context, final AttributeSet set) {
		super(context, set);
		this.intPath = 0;
		this.intRemovePath = 0;
		this.intBrushSize = 30;
		this.imgBitmap = null;
		this.f_mv = new float[9];
		this.matrix = new Matrix();
		this.Matrix_save = new Matrix();
		this.point_start = new PointF();
		this.zoomeImage = false;
		this.mode = 0;
		this.animating = false;
		this.oldDist = 1.0f;
		this.point_mid = new PointF();
		this.handler = new Handler();
		this.min_scale = 0.4f;
		this.maximimScale = 8.0f;
		this.float_resize = 1.0f;
		this.list_paths = new ArrayList<Path>();
		this.list_color = new ArrayList<Paint>();
		this.list_undonePaths = new ArrayList<Path>();
		this.list_colorPath = new ArrayList<Paint>();
		this.update_imagePosition = new Runnable() {
			@Override
			public void run() {
				if (Math.abs(ImageScale.this.tX
						- ImageScale.this.cX) < 5.0f
						&& Math.abs(ImageScale.this.tY
								- ImageScale.this.cY) < 5.0f) {
					ImageScale.this.animating = false;
					ImageScale.this.handler
							.removeCallbacks(ImageScale.this.update_imagePosition);
					final float[] array = new float[9];
					ImageScale.this.matrix.getValues(array);
					ImageScale.this.cscale = array[0];
					ImageScale.this.cX = array[2];
					ImageScale.this.cY = array[5];
					ImageScale.this.matrix.postTranslate(
							ImageScale.this.tX
									- ImageScale.this.cX,
							ImageScale.this.tY
									- ImageScale.this.cY);
				} else {
					ImageScale.this.animating = true;
					final float[] array2 = new float[9];
					ImageScale.this.matrix.getValues(array2);
					ImageScale.this.cscale = array2[0];
					ImageScale.this.cX = array2[2];
					ImageScale.this.cY = array2[5];
					ImageScale.this.matrix
							.postTranslate(
									(ImageScale.this.tX - ImageScale.this.cX) * 0.3f,
									(ImageScale.this.tY - ImageScale.this.cY) * 0.3f);
					ImageScale.this.handler.postDelayed((Runnable) this,
							25L);
				}
				ImageScale.this.invalidate();
				System.out.println("Entered update_imagePosition");
			}
		};
		this.update_imagescale = new Runnable() {
			@Override
			public void run() {
				final float n = ImageScale.this.tScale
						/ ImageScale.this.cscale;
				if (Math.abs(n - 1.0f) > 0.05) {
					ImageScale.this.animating = true;
					if (ImageScale.this.tScale > ImageScale.this.cscale) {
						ImageScale.this.s_change = 0.2f * (n - 1.0f) + 1.0f;
						final ImageScale this$0 = ImageScale.this;
						this$0.cscale *= ImageScale.this.s_change;
						if (ImageScale.this.cscale > ImageScale.this.tScale) {
							ImageScale.this.cscale /= ImageScale.this.s_change;
							ImageScale.this.s_change = 1.0f;
						}
					} else {
						ImageScale.this.s_change = 1.0f - 0.5f * (1.0f - n);
						final ImageScale this$2 = ImageScale.this;
						this$2.cscale *= ImageScale.this.s_change;
						if (ImageScale.this.cscale < ImageScale.this.tScale) {
							ImageScale.this.cscale /= ImageScale.this.s_change;
							ImageScale.this.s_change = 1.0f;
						}
					}
					if (ImageScale.this.s_change != 1.0f) {
						ImageScale.this.matrix.postScale(
								ImageScale.this.s_change,
								ImageScale.this.s_change,
								ImageScale.this.tScaleX,
								ImageScale.this.tScaleY);
						ImageScale.this.handler.postDelayed(
								ImageScale.this.update_imagescale, 15L);
						ImageScale.this.invalidate();
					} else {
						ImageScale.this.animating = false;
						ImageScale.this.s_change = 1.0f;
						ImageScale.this.matrix.postScale(
								ImageScale.this.tScale
										/ ImageScale.this.cscale,
								ImageScale.this.tScale
										/ ImageScale.this.cscale,
								ImageScale.this.tScaleX,
								ImageScale.this.tScaleY);
						ImageScale.this.cscale = ImageScale.this.tScale;
						ImageScale.this.handler
								.removeCallbacks(ImageScale.this.update_imagescale);
						ImageScale.this.invalidate();
						ImageScale.this.checkImageConstraints();
					}
				} else {
					ImageScale.this.animating = false;
					ImageScale.this.s_change = 1.0f;
					ImageScale.this.matrix.postScale(
							ImageScale.this.tScale
									/ ImageScale.this.cscale,
							ImageScale.this.tScale
									/ ImageScale.this.cscale,
							ImageScale.this.tScaleX,
							ImageScale.this.tScaleY);
					ImageScale.this.cscale = ImageScale.this.tScale;
					ImageScale.this.handler
							.removeCallbacks(ImageScale.this.update_imagescale);
					ImageScale.this.invalidate();
					ImageScale.this.checkImageConstraints();
				}
				System.out.println("Entered update_imagescale");
			}
		};
		this.dencity_screen = context.getResources().getDisplayMetrics().density;
		this.initPaints();
		this.gestureDetector = new GestureDetector(context,
				(GestureDetector.OnGestureListener) new MyGestureDetector());
		this.scale_default = 0;
		this.setUpDrawing();
		this.setDrawingCacheEnabled(true);
	}

	private void checkImageConstraints() {
		if (this.imgBitmap == null) {
			return;
		}
		final float[] array = new float[9];
		this.matrix.getValues(array);
		this.cscale = array[0];
		if (this.cscale < this.min_scale) {
			final float n = this.min_scale / this.cscale;
			this.matrix.postScale(n, n, (float) (this.container_width / 2),
					(float) (this.container_height / 2));
			this.invalidate();
		}
		this.matrix.getValues(array);
		this.cscale = array[0];
		this.cX = array[2];
		this.cY = array[5];
		final int n2 = this.container_width
				- (int) (this.imgBitmap.getWidth() * this.cscale);
		final int n3 = this.container_height
				- (int) (this.imgBitmap.getHeight() * this.cscale);
		boolean b = false;
		boolean b2 = false;
		if (n2 < 0) {
			if (this.cX > 0.0f) {
				this.tX = 0.0f;
				b = true;
			} else if (this.cX < n2) {
				this.tX = n2;
				b = true;
			}
		} else {
			this.tX = n2 / 2;
			b = true;
		}
		if (n3 < 0) {
			if (this.cY > 0.0f) {
				this.tY = 0.0f;
				b2 = true;
			} else if (this.cY < n3) {
				this.tY = n3;
				b2 = true;
			}
		} else {
			this.tY = n3 / 2;
			b2 = true;
		}
		if (b || b2) {
			if (!b2) {
				this.tY = this.cY;
			}
			if (!b) {
				this.tX = this.cX;
			}
			this.animating = true;
			this.handler.removeCallbacks(this.update_imagePosition);
			this.handler.postDelayed(this.update_imagePosition, 100L);
		}
		System.out.println("Entered checkImageConstraints");
	}

	private void initPaints() {
		this.Paintbackground = new Paint();
		this.setUpDrawing();
	}

	private void midPoint(final PointF pointF, final MotionEvent motionEvent) {
		pointF.set((motionEvent.getX(0) + motionEvent.getX(1)) / 2.0f,
				(motionEvent.getY(0) + motionEvent.getY(1)) / 2.0f);
	}

	private float spacing(final MotionEvent motionEvent) {
		final float n = motionEvent.getX(0) - motionEvent.getX(1);
		final float n2 = motionEvent.getY(0) - motionEvent.getY(1);
		System.out.println("spacing x :---- " + n + "  spacing y :---- " + n2);
		return (float) Math.sqrt(n * n + n2 * n2);
	}

	public void ResizeBitmap() {
		this.s_change = 1.0f;
		if (Math.abs(this.cscale) > this.float_resize) {
			this.tScale = this.float_resize;
		} else {
			this.tScale = this.float_resize;
		}
		this.tRatio = this.tScale / this.cscale;
		this.handler.removeCallbacks(this.update_imagescale);
		this.handler.post(this.update_imagescale);
	}

	public Bitmap getBitmap_second() {
		if (!this.zoomeImage) {
		}
		final float[] array = new float[9];
		this.matrix.getValues(array);
		final float n = array[2];
		final float n2 = array[5];
		final float n3 = array[0] * this.bitmap_image.getWidth();
		final float n4 = array[4] * this.bitmap_image.getHeight();
		this.matrix.postTranslate(-n, -n2);
		System.out.println("Global x :" + n + "Global y :" + n2
				+ "@@@@@@Width:" + n3 + "@@@@@@Height:" + n4 + "x---"
				+ 16842924 + "y--" + 16842925);
		this.invalidate();
		this.bitmap_second = Bitmap.createBitmap((int) n3, (int) n4,
				Bitmap.Config.ARGB_8888);
		this.draw(new Canvas(this.bitmap_second));
		this.matrix.postTranslate(n, n2);
		final File file = new File(Environment.getExternalStorageDirectory()
				+ "/Temp");
		try {
			this.bitmap_second.compress(Bitmap.CompressFormat.PNG, 100,
					(OutputStream) new FileOutputStream(file));
			return this.bitmap_second;
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		final Bitmap bitmap = Bitmap.createBitmap(this.bitmap_image.getWidth(),
				this.bitmap_image.getHeight(), Bitmap.Config.ARGB_8888);
		this.draw(new Canvas(bitmap));
		final File file2 = new File(Environment.getExternalStorageDirectory()
				+ "/Temp");
		try {
			bitmap.compress(Bitmap.CompressFormat.PNG, 100,
					(OutputStream) new FileOutputStream(file2));
		} catch (Exception ex2) {
			ex2.printStackTrace();
		}
		return bitmap_second;

	}

	protected void onDraw(final Canvas canvas) {
		super.onDraw(canvas);
		canvas.save();
		if (this.bitmap_image != null && canvas != null) {
			if (this.canvas == null) {
				this.canvas = new Canvas(this.bitmap_image);
			}
			this.canvas.drawColor(-5592406);
			this.clipB = canvas.getClipBounds();
			canvas.drawBitmap(this.bitmap_image, this.matrix, this.Paintbackground);
			canvas.concat(this.matrix);
			for (int i = 0; i < this.list_color.size(); ++i) {
				canvas.drawPath((Path) this.list_paths.get(i),
						(Paint) this.list_color.get(i));
			}
			canvas.drawPath(this.path, this.paint);
			this.canvas.drawColor(-65536);
		}
		canvas.restore();
		this.invalidate();
	}

	protected void onSizeChanged(int containerWidth, int containerHeight,
			int n, int n2) {
		super.onSizeChanged(containerWidth, containerHeight, n, n2);
		this.container_width = containerWidth;
		this.container_height = containerHeight;
		if (this.imgBitmap != null) {
			this.canvas = new Canvas(this.imgBitmap);
			final int height = this.imgBitmap.getHeight();
			final int width = this.imgBitmap.getWidth();
			n = 0;
			containerWidth = 0;
			n2 = 0;
			containerHeight = 0;
			if (this.scale_default == 0) {
				float n3;
				if (width > this.container_width) {
					n3 = this.container_width / width;
					containerHeight = (this.container_height - (int) (height * n3)) / 2;
					this.matrix.setScale(n3, n3);
					this.matrix.postTranslate(0.0f, (float) containerHeight);
				} else {
					n3 = this.container_height / height;
					containerWidth = (this.container_width - (int) (width * n3)) / 2;
					this.matrix.setScale(n3, n3);
					this.matrix.postTranslate((float) containerWidth, 0.0f);
				}
				this.cX = containerWidth;
				this.cY = containerHeight;
				this.cscale = n3;
				this.min_scale = n3;
			} else {
				if (width > this.container_width) {
					containerHeight = (this.container_height - height) / 2;
					this.matrix.postTranslate(0.0f, (float) containerHeight);
					containerWidth = n;
				} else {
					containerWidth = (this.container_width - width) / 2;
					this.matrix.postTranslate((float) containerWidth, 0.0f);
					containerHeight = n2;
				}
				this.cX = containerWidth;
				this.cY = containerHeight;
				this.cscale = 1.0f;
				this.min_scale = 1.0f;
			}
			this.invalidate();
			System.out.println("Entered onSizeChanged");
		}
	}

	public boolean onTouch(final View view, final MotionEvent motionEvent) {
		return false;
	}

	public boolean onTouchEvent(final MotionEvent motionEvent) {
		this.paint.setStrokeWidth((float) this.intBrushSize);
		this.matrix.getValues(this.f_mv);
		final float n = motionEvent.getX() * (1.0f / this.f_mv[4]) - this.f_mv[2]
				/ this.f_mv[4];
		final float n2 = motionEvent.getY() * (1.0f / this.f_mv[4]) - this.f_mv[5]
				/ this.f_mv[4];
		if (BrushEditingActivity.bFlag) {
			if (this.gestureDetector.onTouchEvent(motionEvent)) {
				return true;
			}
			if (this.animating) {
				return true;
			}
			this.zoomeImage = true;
			final float[] array = new float[9];
			switch (motionEvent.getAction() & 0xFF) {
			case 0: {
				if (!this.animating) {
					this.Matrix_save.set(this.matrix);
					this.point_start.set(motionEvent.getX(), motionEvent.getY());
					this.mode = 1;
					break;
				}
				break;
			}
			case 5: {
				this.oldDist = this.spacing(motionEvent);
				if (this.oldDist > 10.0f) {
					this.Matrix_save.set(this.matrix);
					this.midPoint(this.point_mid, motionEvent);
					this.mode = 2;
					break;
				}
				break;
			}
			case 1:
			case 6: {
				this.mode = 0;
				this.matrix.getValues(array);
				this.cX = array[2];
				this.cY = array[5];
				this.cscale = array[0];
				if (!this.animating) {
					this.checkImageConstraints();
					break;
				}
				break;
			}
			case 2: {
				if (this.mode == 1 && !this.animating) {
					this.matrix.set(this.Matrix_save);
					this.matrix.postTranslate(
							motionEvent.getX() - this.point_start.x,
							motionEvent.getY() - this.point_start.y);
					this.matrix.getValues(array);
					this.cX = array[2];
					this.cY = array[5];
					this.cscale = array[0];
					System.out.println(" cX :---- " + this.cX
							+ " cY :---- " + this.cY);
					System.out.println("Entered DRAG");
					break;
				}
				if (this.mode != 2 || this.animating) {
					break;
				}
				this.f = this.spacing(motionEvent);
				if (this.f > 10.0f) {
					this.matrix.set(this.Matrix_save);
					final float n3 = this.f / this.oldDist;
					this.matrix.getValues(array);
					this.cscale = array[0];
					if (this.cscale * n3 <= this.min_scale) {
						this.matrix.postScale(
								this.min_scale / this.cscale,
								this.min_scale / this.cscale, this.point_mid.x,
								this.point_mid.y);
					} else if (this.cscale * n3 >= this.maximimScale) {
						this.matrix.postScale(
								this.maximimScale / this.cscale,
								this.maximimScale / this.cscale, this.point_mid.x,
								this.point_mid.y);
					} else {
						this.matrix.postScale(n3, n3, this.point_mid.x, this.point_mid.y);
					}
					this.matrix.getValues(array);
					this.cX = array[2];
					this.cY = array[5];
					this.cscale = array[0];
					System.out.println(" Zoom_curX :---- " + this.cX
							+ " Zoom_curY :---- " + this.cY);
					System.out.println(" point_mid.x :---- " + this.point_mid.x
							+ "  point_mid.y :---- " + this.point_mid.y);
					this.width_new = this.cX - this.point_mid.x;
					this.height_new = this.cY - this.point_mid.y;
					System.out.println("width_new" + this.width_new * 2.0f
							+ "height_new" + this.height_new * 2.0f);
					break;
				}
				break;
			}
			}
		} else {
			switch (motionEvent.getAction()) {
			default: {
				return false;
			}
			case 0: {
				this.path.moveTo(n, n2);
				break;
			}
			case 2: {
				this.path.lineTo(n, n2);
				break;
			}
			case 1: {
				final Paint paint = new Paint();
				paint.set(this.paint);
				this.list_color.add(paint);
				this.list_paths.add(this.path);
				this.path = new Path();
				this.intPath = this.list_paths.size();
				this.path.reset();
				break;
			}
			case 5: {
				System.out.println("bleh");
				break;
			}
			}
		}
		this.invalidate();
		return true;
	}

	public void reDrawRedo() {
		if (this.list_undonePaths.size() > 0) {
			this.list_paths
					.add(this.list_undonePaths.remove(this.list_undonePaths.size() - 1));
			this.list_color.add(this.list_colorPath.remove(this.list_colorPath.size() - 1));
			this.invalidate();
		}
	}

	public void reDrawUndo() {
		System.out.println("list_paths.size" + this.list_paths.size());
		if (this.list_paths.size() > 0) {
			this.list_undonePaths.add(this.list_paths.remove(this.list_paths.size() - 1));
			this.list_colorPath.add(this.list_color.remove(this.list_color.size() - 1));
			this.invalidate();
		}
	}

	public boolean sendvalue() {
		return this.zoomeImage;
	}

	public void setBrushSize(final int brushsize) {
		this.intBrushSize = brushsize;
	}

	public void setImageBitmap(final Bitmap imgBitmap) {
		if (imgBitmap != null) {
			this.imgBitmap = imgBitmap;
			this.container_width = this.getWidth();
			this.container_height = this.getHeight();
			final int height = this.imgBitmap.getHeight();
			final int width = this.imgBitmap.getWidth();
			int n = 0;
			int n2 = 0;
			this.matrix.reset();
			if (this.scale_default == 0) {
				float n3;
				if (width > this.container_width) {
					n3 = this.container_width / width;
					n2 = (this.container_height - (int) (height * n3)) / 2;
					this.matrix.setScale(n3, n3);
					this.matrix.postTranslate(0.0f, (float) n2);
				} else {
					n3 = this.container_height / height;
					n = (this.container_width - (int) (width * n3)) / 2;
					this.matrix.setScale(n3, n3);
					this.matrix.postTranslate((float) n, 0.0f);
				}
				this.cX = n;
				this.cY = n2;
				this.cscale = n3;
				this.min_scale = n3;
			} else {
				int n4;
				int n5;
				if (width > this.container_width) {
					n4 = 0;
					if (height > this.container_height) {
						n5 = 0;
					} else {
						n5 = (this.container_height - height) / 2;
					}
					this.matrix.postTranslate(0.0f, (float) n5);
				} else {
					n4 = (this.container_width - width) / 2;
					if (height > this.container_height) {
						n5 = 0;
					} else {
						n5 = (this.container_height - height) / 2;
					}
					this.matrix.postTranslate((float) n4, 0.0f);
				}
				this.cX = n4;
				this.cY = n5;
				this.cscale = 1.0f;
				this.min_scale = 1.0f;
			}
		}
		this.invalidate();
	}

	public void setUpDrawing() {
		this.path = new Path();
		this.paint = new Paint();
		this.Paintcircle = new Paint();
		this.paint.setColor(0);
		this.canvas.drawColor(0, PorterDuff.Mode.CLEAR);
		this.paint.setAntiAlias(true);
		if (Build.VERSION.SDK_INT >= 11) {
			this.setLayerType(1, (Paint) null);
		}
		this.paint.setStrokeWidth((float) this.intBrushSize);
		this.paint.setStyle(Paint.Style.STROKE);
		this.paint.setStrokeJoin(Paint.Join.ROUND);
		this.paint.setStrokeCap(Paint.Cap.ROUND);
		this.paint.setXfermode((Xfermode) new PorterDuffXfermode(
				PorterDuff.Mode.CLEAR));
	}

	class MyGestureDetector extends GestureDetector.SimpleOnGestureListener {
		public boolean onDoubleTap(final MotionEvent motionEvent) {
			if (ImageScale.this.animating) {
				return true;
			}
			ImageScale.this.s_change = 1.0f;
			ImageScale.this.animating = true;
			ImageScale.this.tScaleX = motionEvent.getX();
			ImageScale.this.tScaleY = motionEvent.getY();
			if (Math.abs(ImageScale.this.cscale
					- ImageScale.this.maximimScale) > 0.1) {
				ImageScale.this.tScale = ImageScale.this.maximimScale;
			} else {
				ImageScale.this.tScale = ImageScale.this.min_scale;
			}
			ImageScale.this.tRatio = ImageScale.this.tScale
					/ ImageScale.this.cscale;
			ImageScale.this.handler
					.removeCallbacks(ImageScale.this.update_imagescale);
			ImageScale.this.handler
					.post(ImageScale.this.update_imagescale);
			System.out.println("Entered MyGestureDetector");
			return true;
		}

		public boolean onDown(final MotionEvent motionEvent) {
			return false;
		}

		public boolean onFling(final MotionEvent motionEvent,
				final MotionEvent motionEvent2, final float n, final float n2) {
			return super.onFling(motionEvent, motionEvent2, n, n2);
		}
	}
}
