package escape.com.ecomirrormagiceditor.Activity;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import escape.com.ecomirrormagiceditor.R;
import escape.com.ecomirrormagiceditor.kprogresshud.KProgressHUD;

public class ImageEditingActivity extends AppCompatActivity {
    RelativeLayout rel_Frame1;
    RelativeLayout rel_Frame10;
    RelativeLayout rel_Frame11;
    RelativeLayout rel_Frame12;
    RelativeLayout rel_Frame13;
    RelativeLayout rel_Frame14;
    RelativeLayout rel_Frame2;
    RelativeLayout rel_Frame3;
    RelativeLayout rel_Frame4;
    RelativeLayout rel_Frame5;
    RelativeLayout rel_Frame6;
    RelativeLayout rel_Frame7;
    RelativeLayout rel_Frame8;
    RelativeLayout rel_Frame9;
    int height;
    Uri image;
    HorizontalScrollView horizontalscrollFrame;
    Bitmap orignalBtimap;
    public static Uri uriShare;
    RelativeLayout relativeZoom;
    ImageView ivBg1;
    HorizontalScrollView horizontalscrollBackground;
    Uri uriCopyimg;
    private boolean bScalingnext;
    Bitmap FinalImageBitmap;
    Bitmap btnmapFlip;
    ImageView ivFlip10_1;
    ImageView ivFlip10_2;
    ImageView ivFlip10_3;
    ImageView ivFlip10_4;
    ImageView ivFlip10_5;
    ImageView ivFlip10_6;
    ImageView ivFlip11_1;
    ImageView ivFlip11_2;
    ImageView ivFlip11_3;
    ImageView ivFlip11_4;
    ImageView ivFlip11_5;
    ImageView ivFlip11_6;
    ImageView ivFlip11_7;
    ImageView ivFlip11_8;
    ImageView ivFlip11_9;
    ImageView ivFlip12_1;
    ImageView ivFlip12_2;
    ImageView ivFlip12_3;
    ImageView ivFlip12_4;
    ImageView ivFlip12_5;
    ImageView ivFlip12_6;
    ImageView ivFlip12_7;
    ImageView ivFlip12_8;
    ImageView ivFlip12_9;
    ImageView ivFlip1_1;
    ImageView ivFlip1_2;
    ImageView ivFlip1_3;
    ImageView ivFlip1_4;
    ImageView ivFlip1_5;
    ImageView ivFlip1_6;
    ImageView ivFlip2_1;
    ImageView ivFlip2_2;
    ImageView ivFlip2_3;
    ImageView ivFlip2_4;
    ImageView ivFlip2_5;
    ImageView ivFlip2_6;
    ImageView ivFlip3_1;
    ImageView ivFlip3_2;
    ImageView ivFlip3_3;
    ImageView ivFlip3_4;
    ImageView ivFlip3_5;
    ImageView ivFlip4_1;
    ImageView ivFlip4_2;
    ImageView ivFlip4_3;
    ImageView ivFlip4_4;
    ImageView ivFlip4_5;
    ImageView ivFlip5_1;
    ImageView ivFlip5_2;
    ImageView ivFlip5_3;
    ImageView ivFlip5_4;
    ImageView ivFlip5_5;
    ImageView ivFlip5_6;
    ImageView ivFlip5_7;
    ImageView ivFlip5_8;
    ImageView ivFlip5_9;
    ImageView ivFlip6_1;
    ImageView ivFlip6_2;
    ImageView ivFlip6_3;
    ImageView ivFlip7_1;
    ImageView ivFlip7_2;
    ImageView ivFlip7_3;
    ImageView ivFlip8_1;
    ImageView ivFlip8_2;
    ImageView ivFlip8_3;
    ImageView ivFlip8_4;
    ImageView ivFlip8_5;
    ImageView ivFlip8_6;
    ImageView ivFlip8_7;
    ImageView ivFlip8_8;
    ImageView ivFlip8_9;
    ImageView ivFlip9_1;
    ImageView ivFlip9_2;
    ImageView ivFlip9_3;
    ImageView ivFlip9_4;
    ImageView ivFlip9_5;
    ImageView ivFlip9_6;
    private float scale;
    private ScaleGestureDetector scaleGestureDetector;
    private PointF touchPoint;
    int width;
    private boolean scal;
    private PointF point;
    ProgressDialog progressDialog;
    private static final int IMAGE_GALLERY_REQUEST = 20;
    public static int Request_Code;
    int hheight;
    int wwidth;
    LinearLayout ll_save;
    LinearLayout ll_eraser;
    LinearLayout ll_flip;
    LinearLayout ll_mirror;
    LinearLayout ll_background;

    public ImageEditingActivity() {
        this.scale = 1.0f;
    }

    static {
        Request_Code = com.theartofdev.edmodo.cropper.CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(escape.com.ecomirrormagiceditor.R.layout.activity_image_editing);
        loadAd();
        this.horizontalscrollFrame = (HorizontalScrollView) findViewById(R.id.frms_Scroll);
        this.horizontalscrollFrame.setVisibility(View.INVISIBLE);
        InitilizeViews();
        this.horizontalscrollBackground = (HorizontalScrollView) findViewById(R.id.backgrounds);
        this.horizontalscrollBackground.setVisibility(View.INVISIBLE);
        this.image = Uri.parse(getIntent().getStringExtra("image_Uri"));
        InputStream inputStream = null;
        try {
            inputStream = getContentResolver().openInputStream(this.image);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        this.orignalBtimap = BitmapFactory.decodeStream(inputStream);
        this.width = this.orignalBtimap.getWidth();
        this.height = this.orignalBtimap.getHeight();
        DisplayMetrics metrics1 = getResources().getDisplayMetrics();
        this.wwidth = metrics1.widthPixels;
        this.hheight = metrics1.heightPixels;
        this.FinalImageBitmap = cropBitmap1();
        saveBitmap(this.FinalImageBitmap);
        this.ll_save = (LinearLayout) findViewById(R.id.ll_save);
        this.ll_eraser = (LinearLayout) findViewById(R.id.ll_eraser);
        this.ll_flip = (LinearLayout) findViewById(R.id.ll_flip);
        this.ll_mirror = (LinearLayout) findViewById(R.id.ll_mirror);
        this.ll_background = (LinearLayout) findViewById(R.id.ll_background);
        this.relativeZoom = (RelativeLayout) findViewById(R.id.relativelyZoom);
        this.btnmapFlip = flip(this.FinalImageBitmap);
        SetImage();
        this.ll_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id = R.id.ll_save;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    ImageEditingActivity.this.saveImage();
                }
            }
        });
        this.ll_eraser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id = R.id.ll_eraser;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent passUriImage = new Intent(ImageEditingActivity.this, BrushEditingActivity.class);
                    passUriImage.putExtra("image_Uri", ImageEditingActivity.this.uriCopyimg.toString());
                    ImageEditingActivity.this.startActivityForResult(passUriImage, ImageEditingActivity.Request_Code);
                }
            }
        });
        this.ll_mirror.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                ImageEditingActivity.this.horizontalscrollBackground.setVisibility(View.INVISIBLE);
                if (ImageEditingActivity.this.horizontalscrollFrame.getVisibility() == View.INVISIBLE) {
                    ImageEditingActivity.this.horizontalscrollFrame.setVisibility(View.VISIBLE);
                    return;
                }
                ImageEditingActivity.this.horizontalscrollFrame.setVisibility(View.INVISIBLE);
            }
        });
        this.ll_background.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageEditingActivity.this.horizontalscrollFrame.setVisibility(View.INVISIBLE);
                if (ImageEditingActivity.this.horizontalscrollBackground.getVisibility() == View.INVISIBLE) {
                    ImageEditingActivity.this.horizontalscrollBackground.setVisibility(View.VISIBLE);
                } else {
                    ImageEditingActivity.this.horizontalscrollBackground.setVisibility(View.INVISIBLE);
                }
            }
        });
        this.ll_flip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageEditingActivity.this.FinalImageBitmap = ImageEditingActivity.this.flip(ImageEditingActivity.this.FinalImageBitmap);
                ImageEditingActivity.this.btnmapFlip = ImageEditingActivity.this.flip(ImageEditingActivity.this.btnmapFlip);
                ImageEditingActivity.this.SetImage();
            }
        });
        this.scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.OnScaleGestureListener() {

            private static final float SCALE_SPEED = 0.02f;

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                ImageEditingActivity.this.bScalingnext = true;
            }

            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                ImageEditingActivity.this.setPivot(detector.getFocusX(), detector.getFocusY());
                ImageEditingActivity.this.scal = true;
                ImageEditingActivity.this.bScalingnext = false;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                ImageEditingActivity.this.scal = true;
                ImageEditingActivity.this.bScalingnext = false;
                if (detector.getScaleFactor() < 1.0f) {
                    ImageEditingActivity.this.scale = ImageEditingActivity.this.scale - SCALE_SPEED;
                } else if (detector.getScaleFactor() > 1.0f) {
                    ImageEditingActivity.this.scale = ImageEditingActivity.this.scale + SCALE_SPEED;
                }
                ImageEditingActivity.this.scaleView();
                return true;
            }
        });
        reset();
    }

    public boolean onTouchEvent(MotionEvent event) {
        this.scaleGestureDetector.onTouchEvent(event);
        float x = event.getRawX();
        float y = event.getRawY();
        System.out.println("X_val" + x + "Y_val" + y);
        if (!(this.scale == 1.0f || this.scal)) {
            if (event.getAction() == View.VISIBLE) {
                this.touchPoint = new PointF(x, y);
                System.out.println("X_val_sca" + x + "Y_val_sca" + y);
            } else if (event.getAction() == 2 && this.touchPoint != null) {
                this.point.x = x - this.touchPoint.x;
                this.point.y = y - this.touchPoint.y;
                System.out.println("X_val_pan" + x + "Y_val_pan" + y);
                panView();
            }
        }
        if (event.getAction() == 2 && this.touchPoint != null) {
            this.point.x = x - this.touchPoint.x;
            this.point.y = y - this.touchPoint.y;
            panView();
        }
        if (this.scal && this.bScalingnext && event.getAction() == 6) {
            this.bScalingnext = false;
            this.scal = false;
        }
        return true;
    }

    private void setPivot(float focusX, float focusY) {
        this.relativeZoom.setPivotX(focusX);
        this.relativeZoom.setPivotY(focusY);
    }

    private void scaleView() {
        this.relativeZoom.setScaleX(this.scale);
        this.relativeZoom.setScaleY(this.scale);
    }

    private void panView() {
        this.relativeZoom.setTranslationX(this.point.x);
        this.relativeZoom.setTranslationY(this.point.y);
    }

    private void reset() {
        setPivot(0.0f, 0.0f);
        this.scale = 1.0f;
        scaleView();
        this.point = new PointF(0.0f, 0.0f);
        panView();
        this.scal = false;
    }

    public void saveImage() {
        this.progressDialog = ProgressDialog.show(this, " ", "Image is saving");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ImageEditingActivity.this.FinalsaveBitmap(ImageEditingActivity.this.getScreenShot1());
                Intent in = new Intent(ImageEditingActivity.this, ShareActivity.class);
                in.putExtra("imageToShare-uri", ImageEditingActivity.this.uriShare.toString());
                ImageEditingActivity.this.startActivity(in);
                ImageEditingActivity.this.progressDialog.dismiss();
            }
        }, 1000);
    }

    public void openGallery(View view) {
        Intent imagePickerIntent = new Intent("android.intent.action.PICK");
        imagePickerIntent.setDataAndType(Uri.parse(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()), "image/*");
        startActivityForResult(imagePickerIntent, IMAGE_GALLERY_REQUEST);
    }

    public void SetImage() {
        this.ivFlip1_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip1_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip1_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip1_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip1_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip1_6.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip2_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip2_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip2_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip2_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip2_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip2_6.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip3_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip3_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip3_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip3_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip3_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip4_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip4_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip4_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip4_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip4_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_6.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_7.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_8.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip5_9.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip6_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip6_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip6_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip7_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip7_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip7_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_6.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_7.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_8.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip8_9.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip9_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip9_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip9_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip9_4.setImageBitmap(this.btnmapFlip);
        this.ivFlip9_5.setImageBitmap(this.btnmapFlip);
        this.ivFlip9_6.setImageBitmap(this.btnmapFlip);
        this.ivFlip10_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip10_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip10_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip10_4.setImageBitmap(this.btnmapFlip);
        this.ivFlip10_5.setImageBitmap(this.btnmapFlip);
        this.ivFlip10_6.setImageBitmap(this.btnmapFlip);
        this.ivFlip11_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_6.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_7.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_8.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip11_9.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_1.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_2.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_3.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_4.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_5.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_6.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_7.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_8.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip12_9.setImageBitmap(this.FinalImageBitmap);
        this.ivFlip1_2.setAlpha(240);
        this.ivFlip1_3.setAlpha(210);
        this.ivFlip1_4.setAlpha(167);
        this.ivFlip1_5.setAlpha(127);
        this.ivFlip1_6.setAlpha(100);
        this.ivFlip2_2.setAlpha(240);
        this.ivFlip2_3.setAlpha(210);
        this.ivFlip2_4.setAlpha(167);
        this.ivFlip2_5.setAlpha(127);
        this.ivFlip2_6.setAlpha(127);
        this.ivFlip3_2.setAlpha(240);
        this.ivFlip3_3.setAlpha(210);
        this.ivFlip3_4.setAlpha(127);
        this.ivFlip3_5.setAlpha(100);
        this.ivFlip4_2.setAlpha(240);
        this.ivFlip4_3.setAlpha(210);
        this.ivFlip4_4.setAlpha(127);
        this.ivFlip4_5.setAlpha(100);
        this.ivFlip5_1.setAlpha(127);
        this.ivFlip5_2.setAlpha(180);
        this.ivFlip5_3.setAlpha(180);
        this.ivFlip5_4.setAlpha(210);
        this.ivFlip5_5.setAlpha(210);
        this.ivFlip5_6.setAlpha(240);
        this.ivFlip5_6.setAlpha(240);
        this.ivFlip8_4.setAlpha(220);
        this.ivFlip8_5.setAlpha(220);
        this.ivFlip8_6.setAlpha(180);
        this.ivFlip8_7.setAlpha(180);
        this.ivFlip8_8.setAlpha(127);
        this.ivFlip8_9.setAlpha(127);
    }

    public void InitilizeViews() {
        this.rel_Frame1 = (RelativeLayout) findViewById(R.id.rel_frm1);
        this.rel_Frame2 = (RelativeLayout) findViewById(R.id.rel_frm2);
        this.rel_Frame3 = (RelativeLayout) findViewById(R.id.rel_frm3);
        this.rel_Frame4 = (RelativeLayout) findViewById(R.id.rl_frm4);
        this.rel_Frame5 = (RelativeLayout) findViewById(R.id.rl_frm5);
        this.rel_Frame6 = (RelativeLayout) findViewById(R.id.rl_frm6);
        this.rel_Frame7 = (RelativeLayout) findViewById(R.id.rl_frm7);
        this.rel_Frame8 = (RelativeLayout) findViewById(R.id.rl_frm8);
        this.rel_Frame9 = (RelativeLayout) findViewById(R.id.rl_frm9);
        this.rel_Frame10 = (RelativeLayout) findViewById(R.id.rl_frm10);
        this.rel_Frame11 = (RelativeLayout) findViewById(R.id.rl_frm11);
        this.rel_Frame12 = (RelativeLayout) findViewById(R.id.rl_frm12);
        this.rel_Frame1.setVisibility(View.VISIBLE);
        this.rel_Frame2.setVisibility(View.INVISIBLE);
        this.rel_Frame3.setVisibility(View.INVISIBLE);
        this.rel_Frame4.setVisibility(View.INVISIBLE);
        this.rel_Frame5.setVisibility(View.INVISIBLE);
        this.rel_Frame6.setVisibility(View.INVISIBLE);
        this.rel_Frame7.setVisibility(View.INVISIBLE);
        this.rel_Frame8.setVisibility(View.INVISIBLE);
        this.rel_Frame9.setVisibility(View.INVISIBLE);
        this.rel_Frame10.setVisibility(View.INVISIBLE);
        this.rel_Frame11.setVisibility(View.INVISIBLE);
        this.rel_Frame12.setVisibility(View.INVISIBLE);
        this.ivBg1 = (ImageView) findViewById(R.id.ivBackground);
        this.ivBg1.setImageResource(R.drawable.bg1);
        this.ivFlip1_1 = (ImageView) findViewById(R.id.ivflip1_1);
        this.ivFlip1_2 = (ImageView) findViewById(R.id.ivflip1_2);
        this.ivFlip1_3 = (ImageView) findViewById(R.id.ivflip1_3);
        this.ivFlip1_4 = (ImageView) findViewById(R.id.ivflip1_4);
        this.ivFlip1_5 = (ImageView) findViewById(R.id.ivflip_1_5);
        this.ivFlip1_6 = (ImageView) findViewById(R.id.ivFlip_1_6);
        this.ivFlip2_1 = (ImageView) findViewById(R.id.ivFlip2_1);
        this.ivFlip2_2 = (ImageView) findViewById(R.id.ivFlip2_2);
        this.ivFlip2_3 = (ImageView) findViewById(R.id.ivFlip2_3);
        this.ivFlip2_4 = (ImageView) findViewById(R.id.ivFlip2_4);
        this.ivFlip2_5 = (ImageView) findViewById(R.id.ivFlip2_5);
        this.ivFlip2_6 = (ImageView) findViewById(R.id.ivFlip2_6);
        this.ivFlip3_1 = (ImageView) findViewById(R.id.ivFlip3_1);
        this.ivFlip3_2 = (ImageView) findViewById(R.id.ivFlip3_2);
        this.ivFlip3_3 = (ImageView) findViewById(R.id.ivFlip3_3);
        this.ivFlip3_4 = (ImageView) findViewById(R.id.ivFlip3_4);
        this.ivFlip3_5 = (ImageView) findViewById(R.id.ivFlip3_5);
        this.ivFlip4_1 = (ImageView) findViewById(R.id.ivFlip4_1);
        this.ivFlip4_2 = (ImageView) findViewById(R.id.ivFlip4_2);
        this.ivFlip4_3 = (ImageView) findViewById(R.id.ivFlip4_3);
        this.ivFlip4_4 = (ImageView) findViewById(R.id.ivFlip4_4);
        this.ivFlip4_5 = (ImageView) findViewById(R.id.ivFlip4_5);
        this.ivFlip5_1 = (ImageView) findViewById(R.id.ivFlip5_1);
        this.ivFlip5_2 = (ImageView) findViewById(R.id.ivFlip5_2);
        this.ivFlip5_3 = (ImageView) findViewById(R.id.ivFlip5_3);
        this.ivFlip5_4 = (ImageView) findViewById(R.id.ivFlip5_4);
        this.ivFlip5_5 = (ImageView) findViewById(R.id.ivFlip5_5);
        this.ivFlip5_6 = (ImageView) findViewById(R.id.ivFlip5_6);
        this.ivFlip5_7 = (ImageView) findViewById(R.id.ivFlip5_7);
        this.ivFlip5_8 = (ImageView) findViewById(R.id.ivFlip5_8);
        this.ivFlip5_9 = (ImageView) findViewById(R.id.ivFlip5_9);
        this.ivFlip6_1 = (ImageView) findViewById(R.id.ivFlip6_1);
        this.ivFlip6_2 = (ImageView) findViewById(R.id.ivFlip6_2);
        this.ivFlip6_3 = (ImageView) findViewById(R.id.ivFlip6_3);
        this.ivFlip7_1 = (ImageView) findViewById(R.id.ivFlip7_1);
        this.ivFlip7_2 = (ImageView) findViewById(R.id.ivFlip7_2);
        this.ivFlip7_3 = (ImageView) findViewById(R.id.ivFlip7_3);
        this.ivFlip8_1 = (ImageView) findViewById(R.id.ivFlip8_1);
        this.ivFlip8_2 = (ImageView) findViewById(R.id.ivFlip8_2);
        this.ivFlip8_3 = (ImageView) findViewById(R.id.ivFlip8_3);
        this.ivFlip8_4 = (ImageView) findViewById(R.id.ivFlip8_4);
        this.ivFlip8_5 = (ImageView) findViewById(R.id.ivFlip8_5);
        this.ivFlip8_6 = (ImageView) findViewById(R.id.ivFlip8_6);
        this.ivFlip8_7 = (ImageView) findViewById(R.id.ivFlip8_7);
        this.ivFlip8_8 = (ImageView) findViewById(R.id.ivFlip8_8);
        this.ivFlip8_9 = (ImageView) findViewById(R.id.ivFlip8_9);
        this.ivFlip9_1 = (ImageView) findViewById(R.id.ivFlip9_1);
        this.ivFlip9_2 = (ImageView) findViewById(R.id.ivFlip9_2);
        this.ivFlip9_3 = (ImageView) findViewById(R.id.ivFlip9_3);
        this.ivFlip9_4 = (ImageView) findViewById(R.id.ivFlip9_4);
        this.ivFlip9_5 = (ImageView) findViewById(R.id.ivFlip9_5);
        this.ivFlip9_6 = (ImageView) findViewById(R.id.ivFlip9_6);
        this.ivFlip10_1 = (ImageView) findViewById(R.id.ivFlip10_1);
        this.ivFlip10_2 = (ImageView) findViewById(R.id.ivFlip10_2);
        this.ivFlip10_3 = (ImageView) findViewById(R.id.ivFlip10_3);
        this.ivFlip10_4 = (ImageView) findViewById(R.id.ivFlip10_4);
        this.ivFlip10_5 = (ImageView) findViewById(R.id.ivFlip10_5);
        this.ivFlip10_6 = (ImageView) findViewById(R.id.ivFlip10_6);
        this.ivFlip11_1 = (ImageView) findViewById(R.id.ivFlip11_1);
        this.ivFlip11_2 = (ImageView) findViewById(R.id.ivFlip11_2);
        this.ivFlip11_3 = (ImageView) findViewById(R.id.ivFlip11_3);
        this.ivFlip11_4 = (ImageView) findViewById(R.id.ivFlip11_4);
        this.ivFlip11_5 = (ImageView) findViewById(R.id.ivFlip11_5);
        this.ivFlip11_6 = (ImageView) findViewById(R.id.ivFlip11_6);
        this.ivFlip11_7 = (ImageView) findViewById(R.id.ivFlip11_7);
        this.ivFlip11_8 = (ImageView) findViewById(R.id.ivFlip11_8);
        this.ivFlip11_9 = (ImageView) findViewById(R.id.ivFlip11_9);
        this.ivFlip12_1 = (ImageView) findViewById(R.id.ivFlip12_1);
        this.ivFlip12_2 = (ImageView) findViewById(R.id.ivFlip12_2);
        this.ivFlip12_3 = (ImageView) findViewById(R.id.ivFlip12_3);
        this.ivFlip12_4 = (ImageView) findViewById(R.id.ivFlip12_4);
        this.ivFlip12_5 = (ImageView) findViewById(R.id.ivFlip12_5);
        this.ivFlip12_6 = (ImageView) findViewById(R.id.ivFlip12_6);
        this.ivFlip12_7 = (ImageView) findViewById(R.id.ivFlip12_7);
        this.ivFlip12_8 = (ImageView) findViewById(R.id.ivFlip12_8);
        this.ivFlip12_9 = (ImageView) findViewById(R.id.ivFlip12_9);
    }


    public void saveBitmap(Bitmap sourceBitmap) {
        ContentValues values;
        Throwable th;
        File dir = new File(Environment.getExternalStorageDirectory() + "/Temp");
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (String file : children) {
                new File(dir, file).delete();
            }
        }
        if (sourceBitmap != null && !sourceBitmap.isRecycled()) {
            File storagePath = new File(Environment.getExternalStorageDirectory() + "/Temp");
            if (!storagePath.exists()) {
                storagePath.mkdirs();
            }
            FileOutputStream out = null;
            int randomNumber = new Random().nextInt();
            File filepath = Environment.getExternalStorageDirectory();
            dir.mkdirs();
            String FileName = new SimpleDateFormat("yyyyMMdd_HHmmss")
                    .format(new Date()) + ".jpeg";

            File imageFile = new File(dir, FileName);
            if (imageFile.exists() && imageFile.delete()) {
                try {
                    imageFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                FileOutputStream out2 = new FileOutputStream(imageFile);
                try {
                    boolean imageSaved = sourceBitmap.compress(Bitmap.CompressFormat.PNG, 100, out2);
                    if (out2 != null) {
                        out = out2;
                    }
                } catch (Exception e2) {
                    out = out2;
                    if (out != null) {
                    }
                    values = new ContentValues(3);
                    values.put("mime_type", "bitmap_image/jpeg");
                    values.put("_data", imageFile.getAbsolutePath());
                    this.uriCopyimg = Uri.fromFile(imageFile.getAbsoluteFile());
                    getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    System.out.println("imageFile" + imageFile);
                } catch (Throwable th2) {
                    th = th2;
                    out = out2;
                    if (out == null) {
                        throw th;
                    }
                    throw th;
                }
            } catch (Exception e3) {
                if (out != null) {
                }
                values = new ContentValues(3);
                values.put("mime_type", "bitmap_image/jpeg");
                values.put("_data", imageFile.getAbsolutePath());
                this.uriCopyimg = Uri.fromFile(imageFile.getAbsoluteFile());
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                System.out.println("imageFile" + imageFile);
            } catch (Throwable th3) {
                th = th3;
                if (out == null) {
                    try {
                        throw th;
                    } catch (Throwable throwable) {
                        throwable.printStackTrace();
                    }
                }
                try {
                    throw th;
                } catch (Throwable throwable) {
                    throwable.printStackTrace();
                }
            }
            values = new ContentValues(3);
            values.put("mime_type", "bitmap_image/jpeg");
            values.put("_data", imageFile.getAbsolutePath());
            this.uriCopyimg = Uri.fromFile(imageFile.getAbsoluteFile());
            getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            System.out.println("imageFile" + imageFile);
        }
    }

    public Bitmap getScreenShot1() {
        View view = findViewById(R.id.rl_root);
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        Bitmap screenshot = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(screenshot));
        return screenshot;
    }

    public void FinalsaveBitmap(Bitmap sourceBitmap) {
        ContentValues values;
        Throwable th;
        if (sourceBitmap != null && !sourceBitmap.isRecycled()) {
            File storagePath = new File(Environment.getExternalStorageDirectory() + "/" + getString(R.string.app_name));
            if (!storagePath.exists()) {
                storagePath.mkdirs();
            }
            FileOutputStream out = null;

            String FileName = new SimpleDateFormat("yyyyMMdd_HHmmss")
                    .format(new Date()) + ".jpeg";

            File imageFile = new File(storagePath, FileName);
            if (imageFile.exists() && imageFile.delete()) {
                try {
                    imageFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                FileOutputStream out2 = new FileOutputStream(imageFile);
                try {
                    boolean imageSaved = sourceBitmap.compress(Bitmap.CompressFormat.PNG, 100, out2);
                    if (out2 != null) {
                        out = out2;
                    }
                } catch (Exception e2) {
                    out = out2;
                    if (out != null) {
                    }
                    values = new ContentValues(3);
                    values.put("mime_type", "bitmap_image/jpeg");
                    values.put("_data", imageFile.getAbsolutePath());
                    this.uriShare = Uri.fromFile(imageFile.getAbsoluteFile());
                    getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    System.out.println("imageFile" + imageFile);
                } catch (Throwable th2) {
                    th = th2;
                    out = out2;
                    if (out == null) {
                        throw th;
                    }
                    throw th;
                }
            } catch (Exception e3) {
                if (out != null) {
                }
                values = new ContentValues(3);
                values.put("mime_type", "bitmap_image/jpeg");
                values.put("_data", imageFile.getAbsolutePath());
                this.uriShare = Uri.fromFile(imageFile.getAbsoluteFile());
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                System.out.println("imageFile" + imageFile);
            } catch (Throwable th3) {
                if (out == null) {
                }
            }
            values = new ContentValues(3);
            values.put("mime_type", "bitmap_image/jpeg");
            values.put("_data", imageFile.getAbsolutePath());
            this.uriShare = Uri.fromFile(imageFile.getAbsoluteFile());
            getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            System.out.println("imageFile" + imageFile);
        }
    }

    public void SetBackground(View view) {
        switch (view.getId()) {
            case R.id.imgBtn_bg1:
                this.ivBg1.setImageResource(R.drawable.bg1);
                break;
            case R.id.imgBtn_bg2:
                this.ivBg1.setImageResource(R.drawable.backgroundimg_2);
                break;
            case R.id.imgBtn_bg3:
                this.ivBg1.setImageResource(R.drawable.bg_3);
                break;
            case R.id.imgBtn_bg4:
                this.ivBg1.setImageResource(R.drawable.bg_4);
                break;
            case R.id.imgBtn_bg5:
                this.ivBg1.setImageResource(R.drawable.bg_5);
                break;
            case R.id.imgBtn_bg6:
                this.ivBg1.setImageResource(R.drawable.bg_6);
                break;
            case R.id.imgBtn_bg7:
                this.ivBg1.setImageResource(R.drawable.bg_7);
                break;
            case R.id.imgBtn_bg8:
                this.ivBg1.setImageResource(R.drawable.bg_8);
                break;
            case R.id.imgBtn_bg9:
                this.ivBg1.setImageResource(R.drawable.bg_9);
                break;
            case R.id.imgBtn_bg10:
                this.ivBg1.setImageResource(R.drawable.bg_10);
                break;
            case R.id.imgBtn_bg11:
                this.ivBg1.setImageResource(R.drawable.bg_11);
                break;
            default:
                break;
        }
    }

    public Bitmap flip2(Bitmap d) {
        Matrix m = new Matrix();
        m.preScale(1.0f, -1.0f);
        Bitmap src = d;
        Bitmap dst = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, false);
        dst.setDensity(160);
        return dst;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        InputStream inputStream;
        if (requestCode == Request_Code) {
            if (resultCode == 2) {
                this.image = Uri.parse(data.getStringExtra("erase_image"));
                inputStream = null;
                try {
                    inputStream = getContentResolver().openInputStream(this.image);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                this.FinalImageBitmap = BitmapFactory.decodeStream(inputStream);
                SetImage();
                File dir = new File(Environment.getExternalStorageDirectory() + "/Temp1");
                if (dir.isDirectory()) {
                    String[] children = dir.list();
                    for (String file : children) {
                        new File(dir, file).delete();
                    }
                }
            }
        } else if (requestCode == IMAGE_GALLERY_REQUEST && resultCode == -1) {
            inputStream = null;
            try {
                inputStream = getContentResolver().openInputStream(data.getData());
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
            }
            Bitmap background_image = BitmapFactory.decodeStream(inputStream);
            int b_width = background_image.getWidth();
            int b_height = background_image.getHeight();
            if (b_width > b_height) {
                while (true) {
                    if (b_width > this.wwidth || b_height > this.hheight) {
                        b_width = (int) (((double) b_width) * 0.9d);
                        b_height = (int) (((double) b_height) * 0.9d);
                    } else {
                        this.ivBg1.setImageBitmap(Bitmap.createScaledBitmap(background_image, (b_width / b_width) * this.wwidth, (b_height / b_height) * this.hheight, true));
                        return;
                    }
                }
            }
            Toast.makeText(this, "Incompatable Image !!! Width should be greater that height.", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap cropBitmap1() {
        System.out.println();
        Bitmap bmOverlay = Bitmap.createBitmap((int) (((double) this.width) * 0.8d), (int) (((double) this.height) * 0.7d), Bitmap.Config.ARGB_8888);
        Paint paint = new Paint();
        new Canvas(bmOverlay).drawBitmap(this.orignalBtimap, null, new Rect(0, 0, (int) (((double) this.width) * 0.9d), (int) (((double) this.height) * 0.9d)), paint);
        return bmOverlay;
    }

    public Bitmap flip(Bitmap d) {
        Matrix m = new Matrix();
        m.preScale(-1.0f, 1.0f);
        Bitmap src = d;
        Bitmap dst = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, false);
        dst.setDensity(160);
        return dst;
    }

    public void OnClickfrms(View view) {
        switch (view.getId()) {
            case R.id.ivFrm1:
                this.rel_Frame1.setVisibility(View.VISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm2:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.VISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm3:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.VISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm4:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.VISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm5:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.VISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm6:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.VISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm7:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.VISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm8:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.VISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm9:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.VISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm10:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.VISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm11:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.VISIBLE);
                this.rel_Frame12.setVisibility(View.INVISIBLE);
                break;
            case R.id.ivFrm12:
                this.rel_Frame1.setVisibility(View.INVISIBLE);
                this.rel_Frame2.setVisibility(View.INVISIBLE);
                this.rel_Frame3.setVisibility(View.INVISIBLE);
                this.rel_Frame4.setVisibility(View.INVISIBLE);
                this.rel_Frame5.setVisibility(View.INVISIBLE);
                this.rel_Frame6.setVisibility(View.INVISIBLE);
                this.rel_Frame7.setVisibility(View.INVISIBLE);
                this.rel_Frame8.setVisibility(View.INVISIBLE);
                this.rel_Frame9.setVisibility(View.INVISIBLE);
                this.rel_Frame10.setVisibility(View.INVISIBLE);
                this.rel_Frame11.setVisibility(View.INVISIBLE);
                this.rel_Frame12.setVisibility(View.VISIBLE);
                break;
            default:
                break;
        }
    }

    private InterstitialAd interstitial;
    private KProgressHUD hud;
    private int id;

    private void loadAd() {
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(ImageEditingActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ll_eraser:
                        Intent passUriImage = new Intent(ImageEditingActivity.this, BrushEditingActivity.class);
                        passUriImage.putExtra("image_Uri", ImageEditingActivity.this.uriCopyimg.toString());
                        ImageEditingActivity.this.startActivityForResult(passUriImage, ImageEditingActivity.Request_Code);
                        break;
                    case R.id.ll_save:
                        ImageEditingActivity.this.saveImage();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode)
            {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ImageEditingActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
