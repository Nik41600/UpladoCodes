package com.esc.photoeditor.utils.sticker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.esc.photoeditor.R;

public class NavigationDrawerListAdapter extends BaseAdapter {
  int[] b = new int[]{R.drawable.xmas28, R.drawable.hny15, R.drawable.glasses_14, R.drawable.accessory_24, R.drawable.mask_19, R.drawable.tb_2, R.drawable.beard_01, R.drawable.wig_07, R.drawable.snap_flower_crown_11, R.drawable.comic_02, R.drawable.emoji_066, R.drawable.love_16, R.drawable.list_icon_love_bird, R.drawable.monster_08, R.drawable.list_icon_flag, R.drawable.hat_01, R.drawable.a3, R.drawable.b6, R.drawable.b42};
  String[] c = new String[]{"Merry Christmas", "Happy New Year", "Goggles", "Tattoo", "Mask", "Tarban", "Beard", "Wig", "Flower queen", "Quotes", "Emoji", "Love", "Love Birds", "Monsters", "Flags", "Hat", "Lion", "Cat", "Animal"};
  Context context;
  LayoutInflater layoutInflater;

  public Object getItem(int i) {
    return null;
  }

  public long getItemId(int i) {
    return 0;
  }

  public View getView(int i, View view, ViewGroup viewGroup) {
    this.layoutInflater = LayoutInflater.from(this.context);
    view = this.layoutInflater.inflate(R.layout.sticker_nav_list_item, viewGroup, false);
    ImageView imageView = (ImageView) view.findViewById(R.id.nav_list_image);
    ((TextView) view.findViewById(R.id.nav_list_text)).setText(this.c[i]);
    imageView.setImageDrawable(this.context.getResources().getDrawable(this.b[i]));
    return view;
  }

  public NavigationDrawerListAdapter(Context context) {
    this.context = context;
  }

  public int getCount() {
    return this.b.length;
  }
}