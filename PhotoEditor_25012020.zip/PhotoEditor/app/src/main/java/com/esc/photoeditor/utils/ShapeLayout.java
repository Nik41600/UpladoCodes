package com.esc.photoeditor.utils;

public class ShapeLayout
{
  boolean isScalable;
  int porterDuffClearBorderIntex;
  public Shape[] shapeArr;

  public ShapeLayout(final Shape[] shapeArr) {
    this.isScalable = false;
    this.porterDuffClearBorderIntex = -1;
    this.shapeArr = shapeArr;
  }

  public int getClearIndex() {
    return this.porterDuffClearBorderIntex;
  }

  public void setClearIndex(final int porterDuffClearBorderIntex) {
    if (porterDuffClearBorderIntex >= 0 && porterDuffClearBorderIntex < this.shapeArr.length) {
      this.porterDuffClearBorderIntex = porterDuffClearBorderIntex;
    }
  }
}
