package com.esc.photoeditor.myStudio;

import java.io.File;
import java.util.ArrayList;

public class Glob {
    public static ArrayList<String> IMAGEALLARY = new ArrayList();

    public static void listAllImages(File filepath) {
        File[] files = filepath.listFiles();
        if (files != null) {
            for (int j = files.length - 1; j >= 0; j--) {
                String ss = files[j].toString();
                File check = new File(ss);
                if (check.toString().contains(".jpg")
                        || check.toString().contains(".png")
                        || check.toString().contains(".jpeg")) {
                    IMAGEALLARY.add(ss);
                }
                System.out.println(ss);
            }
            return;
        }
        System.out.println("Empty Folder");
    }
}
