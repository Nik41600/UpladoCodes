package com.esc.photoeditor.utils.sticker;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.DrawerLayout.SimpleDrawerListener;
import android.support.v7.app.AlertDialog.Builder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.esc.photoeditor.activities.CollageActivity;
import com.esc.photoeditor.R;

import java.util.ArrayList;

public class StickerGalleryFragment extends Fragment implements OnItemClickListener {
    int anInt = 0;
    float aFloat = 0.0f;
    ListView listView;
    OnClickListener onClickListener = new OnClickListener() {
        public final void onClick(View view) {
            if (view.getId() == R.id.textView_header) {
                StickerGalleryFragment.this.opendrawers();
            }
        }
    };
    ArrayList<Integer> arrayList = new ArrayList();
    Animation animation;
    Animation animation1;
    StickerGridItem[][] stickerGridItems;
    ImageView imageView;
    int anInt1 = 0;
    Activity activity;
    int anInt2 = 0;
    DrawerLayout drawerLayout;
    public StickerGalleryListener stickerGalleryListener;
    StickerGridAdapter stickerGridAdapter;
    GridView gridView;
    TextView textView;
    View view;
    public interface StickerGalleryListener {
        void galleyrstickers();

    }
    private void stickersItems() {
        int length = Utility.f73a.length;
        this.stickerGridItems = new StickerGridItem[length][];
        for (int i = 0; i < length; i++) {
            int length2 = Utility.f73a[i].length;
            this.stickerGridItems[i] = new StickerGridItem[length2];
            for (int i2 = 0; i2 < length2; i2++) {
                this.stickerGridItems[i][i2] = new StickerGridItem(Utility.f73a[i][i2]);
            }
        }
    }
    public final void opendrawers() {
        if (this.drawerLayout.isDrawerOpen((View) this.listView)) {
            for (int length = this.stickerGridItems.length, i = 0; i < length; ++i) {
                final StickerGridItem[] array = this.stickerGridItems[i];
                for (int length2 = array.length, j = 0; j < length2; ++j) {
                    array[j].anInt1 = 0;
                }
            }
            this.arrayList.clear();
            this.stickerGalleryListener.galleyrstickers();
            return;
        }
        this.drawerLayout.closeDrawer((View) this.listView);
    }
    public final void c() {
        int[] iArr = new int[2];
        this.imageView.getLocationOnScreen(iArr);
        this.anInt = this.imageView.getWidth() + iArr[0];
        StringBuilder stringBuilder = new StringBuilder("initialTogglePos ");
        stringBuilder.append(this.anInt);
        Log.e("GalleryActivity", stringBuilder.toString());
    }

    public final void StickerGalleryFragment(Activity activity) {
        this.activity = activity;
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        this.view = layoutInflater.inflate(R.layout.sticker_fragment_gallery, viewGroup, false);
        this.textView = (TextView) this.view.findViewById(R.id.textView_header);
        this.textView.setOnClickListener(this.onClickListener);
        ((ImageButton) this.view.findViewById(R.id.sticker_gallery_ok)).setOnClickListener(new OnClickListener() {
            public void onClick(final View view) {
                final StickerGridItem[][] am = StickerGalleryFragment.this.stickerGridItems;
                final int n = 0;
                for (int length = am.length, i = 0; i < length; ++i) {
                    final StickerGridItem[] array = StickerGalleryFragment.this.stickerGridItems[i];
                    for (int length2 = array.length, j = 0; j < length2; ++j) {
                        array[j].anInt1 = 0;
                    }
                }
                final int size = StickerGalleryFragment.this.arrayList.size();
                final int[] array2 = new int[size];
                for (int k = n; k < size; ++k) {
                    array2[k] = StickerGalleryFragment.this.arrayList.get(k);
                }
                StickerGalleryFragment.this.arrayList.clear();
                final Intent intent = new Intent((Context)StickerGalleryFragment.this.getActivity(), (Class)CollageActivity.class);
                final Bundle bundle = new Bundle();
                bundle.putIntArray("MyArray", array2);
                intent.putExtras(bundle);
                StickerGalleryFragment.this.startActivity(intent);
            }
        });
        this.imageView = (ImageView) this.view.findViewById(R.id.toggle_button);
        this.animation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_in_left_galler_toggle);
        this.animation1 = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_out_left_gallery_toggle);
        this.animation.setFillAfter(true);
        this.animation1.setFillAfter(true);
        this.gridView = (GridView) this.view.findViewById(R.id.gridView);
        stickersItems();
        this.stickerGridAdapter = new StickerGridAdapter(getActivity(), this.stickerGridItems[0], this.gridView);
        this.gridView.setAdapter(this.stickerGridAdapter);
        this.gridView.setOnItemClickListener(this);
        if (this.drawerLayout != null) {
            this.drawerLayout.postDelayed(new Runnable() {
                public final void run() {
                    StickerGalleryFragment.this.drawerLayout.closeDrawer(StickerGalleryFragment.this.listView);
                }
            }, 600);
        }
        this.imageView.setOnTouchListener(new OnTouchListener() {
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                StickerGalleryFragment.this.drawerLayout.openDrawer(StickerGalleryFragment.this.listView);
                return true;
            }
        });
        this.imageView.post(new Runnable() {
            public final void run() {
                StickerGalleryFragment.this.c();
            }
        });
        NavigationDrawerListAdapter navigationDrawerListAdapter = new NavigationDrawerListAdapter(getActivity());
        this.drawerLayout = (DrawerLayout) this.view.findViewById(R.id.layout_gallery_fragment_drawer);
        this.listView = (ListView) this.view.findViewById(R.id.drawer);
        this.listView.setAdapter(navigationDrawerListAdapter);
        this.listView.setItemChecked(0, true);
        this.listView.setOnItemClickListener(new OnItemClickListener() {
            public final void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                StickerGalleryFragment.this.drawerLayout.closeDrawer(StickerGalleryFragment.this.listView);
                if (StickerGalleryFragment.this.anInt2 != i) {
                    StickerGalleryFragment.this.stickersItems();
                    StickerGalleryFragment.this.stickerGridAdapter.stickerGridItems = StickerGalleryFragment.this.stickerGridItems[i];
                    StickerGalleryFragment.this.gridView.smoothScrollToPosition(i);
                    StickerGalleryFragment.this.stickerGridAdapter.notifyDataSetChanged();
                }
                StickerGalleryFragment.this.anInt2 = i;
            }
        });
        this.drawerLayout.setDrawerListener(new SimpleDrawerListener() {
            public void onDrawerClosed(View view) {
            }

            public void onDrawerOpened(View view) {
            }

            public void onDrawerStateChanged(int i) {
            }

            public void onDrawerSlide(View view, float f) {
                if (StickerGalleryFragment.this.anInt <= 0) {
                    StickerGalleryFragment.this.c();
                }
                StickerGalleryFragment.this.aFloat = (-f) * ((float) StickerGalleryFragment.this.anInt);
                if (VERSION.SDK_INT >= 11) {
                    StickerGalleryFragment.this.imageView.setX(StickerGalleryFragment.this.aFloat);
                }
            }
        });
        return this.view;
    }
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (this.anInt1 + this.arrayList.size() >= 12) {
            Builder builder = new Builder(getActivity());
            builder.setMessage((int) R.string.sticker_choose_limit);
            builder.setPositiveButton((CharSequence) "OK", new DialogInterface.OnClickListener() {
                public final void onClick(DialogInterface dialogInterface, int i) {
                }
            });
            builder.create().show();
            return;
        }
        int i2 = 0;
        if (this.stickerGridAdapter.stickerGridItems[i].anInt1 == 0) {
            StickerGridItem stickerGridItem = this.stickerGridAdapter.stickerGridItems[i];
            stickerGridItem.anInt1++;
        } else {
            this.stickerGridAdapter.stickerGridItems[i].anInt1 = 0;
        }
        ImageView imageView = (ImageView) view.findViewById(R.id.image_view_item_selected);
        if (imageView.getVisibility() == 4 && this.stickerGridAdapter.stickerGridItems[i].anInt1 == 1) {
            imageView.setVisibility(View.VISIBLE);
        }
        if (imageView.getVisibility() == 0 && this.stickerGridAdapter.stickerGridItems[i].anInt1 == 0) {
            imageView.setVisibility(View.INVISIBLE);
        }
        int i3 = this.stickerGridAdapter.stickerGridItems[i].anInt;
        if (this.stickerGridAdapter.stickerGridItems[i].anInt1 == 1) {
            this.arrayList.add(Integer.valueOf(i3));
        } else {
            while (i2 < this.arrayList.size()) {
                if (((Integer) this.arrayList.get(i2)).intValue() == i3) {
                    this.arrayList.remove(i2);
                    break;
                }
                i2++;
            }
        }
        TextView textView = this.textView;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.anInt1 + this.arrayList.size());
        stringBuilder.append(getActivity().getString(R.string.sticker_items_selected));
        textView.setText(stringBuilder.toString());
    }
    public void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
    }
}