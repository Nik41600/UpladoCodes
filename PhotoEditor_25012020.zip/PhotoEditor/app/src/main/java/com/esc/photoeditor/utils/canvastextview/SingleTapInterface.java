package com.esc.photoeditor.utils.canvastextview;

public interface SingleTapInterface
{
  void onSingleTap(final TextDataItem p0);
}
