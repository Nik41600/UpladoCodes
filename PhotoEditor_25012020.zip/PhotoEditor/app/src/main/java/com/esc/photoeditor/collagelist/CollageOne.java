package com.esc.photoeditor.collagelist;
import android.graphics.*;

import com.esc.photoeditor.R;

import java.util.*;

public class CollageOne extends Collage
{
  public static int shapeCount = 1;

  public CollageOne(final int n, final int n2) {
    this.collageLayoutList = new ArrayList();
    final ArrayList<PointF[]> list = new ArrayList<PointF[]>();
    final float n3 = n;
    final float n4 = n3 * 0.0f;
    final float n5 = n2;
    final float n6 = 0.0f * n5;
    final PointF pointF = new PointF(n4, n6);
    final float n7 = n5 * 1.0f;
    final PointF pointF2 = new PointF(n4, n7);
    final float n8 = n3 * 1.0f;
    list.add(new PointF[] { pointF, pointF2, new PointF(n8, n7), new PointF(n8, n6) });
    this.collageLayoutList.add(new CollageLayout(list));
    final ArrayList<PointF[]> list2 = new ArrayList<PointF[]>();
    list2.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout = new CollageLayout(list2);
    collageLayout.maskPairList.add(new MaskPair(0, R.drawable.mask_butterfly));
    this.collageLayoutList.add(collageLayout);
    final ArrayList<PointF[]> list3 = new ArrayList<PointF[]>();
    list3.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout2 = new CollageLayout(list3);
    collageLayout2.maskPairList.add(new MaskPair(0, R.drawable.mask_cloud));
    this.collageLayoutList.add(collageLayout2);
    final ArrayList<PointF[]> list4 = new ArrayList<PointF[]>();
    list4.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout3 = new CollageLayout(list4);
    collageLayout3.maskPairList.add(new MaskPair(0, R.drawable.mask_clover));
    this.collageLayoutList.add(collageLayout3);
    final ArrayList<PointF[]> list5 = new ArrayList<PointF[]>();
    list5.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout4 = new CollageLayout(list5);
    collageLayout4.maskPairList.add(new MaskPair(0, R.drawable.mask_leaf));
    this.collageLayoutList.add(collageLayout4);
    final ArrayList<PointF[]> list6 = new ArrayList<PointF[]>();
    list6.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout5 = new CollageLayout(list6);
    collageLayout5.maskPairList.add(new MaskPair(0, R.drawable.mask_left_foot));
    this.collageLayoutList.add(collageLayout5);
    final ArrayList<PointF[]> list7 = new ArrayList<PointF[]>();
    list7.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout6 = new CollageLayout(list7);
    collageLayout6.maskPairList.add(new MaskPair(0, R.drawable.mask_diamond));
    this.collageLayoutList.add(collageLayout6);
    final ArrayList<PointF[]> list8 = new ArrayList<PointF[]>();
    list8.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout7 = new CollageLayout(list8);
    collageLayout7.maskPairList.add(new MaskPair(0, R.drawable.mask_hexagon));
    this.collageLayoutList.add(collageLayout7);
    final ArrayList<PointF[]> list9 = new ArrayList<PointF[]>();
    list9.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout8 = new CollageLayout(list9);
    collageLayout8.maskPairList.add(new MaskPair(0, R.drawable.mask_heart));
    this.collageLayoutList.add(collageLayout8);
    final ArrayList<PointF[]> list10 = new ArrayList<PointF[]>();
    list10.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout9 = new CollageLayout(list10);
    collageLayout9.maskPairList.add(new MaskPair(0, R.drawable.mask_paw));
    this.collageLayoutList.add(collageLayout9);
    final ArrayList<PointF[]> list11 = new ArrayList<PointF[]>();
    list11.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout10 = new CollageLayout(list11);
    collageLayout10.maskPairList.add(new MaskPair(0, R.drawable.mask_circle));
    this.collageLayoutList.add(collageLayout10);
    final ArrayList<PointF[]> list12 = new ArrayList<PointF[]>();
    list12.add(new PointF[] { new PointF(n4, n6), new PointF(n4, n7), new PointF(n8, n7), new PointF(n8, n6) });
    final CollageLayout collageLayout11 = new CollageLayout(list12);
    collageLayout11.maskPairList.add(new MaskPair(0, R.drawable.mask_twitter));
    this.collageLayoutList.add(collageLayout11);
  }
}
