package com.esc.photoeditor.adapter;

import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.ViewGroup;

public class RecylceAdapterBase<VH extends ViewHolder> extends Adapter<VH> {
  public int getItemCount() {
    return 0;
  }

  public void onBindViewHolder(VH vh, int i) {
  }

  public VH onCreateViewHolder(ViewGroup viewGroup, int i) {
    return null;
  }

  public void setSelectedPositinVoid() {
  }
}