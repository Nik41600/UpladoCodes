package com.esc.photoeditor.utils;

import android.graphics.*;

public class MirrorImageMode
{
  public int count;
  private Rect drawBitmapSrc;
  public Matrix matrix1;
  public Matrix matrix2;
  public Matrix matrix3;
  public RectF rect1;
  public RectF rect2;
  public RectF rect3;
  public RectF rect4;
  public RectF rectTotalArea;
  private RectF srcRect;
  public int touchMode;

  public MirrorImageMode(final int count, final RectF srcRect, final RectF rect1, final RectF rect2, final Matrix matrix1, final int touchMode, final RectF rectTotalArea) {
    this.count = count;
    this.srcRect = srcRect;
    this.drawBitmapSrc = new Rect();
    this.srcRect.round(this.drawBitmapSrc);
    this.rect1 = rect1;
    this.rect2 = rect2;
    this.matrix1 = matrix1;
    this.touchMode = touchMode;
    this.rectTotalArea = rectTotalArea;
  }

  public MirrorImageMode(final int count, final RectF srcRect, final RectF rect1, final RectF rect2, final RectF rect3, final RectF rect4, final Matrix matrix1, final Matrix matrix2, final Matrix matrix3, final int touchMode, final RectF rectTotalArea) {
    this.count = count;
    this.srcRect = srcRect;
    this.drawBitmapSrc = new Rect();
    this.srcRect.round(this.drawBitmapSrc);
    this.rect1 = rect1;
    this.rect2 = rect2;
    this.rect3 = rect3;
    this.rect4 = rect4;
    this.matrix1 = matrix1;
    this.matrix2 = matrix2;
    this.matrix3 = matrix3;
    this.touchMode = touchMode;
    this.rectTotalArea = rectTotalArea;
  }

  public Rect getDrawBitmapSrc() {
    return this.drawBitmapSrc;
  }

  public RectF getSrcRect() {
    return this.srcRect;
  }

  public void setSrcRect(final RectF rectF) {
    this.srcRect.set(rectF);
    this.updateBitmapSrc();
  }

  public void updateBitmapSrc() {
    this.srcRect.round(this.drawBitmapSrc);
  }
}
