package com.esc.photoeditor.utils;

import android.support.v4.content.FileProvider;
public class GenericFileProvider extends FileProvider {
}
