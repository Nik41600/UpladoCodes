package com.esc.photoeditor.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import com.esc.photoeditor.utils.GridViewItem;
import com.esc.photoeditor.R;

import java.lang.ref.WeakReference;
import java.util.List;

public class GridAdapter extends BaseAdapter {
    private static final String TAG = "GridAdapter";
    Context context;
    GridView gridView;
    LayoutInflater inflater;
    public List<GridViewItem> items;
    Bitmap placeHolder;

    static class AsyncDrawable extends BitmapDrawable {
        private final WeakReference<BitmapWorkerTask> bitmapWorkerTaskReference;

        public AsyncDrawable(Resources resources, Bitmap bitmap, BitmapWorkerTask bitmapWorkerTask) {
            super(resources, bitmap);
            this.bitmapWorkerTaskReference = new WeakReference(bitmapWorkerTask);
        }

        public BitmapWorkerTask getBitmapWorkerTask() {
            return (BitmapWorkerTask) this.bitmapWorkerTaskReference.get();
        }
    }

    class BitmapWorkerTask extends AsyncTask<Long, Void, Bitmap> {
        private long data = 0;
        private final WeakReference<ImageView> imageViewReference;
        private GridViewItem item;

        public BitmapWorkerTask(ImageView imageView, GridViewItem gridViewItem) {
            this.imageViewReference = new WeakReference(imageView);
            this.item = gridViewItem;
        }

        public Bitmap doInBackground(Long... lArr) {
            this.data = lArr[0].longValue();
            return this.item.getImage();
        }

        public void onPostExecute(Bitmap bitmap) {
            if (isCancelled()) {
                bitmap = null;
            }
            if (bitmap != null) {
                ImageView imageView = (ImageView) this.imageViewReference.get();
                if (this == GridAdapter.getBitmapWorkerTask(imageView)) {
                    imageView.setImageBitmap(bitmap);
                }
            }
        }
    }

    static class ViewHolder {
        ImageView imageView;
        TextView selectedCount;
        View textContainer;
        TextView textCount;
        TextView textPath;

        ViewHolder() {
        }
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public GridAdapter(Context context, List<GridViewItem> list, GridView gridView) {
        this.items = list;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.gridView = gridView;
        this.placeHolder = BitmapFactory.decodeResource(context.getResources(), R.drawable.no_pattern);
        this.context = context;
    }

    public static boolean cancelPotentialWork(long j, ImageView imageView) {
        BitmapWorkerTask bitmapWorkerTask = getBitmapWorkerTask(imageView);
        if (bitmapWorkerTask == null) {
            return true;
        }
        long access$000 = bitmapWorkerTask.data;
        if (access$000 != 0 && access$000 == j) {
            return false;
        }
        bitmapWorkerTask.cancel(true);
        return true;
    }

    private static BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
        if (imageView != null) {
            Drawable drawable = imageView.getDrawable();
            if (drawable instanceof AsyncDrawable) {
                return ((AsyncDrawable) drawable).getBitmapWorkerTask();
            }
        }
        return null;
    }

    public int getCount() {
        return this.items.size();
    }

    public Object getItem(int i) {
        return this.items.get(i);
    }

    @SuppressLint({"NewApi"})
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            view = this.inflater.inflate(R.layout.grid_item, null);
            viewHolder = new ViewHolder();
            viewHolder.textPath = (TextView) view.findViewById(R.id.textView_path);
            viewHolder.textCount = (TextView) view.findViewById(R.id.textViewCount);
            viewHolder.imageView = (ImageView) view.findViewById(R.id.imageView);
            viewHolder.textContainer = view.findViewById(R.id.grid_item_text_container);
            viewHolder.selectedCount = (TextView) view.findViewById(R.id.textViewSelectedItemCount);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        String folderName = ((GridViewItem) this.items.get(i)).getFolderName();
        if (folderName == null || folderName.length() == 0) {
            if (viewHolder.textContainer.getVisibility() == View.VISIBLE) {
                viewHolder.textContainer.setVisibility(View.GONE);
            }
            if (((GridViewItem) this.items.get(i)).selectedItemCount > 0) {
                TextView textView = viewHolder.selectedCount;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(((GridViewItem) this.items.get(i)).selectedItemCount);
                textView.setText(stringBuilder.toString());
                if (viewHolder.selectedCount.getVisibility() == View.INVISIBLE) {
                    viewHolder.selectedCount.setVisibility(View.VISIBLE);
                }
            } else if (viewHolder.selectedCount.getVisibility() == View.VISIBLE) {
                viewHolder.selectedCount.setVisibility(View.INVISIBLE);
            }
        } else {
            if (viewHolder.textContainer.getVisibility() == View.GONE) {
                viewHolder.textContainer.setVisibility(View.VISIBLE);
            }
            viewHolder.textPath.setText(((GridViewItem) this.items.get(i)).getFolderName());
            viewHolder.textCount.setText(((GridViewItem) this.items.get(i)).count);
            if (viewHolder.selectedCount.getVisibility() == View.VISIBLE) {
                viewHolder.selectedCount.setVisibility(View.INVISIBLE);
            }
        }
        loadBitmap((long) i, viewHolder.imageView, (GridViewItem) this.items.get(i));
        return view;
    }

    public void loadBitmap(long j, ImageView imageView, GridViewItem gridViewItem) {
        if (cancelPotentialWork(j, imageView)) {
            BitmapWorkerTask bitmapWorkerTask = new BitmapWorkerTask(imageView, gridViewItem);
            imageView.setImageDrawable(new AsyncDrawable(this.context.getResources(), this.placeHolder, bitmapWorkerTask));
            bitmapWorkerTask.execute(new Long[]{Long.valueOf(j)});
        }
    }
}