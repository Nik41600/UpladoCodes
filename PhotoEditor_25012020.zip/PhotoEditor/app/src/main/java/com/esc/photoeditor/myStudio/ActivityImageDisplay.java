package com.esc.photoeditor.myStudio;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.esc.photoeditor.kprogresshud.KProgressHUD;
import com.esc.photoeditor.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.IOException;

public class ActivityImageDisplay extends AppCompatActivity {
    ImageView ivMainImage;
    ImageView ivDelete;
    int pos;
    ImageView ivSetas;
    ImageView ivShare;
    ImageView ivBack;
    private AdView adView;
    private InterstitialAd interstitialAd;
    private KProgressHUD hud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_image_display);
        pos = getIntent().getIntExtra("position", 0);

        loadAds();

        ivMainImage = (ImageView) findViewById(R.id.ivMainImage);
        ivMainImage.setImageURI(Uri.parse((String) Glob.IMAGEALLARY.get(pos)));
        ivDelete = (ImageView) findViewById(R.id.ivDelete);
        ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dial = new Dialog(ActivityImageDisplay.this,
                        android.R.style.Theme_Translucent);
                dial.requestWindowFeature(1);
                dial.setContentView(R.layout.delete_confirmation);
                dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dial.setCanceledOnTouchOutside(true);
                ((TextView) dial.findViewById(R.id.tvDelete))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                File fD = new File((String) Glob.IMAGEALLARY
                                        .get(pos));
                                if (fD.exists()) {
                                    fD.delete();
                                }
                                Glob.IMAGEALLARY.remove(pos);
                                ActivityImageDisplay.this
                                        .sendBroadcast(new Intent(
                                                "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                                                Uri.fromFile(new File(String
                                                        .valueOf(fD)))));

                                if (Glob.IMAGEALLARY.size() == 0) {
                                    Toast.makeText(ActivityImageDisplay.this,
                                            "No Image Found..", Toast.LENGTH_SHORT
                                    ).show();
                                }
                                dial.dismiss();
                                startActivity(new Intent(ActivityImageDisplay.this, ActivityStudio.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                                finish();
                            }
                        });
                ((TextView) dial.findViewById(R.id.tvCancle))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                dial.dismiss();
                            }
                        });
                dial.show();
            }
        });

        ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = 101;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(ActivityImageDisplay.this, ActivityStudio.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        });


        ivSetas = (ImageView) findViewById(R.id.ivSetas);
        ivSetas.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ActivityImageDisplay.this.setWallpaper(
                        "",
                        (String) Glob.IMAGEALLARY.get(pos));
            }
        });
        ivShare = (ImageView) findViewById(R.id.ivShare);
        ivShare.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                Parcelable fromFile;
                if (Build.VERSION.SDK_INT <= 19) {
                    fromFile = Uri.fromFile(new File((String) Glob.IMAGEALLARY.get(pos)));
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(getPackageName());
                    stringBuilder.append(".provider");
                    fromFile = FileProvider.getUriForFile(ActivityImageDisplay.this, stringBuilder.toString(), new File((String) Glob.IMAGEALLARY.get(pos)));
                }
                Intent intentshare = new Intent("android.intent.action.SEND");
                intentshare.setType("image/*");
                intentshare.putExtra("android.intent.extra.STREAM", fromFile);
                intentshare.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intentshare, getString(R.string.share_your_story)));

            }
        });
    }

    private void setWallpaper(String diversity, String s) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int height = metrics.heightPixels;
        int width = metrics.widthPixels;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            wallpaperManager.setBitmap(BitmapFactory.decodeFile(s, options));
            wallpaperManager.suggestDesiredDimensions(width / 2, height / 2);
            Toast.makeText(this, "Wallpaper Set Sucessfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(ActivityImageDisplay.this, ActivityStudio.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
    }

    private int id;

    private void loadAds() {
        //Banner Ad
        adView = findViewById(R.id.AdView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {

            public void onAdLoaded() {
                super.onAdLoaded();
            }

            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case 101:
                        startActivity(new Intent(ActivityImageDisplay.this, ActivityStudio.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        finish();
                        break;
                        
                }
                interstitialAd.loadAd(adRequestfull);
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(ActivityImageDisplay.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //interstitialAd.show();
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }
}
