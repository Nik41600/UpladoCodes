package com.esc.photoeditor.utils.sticker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.esc.photoeditor.R;

public class StickerGridAdapter extends BaseAdapter {
    LayoutInflater layoutInflater;
    Context context;
    Bitmap bitmap;
    GridView gridView;
    BitmapFactory.Options options;
    StickerGridItem[] stickerGridItems;

    public StickerGridAdapter(final Context context, final StickerGridItem[] stickerGridItems, final GridView gridView) {
        this.options = new BitmapFactory.Options();
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.gridView = gridView;
        this.bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.empty_photo);
        this.context = context;
        this.options.inSampleSize = 2;
        this.stickerGridItems = stickerGridItems;
    }

    public int getCount() {
        return this.stickerGridItems.length;
    }

    public Object getItem(final int n) {
        return this.stickerGridItems[n];
    }

    public long getItemId(final int n) {
        return n;
    }

    @SuppressLint({"NewApi"})
    public View getView(final int n, View inflate, final ViewGroup viewGroup) {
        ViewHolder tag;
        if (inflate == null) {
            inflate = this.layoutInflater.inflate(R.layout.sticker_grid_item, (ViewGroup) null);
            tag = new ViewHolder(inflate);
            inflate.setTag(tag);
        } else {
            tag = (ViewHolder) inflate.getTag();
        }
        Glide.with(this.context).load(Integer.valueOf(this.stickerGridItems[n].anInt)).into(tag.stickera);
        if (this.stickerGridItems[n].anInt1 > 0) {
            if (tag.select.getVisibility() == View.INVISIBLE) {
                tag.select.setVisibility(View.VISIBLE);
                return inflate;
            }
        } else if (tag.select.getVisibility() == View.VISIBLE) {
            tag.select.setVisibility(View.INVISIBLE);
            return inflate;
        }
        return inflate;
    }

    static class ViewHolder {
        ImageView select;
        ImageView stickera;

        ViewHolder(final View view) {
            this.stickera = (ImageView) view.findViewById(R.id.imageView);
            this.select = (ImageView) view.findViewById(R.id.image_view_item_selected);
        }
    }
}
