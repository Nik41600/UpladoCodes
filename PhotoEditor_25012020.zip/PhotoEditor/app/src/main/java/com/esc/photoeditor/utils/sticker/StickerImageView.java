package com.esc.photoeditor.utils.sticker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

public class StickerImageView extends StickerView {
    private ImageView imageView;
    private String string;

    public StickerImageView(Context context) {
        super(context);
    }

    public StickerImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public StickerImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void setOwnerId(String str) {
        this.string = str;
    }

    public String getOwnerId() {
        return this.string;
    }

    public View getMainView() {
        if (this.imageView == null) {
            this.imageView = new ImageView(getContext());
            this.imageView.setScaleType(ScaleType.FIT_XY);
        }
        return this.imageView;
    }

    public void setImageBitmap(Bitmap bitmap) {
        this.imageView.setImageBitmap(bitmap);
    }

    public void setImageResource(int i) {
        this.imageView.setImageResource(i);
    }

    public void setImageDrawable(Drawable drawable) {
        this.imageView.setImageDrawable(drawable);
    }

    public Bitmap getImageBitmap() {
        return ((BitmapDrawable) this.imageView.getDrawable()).getBitmap();
    }
}