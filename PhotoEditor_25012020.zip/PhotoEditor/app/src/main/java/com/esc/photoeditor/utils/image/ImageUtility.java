package com.esc.photoeditor.utils.image;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;

import com.esc.photoeditor.R;

import java.io.File;

public class ImageUtility {
    public static int SPLASH_TIME_OUT_LONG = 800;
    static int SPLASH_TIME_OUT_MAX = 1300;
    public static int SPLASH_TIME_OUT_SHORT = 150;
    private static final String TAG = "SaveImage Utils";


    public static boolean getAmazonMarket(final Context context) {
        try {
            final int int1;
            if ((int1 = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA).metaData.getInt("amazon_market")) >= 0) {
                return int1 == 1;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        int int1 = 0;
        return int1 == 1;
    }

    public static String getPrefferredDirectoryPath(final Context context, final boolean b, final boolean b2, final boolean b3) {
        String s;
        if (b3) {
            final StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath()));
            sb.append(File.separator);
            sb.append(context.getResources().getString(R.string.directory));
            s = sb.toString();
        } else {
            final StringBuilder sb2 = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()));
            sb2.append(context.getResources().getString(R.string.directory));
            s = sb2.toString();
        }
        final String string = PreferenceManager.getDefaultSharedPreferences(context).getString("save_image_directory_custom", (String) null);
        String s2 = s;
        if (string != null) {
            final StringBuilder sb3 = new StringBuilder(String.valueOf(string));
            sb3.append(File.separator);
            final String string2 = sb3.toString();
            if (b2) {
                return string2;
            }
            final File file = new File(string2);
            s2 = s;
            if (file.canRead()) {
                s2 = s;
                if (file.canWrite()) {
                    s2 = s;
                }
            }
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("prefDir ");
            sb4.append(string2);
            Log.e("SaveImage Utils", sb4.toString());
        }
        final StringBuilder sb5 = new StringBuilder();
        sb5.append("getPrefferredDirectoryPathEx ");
        sb5.append(getPrefferredDirectoryPathEx(context));
        Log.e("SaveImage Utils", sb5.toString());
        final StringBuilder sb6 = new StringBuilder();
        sb6.append("getPrefferredDirectoryPath ");
        sb6.append(s2);
        Log.e("SaveImage Utils", sb6.toString());
        return s2;
    }

    public static String getPrefferredDirectoryPathEx(final Context context) {
        final StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()));
        sb.append(context.getResources().getString(R.string.directory));
        final String string = sb.toString();
        final String string2 = PreferenceManager.getDefaultSharedPreferences(context).getString("save_image_directory_custom", (String) null);
        if (string2 != null) {
            final StringBuilder sb2 = new StringBuilder(String.valueOf(string2));
            sb2.append(File.separator);
            return sb2.toString();
        }
        return string;
    }
}
