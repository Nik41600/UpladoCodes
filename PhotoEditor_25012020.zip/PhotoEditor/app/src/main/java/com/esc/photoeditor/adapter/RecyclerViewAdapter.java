package com.esc.photoeditor.adapter;

import android.annotation.SuppressLint;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.esc.photoeditor.R;

@SuppressLint({"InflateParams"})
public class RecyclerViewAdapter extends Adapter<RecyclerViewAdapter.ViewHolder> implements OnClickListener {
    int colorDefault;
    int colorSelected;
    public int[] iconList;
    RecyclerAdapterIndexChangedListener listener;
    int proIndex = 100;
    RecyclerView recylceView;
    private int selectedIndex;
    SelectedIndexChangedListener selectedIndexChangedListener;
    View selectedListItem;

    public interface RecyclerAdapterIndexChangedListener {
        void onIndexChanged(int i);
    }

    public interface SelectedIndexChangedListener {
        void selectedIndexChanged(int i);
    }

    public static class ViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder {
        public ImageView imageView;
        RecyclerAdapterIndexChangedListener viewHolderListener;

        public void setRecyclerAdapterIndexChangedListener(RecyclerAdapterIndexChangedListener recyclerAdapterIndexChangedListener) {
            this.viewHolderListener = recyclerAdapterIndexChangedListener;
        }

        public void setItem(int i) {
            this.imageView.setImageResource(i);
        }

        public ViewHolder(View view) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.filter_image);
        }
    }

    public RecyclerViewAdapter(int[] iArr, RecyclerAdapterIndexChangedListener recyclerAdapterIndexChangedListener, int i, int i2, int i3) {
        this.iconList = iArr;
        this.listener = recyclerAdapterIndexChangedListener;
        this.colorDefault = i;
        this.colorSelected = i2;
        this.proIndex = i3;
    }

    public void setSelectedIndexChangedListener(SelectedIndexChangedListener selectedIndexChangedListener) {
        this.selectedIndexChangedListener = selectedIndexChangedListener;
    }

    public int getSelectedIndex() {
        return this.selectedIndex;
    }

    public void setSelectedIndex(int i) {
        this.selectedIndex = i;
        this.selectedIndexChangedListener.selectedIndexChanged(this.selectedIndex);
    }

    public void setData(int[] iArr) {
        this.iconList = iArr;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.viewitem, null);
        ViewHolder viewHolder = new ViewHolder(inflate);
        viewHolder.setRecyclerAdapterIndexChangedListener(this.listener);
        inflate.setOnClickListener(this);
        return viewHolder;
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.setItem(this.iconList[i]);
        if (this.selectedIndex == i) {
            viewHolder.itemView.setBackgroundResource(this.colorSelected);
        } else {
            viewHolder.itemView.setBackgroundResource(this.colorDefault);
        }
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        this.recylceView = recyclerView;
    }

    public void setSelectedView(int i) {
        if (this.selectedListItem != null) {
            this.selectedListItem.setBackgroundResource(this.colorDefault);
        }
        this.selectedListItem = this.recylceView.getChildAt(i);
        if (this.selectedListItem != null) {
            this.selectedListItem.setBackgroundResource(this.colorSelected);
        }
        setSelectedIndex(i);
    }

    public void onClick(View view) {
        int childPosition = this.recylceView.getChildPosition(view);
        android.support.v7.widget.RecyclerView.ViewHolder findViewHolderForPosition = this.recylceView.findViewHolderForPosition(this.selectedIndex);
        if (findViewHolderForPosition != null) {
            View view2 = findViewHolderForPosition.itemView;
            if (view2 != null) {
                view2.setBackgroundResource(this.colorDefault);
            }
        }
        this.selectedIndex = childPosition;
        this.selectedIndexChangedListener.selectedIndexChanged(this.selectedIndex);
        view.setBackgroundResource(this.colorSelected);
        this.selectedListItem = view;
        this.listener.onIndexChanged(childPosition);
    }

    public int getItemCount() {
        return this.iconList.length;
    }
}