package com.esc.photoeditor.utils;

public interface OnItemSelected
{
  void itemSelected(final int p0);
}
