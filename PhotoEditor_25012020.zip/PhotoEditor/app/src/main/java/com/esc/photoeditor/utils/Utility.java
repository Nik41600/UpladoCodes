package com.esc.photoeditor.utils;

import android.util.*;
import android.content.*;
import android.os.*;

public class Utility
{
  private static String TAG = "CALL";
  private static final float limitDivider = 60.0f;
  private static final float limitDividerGinger = 160.0f;

  private static int getDefaultLimit(int n, final float n2) {
    n = (int)(n2 / Math.sqrt(n));
    final String tag = Utility.TAG;
    final StringBuilder sb = new StringBuilder();
    sb.append("limit = ");
    sb.append(n);
    Log.e(tag, sb.toString());
    return n;
  }

  public static double getLeftSizeOfMemory() {
    return Runtime.getRuntime().maxMemory() - (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) - Debug.getNativeHeapAllocatedSize();
  }

  public static void logFreeMemory(final Context context) {
    final String tag = Utility.TAG;
    final StringBuilder sb = new StringBuilder();
    sb.append("free memory own method = ");
    sb.append(getLeftSizeOfMemory() / 1048576.0);
    Log.e(tag, sb.toString());
  }

  public static int maxSizeForDimension(final Context context, final int n, float n2) {
    float n3;
    if (Build.VERSION.SDK_INT <= 11) {
      n3 = 800.0f;
      n2 = 160.0f;
    }
    else {
      final float n4 = 60.0f;
      n3 = n2;
      n2 = n4;
    }
    final String tag = Utility.TAG;
    final StringBuilder sb = new StringBuilder();
    sb.append("divider = ");
    sb.append(n2);
    Log.e(tag, sb.toString());
    int defaultLimit;
    if ((defaultLimit = (int)Math.sqrt(getLeftSizeOfMemory() / (n * n2))) <= 0) {
      defaultLimit = getDefaultLimit(n, n3);
    }
    return Math.min(defaultLimit, getDefaultLimit(n, n3));
  }
}
