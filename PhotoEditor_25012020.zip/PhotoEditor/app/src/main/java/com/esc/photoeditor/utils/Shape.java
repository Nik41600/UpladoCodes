package com.esc.photoeditor.utils;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Xfermode;
import android.graphics.drawable.NinePatchDrawable;
import android.util.Log;

import com.esc.photoeditor.collagelist.Collage;

public class Shape {
    public static final int MATRIX_MODE_MOVE_DOWN = 13;
    public static final int MATRIX_MODE_MOVE_LEFT = 10;
    public static final int MATRIX_MODE_MOVE_RIGHT = 11;
    public static final int MATRIX_MODE_MOVE_UP = 12;
    public static final int MATRIX_MODE_ROTATE_POSITIVE = 7;
    public static final int MATRIX_MODE_ZOOM_IN = 8;
    public static final int MATRIX_MODE_ZOOM_OUT = 9;
    public static final int MESSAGE_DEFAULT = 0;
    public static final int MESSAGE_MAX_BOTTOM = 6;
    public static final int MESSAGE_MAX_LEFT = 3;
    public static final int MESSAGE_MAX_RIGHT = 4;
    public static final int MESSAGE_MAX_TOP = 5;
    public static final int MESSAGE_MAX_ZOOM = 1;
    public static final int MESSAGE_MIN_ZOOM = 2;
    private static final String TAG = "Shape";
    static final int[] scrapBookRotation;
    public final int SHAPE_MODE_MASK;
    public final int SHAPE_MODE_POINT;
    public final int SHAPE_MODE_RECT;
    private Bitmap bitmap;
    int bitmapHeight;
    public Matrix bitmapMatrix;
    RectF bitmapRect;
    int bitmapWidth;
    Paint borderPaint;
    int borderStrokeWidth;
    public RectF bounds;
    Bitmap btmDelete;
    Bitmap btmScale;
    PointF centerOriginal;
    Paint dashPaint;
    Path dashPathHorizontal;
    Path dashPathVertical;
    int delW;
    float deleteWidthHalf;
    float dx;
    float dy;
    int[] exceptionIndex;
    float[] floats1;
    float[] floats;
    public RectF f508r;
    Paint iconMaskPaint;
    Paint iconPaint;
    Xfermode iconXferMode;
    Matrix inverse;
    boolean isScrapBook;
    private Bitmap maskBitmap;
    private Matrix maskMatrix;
    Paint maskPaint;
    float maxScale;
    float minScale;
    NinePatchDrawable npd;
    int npdPadding;
    int offsetX;
    int offsetY;
    RectF originalBounds;
    Path originalPath;
    private Paint paintPath;
    Paint paintScrap;
    private Paint paintTransparent;
    Paint paintXferMode;
    Path path;
    Matrix pathMatrix;
    PointF[] points;
    float[] pts;
    public Region region;
    Matrix removeBitmapMatrix;
    Matrix scaleBitmapMatrix;
    float scaleDown;
    float scaleUp;
    float scrapBookPadding;
    int screenWidth;
    int shapeMode;
    RectF sourceRect;
    final float tempRadius;
    RectF tempRect;
    final float tempScrapBookPadding;
    float tempTouchStrokeWidth;
    Paint touchPaint;
    RectF touchRect;
    float touchStrokeWidth;
    Matrix transparentMaskMatrix;
    float[] values;

    static {
        scrapBookRotation = new int[]{13, -13, -7, -12, 11, 8, -9, 10, 9};
    }

    public Shape(final PointF[] points, final Bitmap bitmap, final int[] exceptionIndex, final int offsetX, final int offsetY, final Bitmap maskBitmap, final boolean isScrapBook, final int n, final boolean b, final Bitmap btmDelete, final Bitmap btmScale, final int screenWidth) {
        this.offsetY = 0;
        this.offsetX = 0;
        this.SHAPE_MODE_POINT = 1;
        this.SHAPE_MODE_RECT = 2;
        this.SHAPE_MODE_MASK = 3;
        this.maskBitmap = null;
        this.maskMatrix = new Matrix();
        this.transparentMaskMatrix = new Matrix();
        this.tempRect = new RectF();
        this.f508r = new RectF();
        this.minScale = 1.0f;
        this.maxScale = 1.0f;
        this.bitmapRect = new RectF();
        this.floats = new float[2];
        this.dx = 0.0f;
        this.dy = 0.0f;
        this.scaleDown = 0.95f;
        this.scaleUp = 1.05f;
        this.floats1 = new float[2];
        this.centerOriginal = new PointF();
        this.touchPaint = new Paint(1);
        this.borderPaint = new Paint(1);
        this.paintScrap = new Paint(2);
        this.pts = new float[2];
        this.inverse = new Matrix();
        this.tempScrapBookPadding = 25.0f;
        this.scrapBookPadding = 25.0f;
        this.tempTouchStrokeWidth = 8.0f;
        this.touchStrokeWidth = this.tempTouchStrokeWidth;
        this.values = new float[9];
        this.tempRadius = 60.0f;
        this.borderStrokeWidth = 6;
        this.dashPaint = new Paint();
        this.delW = 0;
        this.deleteWidthHalf = 0.0f;
        this.npdPadding = 16;
        this.maskBitmap = maskBitmap;
        this.points = points;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.btmDelete = btmDelete;
        this.btmScale = btmScale;
        this.screenWidth = screenWidth;
        this.isScrapBook = isScrapBook;
        this.createPathFromPoints();
        this.path.offset((float) offsetX, (float) offsetY);
        this.exceptionIndex = exceptionIndex;
        this.bitmap = bitmap;
        this.bitmapWidth = this.bitmap.getWidth();
        this.bitmapHeight = this.bitmap.getHeight();
        this.shapeMode = 3;
        this.init(isScrapBook, n, false, 0, 0);
    }

    public Shape(final PointF[] points, final Bitmap bitmap, final int[] exceptionIndex, final int offsetX, final int offsetY, final boolean isScrapBook, final int n, final boolean b, final Bitmap btmDelete, final Bitmap btmScale, final int screenWidth) {
        this.offsetY = 0;
        this.offsetX = 0;
        this.SHAPE_MODE_POINT = 1;
        this.SHAPE_MODE_RECT = 2;
        this.SHAPE_MODE_MASK = 3;
        this.maskBitmap = null;
        this.maskMatrix = new Matrix();
        this.transparentMaskMatrix = new Matrix();
        this.tempRect = new RectF();
        this.f508r = new RectF();
        this.minScale = 1.0f;
        this.maxScale = 1.0f;
        this.bitmapRect = new RectF();
        this.floats = new float[2];
        this.dx = 0.0f;
        this.dy = 0.0f;
        this.scaleDown = 0.95f;
        this.scaleUp = 1.05f;
        this.floats1 = new float[2];
        this.centerOriginal = new PointF();
        this.touchPaint = new Paint(1);
        this.borderPaint = new Paint(1);
        this.paintScrap = new Paint(2);
        this.pts = new float[2];
        this.inverse = new Matrix();
        this.tempScrapBookPadding = 25.0f;
        this.scrapBookPadding = 25.0f;
        this.tempTouchStrokeWidth = 8.0f;
        this.touchStrokeWidth = this.tempTouchStrokeWidth;
        this.values = new float[9];
        this.tempRadius = 60.0f;
        this.borderStrokeWidth = 6;
        this.dashPaint = new Paint();
        this.delW = 0;
        this.deleteWidthHalf = 0.0f;
        this.npdPadding = 16;
        this.points = points;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.btmDelete = btmDelete;
        this.btmScale = btmScale;
        this.screenWidth = screenWidth;
        this.isScrapBook = isScrapBook;
        this.createPathFromPoints();
        this.path.offset((float) offsetX, (float) offsetY);
        this.exceptionIndex = exceptionIndex;
        this.bitmap = bitmap;
        this.bitmapWidth = this.bitmap.getWidth();
        this.bitmapHeight = this.bitmap.getHeight();
        this.shapeMode = 1;
        this.init(isScrapBook, n, false, 0, 0);
    }

    private float getBitmapScale() {
        final float n = this.bounds.width() / this.bitmapWidth;
        final float n2 = this.bounds.height() / this.bitmapHeight;
        if (n < n2) {
            return n2;
        }
        return n;
    }

    private void setBitmapPosition() {
        final float bitmapScale = this.getBitmapScale();
        final float top = this.bounds.top;
        final float n = (this.bitmapHeight * bitmapScale - this.bounds.height()) / 2.0f;
        final float left = this.bounds.left;
        final float n2 = (this.bitmapWidth * bitmapScale - this.bounds.width()) / 2.0f;
        (this.bitmapMatrix = new Matrix()).reset();
        this.bitmapMatrix.postScale(bitmapScale, bitmapScale);
        this.bitmapMatrix.postTranslate(left - n2, top - n);
        if (this.shapeMode == 3) {
            this.setMaskBitmapPositions();
        }
        this.setMaxMinScales(bitmapScale);
    }

    private void setMaskBitmapPositions() {
        if (this.maskBitmap != null) {
            final int width = this.maskBitmap.getWidth();
            final int height = this.maskBitmap.getHeight();
            final float width2 = this.bounds.width();
            final float n = width;
            final float n2 = width2 / n;
            final float height2 = this.bounds.height();
            final float n3 = height;
            final float n4 = height2 / n3;
            float n5 = n2;
            if (n2 > n4) {
                n5 = n4;
            }
            final float top = this.bounds.top;
            final float n6 = (n3 * n5 - this.bounds.height()) / 2.0f;
            final float left = this.bounds.left;
            final float n7 = (n * n5 - this.bounds.width()) / 2.0f;
            (this.maskMatrix = new Matrix()).reset();
            this.maskMatrix.postScale(n5, n5);
            this.maskMatrix.postTranslate(left - n7, top - n6);
            final float n8 = this.originalBounds.width() / n;
            final float n9 = this.originalBounds.height() / n3;
            float n10 = n8;
            if (n8 > n9) {
                n10 = n9;
            }
            final float top2 = this.originalBounds.top;
            final float n11 = (n3 * n10 - this.originalBounds.height()) / 2.0f;
            final float left2 = this.originalBounds.left;
            final float n12 = (n * n10 - this.originalBounds.width()) / 2.0f;
            (this.transparentMaskMatrix = new Matrix()).reset();
            this.transparentMaskMatrix.postScale(n10, n10);
            this.transparentMaskMatrix.postTranslate(left2 - n12, top2 - n11);
        }
    }

    private void setScrapBookBitmapPosition(int i, final boolean b, int n, int n2) {
        if (!b) {
            this.bitmapMatrix = new Matrix();
            this.setMatrixFit();
            final float scale = this.getScale();
            this.setMaxMinScales(scale);
            final float n3 = 1.0f / scale;
            this.touchStrokeWidth = this.tempTouchStrokeWidth * n3;
            this.scrapBookPadding = 25.0f * n3;
            this.bitmapMatrix.postRotate((float) Shape.scrapBookRotation[i], this.bounds.left + this.bounds.width() / 2.0f, this.bounds.top + this.bounds.height() / 2.0f);
            this.touchRect = new RectF(-this.scrapBookPadding, -this.scrapBookPadding, this.bitmapWidth + this.scrapBookPadding, this.bitmapHeight + this.scrapBookPadding);
            this.touchPaint.setColor(1290417);
            this.touchPaint.setFilterBitmap(true);
            this.touchPaint.setStyle(Paint.Style.STROKE);
            this.touchPaint.setStrokeWidth(this.touchStrokeWidth);
            this.borderPaint.setColor(-1);
            this.borderPaint.setStyle(Paint.Style.STROKE);
            this.borderPaint.setStrokeWidth((float) this.borderStrokeWidth);
            this.borderPaint.setAntiAlias(true);
            return;
        }
        final int bitmapWidth = this.bitmapWidth;
        final int bitmapHeight = this.bitmapHeight;
        final float[] array = new float[8];
        i = 0;
        array[1] = (array[0] = 0.0f);
        final float n4 = bitmapWidth;
        array[2] = n4;
        array[3] = 0.0f;
        array[4] = n4;
        final float n5 = bitmapHeight;
        array[5] = n5;
        array[6] = 0.0f;
        array[7] = n5;
        this.bitmapMatrix.mapPoints(array);
        final RectF rectF = new RectF((float) this.offsetX, (float) this.offsetY, (float) (this.offsetX + n), (float) (this.offsetY + n2));
        if (rectF.contains(array[0], array[1])) {
            return;
        }
        if (rectF.contains(array[2], array[3])) {
            return;
        }
        if (rectF.contains(array[4], array[5])) {
            return;
        }
        if (rectF.contains(array[6], array[7])) {
            return;
        }
        final PointF pointF = new PointF((float) this.offsetX, (float) this.offsetY);
        final PointF pointF2 = new PointF((float) (this.offsetX + n), (float) this.offsetY);
        final PointF pointF3 = new PointF();
        if (array[1] < this.offsetY) {
            pointF3.set(array[0], array[1]);
            final float[] array2 = new float[4];
            array2[0] = this.pointToLineDistance(pointF, pointF2, pointF3);
            final StringBuilder sb = new StringBuilder();
            sb.append("0  ");
            sb.append(this.distToSegment(pointF3, pointF, pointF2));
            Log.e("Shape", sb.toString());
            pointF3.set(array[2], array[3]);
            array2[1] = this.pointToLineDistance(pointF, pointF2, pointF3);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("1  ");
            sb2.append(this.distToSegment(pointF3, pointF, pointF2));
            Log.e("Shape", sb2.toString());
            pointF3.set(array[4], array[5]);
            array2[2] = this.pointToLineDistance(pointF, pointF2, pointF3);
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("2  ");
            sb3.append(this.distToSegment(pointF3, pointF, pointF2));
            Log.e("Shape", sb3.toString());
            pointF3.set(array[6], array[7]);
            array2[3] = this.pointToLineDistance(pointF, pointF2, pointF3);
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("3  ");
            sb4.append(this.distToSegment(pointF3, pointF, pointF2));
            Log.e("Shape", sb4.toString());
            float n6 = array2[0];
            n2 = 1;
            n = i;
            float n7;
            StringBuilder sb5;
            for (i = n2; i < 4; ++i, n6 = n7) {
                n7 = n6;
                if (array2[i] < n6) {
                    n7 = array2[i];
                    n = i;
                }
                sb5 = new StringBuilder();
                sb5.append("fi  ");
                sb5.append(array2[i]);
                Log.e("Shape", sb5.toString());
            }
            this.bitmapMatrix.postTranslate(0.0f, this.offsetY + 120 - array[n * 2 + 1]);
            return;
        }
        final PointF pointF4 = new PointF((float) this.offsetX, (float) (this.offsetY + n2));
        final PointF pointF5 = new PointF((float) (this.offsetX + n), (float) (this.offsetY + n2));
        pointF3.set(array[0], array[1]);
        final float[] array3 = new float[4];
        array3[0] = this.pointToLineDistance(pointF4, pointF5, pointF3);
        final float x = pointF4.x;
        final float x2 = pointF5.x;
        final StringBuilder sb6 = new StringBuilder();
        sb6.append("0  ");
        sb6.append(this.distToSegment(pointF3, pointF4, pointF5));
        Log.e("Shape", sb6.toString());
        final float x3 = pointF3.x;
        pointF3.set(array[2], array[3]);
        array3[1] = this.pointToLineDistance(pointF4, pointF5, pointF3);
        final StringBuilder sb7 = new StringBuilder();
        sb7.append("1  ");
        sb7.append(this.distToSegment(pointF3, pointF4, pointF5));
        Log.e("Shape", sb7.toString());
        final float x4 = pointF3.x;
        pointF3.set(array[4], array[5]);
        array3[2] = this.pointToLineDistance(pointF4, pointF5, pointF3);
        final StringBuilder sb8 = new StringBuilder();
        sb8.append("2  ");
        sb8.append(this.distToSegment(pointF3, pointF4, pointF5));
        Log.e("Shape", sb8.toString());
        final float x5 = pointF3.x;
        pointF3.set(array[6], array[7]);
        array3[3] = this.pointToLineDistance(pointF4, pointF5, pointF3);
        final StringBuilder sb9 = new StringBuilder();
        sb9.append("3  ");
        sb9.append(this.distToSegment(pointF3, pointF4, pointF5));
        Log.e("Shape", sb9.toString());
        final float x6 = pointF3.x;
        float n8 = array3[0];
        final StringBuilder sb10 = new StringBuilder();
        sb10.append("bi  ");
        sb10.append(array3[0]);
        Log.e("Shape", sb10.toString());
        n = 0;
        float n9;
        StringBuilder sb11;
        for (i = 1; i < 4; ++i, n8 = n9) {
            n9 = n8;
            if (array3[i] < n8) {
                n9 = array3[i];
                n = i;
            }
            sb11 = new StringBuilder();
            sb11.append("bi  ");
            sb11.append(array3[i]);
            Log.e("Shape", sb11.toString());
        }
        final StringBuilder sb12 = new StringBuilder();
        sb12.append("minIndex  ");
        sb12.append(n);
        Log.e("Shape", sb12.toString());
        final StringBuilder sb13 = new StringBuilder();
        sb13.append(" points[minIndex*2+1] ");
        i = n * 2 + 1;
        sb13.append(array[i]);
        Log.e("Shape", sb13.toString());
        final StringBuilder sb14 = new StringBuilder();
        sb14.append("translate ");
        sb14.append(this.offsetY + n2 - 120 - array[i]);
        Log.e("Shape", sb14.toString());
        this.bitmapMatrix.postTranslate(0.0f, this.offsetY + n2 - 120 - array[i]);
    }

    public void bitmapMatrixRotate(final float n) {
        this.floats[0] = this.bitmapWidth / 2;
        this.floats[1] = this.bitmapHeight / 2;
        this.bitmapMatrix.mapPoints(this.floats);
        this.bitmapMatrix.postRotate(n, this.floats[0], this.floats[1]);
    }

    public void bitmapMatrixScale(final float n, final float n2, final float n3, final float n4) {
        this.bitmapMatrix.postScale(n, n2, n3, n4);
        this.checkScaleBoundries();
    }

    public void bitmapMatrixScaleScrapBook(final float n, final float n2) {
        this.floats[0] = this.bitmapWidth / 2;
        this.floats[1] = this.bitmapHeight / 2;
        this.bitmapMatrix.mapPoints(this.floats);
        this.bitmapMatrix.postScale(n, n2, this.floats[0], this.floats[1]);
        this.checkScaleBoundries();
    }

    public void bitmapMatrixTranslate(final float n, final float n2) {
        this.bitmapMatrix.postTranslate(n, n2);
        if (!this.isScrapBook) {
            this.checkBoundries();
        }
    }

    public void bitmapMatrixgGetValues(final float[] array) {
        this.bitmapMatrix.getValues(array);
    }

    public void changeRatio(final PointF[] points, final int[] exceptionIndex, final int offsetX, final int offsetY, final boolean b, final int n, final int n2, final int n3) {
        this.points = points;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.createPathFromPoints();
        this.path.offset((float) offsetX, (float) offsetY);
        this.exceptionIndex = exceptionIndex;
        this.init(b, n, true, n2, n3);
    }

    public void checkBoundries() {
        final RectF bitmapRect = this.bitmapRect;
        final float n = this.bitmapWidth;
        final float n2 = this.bitmapHeight;
        float n3 = 0.0f;
        bitmapRect.set(0.0f, 0.0f, n, n2);
        this.bitmapMatrix.mapRect(this.bitmapRect);
        float n4;
        if (this.bitmapRect.left > this.bounds.left) {
            n4 = this.bounds.left - this.bitmapRect.left;
        } else {
            n4 = 0.0f;
        }
        if (this.bitmapRect.top > this.bounds.top) {
            n3 = this.bounds.top - this.bitmapRect.top;
        }
        if (this.bitmapRect.right < this.bounds.right) {
            n4 = this.bounds.right - this.bitmapRect.right;
        }
        if (this.bitmapRect.bottom < this.bounds.bottom) {
            n3 = this.bounds.bottom - this.bitmapRect.bottom;
        }
        this.bitmapMatrix.postTranslate(n4, n3);
    }

    float checkRange(final float n, final float n2, final float n3) {
        if (n > n3) {
            return n - n2;
        }
        if (n < n3) {
            return n + n2;
        }
        return n;
    }

    public void checkScaleBoundries() {
        final float scale = this.getScale();
        if (scale < this.minScale) {
            this.bitmapMatrix.postScale(this.minScale / scale, this.minScale / scale, this.floats[0], this.floats[1]);
        }
        if (scale > this.maxScale) {
            this.bitmapMatrix.postScale(this.maxScale / scale, this.maxScale / scale, this.floats[0], this.floats[1]);
        }
    }

    public void checkScaleBounds() {
        this.setMinScales(this.getBitmapScale());
        this.checkScaleBoundries();
    }

    void createPathFromPoints() {
        (this.path = new Path()).setFillType(Path.FillType.EVEN_ODD);
        this.path.moveTo(this.points[0].x, this.points[0].y);
        for (int i = 1; i < this.points.length; ++i) {
            this.path.lineTo(this.points[i].x, this.points[i].y);
        }
        this.path.lineTo(this.points[0].x, this.points[0].y);
        this.path.close();
    }

    void createPathFromRect() {
        (this.path = new Path()).addRect(this.sourceRect, Path.Direction.CCW);
    }

    float dist2(final PointF pointF, final PointF pointF2) {
        return this.sqr(pointF.x - pointF2.x) + this.sqr(pointF.y - pointF2.y);
    }

    public float distToSegment(final PointF pointF, final PointF pointF2, final PointF pointF3) {
        return (float) Math.sqrt(this.distToSegmentSquared(pointF, pointF2, pointF3));
    }

    float distToSegmentSquared(final PointF pointF, final PointF pointF2, final PointF pointF3) {
        final float dist2 = this.dist2(pointF2, pointF3);
        if (dist2 == 0.0f) {
            return this.dist2(pointF, pointF2);
        }
        final float n = ((pointF.x - pointF2.x) * (pointF3.x - pointF2.x) + (pointF.y - pointF2.y) * (pointF3.y - pointF2.y)) / dist2;
        if (n < 0.0f) {
            return this.dist2(pointF, pointF2);
        }
        if (n > 1.0f) {
            return this.dist2(pointF, pointF3);
        }
        return this.dist2(pointF, new PointF(pointF2.x + (pointF3.x - pointF2.x) * n, pointF2.y + (pointF3.y - pointF2.y) * n));
    }

    public void drawShape(final Canvas canvas, int saveLayer, final int n, final int n2, final boolean b) {
        if (b) {
            if (this.shapeMode != 3) {
                canvas.drawPath(this.originalPath, this.paintTransparent);
            } else if (this.maskBitmap != null && !this.maskBitmap.isRecycled()) {
                canvas.drawBitmap(this.maskBitmap, this.transparentMaskMatrix, this.paintTransparent);
            }
            canvas.restoreToCount(n2);
        }
        this.f508r.set(0.0f, 0.0f, (float) this.bitmapWidth, (float) this.bitmapHeight);
        this.bitmapMatrix.mapRect(this.f508r);
        saveLayer = canvas.saveLayer(this.f508r, (Paint) null, 31);
        if (this.shapeMode != 3) {
            canvas.drawPath(this.path, this.paintPath);
        } else if (this.maskBitmap != null && !this.maskBitmap.isRecycled()) {
            canvas.drawBitmap(this.maskBitmap, this.maskMatrix, this.maskPaint);
        }
        canvas.drawBitmap(this.bitmap, this.bitmapMatrix, this.paintXferMode);
        canvas.restoreToCount(saveLayer);
    }

    public void drawShapeForSave(final Canvas canvas, int saveLayer, final int n, final int n2, final boolean b) {
        if (b) {
            if (this.shapeMode != 3) {
                canvas.drawPath(this.originalPath, this.paintTransparent);
            } else if (this.maskBitmap != null && !this.maskBitmap.isRecycled()) {
                canvas.drawBitmap(this.maskBitmap, this.transparentMaskMatrix, this.paintTransparent);
            }
            canvas.restoreToCount(n2);
        }
        final RectF rectF = new RectF(0.0f, 0.0f, (float) (this.bitmapWidth + 0), (float) (this.bitmapHeight + 0));
        this.bitmapMatrix.mapRect(rectF);
        saveLayer = canvas.saveLayer(rectF, (Paint) null, 31);
        if (this.shapeMode != 3) {
            canvas.drawPath(this.path, this.paintPath);
        } else if (this.maskBitmap != null && !this.maskBitmap.isRecycled()) {
            canvas.drawBitmap(this.maskBitmap, this.maskMatrix, this.maskPaint);
        }
        canvas.drawBitmap(this.bitmap, this.bitmapMatrix, this.paintXferMode);
        canvas.restoreToCount(saveLayer);
    }

    public void drawShapeForScrapBook(final Canvas canvas, final int n, final int n2, final boolean b, final boolean b2) {
        canvas.save();
        canvas.concat(this.bitmapMatrix);
        this.npd.setBounds(-this.npdPadding - this.borderStrokeWidth, -this.npdPadding - this.borderStrokeWidth, this.bitmapWidth + this.npdPadding + this.borderStrokeWidth, this.bitmapHeight + this.npdPadding + this.borderStrokeWidth);
        this.npd.draw(canvas);
        canvas.drawBitmap(this.bitmap, 0.0f, 0.0f, this.paintScrap);
        if (b) {
            this.touchStrokeWidth = this.tempTouchStrokeWidth * (1.0f / this.getScale());
            this.touchPaint.setStrokeWidth(this.touchStrokeWidth);
            canvas.drawRect(this.touchRect, this.touchPaint);
            this.setDelAndScaleBitmapMatrix();
            if (this.btmDelete != null && !this.btmDelete.isRecycled()) {
                canvas.drawBitmap(this.btmDelete, this.removeBitmapMatrix, this.touchPaint);
            }
            if (this.btmScale != null && !this.btmScale.isRecycled()) {
                canvas.drawBitmap(this.btmScale, this.scaleBitmapMatrix, this.touchPaint);
            }
            if (b2) {
                canvas.drawPath(this.dashPathVertical, this.dashPaint);
                canvas.drawPath(this.dashPathHorizontal, this.dashPaint);
            }
        }
        canvas.drawRect((float) (-this.borderStrokeWidth / 2), (float) (-this.borderStrokeWidth / 2), (float) (this.bitmapWidth + this.borderStrokeWidth / 2), (float) (this.bitmapHeight + this.borderStrokeWidth / 2), this.borderPaint);
        canvas.restore();
    }

    void drawShapeIcon(final Canvas canvas, int saveLayer, final int n, final int n2, final boolean b) {
        this.setMaskBitmapPositions();
        this.path.offset((float) (-this.offsetX), (float) (-this.offsetY));
        this.originalPath.offset((float) (-this.offsetX), (float) (-this.offsetY));
        this.maskMatrix.postTranslate((float) (-this.offsetX), (float) (-this.offsetY));
        this.transparentMaskMatrix.postTranslate((float) (-this.offsetX), (float) (-this.offsetY));
        if (b) {
            if (this.shapeMode == 3) {
                canvas.drawBitmap(this.maskBitmap, this.transparentMaskMatrix, this.paintTransparent);
            } else {
                canvas.drawPath(this.originalPath, this.paintTransparent);
            }
            canvas.restoreToCount(n2);
        }
        if (this.shapeMode == 3) {
            saveLayer = canvas.saveLayer(0.0f, 0.0f, (float) saveLayer, (float) n, (Paint) null, 31);
            canvas.drawBitmap(this.maskBitmap, this.maskMatrix, this.iconPaint);
            canvas.drawBitmap(this.maskBitmap, this.maskMatrix, this.iconMaskPaint);
            canvas.restoreToCount(saveLayer);
            return;
        }
        canvas.drawPath(this.path, this.iconPaint);
    }

    void drawShapeIcon2(final Canvas canvas, int saveLayer, final int n) {
        this.path.offset((float) (-this.offsetX), (float) (-this.offsetY));
        this.originalPath.offset((float) (-this.offsetX), (float) (-this.offsetY));
        this.maskMatrix.postTranslate((float) (-this.offsetX), (float) (-this.offsetY));
        this.transparentMaskMatrix.postTranslate((float) (-this.offsetX), (float) (-this.offsetY));
        final Paint paint = new Paint();
        if (this.shapeMode == 3) {
            final float n2 = saveLayer;
            final float n3 = n;
            saveLayer = canvas.saveLayer(0.0f, 0.0f, n2, n3, (Paint) null, 31);
            canvas.drawBitmap(this.maskBitmap, this.transparentMaskMatrix, paint);
            paint.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            canvas.drawRect(0.0f, 0.0f, n2, n3, paint);
            paint.setXfermode((Xfermode) null);
            canvas.restoreToCount(saveLayer);
            return;
        }
        canvas.drawPath(this.path, this.iconPaint);
    }

    public void freeBitmaps() {
        if (this.bitmap != null && !this.bitmap.isRecycled()) {
            this.bitmap.recycle();
        }
        if (this.maskBitmap != null && !this.maskBitmap.isRecycled()) {
            this.maskBitmap = null;
        }
    }

    public Bitmap getBitmap() {
        return this.bitmap;
    }

    PointF getCenterOfImage() {
        if (this.centerOriginal == null) {
            this.centerOriginal = new PointF();
        }
        if (this.floats1 == null) {
            this.floats1 = new float[2];
        }
        final float n = this.bitmapHeight / 2.0f;
        this.floats1[0] = this.bitmapWidth / 2.0f;
        this.floats1[1] = n;
        this.bitmapMatrix.mapPoints(this.floats1);
        this.centerOriginal.set(this.floats1[0], this.floats1[1]);
        return this.centerOriginal;
    }

    public float[] getMappedCenter() {
        this.pts[0] = this.bitmapWidth / 2;
        this.pts[1] = this.bitmapHeight / 2;
        this.bitmapMatrix.mapPoints(this.pts, this.pts);
        return this.pts;
    }

    public Bitmap getMaskBitmap() {
        return this.maskBitmap;
    }

    public float getScale() {
        this.bitmapMatrix.getValues(this.values);
        final float n = this.values[0];
        final float n2 = this.values[3];
        final float n3 = (float) Math.sqrt(n * n + n2 * n2);
        if (n3 <= 0.0f) {
            return 1.0f;
        }
        return n3;
    }

    public void init(final boolean b, final int n, final boolean b2, final int n2, final int n3) {
        this.bounds = new RectF();
        this.originalPath = new Path(this.path);
        this.path.computeBounds(this.bounds, true);
        this.originalBounds = new RectF(this.bounds);
        (this.paintXferMode = new Paint(1)).setFilterBitmap(true);
        this.paintXferMode.setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        (this.paintPath = new Paint(1)).setFilterBitmap(true);
        (this.maskPaint = new Paint(1)).setFilterBitmap(true);
        (this.paintTransparent = new Paint(1)).setXfermode((Xfermode) new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        this.paintTransparent.setFilterBitmap(true);
        if (b) {
            this.setScrapBookBitmapPosition(n, b2, n2, n3);
        } else {
            this.setBitmapPosition();
        }
        this.paintPath.setPathEffect((PathEffect) new CornerPathEffect(3.0f));
        this.pathMatrix = new Matrix();
        (this.region = new Region()).setPath(this.path, new Region((int) this.bounds.left, (int) this.bounds.top, (int) this.bounds.right, (int) this.bounds.bottom));
        if (b) {
            this.dashPaint.setColor(7829368);
            this.dashPaint.setStyle(Paint.Style.STROKE);
            float strokeWidth;
            if ((strokeWidth = this.screenWidth / 120.0f) <= 0.0f) {
                strokeWidth = 5.0f;
            }
            this.dashPaint.setStrokeWidth(strokeWidth);
            this.dashPaint.setPathEffect((PathEffect) new DashPathEffect(new float[]{strokeWidth, strokeWidth}, 0.0f));
            (this.dashPathVertical = new Path()).moveTo((float) (this.bitmapWidth / 2), (float) (-this.bitmapHeight / 5));
            this.dashPathVertical.lineTo((float) (this.bitmapWidth / 2), (float) (this.bitmapHeight * 6 / 5));
            (this.dashPathHorizontal = new Path()).moveTo((float) (-this.bitmapWidth / 5), (float) (this.bitmapHeight / 2));
            this.dashPathHorizontal.lineTo((float) (this.bitmapWidth * 6 / 5), (float) (this.bitmapHeight / 2));
        }
    }

    public void initIcon(final int n, final int n2) {
        (this.iconPaint = new Paint(1)).setFilterBitmap(true);
        this.iconPaint.setColor(7829368);
        this.paintXferMode.setColor(7829368);
        this.scalePath(5.0f, n, n2);
        (this.iconMaskPaint = new Paint(1)).setFilterBitmap(true);
        this.iconMaskPaint.setColor(7829368);
        this.iconXferMode = (Xfermode) new PorterDuffXfermode(PorterDuff.Mode.SRC_IN);
        this.iconMaskPaint.setXfermode(this.iconXferMode);
    }

    public void initScrapBook(final NinePatchDrawable ninePatch) {
        this.setNinePatch(ninePatch);
    }

    public boolean isInCircle(float n, float n2) {
        this.pts[0] = n;
        this.pts[1] = n2;
        this.bitmapMatrix.invert(this.inverse);
        this.inverse.mapPoints(this.pts, this.pts);
        n = this.pts[0];
        n2 = this.pts[1];
        final float scale = this.getScale();
        return (n - this.touchRect.right) * (n - this.touchRect.right) + (n2 - this.touchRect.bottom) * (n2 - this.touchRect.bottom) < this.deleteWidthHalf * this.deleteWidthHalf / (scale * scale);
    }

    public boolean isOnCross(float n, float n2) {
        this.pts[0] = n;
        this.pts[1] = n2;
        this.bitmapMatrix.invert(this.inverse);
        this.inverse.mapPoints(this.pts, this.pts);
        n = this.pts[0];
        n2 = this.pts[1];
        final float scale = this.getScale();
        return (n - this.touchRect.left) * (n - this.touchRect.left) + (n2 - this.touchRect.top) * (n2 - this.touchRect.top) < this.deleteWidthHalf * this.deleteWidthHalf / (scale * scale);
    }

    public boolean isScrapBookSelected(float n, float n2) {
        this.pts[0] = n;
        this.pts[1] = n2;
        this.inverse.reset();
        this.bitmapMatrix.invert(this.inverse);
        this.inverse.mapPoints(this.pts, this.pts);
        n = this.pts[0];
        n2 = this.pts[1];
        return n >= 0.0f && n <= this.bitmapWidth && n2 >= 0.0f && n2 <= this.bitmapHeight;
    }

    void pathTransform(final PointF[] array, final Path path, final float n, float n2, float n3) {
        n2 -= this.offsetX;
        n3 -= this.offsetY;
        path.rewind();
        path.setFillType(Path.FillType.EVEN_ODD);
        final int length = array.length;
        final float[] array2 = new float[length];
        for (int i = 0; i < length; ++i) {
            array2[i] = n;
        }
        if (this.exceptionIndex != null) {
            for (int j = 0; j < this.exceptionIndex.length; ++j) {
                array2[this.exceptionIndex[j]] = 2.0f * n;
            }
        }
        path.moveTo(this.checkRange(array[0].x, array2[0], n2), this.checkRange(array[0].y, n, n3));
        for (int k = 1; k < length; ++k) {
            path.lineTo(this.checkRange(array[k].x, array2[k], n2), this.checkRange(array[k].y, n, n3));
        }
        path.lineTo(this.checkRange(array[0].x, array2[0], n2), this.checkRange(array[0].y, n, n3));
        path.close();
        path.offset((float) this.offsetX, (float) this.offsetY);
    }

    void pathTransformFromRect(final float n) {
        this.tempRect.set(this.sourceRect.left + n, this.sourceRect.top + n, this.sourceRect.right - n, this.sourceRect.bottom - n);
        this.path.rewind();
        this.path.addRect(this.tempRect, Path.Direction.CCW);
    }

    public float pointToLineDistance(final PointF pointF, final PointF pointF2, final PointF pointF3) {
        return Math.abs((pointF3.x - pointF.x) * (pointF2.y - pointF.y) - (pointF3.y - pointF.y) * (pointF2.x - pointF.x)) / (float) Math.sqrt((pointF2.x - pointF.x) * (pointF2.x - pointF.x) + (pointF2.y - pointF.y) * (pointF2.y - pointF.y));
    }

    public void resetDashPaths() {
        if (this.dashPathVertical == null) {
            this.dashPathVertical = new Path();
        }
        this.dashPathVertical.reset();
        this.dashPathVertical.moveTo((float) (this.bitmapWidth / 2), (float) (-this.bitmapHeight / 5));
        this.dashPathVertical.lineTo((float) (this.bitmapWidth / 2), (float) (this.bitmapHeight * 6 / 5));
        if (this.dashPathHorizontal == null) {
            this.dashPathHorizontal = new Path();
        }
        this.dashPathHorizontal.reset();
        this.dashPathHorizontal.moveTo((float) (-this.bitmapWidth / 5), (float) (this.bitmapHeight / 2));
        this.dashPathHorizontal.lineTo((float) (6 * this.bitmapWidth / 5), (float) (this.bitmapHeight / 2));
    }

    public void scalePath(float n, float n2, final float n3) {
        if (this.shapeMode == 1) {
            this.pathTransform(this.points, this.path, n, this.originalBounds.centerX(), this.originalBounds.centerY());
        } else if (this.shapeMode == 2) {
            this.pathTransformFromRect(n);
        } else {
            n *= 2.0f;
            n2 = (n2 - n) / n2;
            n = (n3 - n) / n3;
            this.pathMatrix.reset();
            this.pathMatrix.setScale(n2, n, this.originalBounds.centerX(), this.originalBounds.centerY());
            this.originalPath.transform(this.pathMatrix, this.path);
        }
        this.path.computeBounds(this.bounds, true);
        if (this.shapeMode == 3) {
            this.setMaskBitmapPositions();
        }
    }

    public void setBitmap(final Bitmap bitmap, final boolean b) {
        this.bitmap = bitmap;
        this.bitmapWidth = bitmap.getWidth();
        this.bitmapHeight = bitmap.getHeight();
        if (!b) {
            this.setBitmapPosition();
        }
    }

    void setDelAndScaleBitmapMatrix() {
        if (this.removeBitmapMatrix == null) {
            this.removeBitmapMatrix = new Matrix();
        }
        if (this.scaleBitmapMatrix == null) {
            this.scaleBitmapMatrix = new Matrix();
        }
        this.removeBitmapMatrix.reset();
        this.scaleBitmapMatrix.reset();
        if (this.delW == 0 && this.btmDelete != null) {
            this.delW = this.btmDelete.getWidth();
        }
        if (this.screenWidth <= 0) {
            this.screenWidth = 720;
        }
        final float n = this.screenWidth / 20.0f * 2.0f / this.delW;
        this.deleteWidthHalf = this.delW * n / 1.4f;
        this.removeBitmapMatrix.postScale(n, n);
        this.removeBitmapMatrix.postTranslate(-this.scrapBookPadding - this.delW * n / 2.0f, -this.scrapBookPadding - this.delW * n / 2.0f);
        this.scaleBitmapMatrix.postScale(n, n);
        this.scaleBitmapMatrix.postTranslate(this.bitmapWidth + this.scrapBookPadding - this.delW * n / 2.0f, this.bitmapHeight + this.scrapBookPadding - this.delW * n / 2.0f);
        final float scale = this.getScale();
        final Matrix scaleBitmapMatrix = this.scaleBitmapMatrix;
        final float n2 = 1.0f / scale;
        scaleBitmapMatrix.postScale(n2, n2, this.touchRect.right, this.touchRect.bottom);
        this.removeBitmapMatrix.postScale(n2, n2, this.touchRect.left, this.touchRect.top);
        if (this.screenWidth > 0) {
            this.tempTouchStrokeWidth = this.screenWidth / 120.0f;
        }
    }

    void setMatrixFit() {
        float min;
        final float n = min = Math.min(this.bounds.width() / this.bitmapWidth, this.bounds.height() / this.bitmapHeight);
        if (this.isScrapBook) {
            min = n * Collage.scrapBookShapeScale;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Collage.scrapBookShapeScale ");
        sb.append(Collage.scrapBookShapeScale);
        Log.e("Shape", sb.toString());
        final float top = this.bounds.top;
        final float n2 = (this.bounds.height() - this.bitmapHeight * min) / 2.0f;
        final float left = this.bounds.left;
        final float n3 = (this.bounds.width() - this.bitmapWidth * min) / 2.0f;
        this.bitmapMatrix.reset();
        this.bitmapMatrix.postScale(min, min);
        this.bitmapMatrix.postTranslate(left + n3, top + n2);
    }

    void setMaxMinScales(final float minScale) {
        if (this.isScrapBook) {
            this.minScale = minScale / 2.0f;
        } else {
            this.minScale = minScale;
        }
        if (this.isScrapBook) {
            this.maxScale = minScale * 2.0f;
            return;
        }
        this.maxScale = 4.0f * minScale;
    }

    void setMinScales(final float minScale) {
        if (this.isScrapBook) {
            this.minScale = minScale / 2.0f;
            return;
        }
        this.minScale = minScale;
    }

    public void setNinePatch(final NinePatchDrawable npd) {
        this.npd = npd;
        this.touchRect.round(new Rect());
    }

    public void setRadius(final CornerPathEffect cornerPathEffect) {
        this.paintPath.setPathEffect((PathEffect) cornerPathEffect);
        this.paintTransparent.setPathEffect((PathEffect) cornerPathEffect);
    }

    public int setScaleMatrix(final int n) {
        if (this.dx <= 0.5f) {
            this.dx = this.bitmapWidth / 100.0f;
        }
        if (this.dy <= 0.5f) {
            this.dy = this.bitmapHeight / 100.0f;
        }
        final PointF centerOfImage = this.getCenterOfImage();
        if (n == 0) {
            this.setMatrixFit();
        } else if (n == 1) {
            this.setBitmapPosition();
        } else if (n == 3) {
            this.bitmapMatrix.postRotate(-90.0f, centerOfImage.x, centerOfImage.y);
        } else if (n == 2) {
            this.bitmapMatrix.postRotate(90.0f, centerOfImage.x, centerOfImage.y);
        } else if (n == 4) {
            this.bitmapMatrix.postScale(-1.0f, 1.0f, centerOfImage.x, centerOfImage.y);
        } else if (n == 5) {
            this.bitmapMatrix.postScale(1.0f, -1.0f, centerOfImage.x, centerOfImage.y);
        } else if (n == 6) {
            this.bitmapMatrix.postRotate(-10.0f, centerOfImage.x, centerOfImage.y);
        } else if (n == 7) {
            this.bitmapMatrix.postRotate(10.0f, centerOfImage.x, centerOfImage.y);
        } else if (n == 8) {
            if (this.getScale() >= this.maxScale) {
                return 1;
            }
            this.bitmapMatrix.postScale(this.scaleUp, this.scaleUp, centerOfImage.x, centerOfImage.y);
        } else if (n == 9) {
            if (this.getScale() <= this.minScale) {
                return 2;
            }
            this.bitmapMatrix.postScale(this.scaleDown, this.scaleDown, centerOfImage.x, centerOfImage.y);
        } else if (n == 10) {
            this.bitmapRect.set(0.0f, 0.0f, (float) this.bitmapWidth, (float) this.bitmapHeight);
            this.bitmapMatrix.mapRect(this.bitmapRect);
            if (this.bitmapRect.right <= this.bounds.right && !this.isScrapBook) {
                return 3;
            }
            this.bitmapMatrix.postTranslate(-this.dx, 0.0f);
        } else if (n == 11) {
            this.bitmapRect.set(0.0f, 0.0f, (float) this.bitmapWidth, (float) this.bitmapHeight);
            this.bitmapMatrix.mapRect(this.bitmapRect);
            if (this.bitmapRect.left >= this.bounds.left && !this.isScrapBook) {
                return 4;
            }
            this.bitmapMatrix.postTranslate(this.dx, 0.0f);
        } else if (n == 12) {
            this.bitmapRect.set(0.0f, 0.0f, (float) this.bitmapWidth, (float) this.bitmapHeight);
            this.bitmapMatrix.mapRect(this.bitmapRect);
            if (this.bitmapRect.bottom <= this.bounds.bottom && !this.isScrapBook) {
                return 5;
            }
            this.bitmapMatrix.postTranslate(0.0f, -this.dy);
        } else if (n == 13) {
            this.bitmapRect.set(0.0f, 0.0f, (float) this.bitmapWidth, (float) this.bitmapHeight);
            this.bitmapMatrix.mapRect(this.bitmapRect);
            if (this.bitmapRect.top >= this.bounds.top && !this.isScrapBook) {
                return 6;
            }
            this.bitmapMatrix.postTranslate(0.0f, this.dy);
        }
        this.checkScaleBoundries();
        if (!this.isScrapBook) {
            this.checkBoundries();
        }
        return 0;
    }

    public float smallestDistance() {
        float n = 1500.0f;
        for (int i = 0; i < this.points.length; ++i) {
            float n2;
            for (int j = 0; j < this.points.length; ++j, n = n2) {
                n2 = n;
                if (i != j) {
                    final float n3 = Math.abs(this.points[i].x - this.points[j].x) + Math.abs(this.points[i].y - this.points[j].y);
                    n2 = n;
                    if (n3 < n) {
                        n2 = n3;
                    }
                }
            }
        }
        return n;
    }

    float sqr(final float n) {
        return n * n;
    }
}
