package com.esc.photoeditor.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.ViewFlipper;
import android.widget.ViewSwitcher;

import com.commit451.nativestackblur.NativeStackBlur;
import com.esc.photoeditor.adapter.RecyclerViewAdapter;
import com.esc.photoeditor.adapter.RecyclerViewAdapter.RecyclerAdapterIndexChangedListener;
import com.esc.photoeditor.adapter.RecyclerViewAdapter.SelectedIndexChangedListener;
import com.esc.photoeditor.fragments.FragmentFullEffect.HideHeaderListener;
import com.esc.photoeditor.utils.Analytics;
import com.esc.photoeditor.utils.Analytics.Param;
import com.esc.photoeditor.utils.LibUtility;
import com.esc.photoeditor.utils.LibUtility.ExcludeTabListener;
import com.esc.photoeditor.utils.LibUtility.FooterVisibilityListener;
import com.esc.photoeditor.utils.Parameter;
import com.esc.photoeditor.widget.SeekBarHint;
import com.esc.photoeditor.R;

public class FragmentEffect extends Fragment {
    public static final int INDEX_BLUR = 10;
    public static final int INDEX_BRIGHTNESS = 4;
    public static final int INDEX_CONTRAST = 6;
    public static final int INDEX_FRAME = 1;
    public static final int INDEX_FX = 0;
    public static final int INDEX_LIGHT = 2;
    public static final int INDEX_SATURATION = 7;
    public static final int INDEX_SHARPEN = 9;
    public static final int INDEX_TEXTURE = 3;
    public static final int INDEX_TINT = 8;
    public static final int INDEX_WARMTH = 5;
    public static final int TAB_SIZE = 14;
    static final String TAG = "FragmentEffect";
    private static String[] filterBitmapTitle = new String[]{"None", "Gray", "Sepia", "Joey", "Sancia", "Blair", "Sura", "Tara", "Summer", "Penny", "Cuddy", "Cameron", "Lemon", "Tanya", "Lorelai", "Quinn", "Izabella", "Amber", "Cersei", "Debra", "Ellen", "Gabrielle", "Arya"};
    public Paint paint;
    public Paint paint1;
    public Paint paint2;
    public Paint paint3;
    public Paint paint4;
    Activity activity;
    Analytics analytics;
    int bitmapHeight;
    BitmapReady bitmapReadyListener;
    Bitmap bitmapTiltBlur;
    int bitmapWidth;
    RecyclerViewAdapter borderAdapter;
    RecyclerAdapterIndexChangedListener borderIndexChangedListener = null;
    Button buttonAdjustmentLabel;
    public Paint bwPaint;
    public Paint coldlifePaint;
    Context context;
    public Paint cyanPaint;
    public Paint darkenPaint;
    ExcludeTabListener excludeTabListener;
    RecyclerViewAdapter filterAdapter;
    Bitmap filterBitmap;
    FooterVisibilityListener footerListener;
    FilterAndAdjustmentTask ft;
    public Paint grayPaint;
    HideHeaderListener hideHeaderListener;
    boolean inFilterAndAdjustment = false;
    public Paint invertPaint;
    public Paint lightenPaint;
    public Paint limePaint;
    public Paint milkPaint;
    OnSeekBarChangeListener mySeekBarListener = new OnSeekBarChangeListener() {
        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            if (FragmentEffect.this.textHint == null) {
                FragmentEffect.this.textHint = (TextView) FragmentEffect.this.getView().findViewById(R.id.seekbar_hint);
            }
            if (FragmentEffect.this.seekbarHintTextLayoutParams == null) {
                FragmentEffect.this.seekbarHintTextLayoutParams = (LayoutParams) FragmentEffect.this.textHint.getLayoutParams();
            }
            Rect bounds = ((SeekBarHint) seekBar).getSeekBarThumb().getBounds();
            FragmentEffect.this.textHint.setText(String.valueOf(i));
            FragmentEffect.this.textHint.getPaint().getTextBounds(FragmentEffect.this.textHint.getText().toString(), 0, FragmentEffect.this.textHint.getText().length(), FragmentEffect.this.seekbarHintTextBounds);
            FragmentEffect.this.seekbarHintTextLayoutParams.setMargins(bounds.centerX() - (FragmentEffect.this.seekbarHintTextBounds.width() / 2), 0, 0, 0);
            FragmentEffect.this.textHint.setLayoutParams(FragmentEffect.this.seekbarHintTextLayoutParams);
            if (FragmentEffect.this.parameterGlobal.seekBarMode == 0) {
                FragmentEffect.this.parameterGlobal.setBrightness(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 1) {
                FragmentEffect.this.parameterGlobal.setContrast(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 2) {
                FragmentEffect.this.parameterGlobal.setTemperature(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 3) {
                FragmentEffect.this.parameterGlobal.setSaturation(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 4) {
                FragmentEffect.this.parameterGlobal.setTint(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 5) {
                FragmentEffect.this.parameterGlobal.setSharpen(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 6) {
                FragmentEffect.this.parameterGlobal.setBlur(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 7) {
                FragmentEffect.this.parameterGlobal.setHighlight(i);
            } else if (FragmentEffect.this.parameterGlobal.seekBarMode == 8) {
                FragmentEffect.this.parameterGlobal.setShadow(i);
            }
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            if (FragmentEffect.this.textHint == null) {
                FragmentEffect.this.textHint = (TextView) FragmentEffect.this.getView().findViewById(R.id.seekbar_hint);
            }
            FragmentEffect.this.textHint.setVisibility(View.VISIBLE);
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            if (FragmentEffect.this.textHint == null) {
                FragmentEffect.this.textHint = (TextView) FragmentEffect.this.getView().findViewById(R.id.seekbar_hint);
            }
            FragmentEffect.this.textHint.setVisibility(View.INVISIBLE);
            FragmentEffect.this.callBack();
        }
    };
    public Paint oldtimesPaint;
    RecyclerViewAdapter overlayAdapter;
    Parameter parameterBackUp = new Parameter();
    public Parameter parameterGlobal;
    public Paint peachyPaint;
    public Paint polaroidPaint;
    public Paint purplePaint;
    public Paint scrimPaint;
    SeekBar seekbarAdjustment;
    Rect seekbarHintTextBounds = new Rect();
    LayoutParams seekbarHintTextLayoutParams;
    int selectedTab = 0;
    public Paint sepiaPaint;
    public Paint sepiumPaint;
    private Animation slideLeftIn;
    private Animation slideLeftOut;
    private Animation slideRightIn;
    private Animation slideRightOut;
    private Bitmap sourceBitmap;
    ImageView[] tabButtonList;
    TextView textHint;
    RecyclerViewAdapter textureAdapter;
    int thumbSize;
    ViewFlipper viewFlipper;
    private ViewSwitcher viewSwitcher;
    public Paint yellowPaint;

    public interface BitmapReady {
        void onBitmapReady(Bitmap bitmap);
    }

    class FilterAndAdjustmentTask extends AsyncTask<Void, Void, Void> {
        ProgressDialog progressDialog;

        FilterAndAdjustmentTask() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            FragmentEffect.this.inFilterAndAdjustment = true;
            try {
                this.progressDialog = new ProgressDialog(FragmentEffect.this.context);
                this.progressDialog.setMessage("Please Wait...");
                this.progressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public Void doInBackground(Void... voidArr) {
            if (FragmentEffect.this.isAdded()) {
                if (FragmentEffect.this.filterBitmap == null) {
                    FragmentEffect.this.filterBitmap = FragmentEffect.this.sourceBitmap.copy(Config.ARGB_8888, true);
                } else {
                    new Canvas(FragmentEffect.this.filterBitmap).drawBitmap(FragmentEffect.this.sourceBitmap, 0.0f, 0.0f, new Paint());
                }
                new Canvas(FragmentEffect.this.filterBitmap).drawBitmap(FragmentEffect.this.sourceBitmap, 0.0f, 0.0f, new Paint());
                if (FragmentEffect.this.parameterGlobal.blur > 0 && VERSION.SDK_INT > 17) {
                    Bitmap copy = FragmentEffect.this.sourceBitmap.copy(FragmentEffect.this.sourceBitmap.getConfig(), true);
                    FragmentEffect.this.filterBitmap = NativeStackBlur.process(copy, FragmentEffect.this.parameterGlobal.blur);
                }
                if (FragmentEffect.this.isAdded()) {
                    pipeline(FragmentEffect.this.filterBitmap);
                } else {
                    cancel(true);
                    FragmentEffect.this.inFilterAndAdjustment = false;
                }
            } else {
                FragmentEffect.this.inFilterAndAdjustment = false;
            }
            return null;
        }

        public void onPostExecute(Void voidR) {
            super.onPostExecute(voidR);
            FragmentEffect.this.inFilterAndAdjustment = false;
            try {
                this.progressDialog.dismiss();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (FragmentEffect.this.isAdded()) {
                FragmentEffect.this.bitmapReadyListener.onBitmapReady(FragmentEffect.this.filterBitmap);
            }
        }
        public void pipeline(Bitmap bitmap) {
            if (FragmentEffect.this.parameterGlobal.selectedFilterIndex <= 22) {
                FragmentEffect.this.setFilter(FragmentEffect.this.parameterGlobal.selectedFilterIndex, bitmap);
            }
            Bitmap overlayBitmap = FragmentEffect.this.getOverlayBitmap(FragmentEffect.this.parameterGlobal.selectedOverlayIndex);
            if (!(overlayBitmap == null || overlayBitmap.isRecycled())) {
                if (VERSION.SDK_INT > 10) {
                    FragmentEffect.this.applyOverlay11(overlayBitmap, bitmap, FragmentEffect.isOverlayScreenMode(FragmentEffect.this.parameterGlobal.selectedOverlayIndex));
                } else if (FragmentEffect.isOverlayScreenMode(FragmentEffect.this.overlayAdapter.getSelectedIndex()) != 0) {
                    FragmentEffect.this.applyOverlay11(overlayBitmap, bitmap, FragmentEffect.isOverlayScreenMode(FragmentEffect.this.parameterGlobal.selectedOverlayIndex));
                }
            }
            FragmentEffect.this.filterMultiply(bitmap, FragmentEffect.this.parameterGlobal.selectedTextureIndex, false);
            if (FragmentEffect.this.borderIndexChangedListener == null) {
                FragmentEffect.this.setBorder(bitmap, FragmentEffect.this.parameterGlobal.selectedBorderIndex, false);
            }
            Canvas canvas = new Canvas(bitmap);
            if (FragmentEffect.this.parameterGlobal.selectedFilterIndex < 22) {
                canvas.drawBitmap(bitmap, 0.0f, 0.0f, new Paint());
            }
        }
    }

    static int getBorderMode(int i) {
        return 0;
    }

    static int isOverlayScreenMode(int i) {
        return i == 2 ? 2 : 1;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.thumbSize = (int) getResources().getDimension(R.dimen.lib_thumb_save_size);
        return layoutInflater.inflate(R.layout.horizontal_fragment_effect, viewGroup, false);
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.putParcelable(getString(R.string.effect_parameter_bundle_name), this.parameterGlobal);
        super.onSaveInstanceState(bundle);
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        if (bundle != null) {
            this.parameterGlobal = (Parameter) bundle.getParcelable(getString(R.string.effect_parameter_bundle_name));
        } else if (getArguments() != null) {
            this.parameterGlobal = (Parameter) getArguments().getParcelable(getString(R.string.effect_parameter_bundle_name));
        }
        if (this.parameterGlobal == null) {
            this.parameterGlobal = new Parameter();
        }
        this.context = getActivity();
        this.activity = getActivity();
        this.analytics = new Analytics(this.activity);
        PaintInit();
        AdapterInit();
        this.viewSwitcher = (ViewSwitcher) getView().findViewById(R.id.viewswitcher);
        String str = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("viewSwitcher getDisplayedChild");
        stringBuilder.append(this.viewSwitcher.getDisplayedChild());
        Log.e(str, stringBuilder.toString());
        this.viewFlipper = (ViewFlipper) getView().findViewById(R.id.control_container);
        this.slideLeftIn = AnimationUtils.loadAnimation(this.activity, R.anim.slide_in_left);
        this.slideLeftOut = AnimationUtils.loadAnimation(this.activity, R.anim.slide_out_left);
        this.slideRightIn = AnimationUtils.loadAnimation(this.activity, R.anim.slide_in_right);
        this.slideRightOut = AnimationUtils.loadAnimation(this.activity, R.anim.slide_out_right);
        this.buttonAdjustmentLabel = (Button) getView().findViewById(R.id.buttonAdjustmentLabel);
        SelectedTab(this.selectedTab);
        this.viewSwitcher.setDisplayedChild(1);
        TabBg(this.selectedTab);
        if (this.excludeTabListener != null) {
            this.excludeTabListener.exclude();
        }
        if (this.footerListener != null) {
            this.footerListener.setVisibility();
        }
        this.seekbarAdjustment = (SeekBar) getView().findViewById(R.id.seekbarAdjustment);
        this.seekbarAdjustment.setOnSeekBarChangeListener(this.mySeekBarListener);
    }
    public void PaintInit() {
        this.sepiaPaint = new Paint();
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.set(new float[]{0.393f, 0.769f, 0.189f, 0.0f, 0.0f, 0.349f, 0.686f, 0.168f, 0.0f, 0.0f, 0.272f, 0.534f, 0.131f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f});
        this.sepiaPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.grayPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0.0f);
        this.grayPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.invertPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{-1.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, -1.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, -1.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.invertPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.polaroidPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{2.0f, 0.0f, 0.0f, 0.0f, -130.0f, 0.0f, 2.0f, 0.0f, 0.0f, -130.0f, 0.0f, 0.0f, 2.0f, 0.0f, -130.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.polaroidPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.scrimPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{5.0f, 0.0f, 0.0f, 0.0f, -254.0f, 0.0f, 5.0f, 0.0f, 0.0f, -254.0f, 0.0f, 0.0f, 5.0f, 0.0f, -254.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.scrimPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.paint4 = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.paint4.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.paint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{-0.36f, 1.691f, -0.32f, 0.0f, 0.0f, 0.325f, 0.398f, 0.275f, 0.0f, 0.0f, 0.79f, 0.796f, -0.76f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.paint1 = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{-0.41f, 0.539f, -0.873f, 0.0f, 0.0f, 0.452f, 0.666f, -0.11f, 0.0f, 0.0f, -0.3f, 1.71f, -0.4f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.paint1.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.paint2 = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{3.074f, -1.82f, -0.24f, 0.0f, 50.8f, -0.92f, 2.171f, -0.24f, 0.0f, 50.8f, -0.92f, -1.82f, 3.754f, 0.0f, 50.8f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.paint2.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.paint3 = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{0.14f, 0.45f, 0.05f, 0.0f, 0.0f, 0.12f, 0.39f, 0.04f, 0.0f, 0.0f, 0.08f, 0.28f, 0.03f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.paint3.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.purplePaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.0f, -0.2f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, -0.1f, 0.0f, 0.0f, 1.2f, 1.0f, 0.1f, 0.0f, 0.0f, 0.0f, 1.7f, 1.0f, 0.0f}));
        this.purplePaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.yellowPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.2f, 1.0f, 0.3f, 0.1f, 0.0f, -3.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.yellowPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.cyanPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.0f, 0.0f, 0.0f, 1.9f, -2.2f, 0.0f, 1.0f, 0.0f, 0.0f, 0.3f, 3.0f, 0.0f, 1.0f, 0.0f, 0.5f, 0.0f, 0.0f, 0.0f, 1.0f, 0.2f}));
        this.cyanPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.bwPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f}));
        this.bwPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.oldtimesPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.4f, 1.3f, -0.4f, 0.2f, -0.1f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.oldtimesPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.coldlifePaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, -0.2f, 0.2f, 0.1f, 0.4f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.coldlifePaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.sepiumPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.3f, -0.3f, 1.1f, 0.0f, 0.0f, 0.0f, 1.3f, 0.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.2f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.sepiumPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.milkPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.milkPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.limePaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.limePaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.peachyPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.peachyPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.lightenPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{1.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.lightenPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        this.darkenPaint = new Paint();
        colorMatrix = new ColorMatrix();
        colorMatrix.set(new ColorMatrix(new float[]{0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.darkenPaint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
    }


    private void AdapterInit() {
        RecyclerViewAdapter.RecyclerAdapterIndexChangedListener borderIndexChangedListener = new RecyclerViewAdapter.RecyclerAdapterIndexChangedListener() {
            @Override
            public void onIndexChanged(final int n) {
                FragmentEffect.this.applyChangesOnBitmap();
            }
        };
        if (this.borderIndexChangedListener != null) {
            borderIndexChangedListener = this.borderIndexChangedListener;
        }
        this.borderAdapter = new RecyclerViewAdapter(LibUtility.borderResThumb, borderIndexChangedListener, R.color.background_color, R.color.footer_button_color_pressed, 100);
        this.borderAdapter.setSelectedIndexChangedListener(new SelectedIndexChangedListener() {
            public void selectedIndexChanged(int i) {
                String str = FragmentEffect.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("selectedIndexChanged ");
                stringBuilder.append(i);
                Log.e(str, stringBuilder.toString());
                FragmentEffect.this.parameterGlobal.selectedBorderIndex = i;
            }
        });
        this.textureAdapter = new RecyclerViewAdapter(LibUtility.textureResThumb, new RecyclerAdapterIndexChangedListener() {
            public void onIndexChanged(int i) {
                FragmentEffect.this.applyChangesOnBitmap();
            }
        }, R.color.background_color, R.color.footer_button_color_pressed, 100);
        this.textureAdapter.setSelectedIndexChangedListener(new SelectedIndexChangedListener() {
            public void selectedIndexChanged(int i) {
                FragmentEffect.this.parameterGlobal.selectedTextureIndex = i;
            }
        });
        this.overlayAdapter = new RecyclerViewAdapter(LibUtility.overlayResThumb, new RecyclerAdapterIndexChangedListener() {
            public void onIndexChanged(int i) {
                FragmentEffect.this.applyChangesOnBitmap();
            }
        }, R.color.background_color, R.color.footer_button_color_pressed, 100);
        this.overlayAdapter.setSelectedIndexChangedListener(new SelectedIndexChangedListener() {
            public void selectedIndexChanged(int i) {
                FragmentEffect.this.parameterGlobal.selectedOverlayIndex = i;
            }
        });
        this.filterAdapter = new RecyclerViewAdapter(LibUtility.filterResThumb, new RecyclerAdapterIndexChangedListener() {
            public void onIndexChanged(int i) {
                FragmentEffect.this.applyChangesOnBitmap();
            }
        }, R.color.background_color, R.color.footer_button_color_pressed, 100);
        this.filterAdapter.setSelectedIndexChangedListener(new SelectedIndexChangedListener() {
            public void selectedIndexChanged(int i) {
                FragmentEffect.this.parameterGlobal.selectedFilterIndex = i;
            }
        });
        RecyclerView recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerViewBorder);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.context);
        linearLayoutManager.setOrientation(0);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(this.borderAdapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerViewTexture);
        linearLayoutManager = new LinearLayoutManager(this.context);
        linearLayoutManager.setOrientation(0);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(this.textureAdapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerViewOverlay);
        linearLayoutManager = new LinearLayoutManager(this.context);
        linearLayoutManager.setOrientation(0);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(this.overlayAdapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerViewFilter);
        linearLayoutManager = new LinearLayoutManager(this.context);
        linearLayoutManager.setOrientation(0);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(this.filterAdapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.textureAdapter.setSelectedView(this.parameterGlobal.selectedTextureIndex);
        this.borderAdapter.setSelectedView(this.parameterGlobal.selectedBorderIndex);
        this.overlayAdapter.setSelectedView(this.parameterGlobal.selectedOverlayIndex);
        if (this.parameterGlobal.selectedFilterIndex >= this.filterAdapter.getItemCount()) {
            this.parameterGlobal.selectedFilterIndex = 0;
        }
        this.filterAdapter.setSelectedView(this.parameterGlobal.selectedFilterIndex);
    }

    private void TabBg(int i) {
        if (this.tabButtonList == null) {
            this.tabButtonList = new ImageView[14];
            this.tabButtonList[0] = (ImageView) getView().findViewById(R.id.buttonFX);
            this.tabButtonList[1] = (ImageView) getView().findViewById(R.id.buttonFrame);
            this.tabButtonList[2] = (ImageView) getView().findViewById(R.id.buttonLight);
            this.tabButtonList[3] = (ImageView) getView().findViewById(R.id.buttonTexture);
            this.tabButtonList[10] = (ImageView) getView().findViewById(R.id.buttonBlur);
        }
    }
    public void SelectedTab(int i) {
        this.viewSwitcher.setDisplayedChild(0);
        int displayedChild = this.viewFlipper.getDisplayedChild();
        if (i == 0) {
            TabBg(0);
            if (displayedChild != 0) {
                this.viewFlipper.setInAnimation(this.slideLeftIn);
                this.viewFlipper.setOutAnimation(this.slideRightOut);
                this.viewFlipper.setDisplayedChild(0);
            } else {
                return;
            }
        }
        if (i == 1) {
            TabBg(1);
            if (displayedChild != 1) {
                if (displayedChild == 0) {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                } else {
                    this.viewFlipper.setInAnimation(this.slideLeftIn);
                    this.viewFlipper.setOutAnimation(this.slideRightOut);
                }
                this.viewFlipper.setDisplayedChild(1);
            } else {
                return;
            }
        }
        if (i == 2) {
            TabBg(2);
            if (displayedChild != 2) {
                if (displayedChild == 3 || displayedChild == 4) {
                    this.viewFlipper.setInAnimation(this.slideLeftIn);
                    this.viewFlipper.setOutAnimation(this.slideRightOut);
                } else {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                }
                this.viewFlipper.setDisplayedChild(2);
            } else {
                return;
            }
        }
        if (i == 3) {
            TabBg(3);
            if (displayedChild != 3) {
                if (displayedChild == 4) {
                    this.viewFlipper.setInAnimation(this.slideLeftIn);
                    this.viewFlipper.setOutAnimation(this.slideRightOut);
                } else {
                    this.viewFlipper.setInAnimation(this.slideRightIn);
                    this.viewFlipper.setOutAnimation(this.slideLeftOut);
                }
                this.viewFlipper.setDisplayedChild(3);
            } else {
                return;
            }
        }
        if (i == 4 || i == 6 || i == 7 || i == 5 || i == 8 || i == 9 || i == 10) {
            TabBg(i);
            if (displayedChild != 4) {
                this.viewFlipper.setInAnimation(this.slideRightIn);
                this.viewFlipper.setOutAnimation(this.slideLeftOut);
                this.viewFlipper.setDisplayedChild(4);
            }
        }
    }

    public void setBitmapReadyListener(BitmapReady bitmapReady) {
        this.bitmapReadyListener = bitmapReady;
    }

    public void setHideHeaderListener(HideHeaderListener hideHeaderListener) {
        this.hideHeaderListener = hideHeaderListener;
    }

    public boolean showToolBar() {
        if (this.viewSwitcher.getDisplayedChild() != 0) {
            return false;
        }
        cancelViewSwitcher();
        this.viewSwitcher.setDisplayedChild(1);
        return true;
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.context = getActivity();
        this.activity = getActivity();
    }

    public void setBorderIndexChangedListener(RecyclerAdapterIndexChangedListener recyclerAdapterIndexChangedListener) {
        this.borderIndexChangedListener = recyclerAdapterIndexChangedListener;
    }

    public int getSelectedTabIndex() {
        return this.viewFlipper != null ? this.viewFlipper.getDisplayedChild() : -1;
    }

    public void setSelectedTabIndex(int i) {
        if (i >= 0 && i < 14) {
            this.selectedTab = i;
            if (getView() != null) {
                SelectedTab(i);
            }
        }
    }

    public void setSeekBarProgress() {
        int brightProgress = this.parameterGlobal.seekBarMode == 0 ? this.parameterGlobal.getBrightProgress() : this.parameterGlobal.seekBarMode == 1 ? this.parameterGlobal.getContrastProgress() : this.parameterGlobal.seekBarMode == 2 ? this.parameterGlobal.getTemperatureProgress() : this.parameterGlobal.seekBarMode == 3 ? this.parameterGlobal.saturation : this.parameterGlobal.seekBarMode == 4 ? this.parameterGlobal.getTintProgressValue() : this.parameterGlobal.seekBarMode == 5 ? this.parameterGlobal.getSharpenValue() : this.parameterGlobal.seekBarMode == 6 ? this.parameterGlobal.getBlurValue() : this.parameterGlobal.seekBarMode == 7 ? this.parameterGlobal.getHighlightValue() : this.parameterGlobal.seekBarMode == 8 ? this.parameterGlobal.getShadowValue() : 50;
        this.seekbarAdjustment.setProgress(brightProgress);
    }

    public void callBack() {
        execQueue();
    }

    public void setBitmap(Bitmap bitmap) {
        this.sourceBitmap = bitmap;
        this.bitmapWidth = this.sourceBitmap.getWidth();
        this.bitmapHeight = this.sourceBitmap.getHeight();
        this.filterBitmap = null;
    }

    public void setBitmapAndResetBlur(Bitmap bitmap) {
        setBitmap(bitmap);
        if (!(this.bitmapTiltBlur == null || this.bitmapTiltBlur.isRecycled())) {
            this.bitmapTiltBlur.recycle();
        }
        this.bitmapTiltBlur = null;
    }

    public void onDestroyView() {
        super.onDestroyView();
    }

    public synchronized void setBorder(Bitmap bitmap, int i, boolean z) {
        if (isAdded() && i != 0 && LibUtility.borderRes.length > i) {
            Bitmap decodeResource;
            Paint paint = new Paint(1);
            if (getBorderMode(i) == 1) {
                paint.setXfermode(new PorterDuffXfermode(Mode.MULTIPLY));
            }
            Matrix matrix = new Matrix();
            if (z) {
                decodeResource = BitmapFactory.decodeResource(getResources(), LibUtility.borderResThumb[i]);
            } else {
                decodeResource = BitmapFactory.decodeResource(getResources(), LibUtility.borderRes[i]);
            }
            float width = ((float) bitmap.getWidth()) / ((float) decodeResource.getWidth());
            float height = ((float) bitmap.getHeight()) / ((float) decodeResource.getHeight());
            matrix.reset();
            Canvas canvas = new Canvas(bitmap);
            matrix.postScale(width, height);
            canvas.drawBitmap(decodeResource, matrix, paint);
            if (!(decodeResource == null || bitmap == decodeResource)) {
                decodeResource.recycle();
            }
        }
    }

    @SuppressLint({"NewApi"})
    public void filterMultiply(Bitmap bitmap, int i, boolean z) {
        if (i != 0 && isAdded()) {
            Bitmap decodeResource;
            Paint paint = new Paint(1);
            Mode mode = Mode.SCREEN;
            if (LibUtility.textureModes[i] == LibUtility.MODE_MULTIPLY) {
                mode = Mode.MULTIPLY;
            } else if (LibUtility.textureModes[i] == LibUtility.MODE_OVERLAY && VERSION.SDK_INT > 10) {
                mode = Mode.OVERLAY;
            } else if (LibUtility.textureModes[i] == LibUtility.MODE_OVERLAY && VERSION.SDK_INT <= 10) {
                mode = Mode.MULTIPLY;
            }
            paint.setXfermode(new PorterDuffXfermode(mode));
            Matrix matrix = new Matrix();
            if (z) {
                decodeResource = BitmapFactory.decodeResource(getResources(), LibUtility.textureResThumb[i]);
            } else {
                Options options = new Options();
                if (LibUtility.getLeftSizeOfMemory() > 1.024E7d) {
                    options.inSampleSize = 1;
                } else {
                    options.inSampleSize = 2;
                }
                decodeResource = BitmapFactory.decodeResource(getResources(), LibUtility.textureRes[i], options);
            }
            float width = ((float) bitmap.getWidth()) / ((float) decodeResource.getWidth());
            float height = ((float) bitmap.getHeight()) / ((float) decodeResource.getHeight());
            matrix.reset();
            Canvas canvas = new Canvas(bitmap);
            matrix.postScale(width, height);
            canvas.drawBitmap(decodeResource, matrix, paint);
            if (decodeResource != null && bitmap != decodeResource) {
                decodeResource.recycle();
            }
        }
    }

    public Bitmap getOverlayBitmap(int i) {
        if (isAdded()) {
            Options options = new Options();
            options.inPreferredConfig = Config.ARGB_8888;
            if (LibUtility.getLeftSizeOfMemory() > 1.024E7d) {
                options.inSampleSize = 1;
            } else {
                options.inSampleSize = 2;
            }
            if (i > 0 && i < LibUtility.overlayDrawableList.length) {
                Bitmap copy;
                Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), LibUtility.overlayDrawableList[i], options);
                if (decodeResource.getConfig() != Config.ARGB_8888) {
                    copy = decodeResource.copy(Config.ARGB_8888, false);
                    if (copy != decodeResource) {
                        decodeResource.recycle();
                    }
                    decodeResource = copy;
                }
                int width = decodeResource.getWidth();
                int height = decodeResource.getHeight();
                if ((this.bitmapHeight <= this.bitmapWidth || height >= width) && (this.bitmapHeight >= this.bitmapWidth || height <= width)) {
                    return decodeResource;
                }
                Matrix matrix = new Matrix();
                matrix.postRotate(90.0f);
                copy = Bitmap.createBitmap(decodeResource, 0, 0, decodeResource.getWidth(), decodeResource.getHeight(), matrix, true);
                if (copy != decodeResource) {
                    decodeResource.recycle();
                }
                return copy;
            }
        }
        return null;
    }

    public void myClickHandler(int i) {
        if (i != R.id.buttonCancel) {
            this.parameterBackUp.set(this.parameterGlobal);
        }
        if (i == R.id.buttonFX) {
            if (this.analytics != null) {
                this.analytics.logEvent(Param.EDITOR_FILTER_FX, "");
            }
            SelectedTab(0);
        } else if (i == R.id.buttonFrame) {
            if (this.analytics != null) {
                this.analytics.logEvent(Param.EDITOR_FILTER_FRAME, "");
            }
            SelectedTab(1);
        } else if (i == R.id.buttonLight) {
            if (this.analytics != null) {
                this.analytics.logEvent(Param.EDITOR_FILTER_LIGHT, "");
            }
            SelectedTab(2);
        } else if (i == R.id.buttonTexture) {
            if (this.analytics != null) {
                this.analytics.logEvent(Param.EDITOR_FILTER_TEXTURE, "");
            }
            SelectedTab(3);
        } else if (i == R.id.buttonReset) {
            if (this.analytics != null) {
                this.analytics.logEvent(Param.EDITOR_FILTER_RESET, "");
            }
            resetParameters();
        } else if (i == R.id.buttonBlur) {
            if (this.analytics != null) {
                this.analytics.logEvent(Param.EDITOR_FILTER_RESET, "");
            }
            SelectedTab(10);
            this.parameterGlobal.seekBarMode = 6;
            setSeekBarProgress();
        } else if (i == R.id.buttonCancel) {
            cancelViewSwitcher();
            this.viewSwitcher.setDisplayedChild(1);
        } else if (i == R.id.buttonOk) {
            this.viewSwitcher.setDisplayedChild(1);
        }
    }

    @SuppressLint({"NewApi"})
    public void applyOverlay11(Bitmap bitmap, Bitmap bitmap2, int i) {
        Paint paint = new Paint(1);
        paint.setFilterBitmap(true);
        Mode mode = Mode.SCREEN;
        if (i == 0) {
            mode = Mode.OVERLAY;
        }
        Xfermode porterDuffXfermode = new PorterDuffXfermode(mode);
        if (i == 2) {
            porterDuffXfermode = null;
        }
        paint.setXfermode(porterDuffXfermode);
        Matrix matrix = new Matrix();
        float width = ((float) bitmap2.getWidth()) / ((float) bitmap.getWidth());
        float height = ((float) bitmap2.getHeight()) / ((float) bitmap.getHeight());
        matrix.reset();
        Canvas canvas = new Canvas(bitmap2);
        matrix.postScale(width, height);
        canvas.drawBitmap(bitmap, matrix, paint);
    }

    private void cancelViewSwitcher() {
        String str = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("parameterGlobal borderAdapter index ");
        stringBuilder.append(this.parameterGlobal.selectedBorderIndex);
        Log.e(str, stringBuilder.toString());
        str = TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("parameterBackUp index ");
        stringBuilder.append(this.parameterBackUp.selectedBorderIndex);
        Log.e(str, stringBuilder.toString());
        str = TAG;
        stringBuilder = new StringBuilder();
        stringBuilder.append("borderAdapter index ");
        stringBuilder.append(this.borderAdapter.getSelectedIndex());
        Log.e(str, stringBuilder.toString());
        if (this.parameterGlobal.isParameterReallyChanged(this.parameterBackUp)) {
            this.parameterGlobal.set(this.parameterBackUp);
            this.textureAdapter.setSelectedView(this.parameterGlobal.selectedTextureIndex);
            this.borderAdapter.setSelectedView(this.parameterGlobal.selectedBorderIndex);
            if (this.borderIndexChangedListener != null) {
                this.borderIndexChangedListener.onIndexChanged(this.parameterGlobal.selectedBorderIndex);
            }
            str = TAG;
            stringBuilder = new StringBuilder();
            stringBuilder.append("borderAdapter index ");
            stringBuilder.append(this.borderAdapter.getSelectedIndex());
            Log.e(str, stringBuilder.toString());
            this.overlayAdapter.setSelectedView(this.parameterGlobal.selectedOverlayIndex);
            if (this.parameterGlobal.selectedFilterIndex >= this.filterAdapter.getItemCount()) {
                this.parameterGlobal.selectedFilterIndex = 0;
            }
            this.filterAdapter.setSelectedView(this.parameterGlobal.selectedFilterIndex);
            execQueue();
        }
    }

    public void resetParameters() {
        this.parameterGlobal.reset();
        setAdjustmentSeekbarProgress();
    }

    public void setParameters(Parameter parameter) {
        this.parameterGlobal.set(parameter);
        setAdjustmentSeekbarProgress();
    }

    public void resetParametersWithoutChange() {
        this.parameterGlobal.reset();
        this.textureAdapter.setSelectedView(this.parameterGlobal.selectedTextureIndex);
        this.borderAdapter.setSelectedView(this.parameterGlobal.selectedBorderIndex);
        this.overlayAdapter.setSelectedView(this.parameterGlobal.selectedOverlayIndex);
        this.filterAdapter.setSelectedView(this.parameterGlobal.selectedFilterIndex);
        setSeekBarProgress();
    }

    public void setAdjustmentSeekbarProgress() {
        setSeekBarProgress();
        this.textureAdapter.setSelectedView(this.parameterGlobal.selectedTextureIndex);
        this.borderAdapter.setSelectedView(this.parameterGlobal.selectedBorderIndex);
        this.overlayAdapter.setSelectedView(this.parameterGlobal.selectedOverlayIndex);
        this.filterAdapter.setSelectedView(this.parameterGlobal.selectedFilterIndex);
        execQueue();
    }

    public void applyChangesOnBitmap() {
        this.parameterGlobal.selectedFilterIndex = this.filterAdapter.getSelectedIndex();
        this.parameterGlobal.selectedBorderIndex = this.borderAdapter.getSelectedIndex();
        this.parameterGlobal.selectedTextureIndex = this.textureAdapter.getSelectedIndex();
        this.parameterGlobal.selectedOverlayIndex = this.overlayAdapter.getSelectedIndex();
        execQueue();
    }

    public void execQueue() {
        if (this.ft == null || this.ft.getStatus() != AsyncTask.Status.RUNNING) {
            this.ft = new FilterAndAdjustmentTask();
            try {
                this.ft.execute(new Void[0]);
            } catch (Exception unused) {
            }
        }
    }

    public void setFilter(int i, Bitmap bitmap) {
        if (i >= filterBitmapTitle.length) {
            i = 0;
        }
        i--;
        if (VERSION.SDK_INT != 7 && i != -1) {
            if (i == 0) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.grayPaint);
            } else if (i == 1) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.sepiaPaint);
            } else if (i == 2) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.purplePaint);
            } else if (i == 3) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.yellowPaint);
            } else if (i == 4) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.milkPaint);
            } else if (i == 5) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.coldlifePaint);
            } else if (i == 6) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.bwPaint);
            } else if (i == 7) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.limePaint);
            } else if (i == 8) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.sepiumPaint);
            } else if (i == 9) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.oldtimesPaint);
            } else if (i == 10) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.cyanPaint);
            } else if (i == 11) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.polaroidPaint);
            } else if (i == 12) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.invertPaint);
            } else if (i == 13) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.paint);
            } else if (i == 14) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.paint3);
            } else if (i == 15) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.lightenPaint);
            } else if (i == 16) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.paint2);
            } else if (i == 17) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.scrimPaint);
            } else if (i == 18) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.paint1);
            } else if (i == 19) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.darkenPaint);
            } else if (i == 20) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.paint4);
            } else if (i == 21) {
                new Canvas(bitmap).drawBitmap(bitmap, 0.0f, 0.0f, this.peachyPaint);
            }
        }
    }
}