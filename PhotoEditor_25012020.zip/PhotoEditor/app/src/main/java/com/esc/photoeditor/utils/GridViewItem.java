package com.esc.photoeditor.utils;

import android.app.*;
import android.graphics.*;
import android.content.*;

public class GridViewItem
{
  Activity context;
  public String count;
  private String folderName;
  public long imageIdForThumb;
  private boolean isDirectory;
  int orientation;
  public int selectedItemCount;

  public GridViewItem(final Activity context, final String folderName, final String count, final boolean isDirectory, final long imageIdForThumb, final int orientation) {
    this.selectedItemCount = 0;
    this.folderName = folderName;
    this.isDirectory = isDirectory;
    this.count = count;
    this.context = context;
    this.imageIdForThumb = imageIdForThumb;
    this.orientation = orientation;
  }

  public String getFolderName() {
    return this.folderName;
  }

  public Bitmap getImage() {
    return GalleryImageUtility.getThumbnailBitmap((Context)this.context, this.imageIdForThumb, this.orientation);
  }

  public boolean isDirectory() {
    return this.isDirectory;
  }
}
