package com.esc.photoeditor.utils.canvastextview;

public interface ViewSelectedListener
{
  void setSelectedView(final CanvasTextView p0);
}
