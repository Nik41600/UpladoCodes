package com.esc.photoeditor.utils.sticker;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;

import com.esc.photoeditor.R;

import java.util.ArrayList;

public class Stickercontain extends AppCompatActivity {
    Button choose;
    ArrayList arrayList;
    FrameLayout frameLayout;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_stickercontain);
        this.arrayList = new ArrayList();
        this.choose = (Button) findViewById(R.id.choose);
        this.frameLayout = (FrameLayout) findViewById(R.id.sticker_view_container);
        this.choose.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Stickercontain.this.startActivity(new Intent(Stickercontain.this, StickerActivity.class));
            }
        });
        if (getIntent().getExtras() != null) {
            int[] intArray = getIntent().getExtras().getIntArray("MyArray");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("getIntent");
            stringBuilder.append(intArray.length);
            BitmapFactory.decodeResource(getResources(), R.drawable.sticker_remove_text);
            BitmapFactory.decodeResource(getResources(), R.drawable.sticker_scale_text);
            for (int i = 0; i < intArray.length; i++) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("");
                stringBuilder2.append(BitmapFactory.decodeResource(getResources(), intArray[i]));
                if (this.frameLayout == null) {
                    this.frameLayout = (FrameLayout) findViewById(R.id.sticker_view_container);
                }
                StickerImageView stickerImageView = new StickerImageView(this);
                stickerImageView.setImageBitmap(BitmapFactory.decodeResource(getResources(), intArray[i]));
                this.frameLayout.addView(stickerImageView);
            }
        }
    }
}