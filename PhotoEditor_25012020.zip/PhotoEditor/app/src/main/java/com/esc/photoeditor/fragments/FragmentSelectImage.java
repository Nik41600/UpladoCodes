package com.esc.photoeditor.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.esc.photoeditor.adapter.GridAdapter;
import com.esc.photoeditor.utils.AlbumItem;
import com.esc.photoeditor.utils.GalleryImageUtility;
import com.esc.photoeditor.utils.GridViewItem;
import com.esc.photoeditor.R;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.List;

public class FragmentSelectImage extends Fragment implements AdapterView.OnItemClickListener {
    public static int MAX_COLLAGE = 9;
    public static int MAX_SCRAPBOOK = 9;
    private static final String TAG = "GalleryActivity";
    int COLLAGE_IMAGE_LIMIT_MAX;
    int COLLAGE_IMAGE_LIMIT_MIN;
    Activity activity;
    AdView adView;
    com.google.android.gms.ads.AdView adWhirlLayout;
    GridAdapter adapter;
    List<AlbumItem> albumList;
    boolean collageSingleMode;
    Context context;
    TextView deleteAllTv;
    LinearLayout footer;
    GalleryListener galleryListener;
    Parcelable gridState;
    GridView gridView;
    TextView headerText;
    ImageView imageBack;
    boolean isOnBucket;
    public boolean isScrapBook;
    boolean isShape;
    com.google.android.gms.ads.AdView mAdView;
    TextView maxTv;
    TextView nextTv;
    View.OnClickListener onClickListener;
    TextView removeAllTv;
    int selectedBucketId;
    List<Long> selectedImageIdList;
    List<Integer> selectedImageOrientationList;
    Animation slideInLeft;

    public FragmentSelectImage() {
        this.COLLAGE_IMAGE_LIMIT_MAX = 9;
        this.COLLAGE_IMAGE_LIMIT_MIN = 0;
        this.collageSingleMode = false;
        this.isOnBucket = true;
        this.isScrapBook = false;
        this.selectedImageIdList = new ArrayList<Long>();
        this.selectedImageOrientationList = new ArrayList<Integer>();
        this.isShape = false;
        this.onClickListener = (View.OnClickListener) new View.OnClickListener() {
            public void onClick(View view) {
                final int id = view.getId();
                if (id == R.id.imageBack) {
                    FragmentSelectImage.this.backtrace();
                }

                if (id == R.id.imageView_delete) {
                    view = (View) view.getParent();
                    if (view == null || view.getParent() == null) {
                        return;
                    }
                    final int indexOfChild = ((ViewGroup) view.getParent()).indexOfChild(view);
                    FragmentSelectImage.this.footer.removeView(view);
                    final TextView deleteAllTv = FragmentSelectImage.this.deleteAllTv;
                    final StringBuilder sb = new StringBuilder();
                    sb.append("(");
                    sb.append(FragmentSelectImage.this.footer.getChildCount());
                    sb.append(")");
                    deleteAllTv.setText((CharSequence) sb.toString());
                    final long longValue = FragmentSelectImage.this.selectedImageIdList.remove(indexOfChild);
                    FragmentSelectImage.this.selectedImageOrientationList.remove(indexOfChild);
                    final Point itemById = FragmentSelectImage.this.findItemById(longValue);
                    if (itemById != null) {
                        final GridViewItem gridViewItem = FragmentSelectImage.this.albumList.get(itemById.x).gridItems.get(itemById.y);
                        --gridViewItem.selectedItemCount;
                        final int selectedItemCount = FragmentSelectImage.this.albumList.get(itemById.x).gridItems.get(itemById.y).selectedItemCount;
                        if (FragmentSelectImage.this.albumList.get(itemById.x).gridItems == FragmentSelectImage.this.adapter.items && FragmentSelectImage.this.gridView.getFirstVisiblePosition() <= itemById.y && itemById.y <= FragmentSelectImage.this.gridView.getLastVisiblePosition() && FragmentSelectImage.this.gridView.getChildAt(itemById.y) != null) {
                            final TextView textView = (TextView) FragmentSelectImage.this.gridView.getChildAt(itemById.y).findViewById(R.id.textViewSelectedItemCount);
                            final StringBuilder sb2 = new StringBuilder();
                            sb2.append("");
                            sb2.append(selectedItemCount);
                            textView.setText((CharSequence) sb2.toString());
                            if (selectedItemCount <= 0 && textView.getVisibility() == View.VISIBLE) {
                                textView.setVisibility(View.INVISIBLE);
                            }
                        }
                    }
                }
                if (id == R.id.gallery_delete_all && FragmentSelectImage.this.footer != null && FragmentSelectImage.this.footer.getChildCount() != 0) {
                    FragmentSelectImage.this.removeAllTv.setVisibility(View.VISIBLE);
                    FragmentSelectImage.this.maxTv.setVisibility(View.INVISIBLE);
                    FragmentSelectImage.this.deleteAllTv.setVisibility(View.INVISIBLE);
                    FragmentSelectImage.this.removeAllTv.startAnimation(FragmentSelectImage.this.slideInLeft);
                }
                if (id == R.id.gallery_remove_all) {
                    FragmentSelectImage.this.RemoveAll();
                }
                if (id == R.id.gallery_next) {
                    FragmentSelectImage.this.photosSelectFinished();
                }
            }
        };
    }

    private List<GridViewItem> createGridItemsOnClick(int i) {
        final ArrayList<GridViewItem> list = new ArrayList<GridViewItem>();
        final AlbumItem albumItem = this.albumList.get(i);
        final List<Long> imageIdList = albumItem.imageIdList;
        final List<Integer> orientationList = albumItem.orientationList;
        for (i = 0; i < imageIdList.size(); ++i) {
            list.add(new GridViewItem(this.activity, "", "", false, imageIdList.get(i), orientationList.get(i)));
        }
        return list;
    }

    private boolean GalleryFolders() {
        this.albumList = new ArrayList<AlbumItem>();
        final ArrayList<Integer> list = new ArrayList<Integer>();
        final Cursor query = this.context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "bucket_display_name", "bucket_id", "_id", "orientation"}, "1) GROUP BY 1,(2", (String[]) null, "date_modified DESC");
        final int n = 0;
        final int n2 = 0;
        if (query != null && query.moveToFirst()) {
            final int columnIndex = query.getColumnIndex("bucket_display_name");
            final int columnIndex2 = query.getColumnIndex("bucket_id");
            final int columnIndex3 = query.getColumnIndex("_id");
            final int columnIndex4 = query.getColumnIndex("orientation");
            do {
                final AlbumItem albumItem = new AlbumItem();
                final int int1 = query.getInt(columnIndex2);
                albumItem.ID = int1;
                if (list.contains(int1)) {
                    final AlbumItem albumItem2 = this.albumList.get(list.indexOf(albumItem.ID));
                    albumItem2.imageIdList.add(query.getLong(columnIndex3));
                    albumItem2.orientationList.add(query.getInt(columnIndex4));
                } else {
                    final String string = query.getString(columnIndex);
                    list.add(int1);
                    albumItem.name = string;
                    albumItem.imageIdForThumb = query.getLong(columnIndex3);
                    albumItem.imageIdList.add(albumItem.imageIdForThumb);
                    this.albumList.add(albumItem);
                    albumItem.orientationList.add(query.getInt(columnIndex4));
                }
            } while (query.moveToNext());
            final ArrayList<GridViewItem> gridItems = new ArrayList<GridViewItem>();
            for (int i = 0; i < this.albumList.size(); ++i) {
                final Activity activity = this.activity;
                final String name = this.albumList.get(i).name;
                final StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(this.albumList.get(i).imageIdList.size());
                gridItems.add(new GridViewItem(activity, name, sb.toString(), true, this.albumList.get(i).imageIdForThumb, this.albumList.get(i).orientationList.get(0)));
            }
            this.albumList.add(new AlbumItem());
            this.albumList.get(this.albumList.size() - 1).gridItems = gridItems;
            for (int j = n2; j < this.albumList.size() - 1; ++j) {
                this.albumList.get(j).gridItems = this.createGridItemsOnClick(j);
            }
            return true;
        }
        final ArrayList<GridViewItem> gridItems2 = new ArrayList<GridViewItem>();
        for (int k = 0; k < this.albumList.size(); ++k) {
            final Activity activity2 = this.activity;
            final String name2 = this.albumList.get(k).name;
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("");
            sb2.append(this.albumList.get(k).imageIdList.size());
            gridItems2.add(new GridViewItem(activity2, name2, sb2.toString(), true, this.albumList.get(k).imageIdForThumb, this.albumList.get(k).orientationList.get(0)));
        }
        this.albumList.add(new AlbumItem());
        this.albumList.get(this.albumList.size() - 1).gridItems = gridItems2;
        for (int l = n; l < this.albumList.size() - 1; ++l) {
            this.albumList.get(l).gridItems = this.createGridItemsOnClick(l);
        }
        return true;
    }

    private void setGridAdapter() {
        this.gridView = (GridView) this.getView().findViewById(R.id.gridView);
        this.adapter = new GridAdapter(this.context, this.albumList.get(this.albumList.size() - 1).gridItems, this.gridView);
        this.gridView.setAdapter((ListAdapter) this.adapter);
        this.gridView.setOnItemClickListener((AdapterView.OnItemClickListener) this);
    }

    boolean backtrace() {
        if (this.isOnBucket) {
            if (this.galleryListener != null) {
                this.galleryListener.onGalleryCancel();
            }
            return true;
        }
        this.gridView.setNumColumns(2);
        this.adapter.items = this.albumList.get(this.albumList.size() - 1).gridItems;
        this.adapter.notifyDataSetChanged();
        this.gridView.smoothScrollToPosition(0);
        this.isOnBucket = true;
        this.headerText.setText((CharSequence) this.getString(R.string.gallery_select_an_album));
        return false;
    }

    Point findItemById(final long n) {
        for (int i = 0; i < this.albumList.size() - 1; ++i) {
            final List<GridViewItem> gridItems = this.albumList.get(i).gridItems;
            for (int j = 0; j < gridItems.size(); ++j) {
                if (gridItems.get(j).imageIdForThumb == n) {
                    return new Point(i, j);
                }
            }
        }
        return null;
    }

    public int getLimitMax() {
        return this.COLLAGE_IMAGE_LIMIT_MAX;
    }

    public int getLimitMin() {
        return this.COLLAGE_IMAGE_LIMIT_MIN;
    }

    @Override
    public void onActivityCreated(@Nullable final Bundle bundle) {
        super.onActivityCreated(bundle);
        this.GalleryFolders();
        this.setGridAdapter();
    }

    @Override
    public void onAttach(final Activity activity) {
        super.onAttach(activity);
        this.context = (Context) this.getActivity();
        this.activity = this.getActivity();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_select_image, viewGroup, false);
        LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.linearAds);
        linearLayout.setVisibility(View.GONE);
        this.footer = (LinearLayout) inflate.findViewById(R.id.selected_image_linear);
        this.headerText = (TextView) inflate.findViewById(R.id.textView_header);
        this.imageBack = (ImageView) inflate.findViewById(R.id.imageBack);
        this.imageBack.setOnClickListener(this.onClickListener);
        this.maxTv = (TextView) inflate.findViewById(R.id.gallery_max);
        this.nextTv = (TextView) inflate.findViewById(R.id.gallery_next);
        this.nextTv.setOnClickListener(this.onClickListener);
        this.maxTv.setText(String.format(getString(R.string.gallery_lib_max), new Object[]{Integer.valueOf(getLimitMax())}));
        this.deleteAllTv = (TextView) inflate.findViewById(R.id.gallery_delete_all);
        this.removeAllTv = (TextView) inflate.findViewById(R.id.gallery_remove_all);
        this.slideInLeft = AnimationUtils.loadAnimation(this.context, R.anim.slide_in_left);
        this.deleteAllTv.setOnClickListener(this.onClickListener);
        this.removeAllTv.setOnClickListener(this.onClickListener);
        TextView textView = this.deleteAllTv;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(");
        stringBuilder.append(this.footer.getChildCount());
        stringBuilder.append(")");
        textView.setText(stringBuilder.toString());
        return inflate;

    }

    @Override
    public void onDestroy() {
        if (this.mAdView != null) {
            this.mAdView.destroy();
        }
        if (this.adView != null) {
            this.adView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        if (this.adWhirlLayout != null) {
            this.adWhirlLayout.removeAllViews();
            this.adWhirlLayout.destroy();
        }
        super.onDestroyView();
    }

    public void onItemClick(final AdapterView<?> adapterView, final View view, final int selectedBucketId, long longValue) {
        if (this.isOnBucket) {
            this.gridView.setNumColumns(3);
            this.adapter.items = this.albumList.get(selectedBucketId).gridItems;
            this.adapter.notifyDataSetChanged();
            this.gridView.smoothScrollToPosition(0);
            this.isOnBucket = false;
            this.selectedBucketId = selectedBucketId;
            this.headerText.setText((CharSequence) this.albumList.get(selectedBucketId).name);
            return;
        }
        if (this.footer.getChildCount() >= this.COLLAGE_IMAGE_LIMIT_MAX) {
            @SuppressLint({"StringFormatInvalid", "LocalSuppress"}) Toast makeText = Toast.makeText(this.context, String.format(getString(R.string.gallery_no_more), new Object[]{Integer.valueOf(this.COLLAGE_IMAGE_LIMIT_MAX)}), Toast.LENGTH_SHORT);
            makeText.setGravity(17, makeText.getXOffset() / 2, makeText.getYOffset() / 2);
            makeText.show();
            return;
        }
        final View inflate = LayoutInflater.from(this.context).inflate(R.layout.footer_item, (ViewGroup) null);
        inflate.findViewById(R.id.imageView_delete).setOnClickListener(this.onClickListener);
        final ImageView imageView = (ImageView) inflate.findViewById(R.id.imageView);
        if (this.selectedBucketId >= 0 && this.selectedBucketId < this.albumList.size() && selectedBucketId >= 0 && selectedBucketId < this.albumList.get(this.selectedBucketId).imageIdList.size()) {
            longValue = this.albumList.get(this.selectedBucketId).imageIdList.get(selectedBucketId);
            this.selectedImageIdList.add(longValue);
            this.selectedImageOrientationList.add(this.albumList.get(this.selectedBucketId).orientationList.get(selectedBucketId));
            final Bitmap thumbnailBitmap = GalleryImageUtility.getThumbnailBitmap(this.context, longValue, this.albumList.get(this.selectedBucketId).orientationList.get(selectedBucketId));
            if (thumbnailBitmap != null) {
                imageView.setImageBitmap(thumbnailBitmap);
            }
            this.footer.addView(inflate);
            final TextView deleteAllTv = this.deleteAllTv;
            final StringBuilder sb = new StringBuilder();
            sb.append("(");
            sb.append(this.footer.getChildCount());
            sb.append(")");
            deleteAllTv.setText((CharSequence) sb.toString());
            final GridViewItem gridViewItem = this.adapter.items.get(selectedBucketId);
            ++gridViewItem.selectedItemCount;
            final TextView textView = (TextView) view.findViewById(R.id.textViewSelectedItemCount);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("");
            sb2.append(this.adapter.items.get(selectedBucketId).selectedItemCount);
            textView.setText((CharSequence) sb2.toString());
            if (textView.getVisibility() == View.INVISIBLE) {
                textView.setVisibility(View.VISIBLE);
            }
            if (this.collageSingleMode) {
                this.photosSelectFinished();
                this.collageSingleMode = false;
            }
        }
    }

    @Override
    public void onPause() {
        if (this.mAdView != null) {
            this.mAdView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.mAdView != null) {
            this.mAdView.resume();
        }
        if (this.gridView != null) {
            try {
                this.gridState = this.gridView.onSaveInstanceState();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        this.GalleryFolders();
        this.updateListForSelection();
        this.setGridAdapter();
        if (!this.isOnBucket && this.albumList != null && this.selectedBucketId >= 0 && this.selectedBucketId < this.albumList.size()) {
            this.adapter.items = this.albumList.get(this.selectedBucketId).gridItems;
            if (this.gridView != null) {
                this.gridView.post((Runnable) new Runnable() {
                    @Override
                    public void run() {
                        if (FragmentSelectImage.this.gridState != null) {
                            Log.d("GalleryActivity", "trying to restore listview state..");
                            FragmentSelectImage.this.gridView.onRestoreInstanceState(FragmentSelectImage.this.gridState);
                        }
                    }
                });
            }
        }
        this.adapter.notifyDataSetChanged();
    }

    void photosSelectFinished() {
        final int size = this.selectedImageIdList.size();
        final int collage_IMAGE_LIMIT_MIN = this.COLLAGE_IMAGE_LIMIT_MIN;
        final int n = 0;
        if (size <= collage_IMAGE_LIMIT_MIN) {
            @SuppressLint({"StringFormatInvalid", "LocalSuppress"}) final Toast text = Toast.makeText(this.context, (CharSequence) String.format(this.getString(R.string.gallery_select_one), this.getLimitMin() + 1), Toast.LENGTH_SHORT);
            text.setGravity(17, text.getXOffset() / 2, text.getYOffset() / 2);
            text.show();
            return;
        }
        final long[] array = new long[size];
        for (int i = 0; i < size; ++i) {
            array[i] = this.selectedImageIdList.get(i);
        }
        final int[] array2 = new int[size];
        for (int j = n; j < size; ++j) {
            array2[j] = this.selectedImageOrientationList.get(j);
        }
        if (this.galleryListener != null) {
            this.galleryListener.onGalleryOkImageArray(array, array2, this.isScrapBook, this.isShape);
            return;
        }
        try {
            this.getActivity().getSupportFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void RemoveAll() {
        if (this.footer != null) {
            this.footer.removeAllViews();
            if (this.selectedImageIdList != null && this.selectedImageIdList.size() > 0) {
                for (int i = 0; i < this.selectedImageIdList.size(); ++i) {
                    final Point itemById = this.findItemById(this.selectedImageIdList.get(i));
                    if (itemById != null) {
                        final GridViewItem gridViewItem = this.albumList.get(itemById.x).gridItems.get(itemById.y);
                        --gridViewItem.selectedItemCount;
                        final int selectedItemCount = this.albumList.get(itemById.x).gridItems.get(itemById.y).selectedItemCount;
                        if (this.albumList.get(itemById.x).gridItems == this.adapter.items && this.gridView.getFirstVisiblePosition() <= itemById.y && itemById.y <= this.gridView.getLastVisiblePosition() && this.gridView.getChildAt(itemById.y) != null) {
                            final TextView textView = (TextView) this.gridView.getChildAt(itemById.y).findViewById(R.id.textViewSelectedItemCount);
                            final StringBuilder sb = new StringBuilder();
                            sb.append("");
                            sb.append(selectedItemCount);
                            textView.setText((CharSequence) sb.toString());
                            if (selectedItemCount <= 0 && textView.getVisibility() == View.VISIBLE) {
                                textView.setVisibility(View.INVISIBLE);
                            }
                        }
                    }
                }
            }
            if (this.selectedImageIdList != null) {
                this.selectedImageIdList.clear();
            }
            this.selectedImageOrientationList.clear();
            final TextView deleteAllTv = this.deleteAllTv;
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("(");
            sb2.append(this.footer.getChildCount());
            sb2.append(")");
            deleteAllTv.setText((CharSequence) sb2.toString());
            this.getView().findViewById(R.id.gallery_remove_all).setVisibility(View.INVISIBLE);
            this.getView().findViewById(R.id.gallery_max).setVisibility(View.VISIBLE);
            this.deleteAllTv.setVisibility(View.VISIBLE);
        }
    }

    public void CollageSingleMode(final boolean collageSingleMode) {
        this.collageSingleMode = collageSingleMode;
        if (collageSingleMode) {
            if (this.selectedImageIdList != null) {
                for (int i = this.selectedImageIdList.size() - 1; i >= 0; --i) {
                    final Point itemById = this.findItemById(this.selectedImageIdList.remove(i));
                    if (itemById != null) {
                        final GridViewItem gridViewItem = this.albumList.get(itemById.x).gridItems.get(itemById.y);
                        --gridViewItem.selectedItemCount;
                        final int selectedItemCount = this.albumList.get(itemById.x).gridItems.get(itemById.y).selectedItemCount;
                        if (this.albumList.get(itemById.x).gridItems == this.adapter.items && this.gridView.getFirstVisiblePosition() <= itemById.y && itemById.y <= this.gridView.getLastVisiblePosition() && this.gridView.getChildAt(itemById.y) != null) {
                            final TextView textView = (TextView) this.gridView.getChildAt(itemById.y).findViewById(R.id.textViewSelectedItemCount);
                            textView.setText(selectedItemCount);
                            if (selectedItemCount <= 0 && textView.getVisibility() == View.VISIBLE) {
                                textView.setVisibility(View.INVISIBLE);
                            }
                        }
                    }
                }
            }
            if (this.selectedImageOrientationList != null) {
                this.selectedImageOrientationList.clear();
            }
            if (this.footer != null) {
                this.footer.removeAllViews();
            }
            if (this.deleteAllTv != null) {
                this.deleteAllTv.setText((CharSequence) "(0)");
            }
        }
    }

    public void GalleryListener(final GalleryListener galleryListener) {
        this.galleryListener = galleryListener;
    }

    public void setIsScrapbook(final boolean isScrapBook) {
        this.isScrapBook = isScrapBook;
        this.setLimitMax(FragmentSelectImage.MAX_SCRAPBOOK);
        if (this.selectedImageIdList != null && this.selectedImageIdList.size() > this.COLLAGE_IMAGE_LIMIT_MAX) {
            this.RemoveAll();
            return;
        }
        if (this.footer != null && this.footer.getChildCount() > this.COLLAGE_IMAGE_LIMIT_MAX) {
            this.RemoveAll();
        }
    }

    public void setIsShape(final boolean isShape) {
        this.isShape = isShape;
    }

    public void setLimitMax(final int collage_IMAGE_LIMIT_MAX) {
        this.COLLAGE_IMAGE_LIMIT_MAX = collage_IMAGE_LIMIT_MAX;
        if (this.maxTv != null) {
            this.maxTv.setText((CharSequence) String.format(this.getString(R.string.gallery_lib_max), this.COLLAGE_IMAGE_LIMIT_MAX));
        }
    }

    void updateListForSelection() {
        if (this.selectedImageIdList != null && !this.selectedImageIdList.isEmpty()) {
            for (int i = 0; i < this.selectedImageIdList.size(); ++i) {
                final Point itemById = this.findItemById(this.selectedImageIdList.get(i));
                if (itemById != null) {
                    final GridViewItem gridViewItem = this.albumList.get(itemById.x).gridItems.get(itemById.y);
                    ++gridViewItem.selectedItemCount;
                }
            }
        }
    }

    public interface GalleryListener {
        void onGalleryCancel();

        void onGalleryOkImageArray(final long[] p0, final int[] p1, final boolean p2, final boolean p3);

        void onGalleryOkImageArrayRemoveFragment(final long[] p0, final int[] p1, final boolean p2, final boolean p3);

        void onGalleryOkSingleImage(final long p0, final int p1, final boolean p2, final boolean p3);
    }

}
