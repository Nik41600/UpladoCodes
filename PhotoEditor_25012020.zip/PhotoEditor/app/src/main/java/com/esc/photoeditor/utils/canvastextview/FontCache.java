package com.esc.photoeditor.utils.canvastextview;

import android.content.Context;
import android.graphics.Typeface;

import java.util.Hashtable;

public class FontCache {
    private static final Hashtable<String, Typeface> cache = new Hashtable();

    public static Typeface get(Context context, String str) {
        synchronized (cache) {
            if (str != null) {
                try {
                    if (!(str.length() == 0 || str.compareTo("") == 0)) {
                        if (!cache.containsKey(str)) {
                            cache.put(str, Typeface.createFromAsset(context.getAssets(), str));
                        }
                        Typeface typeface = (Typeface) cache.get(str);
                        return typeface;
                    }
                } catch (Throwable th) {
                }
            }
            return null;
        }
    }
}