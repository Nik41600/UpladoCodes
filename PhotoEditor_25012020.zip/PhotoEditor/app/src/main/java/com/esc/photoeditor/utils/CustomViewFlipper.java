package com.esc.photoeditor.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ViewFlipper;

public class CustomViewFlipper extends ViewFlipper {
    public CustomViewFlipper(final Context context) {
        super(context);
    }

    public CustomViewFlipper(final Context context, final AttributeSet set) {
        super(context, set);
    }

    protected void onDetachedFromWindow() {
        try {
            super.onDetachedFromWindow();
            this.stopFlipping();
            return;
        } catch (IllegalArgumentException ex) {
        }
    }
}
