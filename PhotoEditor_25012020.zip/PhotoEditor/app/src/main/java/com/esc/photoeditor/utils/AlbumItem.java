package com.esc.photoeditor.utils;

import java.util.*;

public class AlbumItem
{
  public int ID;
  public List<GridViewItem> gridItems;
  public long imageIdForThumb;
  public List<Long> imageIdList;
  public String name;
  public List<Integer> orientationList;

  public AlbumItem() {
    this.imageIdList = new ArrayList<Long>();
    this.orientationList = new ArrayList<Integer>();
  }
}
