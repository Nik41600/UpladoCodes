package com.esc.photoeditor.utils.canvastextview;

import java.util.*;

public interface ApplyTextInterface
{
  void onCancel();

  void onOk(final ArrayList<TextDataItem> p0);
}
