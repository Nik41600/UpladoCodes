package com.esc.photoeditor.collagelist;

public class MaskPair
{
  public int id;
  public int index;

  public MaskPair(final int index, final int id) {
    this.index = index;
    this.id = id;
  }
}
