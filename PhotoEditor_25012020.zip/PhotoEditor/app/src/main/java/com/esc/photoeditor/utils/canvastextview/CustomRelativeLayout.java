package com.esc.photoeditor.utils.canvastextview;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.esc.photoeditor.utils.OnItemSelected;
import com.esc.photoeditor.R;

import java.util.ArrayList;

public class CustomRelativeLayout extends RelativeLayout implements OnItemSelected, View.OnClickListener {
    private static final String TAG = "CustomRelativeLayout";
    ApplyTextInterface applyListener;
    ArrayList<CanvasTextView> canvasTextViewList;
    Context context;
    int currentCanvasTextIndex;
    RelativeLayout.LayoutParams levelParams;
    RelativeLayout mainLayout;
    public View.OnClickListener onClickListener;
    Bitmap removeBitmap;
    RemoveTextListener removeTextListener;
    Bitmap scaleBitmap;
    SingleTapInterface singleTapListener;
    ArrayList<TextDataItem> textDataList;
    ArrayList<TextDataItem> textDataListOriginal;
    ViewSelectedListener viewSelectedListner;

    public CustomRelativeLayout(final Context context, final ArrayList<TextDataItem> list, final Matrix matrix, final SingleTapInterface singleTapListener) {
        super(context);
        final int n = 0;
        this.currentCanvasTextIndex = 0;
        this.removeTextListener = (RemoveTextListener) new RemoveText();
        this.viewSelectedListner = new ViewSelector();
        this.context = context;
        this.singleTapListener = singleTapListener;
        this.loadBitmaps();
        ((LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.activity_canvas, (ViewGroup) this);
        this.mainLayout = (RelativeLayout) this.findViewById(R.id.canvas_relative_layout);
        (this.levelParams = new RelativeLayout.LayoutParams(-1, -1)).addRule(15, -1);
        this.levelParams.addRule(14, -1);
        this.canvasTextViewList = new ArrayList<CanvasTextView>();
        this.textDataList = new ArrayList<TextDataItem>();
        this.textDataListOriginal = new ArrayList<TextDataItem>();
        int n2 = 0;
        int i;
        while (true) {
            i = n;
            if (n2 >= list.size()) {
                break;
            }
            this.textDataListOriginal.add(new TextDataItem(list.get(n2)));
            this.textDataList.add(new TextDataItem(list.get(n2)));
            ++n2;
        }
        while (i < this.textDataList.size()) {
            final CanvasTextView canvasTextView = new CanvasTextView(this.context, this.textDataList.get(i), this.removeBitmap, this.scaleBitmap);
            canvasTextView.setSingleTapListener(this.singleTapListener);
            canvasTextView.setViewSelectedListener(this.viewSelectedListner);
            canvasTextView.setRemoveTextListener(new RemoveText());
            this.mainLayout.addView((View) canvasTextView, (ViewGroup.LayoutParams) this.levelParams);
            this.canvasTextViewList.add(canvasTextView);
            final CustomMatrix matrix2 = new CustomMatrix();
            matrix2.set((Matrix) this.textDataList.get(i).imageSaveMatrix);
            matrix2.postConcat(matrix);
            canvasTextView.setMatrix(matrix2);
            ++i;
        }
        if (!this.canvasTextViewList.isEmpty()) {
            this.canvasTextViewList.get(this.canvasTextViewList.size() - 1).setTextSelected(true);
            this.currentCanvasTextIndex = this.canvasTextViewList.size() - 1;
        }
        final TextView textView = (TextView) this.findViewById(R.id.button_apply_action);
        final TextView textView2 = (TextView) this.findViewById(R.id.button_cancel_action);
        textView.setOnClickListener((View.OnClickListener) this);
        textView2.setOnClickListener((View.OnClickListener) this);
    }

    public void addTextView(final TextDataItem newTextData) {
        if (this.textDataList.contains(newTextData)) {
            this.canvasTextViewList.get(this.currentCanvasTextIndex).setNewTextData(newTextData);
            return;
        }
        for (int i = 0; i < this.canvasTextViewList.size(); ++i) {
            this.canvasTextViewList.get(i).setTextSelected(false);
        }
        this.currentCanvasTextIndex = this.canvasTextViewList.size();
        this.loadBitmaps();
        final CanvasTextView canvasTextView = new CanvasTextView(this.context, newTextData, this.removeBitmap, this.scaleBitmap);
        canvasTextView.setSingleTapListener(this.singleTapListener);
        canvasTextView.setViewSelectedListener(this.viewSelectedListner);
        canvasTextView.setRemoveTextListener(new RemoveText());
        this.canvasTextViewList.add(canvasTextView);
        this.mainLayout.addView((View) canvasTextView);
        this.textDataList.add(canvasTextView.textData);
        canvasTextView.setTextSelected(true);
        canvasTextView.singleTapped();
    }

    public void hideSoftKeyboard(final Activity activity) {
        final InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null && activity.getCurrentFocus() != null) {
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    public void itemSelected(final int textColor) {
        if (!this.canvasTextViewList.isEmpty()) {
            this.canvasTextViewList.get(this.currentCanvasTextIndex).setTextColor(textColor);
        }
    }

    void loadBitmaps() {
        if (this.removeBitmap == null || this.removeBitmap.isRecycled()) {
            this.removeBitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_cancel);
        }
        if (this.scaleBitmap == null || this.scaleBitmap.isRecycled()) {
            this.scaleBitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_textrightimage);
        }
    }

    public void onClick(final View view) {
        this.hideSoftKeyboard((Activity) this.context);
        final int id = view.getId();
        if (id == R.id.button_text_color) {
            return;
        }
        final int n = 0;
        int i = 0;
        if (id == R.id.button_apply_action) {
            while (i < this.textDataList.size()) {
                int n2 = i;
                if (this.textDataList.get(i).message.compareTo("Preview Text") == 0) {
                    this.textDataList.remove(i);
                    n2 = i - 1;
                }
                i = n2 + 1;
            }
            this.applyListener.onOk(this.textDataList);
            return;
        }
        if (id == R.id.button_cancel_action) {
            this.textDataList.clear();
            for (int j = n; j < this.textDataListOriginal.size(); ++j) {
                this.textDataList.add(this.textDataListOriginal.get(j));
            }
            this.applyListener.onCancel();
        }
    }

    public boolean onTouchEvent(final MotionEvent motionEvent) {
        this.hideSoftKeyboard((Activity) this.context);
        return true;
    }

    public void setApplyTextListener(final ApplyTextInterface applyListener) {
        this.applyListener = applyListener;
    }

    public void setSingleTapListener(final SingleTapInterface singleTapListener) {
        this.singleTapListener = singleTapListener;
    }

    class RemoveText implements RemoveTextListener {
        @Override
        public void onRemove() {
            if (!CustomRelativeLayout.this.canvasTextViewList.isEmpty()) {
                final CanvasTextView canvasTextView = CustomRelativeLayout.this.canvasTextViewList.get(CustomRelativeLayout.this.currentCanvasTextIndex);
                CustomRelativeLayout.this.mainLayout.removeView((View) canvasTextView);
                CustomRelativeLayout.this.canvasTextViewList.remove(canvasTextView);
                CustomRelativeLayout.this.textDataList.remove(canvasTextView.textData);
                CustomRelativeLayout.this.currentCanvasTextIndex = CustomRelativeLayout.this.canvasTextViewList.size() - 1;
                if (!CustomRelativeLayout.this.canvasTextViewList.isEmpty()) {
                    CustomRelativeLayout.this.canvasTextViewList.get(CustomRelativeLayout.this.currentCanvasTextIndex).setTextSelected(true);
                }
            }
        }
    }

    public interface RemoveTextListener {
        void onRemove();
    }

    class ViewSelector implements ViewSelectedListener {
        @Override
        public void setSelectedView(final CanvasTextView canvasTextView) {
            CustomRelativeLayout.this.currentCanvasTextIndex = CustomRelativeLayout.this.canvasTextViewList.indexOf(canvasTextView);
            for (int i = 0; i < CustomRelativeLayout.this.canvasTextViewList.size(); ++i) {
                if (CustomRelativeLayout.this.currentCanvasTextIndex != i) {
                    CustomRelativeLayout.this.canvasTextViewList.get(i).setTextSelected(false);
                }
            }
        }
    }
}
