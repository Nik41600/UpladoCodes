package com.esc.photoeditor.widget;

import android.support.v7.widget.*;
import android.content.*;
import android.util.*;
import android.support.annotation.*;

public class GallerySquareImageView extends AppCompatImageView
{
  public GallerySquareImageView(final Context context) {
    super(context);
  }

  public GallerySquareImageView(final Context context, @Nullable final AttributeSet set) {
    super(context, set);
  }

  public GallerySquareImageView(final Context context, @Nullable final AttributeSet set, final int n) {
    super(context, set, n);
  }

  protected void onMeasure(int measuredWidth, final int n) {
    super.onMeasure(measuredWidth, n);
    measuredWidth = this.getMeasuredWidth();
    this.setMeasuredDimension(measuredWidth, measuredWidth);
  }
}
