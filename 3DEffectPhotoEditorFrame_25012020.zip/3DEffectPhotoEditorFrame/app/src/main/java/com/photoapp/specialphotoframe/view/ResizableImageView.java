package com.photoapp.specialphotoframe.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.ImageView;

public class ResizableImageView extends ImageView {
	public ResizableImageView(Context paramContext) {
		super(paramContext);
	}

	public ResizableImageView(Context paramContext,
			AttributeSet paramAttributeSet) {
		super(paramContext, paramAttributeSet);
	}

	protected void onMeasure(int paramInt1, int paramInt2) {
		Drawable localDrawable = getDrawable();
		if (localDrawable != null) {
			paramInt1 = View.MeasureSpec.getSize(paramInt1);
			paramInt2 = (int) Math.ceil(paramInt1
					* localDrawable.getIntrinsicHeight()
					/ localDrawable.getIntrinsicWidth());
			setMeasuredDimension(paramInt1, paramInt1);
			return;
		}
		super.onMeasure(paramInt1, paramInt1);
	}
}
