package com.photoapp.specialphotoframe.activity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.photoapp.specialphotoframe.fragment.HomeFragment;
import com.photoapp.specialphotoframe.kprogresshud.KProgressHUD;
import com.theartofdev.edmodo.cropper.*;

import android.widget.*;

import com.photoapp.specialphotoframe.utils.*;

import android.view.*;
import android.os.*;
import android.app.Activity;
import android.content.*;
import android.util.*;

import com.photoapp.specialphotoframe.R;

public class ActivityCrop extends Activity implements View.OnClickListener {
    RelativeLayout back_main;
    LinearLayout btnCrop16_9;
    LinearLayout btnCrop4_3;
    LinearLayout btnCrop4_5;
    LinearLayout btnCrop5_6;
    LinearLayout btnCropCustom;
    LinearLayout btnCropOriginal;
    LinearLayout btnCropSquare;
    CropImageView cropView;
    TextView custom_size;
    TextView org_size;
    RelativeLayout rlnext;
    TextView size4_3;
    TextView size_16_9;
    TextView size_4_5;
    TextView size_5_6;
    TextView square_size;
    ImageLoadingUtils utils;
    private AdView adView;
    private KProgressHUD hud;

    private void backgroundchange(final int n) {
        this.btnCropOriginal.setBackgroundColor(0);
        this.btnCropSquare.setBackgroundColor(0);
        this.btnCrop4_5.setBackgroundColor(0);
        this.btnCrop5_6.setBackgroundColor(0);
        this.btnCrop4_3.setBackgroundColor(0);
        this.btnCrop16_9.setBackgroundColor(0);
        this.btnCropCustom.setBackgroundColor(0);
        this.org_size = (TextView) findViewById(R.id.org_size);
        this.square_size = (TextView) findViewById(R.id.square_size);
        this.custom_size = (TextView) findViewById(R.id.custom_size);
        this.size_4_5 = (TextView) findViewById(R.id.size_4_5);
        this.size_5_6 = (TextView) findViewById(R.id.size_5_6);
        this.size_16_9 = (TextView) findViewById(R.id.size_16_9);
        this.size4_3 = (TextView) findViewById(R.id.size4_3);
        switch (n) {
            default: {
                break;
            }
            case R.id.btnCropOriginal: {
                this.btnCropOriginal.setBackgroundColor(this.getResources()
                        .getColor(R.color.crop_op_bg));
                this.org_size.setTextColor(-1);
            }
            break;
            case R.id.btnCropSquare: {
                this.btnCropSquare.setBackgroundColor(this.getResources().getColor(
                        R.color.crop_op_bg));
                this.square_size.setTextColor(-1);
            }
            break;
            case R.id.btnCropCustom: {
                this.btnCropCustom.setBackgroundColor(this.getResources().getColor(
                        R.color.crop_op_bg));
                this.custom_size.setTextColor(-1);
            }
            break;
            case R.id.btnCrop4_5: {
                this.btnCrop4_5.setBackgroundColor(this.getResources().getColor(
                        R.color.crop_op_bg));
                this.size_4_5.setTextColor(-1);
            }
            break;
            case R.id.btnCrop5_6: {
                this.btnCrop5_6.setBackgroundColor(this.getResources().getColor(
                        R.color.crop_op_bg));
                this.size_5_6.setTextColor(-1);
            }
            break;
            case R.id.btnCrop16_9: {
                this.btnCrop16_9.setBackgroundColor(this.getResources().getColor(
                        R.color.crop_op_bg));
                this.size_16_9.setTextColor(-1);
            }
            break;
            case R.id.btnCrop4_3: {
                this.btnCrop4_3.setBackgroundColor(this.getResources().getColor(
                        R.color.crop_op_bg));
                this.size4_3.setTextColor(-1);
            }
            break;
        }
    }

    public void onClick(final View view) {
        switch (view.getId()) {
            default: {
                break;
            }
            case R.id.btnCropOriginal: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(HomeFragment.bitmap.getWidth(),
                        HomeFragment.bitmap.getHeight());
                this.backgroundchange(R.id.btnCropOriginal);
            }
            break;
            case R.id.btnCropSquare: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(1, 1);
                this.backgroundchange(R.id.btnCropSquare);
            }
            break;
            case R.id.btnCropCustom: {
                this.cropView.setFixedAspectRatio(false);
                this.backgroundchange(R.id.btnCropCustom);
            }
            break;
            case R.id.btnCrop4_5: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(4, 5);
                this.backgroundchange(R.id.btnCrop4_5);
            }
            break;
            case R.id.btnCrop5_6: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(5, 6);
                this.backgroundchange(R.id.btnCrop5_6);
            }
            break;
            case R.id.btnCrop16_9: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(16, 9);
                this.backgroundchange(R.id.btnCrop16_9);
            }
            break;
            case R.id.btnCrop4_3: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(4, 3);
                this.backgroundchange(R.id.btnCrop4_3);
            }
            break;

            case R.id.back_main:
                id = R.id.back_main;
                if (interstitial != null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    Intent back = new Intent(ActivityCrop.this, HomeActivity.class);
                    startActivity(back);
                }
            break;

            case R.id.next_main:
                id = R.id.next_main;
                if (interstitial != null && interstitial.isLoaded()){
                    DialogShow();
                    AdsDialogShow();
                }else {
                    HomeFragment.bitmap = ActivityCrop.this.cropView
                            .getCroppedImage();
                    ActivityCrop.this.startActivity(new Intent(
                            (Context) ActivityCrop.this,
                            ImageChangeActivity.class));
                    ActivityCrop.this.finish();
                }
            break;
        }
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_crop);
        this.cropView = (CropImageView) this.findViewById(R.id.CropImageView);
        this.cropView.setFixedAspectRatio(true);
        this.cropView.setAspectRatio(1, 1);
        this.utils = new ImageLoadingUtils(this.getApplicationContext());
        this.cropView.setImageBitmap(HomeFragment.bitmap);
        this.back_main = (RelativeLayout) findViewById(R.id.back_main);
        this.rlnext = (RelativeLayout) this.findViewById(R.id.next_main);
        this.org_size = (TextView) findViewById(R.id.org_size);
        this.square_size = (TextView) findViewById(R.id.square_size);
        this.custom_size = (TextView) findViewById(R.id.custom_size);
        this.size_4_5 = (TextView) findViewById(R.id.size_4_5);
        this.size_5_6 = (TextView) findViewById(R.id.size_5_6);
        this.size_16_9 = (TextView) findViewById(R.id.size_16_9);
        this.size4_3 = (TextView) findViewById(R.id.size4_3);
        this.btnCropOriginal = (LinearLayout) findViewById(R.id.btnCropOriginal);
        this.btnCropSquare = (LinearLayout) findViewById(R.id.btnCropSquare);
        this.btnCrop4_5 = (LinearLayout) findViewById(R.id.btnCrop4_5);
        this.btnCrop5_6 = (LinearLayout) findViewById(R.id.btnCrop5_6);
        this.btnCrop4_3 = (LinearLayout) findViewById(R.id.btnCrop4_3);
        this.btnCropCustom = (LinearLayout) findViewById(R.id.btnCropCustom);
        this.btnCrop16_9 = (LinearLayout) findViewById(R.id.btnCrop16_9);

        loadAd();
    }

    private InterstitialAd interstitial;
    private int id;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.back_main:
                        Intent back = new Intent(ActivityCrop.this, HomeActivity.class);
                        startActivity(back);
                        break;
                    case R.id.next_main:
                        HomeFragment.bitmap = ActivityCrop.this.cropView
                                .getCroppedImage();
                        ActivityCrop.this.startActivity(new Intent(
                                (Context) ActivityCrop.this,
                                ImageChangeActivity.class));
                        ActivityCrop.this.finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityCrop.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

}
