package com.photoapp.specialphotoframe.fragment;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.gson.Gson;
import com.photoapp.specialphotoframe.R;
import com.photoapp.specialphotoframe.activity.ActivityCrop;
import com.photoapp.specialphotoframe.activity.MyApplication;
import com.photoapp.specialphotoframe.activity.MyStudioActivity;
import com.photoapp.specialphotoframe.adapter.MoreAppAdapter;
import com.photoapp.specialphotoframe.kprogresshud.KProgressHUD;
import com.photoapp.specialphotoframe.model.App_data;
import com.photoapp.specialphotoframe.utils.Glob;
import com.photoapp.specialphotoframe.utils.ImageLoadingUtils;
import com.photoapp.specialphotoframe.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HomeFragment extends Fragment {
    private View v;

    private static final int FINAL_SAVE = 20;
    private static final int MY_REQUEST_CODE = 3;
    private static final int MY_REQUEST_CODE2 = 4;
    private static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 2;
    private static final int RE_CAMERA = 5;
    private static final int RE_GALLERY = 6;
    private static final String TAG = "HomeActivity";
    public static Bitmap bitmap;
    static SharedPreferences.Editor editor;
    public static ArrayList<String> listIcon;
    public static ArrayList<String> listName;
    public static ArrayList<String> listUrl;
    static SharedPreferences sp;
    private LinearLayout banner_new;
    private ImageView iv_Gallery;
    private ImageView iv_Mycreation;
    private boolean dataAvailable;
    private long diffMills;
    boolean doubleBackToExitPressedOnce;
    int i;
    private Uri imageUri;
    private boolean isAlreadyCall;
    int j;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    private int totalHours;
    private UnifiedNativeAd nativeAd;
    private KProgressHUD hud;
    private ArrayList<App_data> array_appdata;
    private MoreAppAdapter moreAppAdapter;
    private RecyclerView recyclerView;

    static {
        listIcon = new ArrayList<String>();
        listName = new ArrayList<String>();
        listUrl = new ArrayList<String>();
    }

    public HomeFragment() {
        this.i = 0;
        this.j = 0;
        this.diffMills = 0L;
        this.totalHours = 0;
        this.isAlreadyCall = false;
        this.dataAvailable = false;
        this.doubleBackToExitPressedOnce = false;
    }

    private void bindView() {
        (this.iv_Gallery = (ImageView) v.findViewById(R.id.iv_gallery))
                .setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                    @SuppressLint("WrongConstant")
                    public void onClick(final View view) {
                        id = 101;
                        if (interstitial != null && interstitial.isLoaded()) {

                            DialogShow();
                            AdsDialogShow();
                        } else {
                            if (Build.VERSION.SDK_INT >= 23) {
                                if (getActivity().checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0) {
                                    openGallery();
                                } else if (getActivity()
                                        .checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
                                    getActivity()
                                            .requestPermissions(
                                                    new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                                                    3);
                                }
                                return;
                            }
                            openGallery();
                        }
                    }
                });
        (this.iv_Mycreation = (ImageView)
                v.findViewById(R.id.iv_mycreation))
                .setOnClickListener((View.OnClickListener) new View.OnClickListener() {
                    public void onClick(final View view)
                    {
                        id = 102;
                        if (interstitial != null && interstitial.isLoaded())
                        {
                            DialogShow();
                            AdsDialogShow();
                        }else {
                            getActivity().startActivity(new Intent(
                                    getActivity().getApplicationContext(),
                                    (Class) MyStudioActivity.class));
                        }
                    }
                });
    }

    private boolean checkAndRequestPermissions() {
        final int checkSelfPermission = ContextCompat.checkSelfPermission(
                getActivity(), "android.permission.CAMERA");
        final int checkSelfPermission2 = ContextCompat.checkSelfPermission(
                getActivity(), "android.permission.WRITE_EXTERNAL_STORAGE");
        final ArrayList<String> list = new ArrayList<String>();
        if (checkSelfPermission2 != 0) {
            list.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission != 0) {
            list.add("android.permission.CAMERA");
        }
        if (!list.isEmpty()) {
            ActivityCompat.requestPermissions(getActivity(),
                    list.toArray(new String[list.size()]), 2);
            return false;
        }
        return true;
    }

    private void openGallery() {
        this.startActivityForResult(new Intent("android.intent.action.PICK",
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 6);
    }

    private void showDialogOK(
            final String message,
            final DialogInterface.OnClickListener dialogInterface$OnClickListener) {
        new AlertDialog.Builder(getActivity()).setMessage(message)
                .setPositiveButton("OK", dialogInterface$OnClickListener)
                .setNegativeButton("Cancel", dialogInterface$OnClickListener)
                .create().show();
    }

    @Override
    public void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n2 == -1) {
            switch (n) {
                case 6: {
                    this.imageUri = intent.getData();
                    try {
                        new ImageCompressionAsyncTask(true)
                                .execute((String[]) new String[]{this.imageUri
                                        .toString()});
                        return;
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        return;
                    }
                    // break;
                }
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_home, container, false);

        array_appdata = new ArrayList<>();
        makeJsonRequest(getResources().getString(R.string.more_appurl));
        recyclerView = (RecyclerView) v.findViewById(R.id.ad_inter_recycle_view);
        final GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.mRegistrationBroadcastReceiver = new BroadcastReceiver() {
            @SuppressLint({"LongLogTag", "WrongConstant"})
            public void onReceive(final Context context, final Intent intent) {
                final SharedPreferences defaultSharedPreferences = PreferenceManager
                        .getDefaultSharedPreferences(context);
                if (defaultSharedPreferences.getBoolean("sentTokenToServer",
                        false)) {
                    Utils.DEVICE_ID = defaultSharedPreferences.getString(
                            "device_token", (String) null);
                    Log.d("HomeActivity",
                            "onReceive() called with: DEVICE_ID[ "
                                    + Utils.DEVICE_ID + " ]");
                    return;
                }
                Toast.makeText((Context) getActivity(),
                        (CharSequence) "error", 0).show();
            }
        };
        this.bindView();
        loadAd();
        return v;
    }

    private void makeJsonRequest(String url) {
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("application_detail");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                App_data app_data = new Gson().fromJson(jsonArray.get(i).toString(), App_data.class);
                                if (!app_data.getApplication_name().equalsIgnoreCase(getString(R.string.app_name))) {
                                    array_appdata.add(app_data);
                                    moreAppAdapter = new MoreAppAdapter(getActivity(), array_appdata);
                                    recyclerView.setAdapter(moreAppAdapter);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Error", "Error: " + error.getMessage());
            }
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq, "");
    }


    @Override
    public void onPause() {
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(
                this.mRegistrationBroadcastReceiver);
        super.onPause();
    }

    @SuppressLint("WrongConstant")
    @TargetApi(23)
    @Override
    public void onRequestPermissionsResult(int i, @NonNull final String[] array, @NonNull final int[] array2) {
        switch (i) {
            case 2: {
                final HashMap<Object, Integer> hashMap = new HashMap<Object, Integer>();
                hashMap.put("android.permission.CAMERA", 0);
                hashMap.put("android.permission.WRITE_EXTERNAL_STORAGE", 0);
                if (array2.length <= 0) {
                    break;
                }
                for (i = 0; i < array.length; ++i) {
                    hashMap.put(array[i], array2[i]);
                }
                if ((int) hashMap.get("android.permission.CAMERA") == 0
                        && (int) hashMap
                        .get("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                    Log.d("HomeActivity", "Camera & Storage permission granted");
                    this.openGallery();
                    return;
                }
                Log.d("HomeActivity", "Some permissions are not granted ask again ");
                if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                        "android.permission.CAMERA")
                        || ActivityCompat.shouldShowRequestPermissionRationale(
                        getActivity(), "android.permission.WRITE_EXTERNAL_STORAGE")) {
                    this.showDialogOK(
                            "Camera & Storage Permission required for this app",
                            (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                                public void onClick(
                                        final DialogInterface dialogInterface,
                                        final int n) {
                                    switch (n) {
                                        default: {
                                        }
                                        case -1: {
                                            checkAndRequestPermissions();
                                        }
                                    }
                                }
                            });
                    return;
                }
                Toast.makeText(getActivity(),
                        (CharSequence) "Go to settings and enable permissions", 1)
                        .show();
            }
            case 3: {
                if (array2[0] == 0) {
                    this.openGallery();
                    return;
                }
                if (getActivity().checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
                    this.requestPermissions(
                            new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                            3);
                    return;
                }
                break;
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(
                this.mRegistrationBroadcastReceiver,
                new IntentFilter("registrationComplete"));
    }

    class ImageCompressionAsyncTask extends AsyncTask<String, Void, Bitmap> {
        private boolean fromGallery;

        public ImageCompressionAsyncTask(final boolean fromGallery) {
            this.fromGallery = fromGallery;
        }

        private String getRealPathFromURI(final String s) {
            final Uri parse = Uri.parse(s);
            final Cursor query = getActivity().getContentResolver().query(
                    parse, (String[]) null, (String) null, (String[]) null,
                    (String) null);
            if (query == null) {
                return parse.getPath();
            }
            query.moveToFirst();
            return query.getString(query.getColumnIndex("_data"));
        }

        public Bitmap compressImage(String imageUri) {
            String filePath = getRealPathFromURI(imageUri);
            Log.e("FILE_PATH", filePath);
            Bitmap scaledBitmap = null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            Bitmap bmp = BitmapFactory.decodeFile(filePath, options);
            int actualHeight = options.outHeight;
            int actualWidth = options.outWidth;
            float imgRatio = (float) (actualWidth / actualHeight);
            if (((float) actualHeight) > 2048.0f
                    || ((float) actualWidth) > 1440.0f) {
                if (imgRatio < 0.703125f) {
                    actualWidth = (int) (((float) actualWidth) * (2048.0f / ((float) actualHeight)));
                    actualHeight = AccessibilityNodeInfoCompat.ACTION_PREVIOUS_HTML_ELEMENT;
                } else if (imgRatio > 0.703125f) {
                    actualHeight = (int) (((float) actualHeight) * (1440.0f / ((float) actualWidth)));
                    actualWidth = 1440;
                } else {
                    actualHeight = AccessibilityNodeInfoCompat.ACTION_PREVIOUS_HTML_ELEMENT;
                    actualWidth = 1440;
                }
            }
            options.inSampleSize = ImageLoadingUtils.calculateInSampleSize(
                    options, actualWidth, actualHeight);
            options.inJustDecodeBounds = false;
            options.inDither = false;
            options.inPurgeable = true;
            options.inInputShareable = true;
            options.inTempStorage = new byte[AccessibilityNodeInfoCompat.ACTION_COPY];
            try {
                bmp = BitmapFactory.decodeFile(filePath, options);
            } catch (OutOfMemoryError exception) {
                exception.printStackTrace();
            }
            try {
                scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight,
                        Bitmap.Config.ARGB_8888);
            } catch (OutOfMemoryError exception2) {
                exception2.printStackTrace();
            }
            float ratioX = ((float) actualWidth) / ((float) options.outWidth);
            float ratioY = ((float) actualHeight) / ((float) options.outHeight);
            float middleX = ((float) actualWidth) / 2.0f;
            float middleY = ((float) actualHeight) / 2.0f;
            Matrix scaleMatrix = new Matrix();
            scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
            Canvas canvas = new Canvas(scaledBitmap);
            canvas.setMatrix(scaleMatrix);
            canvas.drawBitmap(
                    bmp,
                    middleX
                            - ((float) (bmp.getWidth() / REQUEST_ID_MULTIPLE_PERMISSIONS)),
                    middleY
                            - ((float) (bmp.getHeight() / REQUEST_ID_MULTIPLE_PERMISSIONS)),
                    new Paint(REQUEST_ID_MULTIPLE_PERMISSIONS));
            try {
                int orientation = new ExifInterface(filePath).getAttributeInt(
                        "Orientation", 0);
                Log.d("EXIF", "Exif: " + orientation);
                Matrix matrix = new Matrix();
                if (orientation == RE_GALLERY) {
                    matrix.postRotate(90.0f);
                    Log.d("EXIF", "Exif: " + orientation);
                } else if (orientation == MY_REQUEST_CODE) {
                    matrix.postRotate(Glob.HUE_CYAN);
                    Log.d("EXIF", "Exif: " + orientation);
                } else if (orientation == 8) {
                    matrix.postRotate(Glob.HUE_VIOLET);
                    Log.d("EXIF", "Exif: " + orientation);
                }
                scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
                        scaledBitmap.getWidth(), scaledBitmap.getHeight(),
                        matrix, true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return scaledBitmap;
        }

        protected Bitmap doInBackground(final String... array) {
            return this.compressImage(array[0]);
        }

        protected void onPostExecute(final Bitmap bitmap) {
            super.onPostExecute((Bitmap) bitmap);
            HomeFragment.bitmap = bitmap;
            final SharedPreferences defaultSharedPreferences = PreferenceManager
                    .getDefaultSharedPreferences(getActivity()
                            .getApplicationContext());
            final Intent intent = new Intent((Context) getActivity(),
                    (Class) ActivityCrop.class);
            if (defaultSharedPreferences.getBoolean("isHair", false)) {
                intent.putExtra("hair", false);
                getActivity().startActivity(intent);
                return;
            }
            intent.putExtra("hair", false);
            getActivity().startActivity(intent);
        }
    }

    private InterstitialAd interstitial;
    private int id;

    public void loadAd() {
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(getActivity());
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case 101:
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (getActivity().checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0) {
                                openGallery();
                            } else if (getActivity()
                                    .checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
                                getActivity()
                                        .requestPermissions(
                                                new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                                                3);
                            }
                            return;
                        }
                        openGallery();
                        break;
                    case 102:
                        getActivity().startActivity(new Intent(
                                getActivity().getApplicationContext(),
                                (Class) MyStudioActivity.class));
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(getActivity())
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    public void onDestroy() {
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        super.onDestroy();
    }
}
