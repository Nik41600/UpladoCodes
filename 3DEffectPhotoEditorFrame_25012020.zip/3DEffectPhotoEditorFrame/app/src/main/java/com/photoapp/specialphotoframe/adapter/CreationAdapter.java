package com.photoapp.specialphotoframe.adapter;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;

import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.photoapp.specialphotoframe.R;
import com.photoapp.specialphotoframe.utils.Glob;

public class CreationAdapter extends BaseAdapter {
    private static LayoutInflater inflater;
    private Activity dactivity;
    private int imageSize;
    ArrayList<String> imagegallary;
    SparseBooleanArray mSparseBooleanArray;
    MediaMetadataRetriever metaRetriever;
    View vi;

    class creationAdapter_class implements OnClickListener {
        final int val$position;

        class ImageShare implements OnClickListener {
            final Dialog val$dialog;

            ImageShare(Dialog dialog) {
                this.val$dialog = dialog;
            }

            public void onClick(View v)
            {
                Intent shareIntent = new Intent("android.intent.action.SEND");
                shareIntent.setType("image/*");
                shareIntent.putExtra("android.intent.extra.TEXT", Glob.app_name
                        + " Create By : " + Glob.app_name);
                shareIntent
                        .putExtra(
                                "android.intent.extra.STREAM",
                                Uri.fromFile(new File(
                                        (String) CreationAdapter.this.imagegallary
                                                .get(creationAdapter_class.this.val$position))));
                CreationAdapter.this.dactivity.startActivity(Intent
                        .createChooser(shareIntent, "Share Image using"));
                this.val$dialog.dismiss();
            }
        }

        class ImgSetAs implements OnClickListener {
            final Dialog val$dialog;

            ImgSetAs(Dialog dialog) {
                this.val$dialog = dialog;
            }

            public void onClick(View v) {
                CreationAdapter.this.setWallpaper("Diversity",
                        (String) CreationAdapter.this.imagegallary
                                .get(creationAdapter_class.this.val$position));
                this.val$dialog.dismiss();
            }
        }

        class ImgDelete implements OnClickListener {
            final Dialog val$dialog;

            class Dialogdeleteyes implements OnClickListener {
                final Dialog val$dial;

                Dialogdeleteyes(Dialog dialog) {
                    this.val$dial = dialog;
                }

                @SuppressLint("WrongConstant")
                public void onClick(View view) {
                    File fD = new File(
                            (String) CreationAdapter.this.imagegallary
                                    .get(creationAdapter_class.this.val$position));
                    if (fD.exists()) {
                        fD.delete();
                    }
                    CreationAdapter.this.imagegallary
                            .remove(creationAdapter_class.this.val$position);
                    CreationAdapter.this.dactivity.sendBroadcast(new Intent(
                            "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                            Uri.fromFile(new File(String.valueOf(fD)))));
                    CreationAdapter.this.notifyDataSetChanged();
                    if (CreationAdapter.this.imagegallary.size() == 0) {
                        Toast.makeText(CreationAdapter.this.dactivity,
                                "No Image Found..", 1).show();
                    }
                    this.val$dial.dismiss();
                    ImgDelete.this.val$dialog.dismiss();
                }
            }

            class DialogdeleteNo implements OnClickListener {
                final Dialog val$dial;

                DialogdeleteNo(Dialog dialog) {
                    this.val$dial = dialog;
                }

                public void onClick(View view) {
                    this.val$dial.dismiss();
                }
            }

            ImgDelete(Dialog dialog) {
                this.val$dialog = dialog;
            }

            public void onClick(View v) {
                @SuppressLint("ResourceType") Dialog dial = new Dialog(CreationAdapter.this.dactivity,
                        16973839);
                dial.requestWindowFeature(1);
                dial.setContentView(R.layout.delete_confirmation);
                dial.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dial.setCanceledOnTouchOutside(true);
                ((TextView) dial.findViewById(R.id.delete_yes))
                        .setOnClickListener(new Dialogdeleteyes(dial));
                ((TextView) dial.findViewById(R.id.delete_no))
                        .setOnClickListener(new DialogdeleteNo(dial));
                dial.show();
            }
        }

        creationAdapter_class(int i) {
            this.val$position = i;
        }

        public void onClick(View view) {
            @SuppressLint("ResourceType") Dialog dialog = new Dialog(CreationAdapter.this.dactivity, 16973839);
            DisplayMetrics metrics = new DisplayMetrics();
            CreationAdapter.this.dactivity.getWindowManager()
                    .getDefaultDisplay().getMetrics(metrics);
            int height = (int) (((double) metrics.heightPixels) * 1.0d);
            int width = (int) (((double) metrics.widthPixels) * 1.0d);
            dialog.requestWindowFeature(1);
            dialog.getWindow().setFlags(
                    AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT,
                    AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT);
            dialog.setContentView(R.layout.layout_fullscreen_image);
            dialog.getWindow().setLayout(width, height);
            dialog.setCanceledOnTouchOutside(true);
            ImageView imgDelete = (ImageView) dialog
                    .findViewById(R.id.imgDelete);
            ImageView imgShare = (ImageView) dialog.findViewById(R.id.imgShare);
            ImageView imgSetAs = (ImageView) dialog.findViewById(R.id.imgSetAs);
            ((ImageView) dialog.findViewById(R.id.imgDisplay)).setImageURI(Uri
                    .parse((String) Glob.IMAGEALLARY.get(this.val$position)));
            imgShare.setOnClickListener(new ImageShare(dialog));
            imgSetAs.setOnClickListener(new ImgSetAs(dialog));
            imgDelete.setOnClickListener(new ImgDelete(dialog));
            dialog.show();
        }
    }

    static class ViewHolder {
        public FrameLayout frm;
        ImageView imgIcon;

        ViewHolder() {
        }
    }

    static {
        inflater = null;
    }

    @SuppressLint("WrongConstant")
    public CreationAdapter(Activity dAct, ArrayList<String> dUrl) {
        this.imagegallary = new ArrayList();
        this.dactivity = dAct;
        this.imagegallary = dUrl;
        inflater = (LayoutInflater) this.dactivity
                .getSystemService("layout_inflater");
        this.mSparseBooleanArray = new SparseBooleanArray(
                this.imagegallary.size());
    }

    public int getCount() {
        return this.imagegallary.size();
    }

    public Object getItem(int position) {
        return Integer.valueOf(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        View row = convertView;
        int width = this.dactivity.getResources().getDisplayMetrics().widthPixels;
        if (row == null) {
            row = LayoutInflater.from(this.dactivity).inflate(
                    R.layout.list_gallary, parent, false);
            holder = new ViewHolder();
            holder.frm = (FrameLayout) row.findViewById(R.id.frm);
            holder.imgIcon = (ImageView) row.findViewById(R.id.imgIcon);
            holder.imgIcon.setOnClickListener(new creationAdapter_class(
                    position));
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }
        Glide.with(this.dactivity)
                .load((String) this.imagegallary.get(position))
                .into(holder.imgIcon);
        System.gc();
        return row;
    }

    @SuppressLint("WrongConstant")
    private void setWallpaper(String diversity, String s) {
        WallpaperManager wallpaperManager = WallpaperManager
                .getInstance(this.dactivity);
        DisplayMetrics metrics = new DisplayMetrics();
        this.dactivity.getWindowManager().getDefaultDisplay()
                .getMetrics(metrics);
        int height = metrics.heightPixels;
        int width = metrics.widthPixels;
        try {
            Options options = new Options();
            options.inPreferredConfig = Config.ARGB_8888;
            wallpaperManager.setBitmap(BitmapFactory.decodeFile(s, options));
            wallpaperManager.suggestDesiredDimensions(width / 2, height / 2);
            Toast.makeText(this.dactivity, "Wallpaper Set", 1).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
