package com.photoapp.specialphotoframe.adapter;

import com.photoapp.specialphotoframe.R;

import android.content.*;
import android.view.*;
import android.app.*;
import android.widget.*;
import android.graphics.*;

public class CardFontStyleAdapter extends BaseAdapter {
	private Context context;
	private final String[] mobileValues;

	public CardFontStyleAdapter(final Context context,
			final String[] mobileValues) {
		this.context = context;
		this.mobileValues = mobileValues;
	}

	public int getCount() {
		return this.mobileValues.length;
	}

	public Object getItem(final int n) {
		return null;
	}

	public long getItemId(final int n) {
		return 0L;
	}

	public View getView(final int n, View inflate, final ViewGroup viewGroup) {
		RecordHolder tag;
		if (inflate == null) {
			inflate = ((Activity) this.context).getLayoutInflater().inflate(
					R.layout.listitem_fontstyle, viewGroup, false);
			tag = new RecordHolder();
			tag.txt_font = (TextView) inflate.findViewById(R.id.img_grid_item);
			inflate.setTag((Object) tag);
		} else {
			tag = (RecordHolder) inflate.getTag();
		}
		tag.type = Typeface.createFromAsset(this.context.getAssets(),
				this.mobileValues[n]);
		tag.txt_font.setTypeface(tag.type);
		return inflate;
	}

	static class RecordHolder {
		TextView txt_font;
		Typeface type;
	}
}
