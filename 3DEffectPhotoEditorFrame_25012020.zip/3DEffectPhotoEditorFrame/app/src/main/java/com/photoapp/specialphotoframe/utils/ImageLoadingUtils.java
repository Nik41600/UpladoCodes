package com.photoapp.specialphotoframe.utils;

import android.content.*;
import android.util.*;
import android.graphics.*;

public class ImageLoadingUtils {
	private Context context;

	public ImageLoadingUtils(final Context context) {
		this.context = context;
	}

	public static int calculateInSampleSize(
			final BitmapFactory.Options bitmapFactory$Options, final int n,
			final int n2) {
		final int outHeight = bitmapFactory$Options.outHeight;
		final int outWidth = bitmapFactory$Options.outWidth;
		int round = 1;
		if (outHeight > n2 || outWidth > n) {
			round = Math.round(outHeight / n2);
			final int round2 = Math.round(outWidth / n);
			if (round >= round2) {
				round = round2;
			}
		}
		while (outWidth * outHeight / (round * round) > n * n2 * 2) {
			++round;
		}
		return round;
	}

	public int convertDipToPixels(final float n) {
		return (int) TypedValue.applyDimension(1, n, this.context
				.getResources().getDisplayMetrics());
	}

	public Bitmap decodeBitmapFromPath(final String s) {
		final BitmapFactory.Options bitmapFactory$Options = new BitmapFactory.Options();
		bitmapFactory$Options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(s, bitmapFactory$Options);
		bitmapFactory$Options.inSampleSize = calculateInSampleSize(
				bitmapFactory$Options, this.convertDipToPixels(150.0f),
				this.convertDipToPixels(200.0f));
		bitmapFactory$Options.inDither = false;
		bitmapFactory$Options.inPurgeable = true;
		bitmapFactory$Options.inInputShareable = true;
		bitmapFactory$Options.inJustDecodeBounds = false;
		return BitmapFactory.decodeFile(s, bitmapFactory$Options);
	}
}
