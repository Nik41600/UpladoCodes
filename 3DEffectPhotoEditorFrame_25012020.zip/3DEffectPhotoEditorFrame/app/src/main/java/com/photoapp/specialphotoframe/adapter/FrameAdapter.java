package com.photoapp.specialphotoframe.adapter;

import java.util.*;

import android.annotation.SuppressLint;
import android.content.*;
import android.widget.*;
import android.view.*;
import com.bumptech.glide.*;
import com.photoapp.specialphotoframe.R;

import android.util.*;

public class FrameAdapter extends BaseAdapter {
	ArrayList<Integer> collage;
	Context context;
	private int height;
	ImageView img_editing;
	private LayoutInflater inflater;
	private int width;

	@SuppressLint("WrongConstant")
	public FrameAdapter(final Context context, final ArrayList<Integer> collage) {
		this.context = context;
		this.collage = collage;
		this.inflater = (LayoutInflater) this.context
				.getSystemService("layout_inflater");
	}

	public int getCount() {
		return this.collage.size();
	}

	public Object getItem(final int n) {
		return this.collage.get(n);
	}

	public long getItemId(final int n) {
		return n;
	}

	public View getView(int intValue, final View view, final ViewGroup viewGroup) {
		View inflate = view;
		if (view == null) {
			inflate = this.inflater.inflate(R.layout.frame_item,
					(ViewGroup) null);
		}
		this.img_editing = (ImageView) inflate.findViewById(R.id.img_editing);
		final DisplayMetrics displayMetrics = this.context.getResources()
				.getDisplayMetrics();
		this.width = displayMetrics.widthPixels;
		this.height = displayMetrics.heightPixels;
		intValue = this.collage.get(intValue);
		Glide.with(this.context).load(Integer.valueOf(intValue))
				.override(this.width / 4, this.height / 7)
				.into(this.img_editing);
		System.gc();
		return inflate;
	}
}
