package com.photoapp.specialphotoframe.utils;

import java.util.*;
import android.graphics.*;
import android.os.*;
import java.io.*;
import android.util.*;

public class Glob {
	public static final int BATTERY_USAGE_UNRESTRICTED = 256;
	public static String DEVICE_ID;
	public static String Edit_Folder_name;
	public static final float HUE_CYAN = 180.0f;
	public static final float HUE_MAGENTA = 300.0f;
	public static final float HUE_VIOLET = 270.0f;
	public static ArrayList<String> IMAGEALLARY;
	public static String acc_link;
	public static int appID;
	public static String app_link;
	public static String app_name;
	public static String privacy_link;
	public static Bitmap txtBitmap;

	static {
		Glob.Edit_Folder_name = "3D Stylish Photo Frame";
		Glob.app_name = "3D Stylish Photo Frame";
		Glob.privacy_link = "http://photoapplounge.com/policy.html";
		Glob.appID = 73;
		Glob.IMAGEALLARY = new ArrayList<String>();
		Glob.DEVICE_ID = "";
	}

	public static boolean createDirIfNotExists(final String s) {
		boolean b = true;
		final File file = new File(Environment.getExternalStorageDirectory(),
				"/" + s);
		if (!file.exists()) {
			file.mkdir();
			if (!file.mkdirs()) {
				b = false;
			}
			return b;
		}
		System.out.println("Can't create folder");
		return true;
	}

	public static void listAllImages(final File file) {
		final File[] listFiles = file.listFiles();
		if (listFiles != null) {
			for (int i = listFiles.length - 1; i >= 0; --i) {
				final String string = listFiles[i].toString();
				final File file2 = new File(string);
				Log.d("" + file2.length(), "" + file2.length());
				if (file2.length() > 1024L) {
					if (file2.toString().contains(".jpg")
							|| file2.toString().contains(".png")
							|| file2.toString().contains(".jpeg")) {
						Glob.IMAGEALLARY.add(string);
					}
				} else {
					Log.i("Invalid Image", "Delete Image");
				}
				System.out.println(string);
			}
		} else {
			System.out.println("Empty Folder");
		}
	}
}
