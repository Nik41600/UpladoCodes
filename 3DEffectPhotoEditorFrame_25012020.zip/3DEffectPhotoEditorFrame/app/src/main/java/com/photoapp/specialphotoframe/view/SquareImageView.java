package com.photoapp.specialphotoframe.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class SquareImageView
  extends ImageView
{
  public SquareImageView(Context paramContext)
  {
    super(paramContext);
  }
  
  public SquareImageView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public SquareImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    paramInt1 = getMeasuredWidth();
    setMeasuredDimension(paramInt1, paramInt1);
  }
  
  public void setWidthHeight(int paramInt)
  {
    setMeasuredDimension(paramInt, paramInt);
  }
}


/* Location:              E:\Decompile\dex2jar-2.0\dex2jar-2.0\3D Effect Photo Editor Frame_v1.0_apkpure.com-dex2jar.jar!\com\photoapp\specialphotoframe\view\SquareImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */