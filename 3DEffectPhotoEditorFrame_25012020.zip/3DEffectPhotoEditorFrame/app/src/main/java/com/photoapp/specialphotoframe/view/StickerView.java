package com.photoapp.specialphotoframe.view;

import com.photoapp.specialphotoframe.R;

import android.widget.*;
import android.content.*;
import android.view.*;
import android.util.*;
import android.graphics.*;
import androidx.core.view.*;

public class StickerView extends ImageView {
	private static final float BITMAP_SCALE = 0.7f;
	private static final String TAG = "StickerView";
	private float MAX_SCALE;
	private float MIN_SCALE;
	private Bitmap deleteBitmap;
	private int deleteBitmapHeight;
	private int deleteBitmapWidth;
	private DisplayMetrics dm;
	private Rect dst_delete;
	private Rect dst_flipV;
	private Rect dst_resize;
	private Rect dst_top;
	private Bitmap flipVBitmap;
	private int flipVBitmapHeight;
	private int flipVBitmapWidth;
	private double halfDiagonalLength;
	private boolean isHorizonMirror;
	private boolean isInEdit;
	private boolean isInResize;
	private boolean isInSide;
	private boolean isPointerDown;
	private float lastLength;
	private float lastRotateDegree;
	private float lastX;
	private float lastY;
	private Paint localPaint;
	private Bitmap mBitmap;
	private int mScreenHeight;
	private int mScreenwidth;
	private Matrix matrix;
	private PointF mid;
	private float oldDis;
	private OperationListener operationListener;
	private float oringinWidth;
	private final float pointerLimitDis;
	private final float pointerZoomCoeff;
	private Bitmap resizeBitmap;
	private int resizeBitmapHeight;
	private int resizeBitmapWidth;
	private final long stickerId;
	private Bitmap topBitmap;
	private int topBitmapHeight;
	private int topBitmapWidth;

	public StickerView(final Context context) {
		super(context);
		this.mid = new PointF();
		this.isPointerDown = false;
		this.pointerLimitDis = 20.0f;
		this.pointerZoomCoeff = 0.09f;
		this.isInResize = false;
		this.matrix = new Matrix();
		this.isInEdit = true;
		this.MIN_SCALE = 0.5f;
		this.MAX_SCALE = 1.2f;
		this.oringinWidth = 0.0f;
		this.isHorizonMirror = false;
		this.stickerId = 0L;
		this.init();
	}

	public StickerView(final Context context, final AttributeSet set) {
		super(context, set);
		this.mid = new PointF();
		this.isPointerDown = false;
		this.pointerLimitDis = 20.0f;
		this.pointerZoomCoeff = 0.09f;
		this.isInResize = false;
		this.matrix = new Matrix();
		this.isInEdit = true;
		this.MIN_SCALE = 0.5f;
		this.MAX_SCALE = 1.2f;
		this.oringinWidth = 0.0f;
		this.isHorizonMirror = false;
		this.stickerId = 0L;
		this.init();
	}

	public StickerView(final Context context, final AttributeSet set,
			final int n) {
		super(context, set, n);
		this.mid = new PointF();
		this.isPointerDown = false;
		this.pointerLimitDis = 20.0f;
		this.pointerZoomCoeff = 0.09f;
		this.isInResize = false;
		this.matrix = new Matrix();
		this.isInEdit = true;
		this.MIN_SCALE = 0.5f;
		this.MAX_SCALE = 1.2f;
		this.oringinWidth = 0.0f;
		this.isHorizonMirror = false;
		this.stickerId = 0L;
		this.init();
	}

	private float diagonalLength(final MotionEvent motionEvent) {
		return (float) Math.hypot(motionEvent.getX(0) - this.mid.x,
				motionEvent.getY(0) - this.mid.y);
	}

	private void init() {
		this.dst_delete = new Rect();
		this.dst_resize = new Rect();
		this.dst_flipV = new Rect();
		this.dst_top = new Rect();
		(this.localPaint = new Paint()).setColor(this.getResources().getColor(
				R.color.colorAccent));
		this.localPaint.setAntiAlias(true);
		this.localPaint.setDither(true);
		this.localPaint.setStyle(Paint.Style.STROKE);
		this.localPaint.setStrokeWidth(2.0f);
		this.dm = this.getResources().getDisplayMetrics();
		this.mScreenwidth = this.dm.widthPixels;
		this.mScreenHeight = this.dm.heightPixels;
	}

	private void initBitmaps() {
		if (this.mBitmap.getWidth() >= this.mBitmap.getHeight()) {
			final float n = this.mScreenwidth / 8;
			if (this.mBitmap.getWidth() < n) {
				this.MIN_SCALE = 1.0f;
			} else {
				this.MIN_SCALE = 1.0f * n / this.mBitmap.getWidth();
			}
			if (this.mBitmap.getWidth() > this.mScreenwidth) {
				this.MAX_SCALE = 1.0f;
			} else {
				this.MAX_SCALE = this.mScreenwidth * 1.0f
						/ this.mBitmap.getWidth();
			}
		} else {
			final float n2 = this.mScreenwidth / 8;
			if (this.mBitmap.getHeight() < n2) {
				this.MIN_SCALE = 1.0f;
			} else {
				this.MIN_SCALE = 1.0f * n2 / this.mBitmap.getHeight();
			}
			if (this.mBitmap.getHeight() > this.mScreenwidth) {
				this.MAX_SCALE = 1.0f;
			} else {
				this.MAX_SCALE = this.mScreenwidth * 1.0f
						/ this.mBitmap.getHeight();
			}
		}
		this.topBitmap = BitmapFactory.decodeResource(getResources(),
				R.mipmap.icon_top_enable);
		this.deleteBitmap = BitmapFactory.decodeResource(getResources(),
				R.mipmap.icon_delete);
		this.flipVBitmap = BitmapFactory.decodeResource(getResources(),
				R.mipmap.icon_flip);
		this.resizeBitmap = BitmapFactory.decodeResource(getResources(),
				R.mipmap.icon_resize);
		this.deleteBitmapWidth = (int) (((float) this.deleteBitmap.getWidth()) * BITMAP_SCALE);
		this.deleteBitmapHeight = (int) (((float) this.deleteBitmap.getHeight()) * BITMAP_SCALE);
		this.resizeBitmapWidth = (int) (((float) this.resizeBitmap.getWidth()) * BITMAP_SCALE);
		this.resizeBitmapHeight = (int) (((float) this.resizeBitmap.getHeight()) * BITMAP_SCALE);
		this.flipVBitmapWidth = (int) (((float) this.flipVBitmap.getWidth()) * BITMAP_SCALE);
		this.flipVBitmapHeight = (int) (((float) this.flipVBitmap.getHeight()) * BITMAP_SCALE);
		this.topBitmapWidth = (int) (((float) this.topBitmap.getWidth()) * BITMAP_SCALE);
		this.topBitmapHeight = (int) (((float) this.topBitmap.getHeight()) * BITMAP_SCALE);
	}

	private boolean isInBitmap(final MotionEvent motionEvent) {
		final float[] array = new float[9];
		this.matrix.getValues(array);
		return this.pointInRect(
				new float[] {
						0.0f * array[0] + 0.0f * array[1] + array[2],
						array[0] * this.mBitmap.getWidth() + 0.0f * array[1]
								+ array[2],
						array[0] * this.mBitmap.getWidth() + array[1]
								* this.mBitmap.getHeight() + array[2],
						0.0f * array[0] + array[1] * this.mBitmap.getHeight()
								+ array[2] }, new float[] {
						0.0f * array[3] + 0.0f * array[4] + array[5],
						array[3] * this.mBitmap.getWidth() + 0.0f * array[4]
								+ array[5],
						array[3] * this.mBitmap.getWidth() + array[4]
								* this.mBitmap.getHeight() + array[5],
						0.0f * array[3] + array[4] * this.mBitmap.getHeight()
								+ array[5] }, motionEvent.getX(0),
				motionEvent.getY(0));
	}

	private boolean isInButton(final MotionEvent motionEvent, final Rect rect) {
		final boolean b = false;
		final int left = rect.left;
		final int right = rect.right;
		final int top = rect.top;
		final int bottom = rect.bottom;
		boolean b2 = b;
		if (motionEvent.getX(0) >= left) {
			b2 = b;
			if (motionEvent.getX(0) <= right) {
				b2 = b;
				if (motionEvent.getY(0) >= top) {
					b2 = b;
					if (motionEvent.getY(0) <= bottom) {
						b2 = true;
					}
				}
			}
		}
		return b2;
	}

	private boolean isInResize(final MotionEvent motionEvent) {
		final boolean b = false;
		final int left = this.dst_resize.left;
		final int top = this.dst_resize.top;
		final int right = this.dst_resize.right;
		final int bottom = this.dst_resize.bottom;
		boolean b2 = b;
		if (motionEvent.getX(0) >= left - 20) {
			b2 = b;
			if (motionEvent.getX(0) <= right + 20) {
				b2 = b;
				if (motionEvent.getY(0) >= top - 20) {
					b2 = b;
					if (motionEvent.getY(0) <= bottom + 20) {
						b2 = true;
					}
				}
			}
		}
		return b2;
	}

	private void midDiagonalPoint(final PointF pointF) {
		final float[] array = new float[9];
		this.matrix.getValues(array);
		pointF.set(
				(array[0] * 0.0f + array[1] * 0.0f + array[2] + (array[0]
						* this.mBitmap.getWidth() + array[1]
						* this.mBitmap.getHeight() + array[2])) / 2.0f,
				(array[3] * 0.0f + array[4] * 0.0f + array[5] + (array[3]
						* this.mBitmap.getWidth() + array[4]
						* this.mBitmap.getHeight() + array[5])) / 2.0f);
	}

	private void midPointToStartPoint(final MotionEvent motionEvent) {
		final float[] array = new float[9];
		this.matrix.getValues(array);
		this.mid.set(
				(array[0] * 0.0f + array[1] * 0.0f + array[2] + motionEvent
						.getX(0)) / 2.0f, (array[3] * 0.0f + array[4] * 0.0f
						+ array[5] + motionEvent.getY(0)) / 2.0f);
	}

	private boolean pointInRect(final float[] array, final float[] array2,
			final float n, final float n2) {
		final double hypot = Math.hypot(array[0] - array[1], array2[0]
				- array2[1]);
		final double hypot2 = Math.hypot(array[1] - array[2], array2[1]
				- array2[2]);
		final double hypot3 = Math.hypot(array[3] - array[2], array2[3]
				- array2[2]);
		final double hypot4 = Math.hypot(array[0] - array[3], array2[0]
				- array2[3]);
		final double hypot5 = Math.hypot(n - array[0], n2 - array2[0]);
		final double hypot6 = Math.hypot(n - array[1], n2 - array2[1]);
		final double hypot7 = Math.hypot(n - array[2], n2 - array2[2]);
		final double hypot8 = Math.hypot(n - array[3], n2 - array2[3]);
		final double n3 = (hypot + hypot5 + hypot6) / 2.0;
		final double n4 = (hypot2 + hypot6 + hypot7) / 2.0;
		final double n5 = (hypot3 + hypot7 + hypot8) / 2.0;
		final double n6 = (hypot4 + hypot8 + hypot5) / 2.0;
		return Math.abs(hypot
				* hypot2
				- (Math.sqrt((n3 - hypot) * n3 * (n3 - hypot5) * (n3 - hypot6))
						+ Math.sqrt((n4 - hypot2) * n4 * (n4 - hypot6)
								* (n4 - hypot7))
						+ Math.sqrt((n5 - hypot3) * n5 * (n5 - hypot7)
								* (n5 - hypot8)) + Math.sqrt((n6 - hypot4) * n6
						* (n6 - hypot8) * (n6 - hypot5)))) < 0.5;
	}

	private float rotationToStartPoint(final MotionEvent motionEvent) {
		final float[] array = new float[9];
		this.matrix.getValues(array);
		return (float) Math.toDegrees(Math.atan2(motionEvent.getY(0)
				- (array[3] * 0.0f + array[4] * 0.0f + array[5]),
				motionEvent.getX(0)
						- (array[0] * 0.0f + array[1] * 0.0f + array[2])));
	}

	private void setDiagonalLength() {
		this.halfDiagonalLength = Math.hypot(this.mBitmap.getWidth(),
				this.mBitmap.getHeight()) / 2.0;
	}

	private float spacing(final MotionEvent motionEvent) {
		if (motionEvent.getPointerCount() == 2) {
			final float n = motionEvent.getX(0) - motionEvent.getX(1);
			final float n2 = motionEvent.getY(0) - motionEvent.getY(1);
			return (float) Math.sqrt(n * n + n2 * n2);
		}
		return 0.0f;
	}

	public StickerPropertyModel calculate(
			final StickerPropertyModel stickerPropertyModel) {
		final float[] array = new float[9];
		this.matrix.getValues(array);
		Log.d("StickerView", "tx : " + array[2] + " ty : " + array[5]);
		final float n = array[0];
		final float n2 = array[3];
		final float n3 = (float) Math.sqrt(n * n + n2 * n2);
		Log.d("StickerView", "rScale : " + n3);
		final float n4 = Math
				.round(Math.atan2(array[1], array[0]) * 57.29577951308232);
		Log.d("StickerView", "rAngle : " + n4);
		final PointF pointF = new PointF();
		this.midDiagonalPoint(pointF);
		Log.d("StickerView", " width  : " + this.mBitmap.getWidth() * n3
				+ " height " + this.mBitmap.getHeight() * n3);
		final float x = pointF.x;
		final float y = pointF.y;
		Log.d("StickerView", "midX : " + x + " midY : " + y);
		stickerPropertyModel.setDegree((float) Math.toRadians(n4));
		stickerPropertyModel.setScaling(this.mBitmap.getWidth() * n3
				/ this.mScreenwidth);
		stickerPropertyModel.setxLocation(x / this.mScreenwidth);
		stickerPropertyModel.setyLocation(y / this.mScreenwidth);
		stickerPropertyModel.setStickerId(this.stickerId);
		if (this.isHorizonMirror) {
			stickerPropertyModel.setHorizonMirror(1);
			return stickerPropertyModel;
		}
		stickerPropertyModel.setHorizonMirror(2);
		return stickerPropertyModel;
	}

	protected void onDraw(final Canvas canvas) {
		if (this.mBitmap != null) {
			final float[] array = new float[9];
			this.matrix.getValues(array);
			final float n = 0.0f * array[0] + 0.0f * array[1] + array[2];
			final float n2 = 0.0f * array[3] + 0.0f * array[4] + array[5];
			final float n3 = array[0] * this.mBitmap.getWidth() + 0.0f
					* array[1] + array[2];
			final float n4 = array[3] * this.mBitmap.getWidth() + 0.0f
					* array[4] + array[5];
			final float n5 = 0.0f * array[0] + array[1]
					* this.mBitmap.getHeight() + array[2];
			final float n6 = 0.0f * array[3] + array[4]
					* this.mBitmap.getHeight() + array[5];
			final float n7 = array[0] * this.mBitmap.getWidth() + array[1]
					* this.mBitmap.getHeight() + array[2];
			final float n8 = array[3] * this.mBitmap.getWidth() + array[4]
					* this.mBitmap.getHeight() + array[5];
			canvas.save();
			canvas.drawBitmap(this.mBitmap, this.matrix, (Paint) null);
			this.dst_delete.left = (int) (n3 - this.deleteBitmapWidth / 2);
			this.dst_delete.right = (int) (this.deleteBitmapWidth / 2 + n3);
			this.dst_delete.top = (int) (n4 - this.deleteBitmapHeight / 2);
			this.dst_delete.bottom = (int) (this.deleteBitmapHeight / 2 + n4);
			this.dst_resize.left = (int) (n7 - this.resizeBitmapWidth / 2);
			this.dst_resize.right = (int) (this.resizeBitmapWidth / 2 + n7);
			this.dst_resize.top = (int) (n8 - this.resizeBitmapHeight / 2);
			this.dst_resize.bottom = (int) (this.resizeBitmapHeight / 2 + n8);
			this.dst_top.left = (int) (n - this.flipVBitmapWidth / 2);
			this.dst_top.right = (int) (this.flipVBitmapWidth / 2 + n);
			this.dst_top.top = (int) (n2 - this.flipVBitmapHeight / 2);
			this.dst_top.bottom = (int) (this.flipVBitmapHeight / 2 + n2);
			this.dst_flipV.left = (int) (n5 - this.topBitmapWidth / 2);
			this.dst_flipV.right = (int) (this.topBitmapWidth / 2 + n5);
			this.dst_flipV.top = (int) (n6 - this.topBitmapHeight / 2);
			this.dst_flipV.bottom = (int) (this.topBitmapHeight / 2 + n6);
			if (this.isInEdit) {
				canvas.drawLine(n, n2, n3, n4, this.localPaint);
				canvas.drawLine(n3, n4, n7, n8, this.localPaint);
				canvas.drawLine(n5, n6, n7, n8, this.localPaint);
				canvas.drawLine(n5, n6, n, n2, this.localPaint);
				canvas.drawBitmap(this.deleteBitmap, (Rect) null,
						this.dst_delete, (Paint) null);
				canvas.drawBitmap(this.resizeBitmap, (Rect) null,
						this.dst_resize, (Paint) null);
				canvas.drawBitmap(this.flipVBitmap, (Rect) null,
						this.dst_flipV, (Paint) null);
				canvas.drawBitmap(this.topBitmap, (Rect) null, this.dst_top,
						(Paint) null);
			}
			canvas.restore();
		}
	}

	public boolean onTouchEvent(final MotionEvent motionEvent) {
		final int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
		boolean b2;
		final boolean b = b2 = true;

		switch (actionMasked) {
		default: {
			b2 = b;
			break;
		}
		case 1:
		case 3: {
			this.isInResize = false;
			this.isInSide = false;
			this.isPointerDown = false;
			b2 = b;
			break;
		}
		case 5: {
			if (this.spacing(motionEvent) > 20.0f) {
				this.oldDis = this.spacing(motionEvent);
				this.isPointerDown = true;
				this.midPointToStartPoint(motionEvent);
			} else {
				this.isPointerDown = false;
			}
			this.isInSide = false;
			this.isInResize = false;
			b2 = b;
		}
		case 4: {
			if (b2 && this.operationListener != null) {
				this.operationListener.onEdit(this);
			}
			return b2;
		}
		case 0: {
			if (this.isInButton(motionEvent, this.dst_delete)) {
				b2 = b;
				if (this.operationListener != null) {
					this.operationListener.onDeleteClick();
					b2 = b;
				}
				break;
			} else {
				if (this.isInResize(motionEvent)) {
					this.isInResize = true;
					this.lastRotateDegree = this
							.rotationToStartPoint(motionEvent);
					this.midPointToStartPoint(motionEvent);
					this.lastLength = this.diagonalLength(motionEvent);
					b2 = b;
					break;
				}
				if (this.isInButton(motionEvent, this.dst_flipV)) {
					final PointF pointF = new PointF();
					this.midDiagonalPoint(pointF);
					this.matrix.postScale(-1.0f, 1.0f, pointF.x, pointF.y);
					this.isHorizonMirror = !this.isHorizonMirror;
					this.invalidate();
					b2 = b;
					break;
				}
				if (this.isInButton(motionEvent, this.dst_top)) {
					this.bringToFront();
					b2 = b;
					if (this.operationListener != null) {
						this.operationListener.onTop(this);
						b2 = b;
					}
					break;
				} else {
					if (this.isInBitmap(motionEvent)) {
						this.isInSide = true;
						this.lastX = motionEvent.getX(0);
						this.lastY = motionEvent.getY(0);
						b2 = b;
						break;
					}
					b2 = false;
					break;
				}

			}
		}
		case 2: {
			if (this.isPointerDown) {
				final float spacing = this.spacing(motionEvent);
				float n;
				if (spacing == 0.0f || spacing < 20.0f) {
					n = 1.0f;
				} else {
					n = (spacing / this.oldDis - 1.0f) * 0.09f + 1.0f;
				}
				final float n2 = Math.abs(this.dst_flipV.left
						- this.dst_resize.left)
						* n / this.oringinWidth;
				if ((n2 <= this.MIN_SCALE && n < 1.0f)
						|| (n2 >= this.MAX_SCALE && n > 1.0f)) {
					n = 1.0f;
				} else {
					this.lastLength = this.diagonalLength(motionEvent);
				}
				this.matrix.postScale(n, n, this.mid.x, this.mid.y);
				this.invalidate();
				b2 = b;
				break;
			}
			if (this.isInResize) {
				this.matrix
						.postRotate(
								(this.rotationToStartPoint(motionEvent) - this.lastRotateDegree) * 2.0f,
								this.mid.x, this.mid.y);
				this.lastRotateDegree = this.rotationToStartPoint(motionEvent);
				float n3 = this.diagonalLength(motionEvent) / this.lastLength;
				if ((this.diagonalLength(motionEvent) / this.halfDiagonalLength <= this.MIN_SCALE && n3 < 1.0f)
						|| (this.diagonalLength(motionEvent)
								/ this.halfDiagonalLength >= this.MAX_SCALE && n3 > 1.0f)) {
					final float n4 = n3 = 1.0f;
					if (!this.isInResize(motionEvent)) {
						this.isInResize = false;
						n3 = n4;
					}
				} else {
					this.lastLength = this.diagonalLength(motionEvent);
				}
				this.matrix.postScale(n3, n3, this.mid.x, this.mid.y);
				this.invalidate();
				b2 = b;
				break;
			}
			b2 = b;
			if (this.isInSide) {
				final float x = motionEvent.getX(0);
				final float y = motionEvent.getY(0);
				this.matrix.postTranslate(x - this.lastX, y - this.lastY);
				this.lastX = x;
				this.lastY = y;
				this.invalidate();
				b2 = b;
			}
			break;
		}
		}

		return b;

	}

	public void setBitmap(final Bitmap mBitmap) {
		this.matrix.reset();
		this.mBitmap = mBitmap;
		this.setDiagonalLength();
		this.initBitmaps();
		final int width = this.mBitmap.getWidth();
		final int height = this.mBitmap.getHeight();
		this.oringinWidth = width;
		final float n = (this.MIN_SCALE + this.MAX_SCALE) / 2.0f;
		this.matrix.postTranslate((float) (this.mScreenwidth / 2 - width / 2),
				(float) (this.mScreenHeight / 2 - height / 2));
		this.invalidate();
	}

	public void setImageResource(final int n) {
		this.setBitmap(BitmapFactory.decodeResource(this.getResources(), n));
	}

	public void setInEdit(final boolean isInEdit) {
		this.isInEdit = isInEdit;
		this.invalidate();
	}

	public void setOperationListener(final OperationListener operationListener) {
		this.operationListener = operationListener;
	}

	public interface OperationListener {
		void onDeleteClick();

		void onEdit(final StickerView p0);

		void onTop(final StickerView p0);
	}
}
