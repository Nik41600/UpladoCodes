package com.esc.specialphotoframe.utils;

public class Utils {
	public static String DEVICE_ID = "DEVICE_ID";
}
