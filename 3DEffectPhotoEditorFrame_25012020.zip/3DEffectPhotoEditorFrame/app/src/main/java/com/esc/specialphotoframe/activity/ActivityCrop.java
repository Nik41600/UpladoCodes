package com.esc.specialphotoframe.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esc.specialphotoframe.R;
import com.esc.specialphotoframe.fragment.HomeFragment;
import com.esc.specialphotoframe.kprogresshud.KProgressHUD;
import com.esc.specialphotoframe.utils.*;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.theartofdev.edmodo.cropper.*;

public class ActivityCrop extends Activity implements View.OnClickListener {

    LinearLayout btnCrop16_9;
    LinearLayout btnCrop4_3;
    LinearLayout btnCrop4_5;
    LinearLayout btnCrop5_6;
    LinearLayout btnCropCustom;
    LinearLayout btnCropOriginal;
    LinearLayout btnCropSquare;
    CropImageView cropView;
    ImageView custom_size;
    ImageView org_size;
    ImageView iv_back, iv_next;
    ImageView size4_3;
    ImageView size_16_9;
    ImageView size_4_5;
    ImageView size_5_6;
    ImageView square_size;
    ImageLoadingUtils utils;
    private AdView adView;
    private KProgressHUD hud;

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_crop);
        this.cropView = this.findViewById(R.id.CropImageView);
        this.cropView.setFixedAspectRatio(true);
        this.cropView.setAspectRatio(1, 1);
        this.utils = new ImageLoadingUtils(this.getApplicationContext());
        this.cropView.setImageBitmap(HomeFragment.bitmap);

        this.iv_back = findViewById(R.id.iv_back);
        this.iv_back.setOnClickListener(this);

        this.iv_next = this.findViewById(R.id.iv_next);
        this.iv_next.setOnClickListener(this);

        this.org_size = findViewById(R.id.org_size);
        this.square_size = findViewById(R.id.square_size);
        this.custom_size = findViewById(R.id.custom_size);
        this.size_4_5 = findViewById(R.id.size_4_5);
        this.size_5_6 = findViewById(R.id.size_5_6);
        this.size_16_9 = findViewById(R.id.size_16_9);
        this.size4_3 = findViewById(R.id.size4_3);
        this.btnCropOriginal = findViewById(R.id.btnCropOriginal);
        this.btnCropSquare = findViewById(R.id.btnCropSquare);
        this.btnCrop4_5 = findViewById(R.id.btnCrop4_5);
        this.btnCrop5_6 = findViewById(R.id.btnCrop5_6);
        this.btnCrop4_3 = findViewById(R.id.btnCrop4_3);
        this.btnCropCustom = findViewById(R.id.btnCropCustom);
        this.btnCrop16_9 = findViewById(R.id.btnCrop16_9);

        loadAd();
    }

    public void onClick(final View view) {
        switch (view.getId()) {
            default: {
                break;
            }
            case R.id.btnCropOriginal: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(HomeFragment.bitmap.getWidth(),
                        HomeFragment.bitmap.getHeight());
                org_size.setImageResource(R.drawable.ic_press_fit);
                square_size.setImageResource(R.drawable.ic_unpress_square);
                custom_size.setImageResource(R.drawable.ic_unpress_free);
                size_4_5.setImageResource(R.drawable.ic_unpress_4_5);
                size_5_6.setImageResource(R.drawable.ic_unpress_5_6);
                size_16_9.setImageResource(R.drawable.ic_unpress_16_9);
                size4_3.setImageResource(R.drawable.ic_unpress_4_3);

            }
            break;
            case R.id.btnCropSquare: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(1, 1);

                org_size.setImageResource(R.drawable.ic_unpress_fit);
                square_size.setImageResource(R.drawable.ic_press_square);
                custom_size.setImageResource(R.drawable.ic_unpress_free);
                size_4_5.setImageResource(R.drawable.ic_unpress_4_5);
                size_5_6.setImageResource(R.drawable.ic_unpress_5_6);
                size_16_9.setImageResource(R.drawable.ic_unpress_16_9);
                size4_3.setImageResource(R.drawable.ic_unpress_4_3);
            }
            break;
            case R.id.btnCropCustom: {
                this.cropView.setFixedAspectRatio(false);
                org_size.setImageResource(R.drawable.ic_unpress_fit);
                square_size.setImageResource(R.drawable.ic_unpress_square);
                custom_size.setImageResource(R.drawable.ic_press_free);
                size_4_5.setImageResource(R.drawable.ic_unpress_4_5);
                size_5_6.setImageResource(R.drawable.ic_unpress_5_6);
                size_16_9.setImageResource(R.drawable.ic_unpress_16_9);
                size4_3.setImageResource(R.drawable.ic_unpress_4_3);
            }
            break;
            case R.id.btnCrop4_5: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(4, 5);
                org_size.setImageResource(R.drawable.ic_unpress_fit);
                square_size.setImageResource(R.drawable.ic_unpress_square);
                custom_size.setImageResource(R.drawable.ic_unpress_free);
                size_4_5.setImageResource(R.drawable.ic_press_4_5);
                size_5_6.setImageResource(R.drawable.ic_unpress_5_6);
                size_16_9.setImageResource(R.drawable.ic_unpress_16_9);
                size4_3.setImageResource(R.drawable.ic_unpress_4_3);
            }
            break;
            case R.id.btnCrop5_6: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(5, 6);
                org_size.setImageResource(R.drawable.ic_unpress_fit);
                square_size.setImageResource(R.drawable.ic_unpress_square);
                custom_size.setImageResource(R.drawable.ic_unpress_free);
                size_4_5.setImageResource(R.drawable.ic_unpress_4_5);
                size_5_6.setImageResource(R.drawable.ic_press_5_6);
                size_16_9.setImageResource(R.drawable.ic_unpress_16_9);
                size4_3.setImageResource(R.drawable.ic_unpress_4_3);

            }
            break;
            case R.id.btnCrop16_9: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(16, 9);
                org_size.setImageResource(R.drawable.ic_unpress_fit);
                square_size.setImageResource(R.drawable.ic_unpress_square);
                custom_size.setImageResource(R.drawable.ic_unpress_free);
                size_4_5.setImageResource(R.drawable.ic_unpress_4_5);
                size_5_6.setImageResource(R.drawable.ic_unpress_5_6);
                size_16_9.setImageResource(R.drawable.ic_press_16_9);
                size4_3.setImageResource(R.drawable.ic_unpress_4_3);
            }
            break;
            case R.id.btnCrop4_3: {
                this.cropView.setFixedAspectRatio(true);
                this.cropView.setAspectRatio(4, 3);
                org_size.setImageResource(R.drawable.ic_unpress_fit);
                square_size.setImageResource(R.drawable.ic_unpress_square);
                custom_size.setImageResource(R.drawable.ic_unpress_free);
                size_4_5.setImageResource(R.drawable.ic_unpress_4_5);
                size_5_6.setImageResource(R.drawable.ic_unpress_5_6);
                size_16_9.setImageResource(R.drawable.ic_unpress_16_9);
                size4_3.setImageResource(R.drawable.ic_press_4_3);
            }
            break;

            case R.id.iv_back:
                id = R.id.iv_back;
                iv_next.setImageResource(R.drawable.ic_press_done);
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent back = new Intent(ActivityCrop.this, HomeActivity.class);
                    startActivity(back);
                }
                break;

            case R.id.iv_next:
                id = R.id.iv_next;
                iv_next.setImageResource(R.drawable.ic_press_done);
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    HomeFragment.bitmap = ActivityCrop.this.cropView
                            .getCroppedImage();
                    ActivityCrop.this.startActivity(new Intent(
                            ActivityCrop.this,
                            ImageChangeActivity.class));
                    ActivityCrop.this.finish();
                }
                break;
        }
    }


    private InterstitialAd interstitial;
    private int id;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_back:
                        Intent back = new Intent(ActivityCrop.this, HomeActivity.class);
                        startActivity(back);
                        break;
                    case R.id.iv_next:
                        HomeFragment.bitmap = ActivityCrop.this.cropView
                                .getCroppedImage();
                        ActivityCrop.this.startActivity(new Intent(
                                ActivityCrop.this,
                                ImageChangeActivity.class));
                        ActivityCrop.this.finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityCrop.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
