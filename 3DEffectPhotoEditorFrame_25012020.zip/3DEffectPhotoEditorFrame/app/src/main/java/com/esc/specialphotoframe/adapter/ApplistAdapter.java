package com.esc.specialphotoframe.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.media.MediaMetadataRetriever;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.*;
import com.esc.specialphotoframe.R;
import java.util.ArrayList;

public class ApplistAdapter extends BaseAdapter {
	private static LayoutInflater inflater;
	private Activity activity;
	ArrayList<String> dIcon;
	ArrayList<String> dLink;
	ArrayList<String> dName;
	private int imageSize;
	SparseBooleanArray mSparseBooleanArray;
	MediaMetadataRetriever metaRetriever;
	MediaMetadataRetriever retriever;
	TextView txtname;
	View vi;
	int width;

	static {
		ApplistAdapter.inflater = null;
	}

	@SuppressLint("WrongConstant")
	public ApplistAdapter(final Activity activity,
                          final ArrayList<String> dLink, final ArrayList<String> dIcon,
                          final ArrayList<String> dName) {
		this.dLink = new ArrayList<String>();
		this.dName = new ArrayList<String>();
		this.dIcon = new ArrayList<String>();
		this.retriever = new MediaMetadataRetriever();
		this.activity = activity;
		this.dLink = dLink;
		this.dName = dName;
		this.dIcon = dIcon;
		ApplistAdapter.inflater = (LayoutInflater) this.activity
				.getSystemService("layout_inflater");
		this.mSparseBooleanArray = new SparseBooleanArray(this.dLink.size());
	}

	public int getCount() {
		return this.dLink.size();
	}

	public Object getItem(final int n) {
		return n;
	}

	public long getItemId(final int n) {
		return n;
	}

	public View getView(final int n, View inflate, final ViewGroup viewGroup) {
		final DisplayMetrics displayMetrics = this.activity.getResources()
				.getDisplayMetrics();
		this.width = displayMetrics.widthPixels;
		final int heightPixels = displayMetrics.heightPixels;
		ViewHolder tag;
		if (inflate == null) {
			inflate = LayoutInflater.from(this.activity).inflate(
					R.layout.list_appstore, viewGroup, false);
			tag = new ViewHolder();
			tag.imgIcon = (ImageView) inflate.findViewById(R.id.imglogo);
			tag.txtname = (TextView) inflate.findViewById(R.id.txtname);
			inflate.setTag((Object) tag);
		} else {
			tag = (ViewHolder) inflate.getTag();
		}
		tag.txtname.setText((CharSequence) this.dName.get(n));
		Glide.with(this.activity).load((String) this.dIcon.get(n)).centerCrop()
				.placeholder(R.mipmap.ic_launcher).crossFade()
				.into(tag.imgIcon);
		System.gc();
		return inflate;
	}

	static class ViewHolder {
		ImageView imgIcon;
		TextView txtname;
	}
}
