package com.esc.specialphotoframe.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.GridView;
import android.widget.ImageView;

import com.esc.specialphotoframe.R;
import com.esc.specialphotoframe.adapter.CreationAdapter;
import com.esc.specialphotoframe.kprogresshud.KProgressHUD;
import com.esc.specialphotoframe.utils.Glob;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.util.Collections;

public class MyStudioActivity extends Activity implements OnClickListener {

    private ImageView iv_back;
    private CreationAdapter galleryAdapter;
    private GridView lstList;
    private ImageView noImage;
    private KProgressHUD hud;
    private AdView adView;
    private static final int MY_REQUEST_CODE = 5;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_my_creation);
        loadAd();
    }

    @SuppressLint("WrongConstant")
    private void bindView() {
        this.noImage = (ImageView) findViewById(R.id.novideoimg);
        this.lstList = (GridView) findViewById(R.id.lstList);

        getImages();
        if (Glob.IMAGEALLARY.size() <= 0) {
            this.noImage.setVisibility(0);
            this.lstList.setVisibility(8);
        } else {
            this.noImage.setVisibility(8);
            this.lstList.setVisibility(0);
        }
        Collections.sort(Glob.IMAGEALLARY);
        Collections.reverse(Glob.IMAGEALLARY);

        this.iv_back = (ImageView) findViewById(R.id.iv_back);
        this.iv_back.setOnClickListener(this);

        this.galleryAdapter = new CreationAdapter(this, Glob.IMAGEALLARY);
        this.lstList.setAdapter(this.galleryAdapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.iv_back:
                id = R.id.iv_back;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent back = new Intent(MyStudioActivity.this, HomeActivity.class);
                    startActivity(back);
                }
                return;
        }
    }

    protected void onResume() {
        super.onResume();
        bindView();
    }

    @SuppressLint("WrongConstant")
    private void getImages() {
        if (VERSION.SDK_INT < 23) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
            requestPermissions(
                    new String[] { "android.permission.READ_EXTERNAL_STORAGE" },
                    MY_REQUEST_CODE);
        }
    }


    private void fetchImage() {
        Glob.IMAGEALLARY.clear();
        Glob.listAllImages(new File("/mnt/sdcard/" + Glob.Edit_Folder_name
                + "/"));
    }

    @SuppressLint("WrongConstant")
    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_REQUEST_CODE /* 5 */:
                if (grantResults[0] == 0) {
                    fetchImage();
                } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
                    requestPermissions(
                            new String[] { "android.permission.READ_EXTERNAL_STORAGE" },
                            MY_REQUEST_CODE);
                }
                break;
            default:
                break;
        }
    }

    private InterstitialAd interstitial;
    private int id;

    public void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //InterstitialAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(MyStudioActivity.this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.iv_back:
                        Intent back = new Intent(MyStudioActivity.this, HomeActivity.class);
                        startActivity(back);
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(MyStudioActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
