package com.esc.specialphotoframe.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.esc.specialphotoframe.R;
import com.esc.specialphotoframe.utils.Glob;


public class ActivityWeb extends AppCompatActivity {
	private WebView webPrivacyPolicy;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_web);
		this.webPrivacyPolicy = (WebView) findViewById(R.id.wvPrivacyPolicy);
		WebSettings webSettings = this.webPrivacyPolicy.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
		this.webPrivacyPolicy.setWebViewClient(new webviewClient());
		this.webPrivacyPolicy.loadUrl(Glob.privacy_link);
	}

	private class webviewClient extends WebViewClient {
		webviewClient() {
		}

		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			if (url.startsWith("http:") || url.startsWith("https:")) {
				return false;
			}
			ActivityWeb.this.startActivity(new Intent(
					"android.intent.action.VIEW", Uri.parse(url)));
			return true;
		}

		@SuppressLint("WrongConstant")
		public void onReceivedError(WebView view, int errorCode,
									String description, String failingUrl) {
			Toast.makeText(ActivityWeb.this, description, 0).show();
		}
	}

	public void onBackPressed() {
		finish();
	}
}
