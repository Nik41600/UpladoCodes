package com.esc.specialphotoframe.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.esc.specialphotoframe.R;
import com.esc.specialphotoframe.fragment.HomeFragment;
import com.esc.specialphotoframe.kprogresshud.KProgressHUD;
import com.esc.specialphotoframe.utils.Glob;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

import java.io.File;

public class ActivityShare extends AppCompatActivity implements OnClickListener {
    private ImageView finalimg;
    private ImageView iv_home;
    private ImageView iv_back;
    private ImageView iv_Share_More;
    private ImageView iv_facebook;
    private ImageView iv_instagram;
    private ImageView iv_whatsapp;
    private KProgressHUD hud;

    @SuppressLint("WrongConstant")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_share);

        if (VERSION.SDK_INT >= 21) {
            this.finalimg = findViewById(R.id.finalimg);
            findViewById(R.id.simpleFrame).setVisibility(8);
            findViewById(R.id.roundFrame).setVisibility(0);
        } else {
            this.finalimg = findViewById(R.id.img);
            findViewById(R.id.roundFrame).setVisibility(8);
            findViewById(R.id.simpleFrame).setVisibility(0);
        }

        Glide.with(this)
                .load(ImageChangeActivity.urlForShareImage)
                .into(this.finalimg);

        this.iv_home = findViewById(R.id.iv_home);
        this.iv_home.setOnClickListener(this);
        this.iv_whatsapp = findViewById(R.id.iv_whatsapp);
        this.iv_whatsapp.setOnClickListener(this);
        this.iv_instagram = findViewById(R.id.iv_instagram);
        this.iv_instagram.setOnClickListener(this);
        this.iv_facebook = findViewById(R.id.iv_facebook);
        this.iv_facebook.setOnClickListener(this);
        this.iv_Share_More = findViewById(R.id.iv_Share_More);
        this.iv_Share_More.setOnClickListener(this);

        this.iv_back = findViewById(R.id.iv_back);
        this.iv_back.setOnClickListener(this);
        this.iv_back = findViewById(R.id.iv_back);
        this.iv_back.setOnClickListener(this);

        loadAd();
    }

    @SuppressLint("WrongConstant")
    public void onClick(View view) {
        Intent shareIntent = new Intent("android.intent.action.SEND");
        shareIntent.setType("image/*");
        shareIntent.putExtra("android.intent.extra.TEXT", Glob.app_name
                + " Created By : " + Glob.app_link);
        shareIntent.putExtra("android.intent.extra.STREAM",
                Uri.fromFile(new File(ImageChangeActivity.urlForShareImage)));
        switch (view.getId()) {
            case R.id.iv_home:
                id = R.id.iv_home;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent intent = new Intent(this, HomeActivity.class);
                    intent.setFlags(268468224);
                    intent.putExtra("ToHome", true);
                    startActivity(intent);
                    finish();
                }
                break;
            case R.id.iv_back:
                id = R.id.iv_back;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent back = new Intent(ActivityShare.this, HomeActivity.class);
                    startActivity(back);
                    finish();
                }
                break;
            case R.id.iv_whatsapp:
                try {
                    shareIntent.setPackage("com.whatsapp");
                    startActivity(shareIntent);
                } catch (Exception e) {
                    Toast.makeText(this, "WhatsApp doesn't installed", 1).show();
                }
                break;
            case R.id.iv_facebook:
                try {
                    shareIntent.setPackage("com.facebook.katana");
                    startActivity(shareIntent);
                } catch (Exception e2) {
                    Toast.makeText(this, "Facebook doesn't installed", 1).show();
                }
                break;
            case R.id.iv_instagram:
                try {
                    shareIntent.setPackage("com.instagram.android");
                    startActivity(shareIntent);
                } catch (Exception e3) {
                    Toast.makeText(this, "Instagram doesn't installed", 1).show();
                }
                break;
            case R.id.iv_Share_More:
                Intent sharingIntent = new Intent("android.intent.action.SEND");
                sharingIntent.setType("image/*");
                sharingIntent.putExtra("android.intent.extra.TEXT", Glob.app_name
                        + " Create By : " + Glob.app_link);
                sharingIntent.putExtra("android.intent.extra.STREAM", Uri
                        .fromFile(new File(ImageChangeActivity.urlForShareImage)));
                startActivity(Intent.createChooser(sharingIntent,
                        "Share Image using"));
                break;
            default:
                break;
        }
    }

    private InterstitialAd interstitial;
    private UnifiedNativeAd nativeAd;
    private int id;

    private void loadAd() {
        //InterstitialAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_back:
                        Intent back = new Intent(ActivityShare.this, MyStudioActivity.class);
                        startActivity(back);
                        finish();
                        break;
                    case R.id.iv_home:
                        Intent intent = new Intent(ActivityShare.this, HomeActivity.class);
                        intent.setFlags(268468224);
                        intent.putExtra("ToHome", true);
                        startActivity(intent);
                        finish();
                        break;

                    case 100:
                        Intent intent1 = new Intent(ActivityShare.this, MyStudioActivity.class);
                        intent1.setFlags(268468224);
                        intent1.putExtra("ToHome", true);
                        startActivity(intent1);
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());

        //NativeAdvanceAd
        AdLoader.Builder builder = new AdLoader.Builder(this, getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);
                findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater()
                        .inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }

        });
        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Toast.makeText(ActivityShare.this, "Failed to load native ad: "
                        + errorCode, Toast.LENGTH_SHORT).show();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ActivityShare.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onBackPressed() {
        id = 100;
        if (interstitial != null && interstitial.isLoaded()) {
            DialogShow();
            AdsDialogShow();
        } else {
            Intent intent = new Intent(ActivityShare.this, MyStudioActivity.class);
            intent.setFlags(268468224);
            intent.putExtra("ToHome", true);
            startActivity(intent);
            finish();
        }
    }
}
