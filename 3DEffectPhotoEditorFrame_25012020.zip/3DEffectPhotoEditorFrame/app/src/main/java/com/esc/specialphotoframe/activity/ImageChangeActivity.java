package com.esc.specialphotoframe.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.esc.specialphotoframe.R;
import com.esc.specialphotoframe.adapter.*;
import com.esc.specialphotoframe.fragment.HomeFragment;
import com.esc.specialphotoframe.kprogresshud.KProgressHUD;
import com.esc.specialphotoframe.mytouch.*;
import com.esc.specialphotoframe.utils.*;
import com.esc.specialphotoframe.view.*;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ImageChangeActivity extends Activity implements View.OnClickListener {
    private static final int FINAL_SAVE = 3;
    private static final int MY_REQUEST_CODE = 2;
    private static final int REQUEST_CODE_GALLERY = 1;
    private static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 4;
    public static String _uri2;
    public static Bitmap b;
    public static Canvas c;
    private static int columnWidth = 80;
    public static Bitmap textBitmap;
    public static String urlForShareImage;
    private ImageView ImgFrm;
    private SquareImageView Img_light;
    private ImageView iv_back;
    private Dialog dialog;
    private EditText edittext;
    private ImageView ef1;
    private ImageView ef10;
    private ImageView ef11;
    private ImageView ef12;
    private ImageView ef13;
    private ImageView ef14;
    private ImageView ef15;
    private ImageView ef16;
    private ImageView ef17;
    private ImageView ef18;
    private ImageView ef19;
    private ImageView ef2;
    private ImageView ef20;
    private ImageView ef21;
    private ImageView ef22;
    private ImageView ef3;
    private ImageView ef4;
    private ImageView ef5;
    private ImageView ef6;
    private ImageView ef7;
    private ImageView ef8;
    private ImageView ef9;
    private ImageView ef_original;
    private boolean flagForFlip;
    String[] fonts;
    private BaseAdapter frameAdapter;
    private ArrayList<Integer> frmList;
    private ArrayList<Integer> frmThumbList;
    FrameLayout frm_Main;
    GridView gvcolorlist;
    GridView gvfontlist;
    private HorizontalListView hl_Frm;
    InputMethodManager imm;
    private int initColor;
    private boolean isBrightness;
    private boolean isFilerOpen;
    private boolean isFrm;
    private boolean isLight;
    ImageView iv_color;
    ImageView iv_done;
    ImageView iv_fontstyle;
    private ImageView iv_gravity;
    ImageView iv_keyboard;
    private LinearLayout llBrightness;
    private LinearLayout llFilter;
    private LinearLayout llFlip;
    private LinearLayout llOverView;
    private LinearLayout llRotate;
    private LinearLayout llSticker;
    private LinearLayout llText;
    private LinearLayout ll_detail;
    private LinearLayout ll_effect_list;
    private LinearLayout lycolorlist;
    private LinearLayout lyfontlist;
    private ImageView iv_frame, iv_effect, iv_brightness, iv_text, iv_sticker, iv_flip, iv_rotate;
    private TextView txt_frame, txt_effect, txt_brightness, txt_text, txt_sticker, txt_flip, txt_rotate;
    private StickerView mCurrentView;
    private int mPickedColor;
    private ArrayList<View> mStickers;
    private ArrayList<View> mViews;
    public float[] mainMatrix;
    private ImageView orgImage;
    private int rotate;
    private ImageView iv_save;
    private SeekBar seekBrightness;
    private ProgressDialog progressDialog;
    private StickerAdapter stickerAdapter;
    private ArrayList<Integer> stickerList;
    private Typeface type;
    private int w;
    private AdView adView;
    private KProgressHUD hud;

    public ImageChangeActivity() {
        this.rotate = 1;
        this.flagForFlip = true;
        this.mPickedColor = -1;
        this.fonts = new String[]{"font1.ttf", "font2.ttf", "font3.ttf",
                "font4.ttf", "font6.ttf", "font9.ttf", "font11.ttf",
                "font12.ttf", "font14.TTF", "font16.TTF", "font20.ttf",
                "font22.ttf"};
        this.w = 0;
        this.isLight = false;
        this.mainMatrix = new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
                1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
                0.0f, 0.0f, 1.0f, 0.0f};
        this.isFilerOpen = false;
        this.isBrightness = false;
        this.isFrm = false;
        this.stickerList = new ArrayList<Integer>();
    }

    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.initColor = this.getResources().getColor(R.color.white);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_image_editing);
        this.mViews = new ArrayList<View>();
        this.mStickers = new ArrayList<View>();
        this.bindView();
        this.createDir();
        this.StickerArrlist();
        loadAd();
    }

    @SuppressLint({"WrongConstant", "ClickableViewAccessibility"})
    private void bindView() {
        this.iv_back = findViewById(R.id.iv_back);
        this.iv_back.setOnClickListener(this);
        this.iv_save = findViewById(R.id.iv_save);
        this.iv_save.setOnClickListener(this);
        this.ll_detail = findViewById(R.id.ll_detail);
        this.ll_detail.setVisibility(8);
        this.ll_effect_list = findViewById(R.id.ll_effect_list);
        this.ll_effect_list.setVisibility(8);
        this.llOverView = findViewById(R.id.ll_overview);
        this.llOverView.setOnClickListener(this);
        this.llText = findViewById(R.id.ll_text);
        this.llText.setOnClickListener(this);

        this.seekBrightness = this.findViewById(R.id.seek_brightness);
        this.seekBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                ImageChangeActivity.this.setBlackAndWhite(ImageChangeActivity.this.orgImage, n + 100);
                ImageChangeActivity.this.seekBrightness
                        .setVisibility(0);
            }

            public void onStartTrackingTouch(final SeekBar seekBar) {
            }

            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });

        this.frm_Main = this.findViewById(R.id.frm_Main);
        this.frm_Main.setOnClickListener(this);

        this.llFilter = this.findViewById(R.id.ll_filter);
        this.llFilter.setOnClickListener(this);

        this.llSticker = this.findViewById(R.id.ll_sticker);
        this.llSticker.setOnClickListener(this);

        this.llRotate = this.findViewById(R.id.ll_Rotate);
        this.llRotate.setOnClickListener(this);

        this.llBrightness = this.findViewById(R.id.ll_brightness);
        this.llBrightness.setOnClickListener(this);

        this.llFlip = this.findViewById(R.id.ll_Flip);
        this.llFlip.setOnClickListener(this);

        this.hl_Frm = this.findViewById(R.id.hl_Frm);

        this.orgImage = this.findViewById(R.id.org_Img);
        this.orgImage.setImageBitmap(HomeFragment.bitmap);

        this.orgImage.setOnTouchListener(new MultiTouchListener(
                new MultiTouchListener.OnTouch() {
                    @Override
                    public void onTouchDown() {
                        if (ImageChangeActivity.this.mCurrentView != null) {
                            ImageChangeActivity.this.mCurrentView
                                    .setInEdit(false);
                        }
                    }
                }));

        this.ImgFrm = this.findViewById(R.id.Img_Frm);
        this.ImgFrm.setImageResource(R.drawable.frame_1);

        this.hl_Frm.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView,
                                    final View view, final int n, final long n2) {
                if (ImageChangeActivity.this.isLight) {
                    ImageChangeActivity.this.Img_light.setImageResource(ImageChangeActivity.this.frmList.get(n));
                    return;
                }
                ImageChangeActivity.this.ImgFrm.setImageResource(ImageChangeActivity.this.frmList.get(n));
            }
        });

        iv_frame = findViewById(R.id.iv_frame);
        iv_effect = findViewById(R.id.iv_effect);
        iv_brightness = findViewById(R.id.iv_brightness);
        iv_text = findViewById(R.id.iv_text);
        iv_sticker = findViewById(R.id.iv_sticker);
        iv_flip = findViewById(R.id.iv_Flip);
        iv_rotate = findViewById(R.id.iv_Rotate);

        txt_frame = findViewById(R.id.txt_frame);
        txt_effect = findViewById(R.id.txt_effect);
        txt_brightness = findViewById(R.id.txt_brightness);
        txt_text = findViewById(R.id.txt_text);
        txt_sticker = findViewById(R.id.txt_sticker);
        txt_flip = findViewById(R.id.txt_flip);
        txt_rotate = findViewById(R.id.txt_rotate);

        this.setFrmList();
        this.overViewList();
        this.EffectIcon();
    }

    @SuppressLint("WrongConstant")
    public void onClick(final View v) {
        this.isLight = false;
        switch (v.getId()) {
            case R.id.iv_back /* 2131427457 */:
                id = R.id.iv_back;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent back = new Intent(ImageChangeActivity.this, HomeActivity.class);
                    startActivity(back);
                }
                break;
            case R.id.iv_save:

                iv_save.setImageResource(R.drawable.ic_press_done);
                if (this.mCurrentView != null) {
                    this.mCurrentView.setInEdit(false);
                }

                id = R.id.iv_save;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    progressDialog = ProgressDialog.show(ImageChangeActivity.this, " ", "Loading...");
                    new Thread() {
                        public void run() {
                            try {
                                saveImage(getMainFrameBitmap());
                                startActivity(new Intent(ImageChangeActivity.this, ActivityShare.class));
                                finish();
                            } catch (Exception e) {
                            }
                            progressDialog.dismiss();
                        }
                    }.start();
                }
                return;

            case R.id.frm_Main:
                if (this.mCurrentView != null) {
                    this.mCurrentView.setInEdit(false);
                }
                break;
            case R.id.ef_original:
                Effects.applyEffectNone(this.orgImage);
                break;
            case R.id.ef1:
                Effects.applyEffect1(this.orgImage);
                break;
            case R.id.ef2:
                Effects.applyEffect2(this.orgImage);
                break;
            case R.id.ef3:
                Effects.applyEffect3(this.orgImage);
                break;
            case R.id.ef4:
                Effects.applyEffect4(this.orgImage);
                break;
            case R.id.ef5:
                Effects.applyEffect5(this.orgImage);
                break;
            case R.id.ef6:
                Effects.applyEffect6(this.orgImage);
                break;
            case R.id.ef7:
                Effects.applyEffect7(this.orgImage);
                break;
            case R.id.ef8:
                Effects.applyEffect8(this.orgImage);
                break;
            case R.id.ef9:
                Effects.applyEffect9(this.orgImage);
                break;
            case R.id.ef10:
                Effects.applyEffect10(this.orgImage);
                break;
            case R.id.ef11:
                Effects.applyEffect11(this.orgImage);
                break;
            case R.id.ef12:
                Effects.applyEffect12(this.orgImage);
                break;
            case R.id.ef13:
                Effects.applyEffect13(this.orgImage);
                break;
            case R.id.ef14:
                Effects.applyEffect14(this.orgImage);
                break;
            case R.id.ef15:
                Effects.applyEffect15(this.orgImage);
                break;
            case R.id.ef16:
                Effects.applyEffect16(this.orgImage);
                break;
            case R.id.ef17:
                Effects.applyEffect17(this.orgImage);
                break;
            case R.id.ef18:
                Effects.applyEffect18(this.orgImage);
                break;
            case R.id.ef19:
                Effects.applyEffect19(this.orgImage);
                break;
            case R.id.ef20:
                Effects.applyEffect20(this.orgImage);
                break;
            case R.id.ef21:
                Effects.applyEffect21(this.orgImage);
                break;
            case R.id.ef22:
                Effects.applyEffect22(this.orgImage);
                break;
            case R.id.ll_overview:
                iv_frame.setImageResource(R.drawable.ic_unpress_free);
                iv_effect.setImageResource(R.drawable.ic_unpress_effect);
                iv_brightness.setImageResource(R.drawable.ic_unpress_brightness);
                iv_text.setImageResource(R.drawable.ic_unpress_text);
                iv_sticker.setImageResource(R.drawable.ic_unpress_sticker);
                iv_flip.setImageResource(R.drawable.ic_unpress_flip);
                iv_rotate.setImageResource(R.drawable.ic_unpress_rotate);

                txt_frame.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_effect.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_brightness.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_text.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_sticker.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_flip.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.color_unpresstext));
                overViewList();
                break;
            case R.id.ll_filter:
                iv_frame.setImageResource(R.drawable.ic_unpress_frame);
                iv_effect.setImageResource(R.drawable.ic_effect);
                iv_brightness.setImageResource(R.drawable.ic_unpress_brightness);
                iv_text.setImageResource(R.drawable.ic_unpress_text);
                iv_sticker.setImageResource(R.drawable.ic_unpress_sticker);
                iv_flip.setImageResource(R.drawable.ic_unpress_flip);
                iv_rotate.setImageResource(R.drawable.ic_unpress_rotate);

                txt_frame.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_effect.setTextColor(getResources().getColor(R.color.white));
                txt_brightness.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_text.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_sticker.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_flip.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.color_unpresstext));

                if (!this.isFilerOpen) {
                    this.isFilerOpen = true;
                    this.isBrightness = false;
                    this.isFrm = false;
                    this.ll_effect_list.setVisibility(0);
                    this.hl_Frm.setVisibility(8);
                    this.seekBrightness.setVisibility(8);
                    this.openDetail();
                    return;
                }
                this.isFilerOpen = false;
                this.ll_detail.setVisibility(0);
                final TranslateAnimation translateAnimation = new TranslateAnimation(
                        0.0f, 0.0f, this.llOverView.getY(), this.llOverView.getY()
                        + this.ll_detail.getHeight());
                translateAnimation.setDuration(300L);
                translateAnimation.setFillAfter(true);
                this.ll_detail.startAnimation(translateAnimation);
                translateAnimation.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationEnd(final Animation animation) {
                        ImageChangeActivity.this.ll_detail.setVisibility(8);
                        ImageChangeActivity.this.ll_effect_list
                                .setVisibility(8);
                        ImageChangeActivity.this.seekBrightness
                                .setVisibility(8);
                        ImageChangeActivity.this.hl_Frm.setVisibility(8);
                    }

                    public void onAnimationRepeat(final Animation animation) {
                    }

                    public void onAnimationStart(final Animation animation) {
                    }
                });
                break;
            case R.id.ll_brightness:

                iv_frame.setImageResource(R.drawable.ic_unpress_frame);
                iv_effect.setImageResource(R.drawable.ic_unpress_effect);
                iv_brightness.setImageResource(R.drawable.ic_brightness);
                iv_text.setImageResource(R.drawable.ic_unpress_text);
                iv_sticker.setImageResource(R.drawable.ic_unpress_sticker);
                iv_flip.setImageResource(R.drawable.ic_unpress_flip);
                iv_rotate.setImageResource(R.drawable.ic_unpress_rotate);

                txt_frame.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_effect.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_brightness.setTextColor(getResources().getColor(R.color.white));
                txt_text.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_sticker.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_flip.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.color_unpresstext));

                if (!this.isBrightness) {
                    this.isBrightness = true;
                    this.isFilerOpen = false;
                    this.isFrm = false;
                    this.hl_Frm.setVisibility(8);
                    this.ll_effect_list.setVisibility(8);
                    this.seekBrightness.setVisibility(0);
                    this.openDetail();
                    return;
                }
                this.isBrightness = false;
                this.ll_detail.setVisibility(0);
                final TranslateAnimation translateAnimation1 = new TranslateAnimation(0.0f, 0.0f, this.llOverView.getY(), this.llOverView.getY() + this.ll_detail.getHeight());
                translateAnimation1.setDuration(300L);
                translateAnimation1.setFillAfter(true);
                this.ll_detail.startAnimation(translateAnimation1);
                translateAnimation1.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationEnd(final Animation animation) {
                        ImageChangeActivity.this.ll_detail.setVisibility(8);
                        ImageChangeActivity.this.ll_effect_list.setVisibility(8);
                        ImageChangeActivity.this.seekBrightness.setVisibility(8);
                        ImageChangeActivity.this.hl_Frm.setVisibility(8);
                    }

                    public void onAnimationRepeat(final Animation animation) {
                    }

                    public void onAnimationStart(final Animation animation) {
                    }
                });
                break;
            case R.id.ll_text:
                iv_frame.setImageResource(R.drawable.ic_unpress_frame);
                iv_effect.setImageResource(R.drawable.ic_unpress_effect);
                iv_brightness.setImageResource(R.drawable.ic_unpress_brightness);
                iv_text.setImageResource(R.drawable.ic_text);
                iv_sticker.setImageResource(R.drawable.ic_unpress_sticker);
                iv_flip.setImageResource(R.drawable.ic_unpress_flip);
                iv_rotate.setImageResource(R.drawable.ic_unpress_rotate);

                txt_frame.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_effect.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_brightness.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_text.setTextColor(getResources().getColor(R.color.white));
                txt_sticker.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_flip.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.color_unpresstext));
                selecttext();
                break;
            case R.id.ll_sticker:

                iv_frame.setImageResource(R.drawable.ic_unpress_frame);
                iv_effect.setImageResource(R.drawable.ic_unpress_effect);
                iv_brightness.setImageResource(R.drawable.ic_unpress_brightness);
                iv_text.setImageResource(R.drawable.ic_unpress_text);
                iv_sticker.setImageResource(R.drawable.ic_sticker);
                iv_flip.setImageResource(R.drawable.ic_unpress_flip);
                iv_rotate.setImageResource(R.drawable.ic_unpress_rotate);

                txt_frame.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_effect.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_brightness.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_text.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_sticker.setTextColor(getResources().getColor(R.color.white));
                txt_flip.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.color_unpresstext));

                @SuppressLint("ResourceType") final Dialog dialog = new Dialog(this, 16973839);
                dialog.requestWindowFeature(1);
                dialog.setContentView(R.layout.sticker_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.setCanceledOnTouchOutside(true);
                dialog.findViewById(R.id.back_dialog)
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(final View view) {
                                dialog.dismiss();
                            }
                        });
                this.stickerAdapter = new StickerAdapter(this.getApplicationContext(), this.stickerList);
                final GridView gridView = dialog.findViewById(R.id.gridStickerList);
                gridView.setAdapter(this.stickerAdapter);
                gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
                        ImageChangeActivity.this.StickerView(ImageChangeActivity.this.stickerList.get(n));
                        dialog.dismiss();
                    }
                });
                dialog.show();
                break;
            case R.id.ll_Rotate:

                iv_frame.setImageResource(R.drawable.ic_unpress_frame);
                iv_effect.setImageResource(R.drawable.ic_unpress_effect);
                iv_brightness.setImageResource(R.drawable.ic_unpress_brightness);
                iv_text.setImageResource(R.drawable.ic_unpress_text);
                iv_sticker.setImageResource(R.drawable.ic_unpress_sticker);
                iv_flip.setImageResource(R.drawable.ic_unpress_flip);
                iv_rotate.setImageResource(R.drawable.ic_rotate);

                txt_frame.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_effect.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_brightness.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_text.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_sticker.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_flip.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_rotate.setTextColor(getResources().getColor(R.color.white));

                if (this.rotate == REQUEST_CODE_GALLERY) {
                    this.orgImage.setRotation(90.0f);
                    this.rotate = MY_REQUEST_CODE;
                } else if (this.rotate == MY_REQUEST_CODE) {
                    this.orgImage.setRotation(Glob.HUE_CYAN);
                    this.rotate = FINAL_SAVE;
                } else if (this.rotate == FINAL_SAVE) {
                    this.orgImage.setRotation(Glob.HUE_VIOLET);
                    this.rotate = REQUEST_ID_MULTIPLE_PERMISSIONS;
                } else if (this.rotate == REQUEST_ID_MULTIPLE_PERMISSIONS) {
                    this.orgImage.setRotation(360.0f);
                    this.rotate = REQUEST_CODE_GALLERY;
                }
                break;
            case R.id.ll_Flip:
                iv_frame.setImageResource(R.drawable.ic_unpress_frame);
                iv_effect.setImageResource(R.drawable.ic_unpress_effect);
                iv_brightness.setImageResource(R.drawable.ic_unpress_brightness);
                iv_text.setImageResource(R.drawable.ic_unpress_text);
                iv_sticker.setImageResource(R.drawable.ic_unpress_sticker);
                iv_flip.setImageResource(R.drawable.ic_flip);
                iv_rotate.setImageResource(R.drawable.ic_unpress_rotate);

                txt_frame.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_effect.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_brightness.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_text.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_sticker.setTextColor(getResources().getColor(R.color.color_unpresstext));
                txt_flip.setTextColor(getResources().getColor(R.color.white));
                txt_rotate.setTextColor(getResources().getColor(R.color.color_unpresstext));
                if (this.flagForFlip) {
                    this.orgImage.setRotationY(Glob.HUE_CYAN);
                    this.flagForFlip = false;
                    return;
                }
                this.orgImage.setRotationY(360.0f);
                this.flagForFlip = true;
                break;
            default:
                break;
        }
    }

    @SuppressLint("WrongConstant")
    void openDetail() {
        this.ll_detail.setVisibility(0);
        final TranslateAnimation translateAnimation = new TranslateAnimation(
                0.0f, 0.0f, this.llOverView.getY() + 70.0f,
                this.llOverView.getY());
        translateAnimation.setDuration(300L);
        translateAnimation.setFillAfter(true);
        this.ll_detail.startAnimation(translateAnimation);
    }

    @SuppressLint("WrongConstant")
    void overViewList() {
        if (!this.isFrm) {
            this.isFrm = true;
            this.isFilerOpen = false;
            this.isBrightness = false;
            this.setFrmList();
            this.hl_Frm.setVisibility(0);
            this.seekBrightness.setVisibility(8);
            this.ll_effect_list.setVisibility(8);
            this.openDetail();
            return;
        }
        this.isFrm = false;
        this.ll_detail.setVisibility(0);
        final TranslateAnimation translateAnimation = new TranslateAnimation(
                0.0f, 0.0f, this.llOverView.getY(), this.llOverView.getY()
                + this.ll_detail.getHeight());
        translateAnimation.setDuration(300L);
        translateAnimation.setFillAfter(true);
        this.ll_detail.startAnimation(translateAnimation);
        translateAnimation.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationEnd(final Animation animation) {
                ImageChangeActivity.this.ll_detail.setVisibility(8);
                ImageChangeActivity.this.ll_effect_list
                        .setVisibility(8);
                ImageChangeActivity.this.seekBrightness
                        .setVisibility(8);
                ImageChangeActivity.this.hl_Frm.setVisibility(8);
            }

            public void onAnimationRepeat(final Animation animation) {
            }

            public void onAnimationStart(final Animation animation) {
            }
        });
    }

    @SuppressLint("WrongConstant")
    protected void selecttext() {
        (this.dialog = new Dialog(this)).requestWindowFeature(1);
        this.dialog.setContentView(R.layout.activity_text);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        (this.imm = (InputMethodManager) this.getSystemService("input_method")).toggleSoftInput(2, 0);
        final TextView textView = new TextView(this);
        (this.edittext = this.dialog.findViewById(R.id.edittext)).requestFocus();
        (this.lyfontlist = this.dialog.findViewById(R.id.lyfontlist)).setVisibility(8);
        (this.gvfontlist = this.dialog.findViewById(R.id.gvfontlist)).setAdapter(new CardFontStyleAdapter(this, this.fonts));
        this.gvfontlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView,
                                    final View view, final int n, final long n2) {
                ImageChangeActivity.this.type = Typeface
                        .createFromAsset(ImageChangeActivity.this.getAssets(), ImageChangeActivity.this.fonts[n]);
                ImageChangeActivity.this.edittext.setTypeface(ImageChangeActivity.this.type);
                textView.setTypeface(ImageChangeActivity.this.type);
            }
        });
        (this.lycolorlist = this.dialog.findViewById(R.id.lycolorlist)).setVisibility(8);
        this.gvcolorlist = this.dialog.findViewById(R.id.gvcolorlist);
        final ArrayList hsvColors = HSVColors();
        this.gvcolorlist.setAdapter(new ArrayAdapter<Integer>(this.getApplicationContext(), 17367043, hsvColors) {
            public View getView(final int n, final View view, final ViewGroup viewGroup) {
                final TextView textView = (TextView) super.getView(n, view, viewGroup);
                textView.setBackgroundColor((int) hsvColors.get(n));
                textView.setText("");
                textView.setLayoutParams(new AbsListView.LayoutParams(-1, -1));
                final AbsListView.LayoutParams layoutParams = (AbsListView.LayoutParams) textView.getLayoutParams();
                layoutParams.width = ImageChangeActivity.columnWidth;
                layoutParams.height = ImageChangeActivity.columnWidth;
                textView.setLayoutParams(layoutParams);
                textView.requestLayout();
                return textView;
            }
        });
        this.gvcolorlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(final AdapterView<?> adapterView,
                                    final View view, final int n, final long n2) {
                ImageChangeActivity.this.mPickedColor = (int) adapterView.getItemAtPosition(n);
                ImageChangeActivity.this.edittext.setTextColor(ImageChangeActivity.this.mPickedColor);
                textView.setTextColor(ImageChangeActivity.this.mPickedColor);
            }
        });
        (this.iv_keyboard = this.dialog.findViewById(R.id.iv_keyboard))
                .setOnClickListener(new View.OnClickListener() {
                    public void onClick(final View view) {
                        ((InputMethodManager) ImageChangeActivity.this.getSystemService("input_method"))
                                .showSoftInput(ImageChangeActivity.this.edittext, 2);
                        ImageChangeActivity.this.lyfontlist.setVisibility(8);
                        ImageChangeActivity.this.lycolorlist.setVisibility(8);
                    }
                });
        (this.iv_fontstyle = this.dialog.findViewById(R.id.iv_fontstyle))
                .setOnClickListener(new View.OnClickListener() {
                    public void onClick(final View view) {
                        ImageChangeActivity.this.lyfontlist.setVisibility(0);
                        ImageChangeActivity.this.lycolorlist.setVisibility(8);
                        ((InputMethodManager) ImageChangeActivity.this
                                .getSystemService("input_method"))
                                .hideSoftInputFromWindow(
                                        ImageChangeActivity.this.edittext.getWindowToken(), 0);
                    }
                });
        (this.iv_color = this.dialog.findViewById(R.id.iv_color))
                .setOnClickListener(new View.OnClickListener() {
                    public void onClick(final View view) {
                        ((InputMethodManager) ImageChangeActivity.this.getSystemService("input_method"))
                                .hideSoftInputFromWindow(ImageChangeActivity.this.edittext.getWindowToken(), 0);
                        ImageChangeActivity.this.lycolorlist.setVisibility(0);
                        ImageChangeActivity.this.lyfontlist.setVisibility(8);
                    }
                });
        (this.iv_gravity = this.dialog.findViewById(R.id.iv_gravity))
                .setOnClickListener(new View.OnClickListener() {
                    public void onClick(final View view) {
                        if (ImageChangeActivity.this.w == 0) {
                            ImageChangeActivity.this.w = 1;
                            ImageChangeActivity.this.iv_gravity
                                    .setImageDrawable(ImageChangeActivity.this
                                            .getResources().getDrawable(
                                                    R.drawable.alignright));
                            ImageChangeActivity.this.edittext.setGravity(5);
                            textView.setGravity(5);
                        } else {
                            if (ImageChangeActivity.this.w == 1) {
                                ImageChangeActivity.this.iv_gravity
                                        .setImageDrawable(ImageChangeActivity.this
                                                .getResources().getDrawable(
                                                        R.drawable.alignleft));
                                ImageChangeActivity.this.edittext
                                        .setGravity(3);
                                textView.setGravity(3);
                                ImageChangeActivity.this.w = 2;
                                return;
                            }
                            if (ImageChangeActivity.this.w == 2) {
                                ImageChangeActivity.this.w = 0;
                                ImageChangeActivity.this.iv_gravity
                                        .setImageDrawable(ImageChangeActivity.this
                                                .getResources().getDrawable(
                                                        R.drawable.aligncenter));
                                ImageChangeActivity.this.edittext
                                        .setGravity(17);
                                textView.setGravity(17);
                            }
                        }
                    }
                });
        this.iv_done = this.dialog.findViewById(R.id.iv_done);
        final TextView textView2 = this.dialog.findViewById(R.id.txtEnteredText);
        textView2.setDrawingCacheEnabled(true);
        this.iv_done.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                ImageChangeActivity.this.imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                final String string = ImageChangeActivity.this.edittext.getText().toString();
                if (!string.isEmpty()) {
                    textView2.setText(string);
                    textView2.setTypeface(ImageChangeActivity.this.type);
                    textView2.setTextColor(ImageChangeActivity.this.mPickedColor);
                    textView2.setGravity(17);
                    final ImageView imageView = new ImageView(ImageChangeActivity.this);
                    textView2.buildDrawingCache();
                    imageView.setImageBitmap(textView2.getDrawingCache());
                    ImageChangeActivity.textBitmap = ImageChangeActivity.loadBitmapFromView(imageView);
                    ImageChangeActivity.textBitmap = ImageChangeActivity.this.CropBitmapTransparency(ImageChangeActivity.textBitmap);
                    textView2.setDrawingCacheEnabled(false);
                    ((InputMethodManager) ImageChangeActivity.this.getSystemService("input_method")).hideSoftInputFromWindow(
                            ImageChangeActivity.this.edittext
                                    .getWindowToken(), 0);

                    ImageChangeActivity.this.StickerViewText(ImageChangeActivity.textBitmap);
                    ImageChangeActivity.this.dialog.dismiss();
                }
            }
        });
        this.dialog.show();
        final WindowManager.LayoutParams attributes = new WindowManager.LayoutParams();
        final Window window = this.dialog.getWindow();
        attributes.copyFrom(window.getAttributes());
        attributes.width = -1;
        attributes.height = -1;
        window.setAttributes(attributes);
    }

    private void StickerViewText(Bitmap bitmap) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setBitmap(bitmap);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                ImageChangeActivity.this.mStickers.remove(stickerView);
                ImageChangeActivity.this.frm_Main.removeView(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                ImageChangeActivity.this.mCurrentView.setInEdit(false);
                ImageChangeActivity.this.mCurrentView = stickerView;
                ImageChangeActivity.this.mCurrentView.setInEdit(true);
            }

            public void onTop(StickerView stickerView) {
                int position = ImageChangeActivity.this.mStickers.indexOf(stickerView);
                if (position != ImageChangeActivity.this.mStickers.size() - 1) {
                    ImageChangeActivity.this.mStickers.add(ImageChangeActivity.this.mStickers
                            .size(), (StickerView) ImageChangeActivity.this.mStickers
                            .remove(position));
                }
            }
        });
        this.frm_Main.addView(stickerView, new AbsListView.LayoutParams(-1, -1));
        this.mStickers.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void StickerView(final int imageResource) {
        final StickerView currentEdit = new StickerView(this);
        currentEdit.setImageResource(imageResource);
        currentEdit.setOperationListener(new StickerView.OperationListener() {
            @Override
            public void onDeleteClick() {
                ImageChangeActivity.this.mStickers.remove(currentEdit);
                ImageChangeActivity.this.frm_Main.removeView(currentEdit);
            }

            @Override
            public void onEdit(final StickerView stickerView) {
                ImageChangeActivity.this.mCurrentView.setInEdit(false);
                ImageChangeActivity.this.mCurrentView = stickerView;
                ImageChangeActivity.this.mCurrentView.setInEdit(true);
            }

            @Override
            public void onTop(StickerView stickerView) {
                final int index = ImageChangeActivity.this.mStickers.indexOf(stickerView);
                if (index == ImageChangeActivity.this.mStickers.size() - 1) {
                    return;
                }
                stickerView = (StickerView) ImageChangeActivity.this.mStickers.remove(index);
                ImageChangeActivity.this.mStickers.add(ImageChangeActivity.this.mStickers.size(), stickerView);
            }

        });
        this.frm_Main.addView(currentEdit, new RelativeLayout.LayoutParams(-1, -1));
        this.mStickers.add(currentEdit);
        this.setCurrentEdit(currentEdit);
    }

    public static int HSVColor(final float n, final float n2, final float n3) {
        return Color.HSVToColor(255, new float[]{n, n2, n3});
    }

    public static ArrayList HSVColors() {
        final ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i = 0; i <= 360; i += 20) {
            list.add(HSVColor(i, 1.0f, 1.0f));
        }
        for (int j = 0; j <= 360; j += 20) {
            list.add(HSVColor(j, 0.25f, 1.0f));
            list.add(HSVColor(j, 0.5f, 1.0f));
            list.add(HSVColor(j, 0.75f, 1.0f));
        }
        for (int k = 0; k <= 360; k += 20) {
            list.add(HSVColor(k, 1.0f, 0.5f));
            list.add(HSVColor(k, 1.0f, 0.75f));
        }
        for (float n = 0.0f; n <= 1.0f; n += 0.1f) {
            list.add(HSVColor(0.0f, 0.0f, n));
        }
        return list;
    }

    private void EffectIcon() {
        this.ef_original = findViewById(R.id.ef_original);
        this.ef_original.setImageBitmap(HomeFragment.bitmap);
        this.ef_original.setOnClickListener(this);
        this.ef1 = findViewById(R.id.ef1);
        this.ef1.setImageBitmap(HomeFragment.bitmap);
        this.ef1.setOnClickListener(this);
        this.ef2 = findViewById(R.id.ef2);
        this.ef2.setImageBitmap(HomeFragment.bitmap);
        this.ef2.setOnClickListener(this);
        this.ef3 = findViewById(R.id.ef3);
        this.ef3.setImageBitmap(HomeFragment.bitmap);
        this.ef3.setOnClickListener(this);
        this.ef4 = findViewById(R.id.ef4);
        this.ef4.setImageBitmap(HomeFragment.bitmap);
        this.ef4.setOnClickListener(this);
        this.ef5 = findViewById(R.id.ef5);
        this.ef5.setImageBitmap(HomeFragment.bitmap);
        this.ef5.setOnClickListener(this);
        this.ef6 = findViewById(R.id.ef6);
        this.ef6.setImageBitmap(HomeFragment.bitmap);
        this.ef6.setOnClickListener(this);
        this.ef7 = findViewById(R.id.ef7);
        this.ef7.setImageBitmap(HomeFragment.bitmap);
        this.ef7.setOnClickListener(this);
        this.ef8 = findViewById(R.id.ef8);
        this.ef8.setImageBitmap(HomeFragment.bitmap);
        this.ef8.setOnClickListener(this);
        this.ef9 = findViewById(R.id.ef9);
        this.ef9.setImageBitmap(HomeFragment.bitmap);
        this.ef9.setOnClickListener(this);
        this.ef10 = findViewById(R.id.ef10);
        this.ef10.setImageBitmap(HomeFragment.bitmap);
        this.ef10.setOnClickListener(this);
        this.ef11 = findViewById(R.id.ef11);
        this.ef11.setImageBitmap(HomeFragment.bitmap);
        this.ef11.setOnClickListener(this);
        this.ef12 = findViewById(R.id.ef12);
        this.ef12.setImageBitmap(HomeFragment.bitmap);
        this.ef12.setOnClickListener(this);
        this.ef13 = findViewById(R.id.ef13);
        this.ef13.setImageBitmap(HomeFragment.bitmap);
        this.ef13.setOnClickListener(this);
        this.ef14 = findViewById(R.id.ef14);
        this.ef14.setImageBitmap(HomeFragment.bitmap);
        this.ef14.setOnClickListener(this);
        this.ef15 = findViewById(R.id.ef15);
        this.ef15.setImageBitmap(HomeFragment.bitmap);
        this.ef15.setOnClickListener(this);
        this.ef16 = findViewById(R.id.ef16);
        this.ef16.setImageBitmap(HomeFragment.bitmap);
        this.ef16.setOnClickListener(this);
        this.ef17 = findViewById(R.id.ef17);
        this.ef17.setImageBitmap(HomeFragment.bitmap);
        this.ef17.setOnClickListener(this);
        this.ef18 = findViewById(R.id.ef18);
        this.ef18.setImageBitmap(HomeFragment.bitmap);
        this.ef18.setOnClickListener(this);
        this.ef19 = findViewById(R.id.ef19);
        this.ef19.setImageBitmap(HomeFragment.bitmap);
        this.ef19.setOnClickListener(this);
        this.ef20 = findViewById(R.id.ef20);
        this.ef20.setImageBitmap(HomeFragment.bitmap);
        this.ef20.setOnClickListener(this);
        this.ef21 = findViewById(R.id.ef21);
        this.ef21.setImageBitmap(HomeFragment.bitmap);
        this.ef21.setOnClickListener(this);
        this.ef22 = findViewById(R.id.ef22);
        this.ef22.setImageBitmap(HomeFragment.bitmap);
        this.ef22.setOnClickListener(this);
        Effects.applyEffectNone(this.ef_original);
        Effects.applyEffect1(this.ef1);
        Effects.applyEffect2(this.ef2);
        Effects.applyEffect3(this.ef3);
        Effects.applyEffect4(this.ef4);
        Effects.applyEffect5(this.ef5);
        Effects.applyEffect6(this.ef6);
        Effects.applyEffect7(this.ef7);
        Effects.applyEffect8(this.ef8);
        Effects.applyEffect9(this.ef9);
        Effects.applyEffect10(this.ef10);
        Effects.applyEffect11(this.ef11);
        Effects.applyEffect12(this.ef12);
        Effects.applyEffect13(this.ef13);
        Effects.applyEffect14(this.ef14);
        Effects.applyEffect15(this.ef15);
        Effects.applyEffect16(this.ef16);
        Effects.applyEffect17(this.ef17);
        Effects.applyEffect18(this.ef18);
        Effects.applyEffect19(this.ef19);
        Effects.applyEffect20(this.ef20);
        Effects.applyEffect21(this.ef21);
        Effects.applyEffect22(this.ef22);
    }

    private void createDir() {
        Glob.createDirIfNotExists(Glob.Edit_Folder_name);
    }

    private Bitmap getMainFrameBitmap() {
        this.frm_Main.setDrawingCacheEnabled(true);
        final Bitmap bitmap = Bitmap.createBitmap(this.frm_Main
                .getDrawingCache());
        if (Build.VERSION.SDK_INT >= 19) {
            bitmap.setConfig(Bitmap.Config.ARGB_8888);
        }
        this.frm_Main.setDrawingCacheEnabled(false);
        final int height = bitmap.getHeight();
        int width;
        int n2;
        final int n = n2 = (width = bitmap.getWidth());
        int n3 = height;
        int n4 = height;
        for (int i = 0; i < n; ++i) {
            int n5;
            int n6;
            int n7;
            int n8;
            for (int j = 0; j < height; ++j, n4 = n5, width = n6, n2 = n7, n3 = n8) {
                n5 = n4;
                n6 = width;
                n7 = n2;
                n8 = n3;
                if (bitmap.getPixel(i, j) != 0) {
                    int n9;
                    if (i - 0 < (n9 = width)) {
                        n9 = i - 0;
                    }
                    int n10;
                    if (n - i < (n10 = n2)) {
                        n10 = n - i;
                    }
                    int n11;
                    if (j - 0 < (n11 = n3)) {
                        n11 = j - 0;
                    }
                    n5 = n4;
                    n6 = n9;
                    n7 = n10;
                    n8 = n11;
                    if (height - j < n4) {
                        n5 = height - j;
                        n8 = n11;
                        n7 = n10;
                        n6 = n9;
                    }
                }
            }
        }
        Log.d("Trimed bitmap", "left:" + width + " right:" + n2 + " top:" + n3
                + " bottom:" + n4);
        return Bitmap.createBitmap(bitmap, width, n3, n - width - n2, height
                - n3 - n4);
    }

    public static Bitmap loadBitmapFromView(final View view) {
        if (view.getMeasuredHeight() <= 0) {
            view.measure(-2, -2);
            ImageChangeActivity.b = Bitmap.createBitmap(
                    view.getMeasuredWidth(), view.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            ImageChangeActivity.c = new Canvas(ImageChangeActivity.b);
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
            view.draw(ImageChangeActivity.c);
            return ImageChangeActivity.b;
        }
        ImageChangeActivity.b = Bitmap.createBitmap(view.getWidth(),
                view.getHeight(), Bitmap.Config.ARGB_8888);
        ImageChangeActivity.c = new Canvas(ImageChangeActivity.b);
        view.layout(view.getLeft(), view.getTop(), view.getRight(),
                view.getBottom());
        view.draw(ImageChangeActivity.c);
        return ImageChangeActivity.b;
    }

    private void saveImage(final Bitmap bitmap) {
        Log.v("TAG", "saveImageInCache is called");
        final File externalStorageDirectory = Environment
                .getExternalStorageDirectory();
        final File file = new File(externalStorageDirectory.getAbsolutePath()
                + "/" + Glob.Edit_Folder_name);
        file.mkdirs();
        final String string = new SimpleDateFormat("yyyyMMdd_HHmmss")
                .format(new Date()) + ".jpeg";
        final File file2 = new File(file, string);
        file2.renameTo(file2);
        final String string2 = "file://"
                + externalStorageDirectory.getAbsolutePath() + "/"
                + Glob.Edit_Folder_name + "/" + string;
        ImageChangeActivity._uri2 = externalStorageDirectory.getAbsolutePath()
                + "/" + Glob.Edit_Folder_name + "/" + string;
        ImageChangeActivity.urlForShareImage = ImageChangeActivity._uri2;
        Log.d("cache uri=", string2);
        try {
            final FileOutputStream fileOutputStream = new FileOutputStream(
                    file2);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100,
                    fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            this.sendBroadcast(new Intent(
                    "android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri
                    .fromFile(new File(string2))));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void FrameArrlist() {
        this.frmList = new ArrayList();
        this.frmList.add(Integer.valueOf(R.drawable.frame_1));
        this.frmList.add(Integer.valueOf(R.drawable.frame_2));
        this.frmList.add(Integer.valueOf(R.drawable.frame_3));
        this.frmList.add(Integer.valueOf(R.drawable.frame_4));
        this.frmList.add(Integer.valueOf(R.drawable.frame_5));
        this.frmList.add(Integer.valueOf(R.drawable.frame_6));
        this.frmList.add(Integer.valueOf(R.drawable.frame_7));
        this.frmList.add(Integer.valueOf(R.drawable.frame_8));
        this.frmList.add(Integer.valueOf(R.drawable.frame_9));
        this.frmList.add(Integer.valueOf(R.drawable.frame_10));
        this.frmList.add(Integer.valueOf(R.drawable.frame_11));
        this.frmList.add(Integer.valueOf(R.drawable.frame_12));
        this.frmList.add(Integer.valueOf(R.drawable.frame_13));
        this.frmList.add(Integer.valueOf(R.drawable.frame_14));
        this.frmList.add(Integer.valueOf(R.drawable.frame_15));
        this.frmList.add(Integer.valueOf(R.drawable.frame_16));
        this.frmList.add(Integer.valueOf(R.drawable.frame_17));
        this.frmList.add(Integer.valueOf(R.drawable.frame_18));
        this.frmList.add(Integer.valueOf(R.drawable.frame_19));
        this.frmList.add(Integer.valueOf(R.drawable.frame_20));
        this.frmThumbList = new ArrayList();
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb1));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb2));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb3));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb4));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb5));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb6));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb7));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb8));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb9));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb10));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb11));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb12));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb13));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb14));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb15));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb16));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb17));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb18));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb19));
        this.frmThumbList.add(Integer.valueOf(R.drawable.thumb20));
    }

    private void StickerArrlist() {
        this.stickerList.add(Integer.valueOf(R.drawable.s1));
        this.stickerList.add(Integer.valueOf(R.drawable.s2));
        this.stickerList.add(Integer.valueOf(R.drawable.s3));
        this.stickerList.add(Integer.valueOf(R.drawable.s4));
        this.stickerList.add(Integer.valueOf(R.drawable.s5));
        this.stickerList.add(Integer.valueOf(R.drawable.s6));
        this.stickerList.add(Integer.valueOf(R.drawable.s7));
        this.stickerList.add(Integer.valueOf(R.drawable.s8));
        this.stickerList.add(Integer.valueOf(R.drawable.s9));
        this.stickerList.add(Integer.valueOf(R.drawable.s10));
        this.stickerList.add(Integer.valueOf(R.drawable.s11));
        this.stickerList.add(Integer.valueOf(R.drawable.s12));
        this.stickerList.add(Integer.valueOf(R.drawable.s13));
        this.stickerList.add(Integer.valueOf(R.drawable.s14));
        this.stickerList.add(Integer.valueOf(R.drawable.s15));
        this.stickerList.add(Integer.valueOf(R.drawable.s16));
        this.stickerList.add(Integer.valueOf(R.drawable.s17));
        this.stickerList.add(Integer.valueOf(R.drawable.s19));
        this.stickerList.add(Integer.valueOf(R.drawable.s20));
        this.stickerList.add(Integer.valueOf(R.drawable.s21));
        this.stickerList.add(Integer.valueOf(R.drawable.s22));
        this.stickerList.add(Integer.valueOf(R.drawable.s23));
        this.stickerList.add(Integer.valueOf(R.drawable.s24));
        this.stickerList.add(Integer.valueOf(R.drawable.s25));
        this.stickerList.add(Integer.valueOf(R.drawable.s26));
        this.stickerList.add(Integer.valueOf(R.drawable.s27));
        this.stickerList.add(Integer.valueOf(R.drawable.s28));
        this.stickerList.add(Integer.valueOf(R.drawable.s29));
        this.stickerList.add(Integer.valueOf(R.drawable.s30));
        this.stickerList.add(Integer.valueOf(R.drawable.s31));
        this.stickerList.add(Integer.valueOf(R.drawable.s32));
        this.stickerList.add(Integer.valueOf(R.drawable.s33));
    }

    private void setBlackAndWhite(final ImageView imageView, final int n) {
        final float n2 = n - 255;
        this.mainMatrix[4] = n2;
        this.mainMatrix[9] = n2;
        this.mainMatrix[14] = n2;
        imageView.setColorFilter(new ColorMatrixColorFilter(this.mainMatrix));
    }

    private void setCurrentEdit(final StickerView mCurrentView) {
        if (this.mCurrentView != null) {
            this.mCurrentView.setInEdit(false);
        }
        (this.mCurrentView = mCurrentView).setInEdit(true);
    }

    private void setFrmList() {
        this.FrameArrlist();
        this.frameAdapter = new FrameAdapter(this, this.frmThumbList);
        this.hl_Frm.setAdapter(this.frameAdapter);
    }

    Bitmap CropBitmapTransparency(final Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int n = -1;
        int n2 = -1;
        for (int i = 0; i < bitmap.getHeight(); ++i) {
            int n3;
            int n4;
            int n5;
            int n6;
            for (int j = 0; j < bitmap.getWidth(); ++j, n = n3, n2 = n4, width = n5, height = n6) {
                n3 = n;
                n4 = n2;
                n5 = width;
                n6 = height;
                if ((bitmap.getPixel(j, i) >> 24 & 0xFF) > 0) {
                    int n7;
                    if (j < (n7 = width)) {
                        n7 = j;
                    }
                    int n8;
                    if (j > (n8 = n)) {
                        n8 = j;
                    }
                    int n9;
                    if (i < (n9 = height)) {
                        n9 = i;
                    }
                    n3 = n8;
                    n4 = n2;
                    n5 = n7;
                    n6 = n9;
                    if (i > n2) {
                        n4 = i;
                        n6 = n9;
                        n5 = n7;
                        n3 = n8;
                    }
                }
            }
        }
        if (n < width || n2 < height) {
            return null;
        }
        return Bitmap.createBitmap(bitmap, width, height, n - width + 1, n2
                - height + 1);
    }

    private InterstitialAd interstitial;
    private int id;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.iv_save:
                        if (mCurrentView != null) {
                            mCurrentView.setInEdit(false);
                        }
                        progressDialog = ProgressDialog.show(ImageChangeActivity.this, "", "Loading...");
                        new Thread() {
                            public void run() {
                                try {
                                    saveImage(getMainFrameBitmap());
                                    startActivity(new Intent(ImageChangeActivity.this, ActivityShare.class));
                                    finish();
                                } catch (Exception e) {
                                }
                                progressDialog.dismiss();
                            }
                        }.start();
                        break;
                    case R.id.iv_back:
                        Intent back = new Intent(ImageChangeActivity.this, HomeActivity.class);
                        startActivity(back);
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(ImageChangeActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }
}
