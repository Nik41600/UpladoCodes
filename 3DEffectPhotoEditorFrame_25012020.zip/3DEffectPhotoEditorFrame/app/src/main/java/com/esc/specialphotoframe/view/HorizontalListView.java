package com.esc.specialphotoframe.view;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.EdgeEffectCompat;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Scroller;
import com.esc.specialphotoframe.R;
import com.esc.specialphotoframe.view.HorizontalListView.OnScrollStateChangedListener.ScrollState;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class HorizontalListView extends AdapterView<ListAdapter> {
	private static final String BUNDLE_ID_CURRENT_X = "BUNDLE_ID_CURRENT_X";
	private static final String BUNDLE_ID_PARENT_STATE = "BUNDLE_ID_PARENT_STATE";
	private static final float FLING_DEFAULT_ABSORB_VELOCITY = 30.0f;
	private static final float FLING_FRICTION = 0.009f;
	private static final int INSERT_AT_END_OF_LIST = -1;
	private static final int INSERT_AT_START_OF_LIST = 0;
	protected ListAdapter mAdapter;
	private DataSetObserver mAdapterDataObserver;
	private boolean mBlockTouchAction;
	private ScrollState mCurrentScrollState;
	protected int mCurrentX;
	private int mCurrentlySelectedAdapterIndex;
	private boolean mDataChanged;
	private Runnable mDelayedLayout;
	private int mDisplayOffset;
	private Drawable mDivider;
	private int mDividerWidth;
	private EdgeEffectCompat mEdgeGlowLeft;
	private EdgeEffectCompat mEdgeGlowRight;
	protected Scroller mFlingTracker;
	private GestureDetector mGestureDetector;
	private final GestureListener mGestureListener;
	private boolean mHasNotifiedRunningLowOnData;
	private int mHeightMeasureSpec;
	private boolean mIsParentVerticiallyScrollableViewDisallowingInterceptTouchEvent;
	private int mLeftViewAdapterIndex;
	private int mMaxX;
	protected int mNextX;
	private OnClickListener mOnClickListener;
	private OnScrollStateChangedListener mOnScrollStateChangedListener;
	private Rect mRect;
	private List<Queue<View>> mRemovedViewsCache;
	private Integer mRestoreX;
	private int mRightViewAdapterIndex;
	private RunningOutOfDataListener mRunningOutOfDataListener;
	private int mRunningOutOfDataThreshold;
	private View mViewBeingTouched;

	public HorizontalListView(final Context context, final AttributeSet set) {
		super(context, set);
		this.mFlingTracker = new Scroller(this.getContext());
		this.mGestureListener = new GestureListener();
		this.mRemovedViewsCache = new ArrayList<Queue<View>>();
		this.mDataChanged = false;
		this.mRect = new Rect();
		this.mViewBeingTouched = null;
		this.mDividerWidth = 0;
		this.mDivider = null;
		this.mRestoreX = null;
		this.mMaxX = Integer.MAX_VALUE;
		this.mRunningOutOfDataListener = null;
		this.mRunningOutOfDataThreshold = 0;
		this.mHasNotifiedRunningLowOnData = false;
		this.mOnScrollStateChangedListener = null;
		this.mCurrentScrollState = ScrollState.SCROLL_STATE_IDLE;
		this.mBlockTouchAction = false;
		this.mIsParentVerticiallyScrollableViewDisallowingInterceptTouchEvent = false;
		this.mAdapterDataObserver = new DataSetObserver() {
			public void onChanged() {
				HorizontalListView.this.mDataChanged = true;
				HorizontalListView.this.mHasNotifiedRunningLowOnData = false;
				HorizontalListView.this.unpressTouchedChild();
				HorizontalListView.this.invalidate();
				HorizontalListView.this.requestLayout();
			}

			public void onInvalidated() {
				HorizontalListView.this.mHasNotifiedRunningLowOnData = false;
				HorizontalListView.this.unpressTouchedChild();
				HorizontalListView.this.reset();
				HorizontalListView.this.invalidate();
				HorizontalListView.this.requestLayout();
			}
		};
		this.mDelayedLayout = new Runnable() {
			@Override
			public void run() {
				HorizontalListView.this.requestLayout();
			}
		};
		this.mEdgeGlowLeft = new EdgeEffectCompat(context);
		this.mEdgeGlowRight = new EdgeEffectCompat(context);
		this.mGestureDetector = new GestureDetector(context,
				(GestureDetector.OnGestureListener) this.mGestureListener);
		this.bindGestureDetector();
		this.initView();
		this.retrieveXmlConfiguration(context, set);
		this.setWillNotDraw(false);
		if (Build.VERSION.SDK_INT >= 11) {
			HoneycombPlus.setFriction(this.mFlingTracker, 0.009f);
		}
	}

	private void addAndMeasureChild(final View view, final int n) {
		this.addViewInLayout(view, n, this.getLayoutParams(view), true);
		this.measureChild(view);
	}

	private void bindGestureDetector() {
		this.setOnTouchListener((OnTouchListener) new OnTouchListener() {
			public boolean onTouch(final View view,
					final MotionEvent motionEvent) {
				return HorizontalListView.this.mGestureDetector
						.onTouchEvent(motionEvent);
			}
		});
	}

	private float determineFlingAbsorbVelocity() {
		if (Build.VERSION.SDK_INT >= 14) {
			return IceCreamSandwichPlus.getCurrVelocity(this.mFlingTracker);
		}
		return 30.0f;
	}

	private void determineIfLowOnData() {
		if (this.mRunningOutOfDataListener != null
				&& this.mAdapter != null
				&& this.mAdapter.getCount() - (this.mRightViewAdapterIndex + 1) < this.mRunningOutOfDataThreshold
				&& !this.mHasNotifiedRunningLowOnData) {
			this.mHasNotifiedRunningLowOnData = true;
			this.mRunningOutOfDataListener.onRunningOutOfData();
		}
	}

	private boolean determineMaxX() {
		boolean b2;
		final boolean b = b2 = false;
		if (this.isLastItemInAdapter(this.mRightViewAdapterIndex)) {
			final View rightmostChild = this.getRightmostChild();
			b2 = b;
			if (rightmostChild != null) {
				final int mMaxX = this.mMaxX;
				this.mMaxX = this.mCurrentX
						+ (rightmostChild.getRight() - this.getPaddingLeft())
						- this.getRenderWidth();
				if (this.mMaxX < 0) {
					this.mMaxX = 0;
				}
				b2 = b;
				if (this.mMaxX != mMaxX) {
					b2 = true;
				}
			}
		}
		return b2;
	}

	private void drawDivider(final Canvas canvas, final Rect bounds) {
		if (this.mDivider != null) {
			this.mDivider.setBounds(bounds);
			this.mDivider.draw(canvas);
		}
	}

	private void drawDividers(final Canvas canvas) {
		final int childCount = this.getChildCount();
		final Rect mRect = this.mRect;
		this.mRect.top = this.getPaddingTop();
		this.mRect.bottom = this.mRect.top + this.getRenderHeight();
		for (int i = 0; i < childCount; ++i) {
			if (i != childCount - 1
					|| !this.isLastItemInAdapter(this.mRightViewAdapterIndex)) {
				final View child = this.getChildAt(i);
				mRect.left = child.getRight();
				mRect.right = child.getRight() + this.mDividerWidth;
				if (mRect.left < this.getPaddingLeft()) {
					mRect.left = this.getPaddingLeft();
				}
				if (mRect.right > this.getWidth() - this.getPaddingRight()) {
					mRect.right = this.getWidth() - this.getPaddingRight();
				}
				this.drawDivider(canvas, mRect);
				if (i == 0 && child.getLeft() > this.getPaddingLeft()) {
					mRect.left = this.getPaddingLeft();
					mRect.right = child.getLeft();
					this.drawDivider(canvas, mRect);
				}
			}
		}
	}

	private void drawEdgeGlow(final Canvas canvas) {
		if (this.mEdgeGlowLeft != null && !this.mEdgeGlowLeft.isFinished()
				&& this.isEdgeGlowEnabled()) {
			final int save = canvas.save();
			final int height = this.getHeight();
			canvas.rotate(-90.0f, 0.0f, 0.0f);
			canvas.translate((float) (-height + this.getPaddingBottom()), 0.0f);
			this.mEdgeGlowLeft.setSize(this.getRenderHeight(),
					this.getRenderWidth());
			if (this.mEdgeGlowLeft.draw(canvas)) {
				this.invalidate();
			}
			canvas.restoreToCount(save);
		} else if (this.mEdgeGlowRight != null
				&& !this.mEdgeGlowRight.isFinished()
				&& this.isEdgeGlowEnabled()) {
			final int save2 = canvas.save();
			final int width = this.getWidth();
			canvas.rotate(90.0f, 0.0f, 0.0f);
			canvas.translate((float) this.getPaddingTop(), (float) (-width));
			this.mEdgeGlowRight.setSize(this.getRenderHeight(),
					this.getRenderWidth());
			if (this.mEdgeGlowRight.draw(canvas)) {
				this.invalidate();
			}
			canvas.restoreToCount(save2);
		}
	}

	private void fillList(final int n) {
		int right = 0;
		final View rightmostChild = this.getRightmostChild();
		if (rightmostChild != null) {
			right = rightmostChild.getRight();
		}
		this.fillListRight(right, n);
		int left = 0;
		final View leftmostChild = this.getLeftmostChild();
		if (leftmostChild != null) {
			left = leftmostChild.getLeft();
		}
		this.fillListLeft(left, n);
	}

	private void fillListLeft(int measuredWidth, final int n) {
		while (measuredWidth + n - this.mDividerWidth > 0
				&& this.mLeftViewAdapterIndex >= 1) {
			--this.mLeftViewAdapterIndex;
			final View view = this.mAdapter.getView(this.mLeftViewAdapterIndex,
					this.getRecycledView(this.mLeftViewAdapterIndex),
					(ViewGroup) this);
			this.addAndMeasureChild(view, 0);
			int measuredWidth2;
			if (this.mLeftViewAdapterIndex == 0) {
				measuredWidth2 = view.getMeasuredWidth();
			} else {
				measuredWidth2 = this.mDividerWidth + view.getMeasuredWidth();
			}
			final int n2 = measuredWidth - measuredWidth2;
			final int mDisplayOffset = this.mDisplayOffset;
			if (n2 + n == 0) {
				measuredWidth = view.getMeasuredWidth();
			} else {
				measuredWidth = this.mDividerWidth + view.getMeasuredWidth();
			}
			this.mDisplayOffset = mDisplayOffset - measuredWidth;
			measuredWidth = n2;
		}
	}

	private void fillListRight(int n, final int n2) {
		while (n + n2 + this.mDividerWidth < this.getWidth()
				&& this.mRightViewAdapterIndex + 1 < this.mAdapter.getCount()) {
			++this.mRightViewAdapterIndex;
			if (this.mLeftViewAdapterIndex < 0) {
				this.mLeftViewAdapterIndex = this.mRightViewAdapterIndex;
			}
			final View view = this.mAdapter.getView(
					this.mRightViewAdapterIndex,
					this.getRecycledView(this.mRightViewAdapterIndex),
					(ViewGroup) this);
			this.addAndMeasureChild(view, -1);
			int mDividerWidth;
			if (this.mRightViewAdapterIndex == 0) {
				mDividerWidth = 0;
			} else {
				mDividerWidth = this.mDividerWidth;
			}
			n += mDividerWidth + view.getMeasuredWidth();
			this.determineIfLowOnData();
		}
	}

	private View getChild(final int n) {
		if (n >= this.mLeftViewAdapterIndex && n <= this.mRightViewAdapterIndex) {
			return this.getChildAt(n - this.mLeftViewAdapterIndex);
		}
		return null;
	}

	private int getChildIndex(final int n, final int n2) {
		for (int childCount = this.getChildCount(), i = 0; i < childCount; ++i) {
			this.getChildAt(i).getHitRect(this.mRect);
			if (this.mRect.contains(n, n2)) {
				return i;
			}
		}
		return -1;
	}

	private LayoutParams getLayoutParams(final View view) {
		LayoutParams layoutParams;
		if ((layoutParams = view.getLayoutParams()) == null) {
			layoutParams = new LayoutParams(-2, -1);
		}
		return layoutParams;
	}

	private View getLeftmostChild() {
		return this.getChildAt(0);
	}

	private View getRecycledView(int itemViewType) {
		itemViewType = this.mAdapter.getItemViewType(itemViewType);
		if (this.isItemViewTypeValid(itemViewType)) {
			return this.mRemovedViewsCache.get(itemViewType).poll();
		}
		return null;
	}

	private int getRenderHeight() {
		return this.getHeight() - this.getPaddingTop()
				- this.getPaddingBottom();
	}

	private int getRenderWidth() {
		return this.getWidth() - this.getPaddingLeft() - this.getPaddingRight();
	}

	private View getRightmostChild() {
		return this.getChildAt(this.getChildCount() - 1);
	}

	private void initView() {
		this.mLeftViewAdapterIndex = -1;
		this.mRightViewAdapterIndex = -1;
		this.mDisplayOffset = 0;
		this.mCurrentX = 0;
		this.mNextX = 0;
		this.mMaxX = Integer.MAX_VALUE;
		this.setCurrentScrollState(ScrollState.SCROLL_STATE_IDLE);
	}

	private void initializeRecycledViewCache(final int n) {
		this.mRemovedViewsCache.clear();
		for (int i = 0; i < n; ++i) {
			this.mRemovedViewsCache.add(new LinkedList<View>());
		}
	}

	private boolean isEdgeGlowEnabled() {
		return this.mAdapter != null && !this.mAdapter.isEmpty()
				&& this.mMaxX > 0;
	}

	private boolean isItemViewTypeValid(final int n) {
		return n < this.mRemovedViewsCache.size();
	}

	private boolean isLastItemInAdapter(final int n) {
		return n == this.mAdapter.getCount() - 1;
	}

	@SuppressLint("WrongConstant")
	private void measureChild(final View view) {
		final LayoutParams layoutParams = this.getLayoutParams(view);
		final int childMeasureSpec = ViewGroup.getChildMeasureSpec(
				this.mHeightMeasureSpec,
				this.getPaddingTop() + this.getPaddingBottom(),
				layoutParams.height);
		int n;
		if (layoutParams.width > 0) {
			n = MeasureSpec
					.makeMeasureSpec(layoutParams.width, 1073741824);
		} else {
			n = MeasureSpec.makeMeasureSpec(0, 0);
		}
		view.measure(n, childMeasureSpec);
	}

	private void positionChildren(int i) {
		final int childCount = this.getChildCount();
		if (childCount > 0) {
			this.mDisplayOffset += i;
			int mDisplayOffset = this.mDisplayOffset;
			View child;
			int n;
			int paddingTop;
			for (i = 0; i < childCount; ++i) {
				child = this.getChildAt(i);
				n = mDisplayOffset + this.getPaddingLeft();
				paddingTop = this.getPaddingTop();
				child.layout(n, paddingTop, n + child.getMeasuredWidth(),
						paddingTop + child.getMeasuredHeight());
				mDisplayOffset += child.getMeasuredWidth() + this.mDividerWidth;
			}
		}
	}

	private void recycleView(int itemViewType, final View view) {
		itemViewType = this.mAdapter.getItemViewType(itemViewType);
		if (this.isItemViewTypeValid(itemViewType)) {
			this.mRemovedViewsCache.get(itemViewType).offer(view);
		}
	}

	private void releaseEdgeGlow() {
		if (this.mEdgeGlowLeft != null) {
			this.mEdgeGlowLeft.onRelease();
		}
		if (this.mEdgeGlowRight != null) {
			this.mEdgeGlowRight.onRelease();
		}
	}

	private void removeNonVisibleChildren(final int n) {
		for (View view = this.getLeftmostChild(); view != null
				&& view.getRight() + n <= 0; view = this.getLeftmostChild()) {
			final int mDisplayOffset = this.mDisplayOffset;
			int measuredWidth;
			if (this.isLastItemInAdapter(this.mLeftViewAdapterIndex)) {
				measuredWidth = view.getMeasuredWidth();
			} else {
				measuredWidth = this.mDividerWidth + view.getMeasuredWidth();
			}
			this.mDisplayOffset = measuredWidth + mDisplayOffset;
			this.recycleView(this.mLeftViewAdapterIndex, view);
			this.removeViewInLayout(view);
			++this.mLeftViewAdapterIndex;
		}
		for (View view2 = this.getRightmostChild(); view2 != null
				&& view2.getLeft() + n >= this.getWidth(); view2 = this
				.getRightmostChild()) {
			this.recycleView(this.mRightViewAdapterIndex, view2);
			this.removeViewInLayout(view2);
			--this.mRightViewAdapterIndex;
		}
	}

	private void requestParentListViewToNotInterceptTouchEvents(final Boolean b) {
		if (this.mIsParentVerticiallyScrollableViewDisallowingInterceptTouchEvent != b) {
			for (Object o = this; ((View) o).getParent() instanceof View; o = ((View) o)
					.getParent()) {
				if (((View) o).getParent() instanceof ListView
						|| ((View) o).getParent() instanceof ScrollView) {
					((View) o).getParent().requestDisallowInterceptTouchEvent(
							(boolean) b);
					this.mIsParentVerticiallyScrollableViewDisallowingInterceptTouchEvent = b;
					break;
				}
			}
		}
	}

	private void reset() {
		this.initView();
		this.removeAllViewsInLayout();
		this.requestLayout();
	}

	private void retrieveXmlConfiguration(final Context context,
			final AttributeSet set) {
		if (set != null) {
			final TypedArray obtainStyledAttributes = context
					.obtainStyledAttributes(set, R.styleable.HorizontalListView);
			@SuppressLint("ResourceType") final Drawable drawable = obtainStyledAttributes.getDrawable(1);
			if (drawable != null) {
				this.setDivider(drawable);
			}
			@SuppressLint("ResourceType") final int dimensionPixelSize = obtainStyledAttributes
					.getDimensionPixelSize(3, 0);
			if (dimensionPixelSize != 0) {
				this.setDividerWidth(dimensionPixelSize);
			}
			if (obtainStyledAttributes != null) {
				obtainStyledAttributes.recycle();
				System.gc();
			}
		}
	}

	private void setCurrentScrollState(final ScrollState mCurrentScrollState) {
		if (this.mCurrentScrollState != mCurrentScrollState
				&& this.mOnScrollStateChangedListener != null) {
			this.mOnScrollStateChangedListener
					.onScrollStateChanged(mCurrentScrollState);
		}
		this.mCurrentScrollState = mCurrentScrollState;
	}

	private void unpressTouchedChild() {
		if (this.mViewBeingTouched != null) {
			this.mViewBeingTouched.setPressed(false);
			this.refreshDrawableState();
			this.mViewBeingTouched = null;
		}
	}

	private void updateOverscrollAnimation(int n) {
		if (this.mEdgeGlowLeft != null && this.mEdgeGlowRight != null) {
			final int n2 = this.mCurrentX + n;
			if (this.mFlingTracker == null || this.mFlingTracker.isFinished()) {
				if (n2 < 0) {
					n = Math.abs(n);
					this.mEdgeGlowLeft.onPull(n / this.getRenderWidth());
					if (!this.mEdgeGlowRight.isFinished()) {
						this.mEdgeGlowRight.onRelease();
					}
				} else if (n2 > this.mMaxX) {
					n = Math.abs(n);
					this.mEdgeGlowRight.onPull(n / this.getRenderWidth());
					if (!this.mEdgeGlowLeft.isFinished()) {
						this.mEdgeGlowLeft.onRelease();
					}
				}
			}
		}
	}

	protected void dispatchDraw(final Canvas canvas) {
		super.dispatchDraw(canvas);
		this.drawEdgeGlow(canvas);
	}

	protected void dispatchSetPressed(final boolean b) {
	}

	public ListAdapter getAdapter() {
		return this.mAdapter;
	}

	public int getFirstVisiblePosition() {
		return this.mLeftViewAdapterIndex;
	}

	public int getLastVisiblePosition() {
		return this.mRightViewAdapterIndex;
	}

	protected float getLeftFadingEdgeStrength() {
		final int horizontalFadingEdgeLength = this
				.getHorizontalFadingEdgeLength();
		if (this.mCurrentX == 0) {
			return 0.0f;
		}
		if (this.mCurrentX < horizontalFadingEdgeLength) {
			return this.mCurrentX / horizontalFadingEdgeLength;
		}
		return 1.0f;
	}

	protected float getRightFadingEdgeStrength() {
		final int horizontalFadingEdgeLength = this
				.getHorizontalFadingEdgeLength();
		if (this.mCurrentX == this.mMaxX) {
			return 0.0f;
		}
		if (this.mMaxX - this.mCurrentX < horizontalFadingEdgeLength) {
			return (this.mMaxX - this.mCurrentX) / horizontalFadingEdgeLength;
		}
		return 1.0f;
	}

	public View getSelectedView() {
		return this.getChild(this.mCurrentlySelectedAdapterIndex);
	}

	protected boolean onDown(final MotionEvent motionEvent) {
		this.mBlockTouchAction = !this.mFlingTracker.isFinished();
		this.mFlingTracker.forceFinished(true);
		this.setCurrentScrollState(ScrollState.SCROLL_STATE_IDLE);
		this.unpressTouchedChild();
		if (!this.mBlockTouchAction) {
			final int childIndex = this.getChildIndex((int) motionEvent.getX(),
					(int) motionEvent.getY());
			if (childIndex >= 0) {
				this.mViewBeingTouched = this.getChildAt(childIndex);
				if (this.mViewBeingTouched != null) {
					this.mViewBeingTouched.setPressed(true);
					this.refreshDrawableState();
				}
			}
		}
		return true;
	}

	protected void onDraw(final Canvas canvas) {
		super.onDraw(canvas);
		this.drawDividers(canvas);
	}

	protected boolean onFling(final MotionEvent motionEvent,
			final MotionEvent motionEvent2, final float n, final float n2) {
		this.mFlingTracker.fling(this.mNextX, 0, (int) (-n), 0, 0, this.mMaxX,
				0, 0);
		this.setCurrentScrollState(ScrollState.SCROLL_STATE_FLING);
		this.requestLayout();
		return true;
	}

	@SuppressLint({ "WrongCall" })
	protected void onLayout(final boolean b, final int n, final int n2,
			final int n3, final int n4) {
		super.onLayout(b, n, n2, n3, n4);
		if (this.mAdapter != null) {
			this.invalidate();
			if (this.mDataChanged) {
				final int mCurrentX = this.mCurrentX;
				this.initView();
				this.removeAllViewsInLayout();
				this.mNextX = mCurrentX;
				this.mDataChanged = false;
			}
			if (this.mRestoreX != null) {
				this.mNextX = this.mRestoreX;
				this.mRestoreX = null;
			}
			if (this.mFlingTracker.computeScrollOffset()) {
				this.mNextX = this.mFlingTracker.getCurrX();
			}
			if (this.mNextX < 0) {
				this.mNextX = 0;
				if (this.mEdgeGlowLeft.isFinished()) {
					this.mEdgeGlowLeft.onAbsorb((int) this
							.determineFlingAbsorbVelocity());
				}
				this.mFlingTracker.forceFinished(true);
				this.setCurrentScrollState(ScrollState.SCROLL_STATE_IDLE);
			} else if (this.mNextX > this.mMaxX) {
				this.mNextX = this.mMaxX;
				if (this.mEdgeGlowRight.isFinished()) {
					this.mEdgeGlowRight.onAbsorb((int) this
							.determineFlingAbsorbVelocity());
				}
				this.mFlingTracker.forceFinished(true);
				this.setCurrentScrollState(ScrollState.SCROLL_STATE_IDLE);
			}
			final int n5 = this.mCurrentX - this.mNextX;
			this.removeNonVisibleChildren(n5);
			this.fillList(n5);
			this.positionChildren(n5);
			this.mCurrentX = this.mNextX;
			if (this.determineMaxX()) {
				this.onLayout(b, n, n2, n3, n4);
				return;
			}
			if (!this.mFlingTracker.isFinished()) {
				ViewCompat.postOnAnimation((View) this, this.mDelayedLayout);
				return;
			}
			if (this.mCurrentScrollState == ScrollState.SCROLL_STATE_FLING) {
				this.setCurrentScrollState(ScrollState.SCROLL_STATE_IDLE);
			}
		}
	}

	protected void onMeasure(final int n, final int mHeightMeasureSpec) {
		super.onMeasure(n, mHeightMeasureSpec);
		this.mHeightMeasureSpec = mHeightMeasureSpec;
	}

	public void onRestoreInstanceState(final Parcelable parcelable) {
		if (parcelable instanceof Bundle) {
			final Bundle bundle = (Bundle) parcelable;
			this.mRestoreX = bundle.getInt("BUNDLE_ID_CURRENT_X");
			super.onRestoreInstanceState(bundle
					.getParcelable("BUNDLE_ID_PARENT_STATE"));
		}
	}

	public Parcelable onSaveInstanceState() {
		final Bundle bundle = new Bundle();
		bundle.putParcelable("BUNDLE_ID_PARENT_STATE",
				super.onSaveInstanceState());
		bundle.putInt("BUNDLE_ID_CURRENT_X", this.mCurrentX);
		return (Parcelable) bundle;
	}

	public boolean onTouchEvent(final MotionEvent motionEvent) {
		if (motionEvent.getAction() == 1) {
			if (this.mFlingTracker == null || this.mFlingTracker.isFinished()) {
				this.setCurrentScrollState(ScrollState.SCROLL_STATE_IDLE);
			}
			this.requestParentListViewToNotInterceptTouchEvents(false);
			this.releaseEdgeGlow();
		} else if (motionEvent.getAction() == 3) {
			this.unpressTouchedChild();
			this.releaseEdgeGlow();
			this.requestParentListViewToNotInterceptTouchEvents(false);
		}
		return super.onTouchEvent(motionEvent);
	}

	public void scrollTo(final int n) {
		this.mFlingTracker.startScroll(this.mNextX, 0, n - this.mNextX, 0);
		this.setCurrentScrollState(ScrollState.SCROLL_STATE_FLING);
		this.requestLayout();
	}

	public void setAdapter(final ListAdapter mAdapter) {
		if (this.mAdapter != null) {
			this.mAdapter.unregisterDataSetObserver(this.mAdapterDataObserver);
		}
		if (mAdapter != null) {
			this.mHasNotifiedRunningLowOnData = false;
			(this.mAdapter = mAdapter)
					.registerDataSetObserver(this.mAdapterDataObserver);
		}
		this.initializeRecycledViewCache(this.mAdapter.getViewTypeCount());
		this.reset();
	}

	public void setDivider(final Drawable mDivider) {
		this.mDivider = mDivider;
		if (mDivider != null) {
			this.setDividerWidth(mDivider.getIntrinsicWidth());
			return;
		}
		this.setDividerWidth(0);
	}

	public void setDividerWidth(final int mDividerWidth) {
		this.mDividerWidth = mDividerWidth;
		this.requestLayout();
		this.invalidate();
	}

	public void setOnClickListener(final OnClickListener mOnClickListener) {
		this.mOnClickListener = mOnClickListener;
	}

	public void setOnScrollStateChangedListener(
			final OnScrollStateChangedListener mOnScrollStateChangedListener) {
		this.mOnScrollStateChangedListener = mOnScrollStateChangedListener;
	}

	public void setRunningOutOfDataListener(
			final RunningOutOfDataListener mRunningOutOfDataListener,
			final int mRunningOutOfDataThreshold) {
		this.mRunningOutOfDataListener = mRunningOutOfDataListener;
		this.mRunningOutOfDataThreshold = mRunningOutOfDataThreshold;
	}

	public void setSelection(final int mCurrentlySelectedAdapterIndex) {
		this.mCurrentlySelectedAdapterIndex = mCurrentlySelectedAdapterIndex;
	}

	private class GestureListener extends
			GestureDetector.SimpleOnGestureListener {
		public boolean onDown(final MotionEvent motionEvent) {
			return HorizontalListView.this.onDown(motionEvent);
		}

		public boolean onFling(final MotionEvent motionEvent,
				final MotionEvent motionEvent2, final float n, final float n2) {
			return HorizontalListView.this.onFling(motionEvent, motionEvent2,
					n, n2);
		}

		public void onLongPress(final MotionEvent motionEvent) {
			HorizontalListView.this.unpressTouchedChild();
			final int access$900 = HorizontalListView.this.getChildIndex(
					(int) motionEvent.getX(), (int) motionEvent.getY());
			if (access$900 >= 0 && !HorizontalListView.this.mBlockTouchAction) {
				final View child = HorizontalListView.this
						.getChildAt(access$900);
				final OnItemLongClickListener onItemLongClickListener = HorizontalListView.this
						.getOnItemLongClickListener();
				if (onItemLongClickListener != null) {
					final int n = HorizontalListView.this.mLeftViewAdapterIndex
							+ access$900;
					if (onItemLongClickListener.onItemLongClick(
							(AdapterView) HorizontalListView.this, child, n,
							HorizontalListView.this.mAdapter.getItemId(n))) {
						HorizontalListView.this.performHapticFeedback(0);
					}
				}
			}
		}

		public boolean onScroll(final MotionEvent motionEvent,
				final MotionEvent motionEvent2, final float n, final float n2) {
			HorizontalListView.this
					.requestParentListViewToNotInterceptTouchEvents(true);
			HorizontalListView.this
					.setCurrentScrollState(ScrollState.SCROLL_STATE_TOUCH_SCROLL);
			HorizontalListView.this.unpressTouchedChild();
			final HorizontalListView this$0 = HorizontalListView.this;
			this$0.mNextX += (int) n;
			HorizontalListView.this.updateOverscrollAnimation(Math.round(n));
			HorizontalListView.this.requestLayout();
			return true;
		}

		public boolean onSingleTapConfirmed(final MotionEvent motionEvent) {
			HorizontalListView.this.unpressTouchedChild();
			final OnItemClickListener onItemClickListener = HorizontalListView.this
					.getOnItemClickListener();
			final int access$900 = HorizontalListView.this.getChildIndex(
					(int) motionEvent.getX(), (int) motionEvent.getY());
			if (access$900 >= 0 && !HorizontalListView.this.mBlockTouchAction) {
				final View child = HorizontalListView.this
						.getChildAt(access$900);
				final int n = HorizontalListView.this.mLeftViewAdapterIndex
						+ access$900;
				if (onItemClickListener != null) {
					onItemClickListener.onItemClick(
							(AdapterView) HorizontalListView.this, child, n,
							HorizontalListView.this.mAdapter.getItemId(n));
					return true;
				}
			}
			if (HorizontalListView.this.mOnClickListener != null
					&& !HorizontalListView.this.mBlockTouchAction) {
				HorizontalListView.this.mOnClickListener
						.onClick((View) HorizontalListView.this);
			}
			return false;
		}
	}

	@TargetApi(11)
	private static final class HoneycombPlus {
		static {
			if (Build.VERSION.SDK_INT < 11) {
				throw new RuntimeException(
						"Should not get to HoneycombPlus class unless sdk is >= 11!");
			}
		}

		public static void setFriction(final Scroller scroller,
				final float friction) {
			if (scroller != null) {
				scroller.setFriction(friction);
			}
		}
	}

	@TargetApi(14)
	private static final class IceCreamSandwichPlus {
		static {
			if (Build.VERSION.SDK_INT < 14) {
				throw new RuntimeException(
						"Should not get to IceCreamSandwichPlus class unless sdk is >= 14!");
			}
		}

		public static float getCurrVelocity(final Scroller scroller) {
			return scroller.getCurrVelocity();
		}
	}

	public interface OnScrollStateChangedListener {
		void onScrollStateChanged(final ScrollState p0);

		public enum ScrollState {
			SCROLL_STATE_FLING, SCROLL_STATE_IDLE, SCROLL_STATE_TOUCH_SCROLL;
		}
	}

	public interface RunningOutOfDataListener {
		void onRunningOutOfData();
	}
}
