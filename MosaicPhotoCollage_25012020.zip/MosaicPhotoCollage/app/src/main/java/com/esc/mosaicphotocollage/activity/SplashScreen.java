package com.esc.mosaicphotocollage.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.esc.mosaicphotocollage.R;

public class SplashScreen extends Activity {

	public void onBackPressed() {
		super.onBackPressed();
	}

	protected void onCreate(Bundle paramBundle) {
		super.onCreate(paramBundle);
		requestWindowFeature(1);
		getWindow().setFlags(1024, 1024);
		setContentView(R.layout.activity_splashscreen);

		new Handler().postDelayed(new Runnable() {
			public final void run() {
				Intent localIntent = new Intent(SplashScreen.this, HomeScreen.class);
				SplashScreen.this.startActivity(localIntent);
				SplashScreen.this.finish();

			}
		}, 3600);
		Animation animation = AnimationUtils.loadAnimation(this,
				R.anim.anim_loading);
		((ImageView) findViewById(R.id.loading)).startAnimation(animation);
	}

	public void onPause() {
		super.onPause();
	}

	protected void onResume() {
		super.onResume();
	}
}
