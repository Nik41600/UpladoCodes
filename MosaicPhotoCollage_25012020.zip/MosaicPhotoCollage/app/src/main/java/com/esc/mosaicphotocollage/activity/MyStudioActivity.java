package com.esc.mosaicphotocollage.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import com.esc.mosaicphotocollage.R;
import com.esc.mosaicphotocollage.adapter.MyStudioAdapter;
import com.esc.mosaicphotocollage.kprogresshud.KProgressHUD;
import com.esc.mosaicphotocollage.util.Glob;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.util.Collections;

public class MyStudioActivity extends AppCompatActivity {
    Activity activity = MyStudioActivity.this;
    private ImageView ivBack;
    private MyStudioAdapter creationAdapter;
    private GridView Grid_Creationlist;
    private ImageView ivNoImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_my_studio);

        loadAd();
    }

    protected void onResume() {
        super.onResume();
        bindView();
    }

    private void bindView() {
        this.ivNoImage = (ImageView) findViewById(R.id.novideoimg);
        this.Grid_Creationlist = (GridView) findViewById(R.id.grid_imgLst);
        getImages();
        if (Glob.IMAGEALLARY.size() <= 0) {
            this.ivNoImage.setVisibility(View.VISIBLE);
            this.Grid_Creationlist.setVisibility(View.GONE);
        } else {
            this.ivNoImage.setVisibility(View.GONE);
            this.Grid_Creationlist.setVisibility(View.VISIBLE);
        }
        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBack;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    Intent i = new Intent(MyStudioActivity.this, HomeScreen.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    finish();
                }
            }
        });

        Collections.sort(Glob.IMAGEALLARY);
        Collections.reverse(Glob.IMAGEALLARY);
        this.creationAdapter = new MyStudioAdapter(this, Glob.IMAGEALLARY);
        this.Grid_Creationlist.setAdapter(this.creationAdapter);
        Grid_Creationlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Intent i = new Intent(MyStudioActivity.this, DisplayImageActivity.class);
                i.putExtra("position", position);
                startActivity(i);
                finish();
            }
        });
    }

    private void getImages() {
        if (Build.VERSION.SDK_INT < 23) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                    5);
        }
    }

    private void fetchImage() {
        Glob.IMAGEALLARY.clear();
        Glob.listAllImages(new File("/mnt/sdcard/" + getString(R.string.app_name)
                + "/"));
    }

    public void onBackPressed() {
        Intent i = new Intent(MyStudioActivity.this, HomeScreen.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 5:
                if (grantResults[0] == 0) {
                    fetchImage();
                    return;
                } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                            new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                            5);
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
    }

    private InterstitialAd interstitialAd;
    private AdView adView;
    private int id;
    private KProgressHUD hud;

    private void loadAd() {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                switch (id) {
                    case R.id.ivBack:
                        Intent i = new Intent(MyStudioActivity.this, HomeScreen.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.e("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(MyStudioActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }


    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

}
