package com.esc.mosaicphotocollage.activity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Random;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

import com.esc.mosaicphotocollage.R;
import com.esc.mosaicphotocollage.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import eu.janmuller.android.simplecropimage.CropImage;

public class ImageEditingActivity extends Activity implements OnClickListener, OnSeekBarChangeListener {
    public File f11a;
    ArrayList<Bitmap> arraylist;
    public int c;
    public int d;
    private int f;
    private Point point;
    private Display display;
    private RelativeLayout relative_ly;
    private String[] str;
    private ImageView imageview;
    private SeekBar seekbar;
    private File file;
    private boolean n;
    private ImageView iv_back;
    LinearLayout ll_contrast, ll_hardness, ll_save, ll_gallery;
    private ImageView iv_contrast;
    private ImageView iv_hardness;
    private ImageView iv_gallery;
    private ImageView iv_save;
    ProgressDialog progressDialog;


    class mediaScannerClass implements OnScanCompletedListener {
        final ImageEditingActivity mainactivity;

        mediaScannerClass(ImageEditingActivity mainActivity) {
            this.mainactivity = mainActivity;
        }

        public final void onScanCompleted(String str, Uri uri) {
        }
    }

    public ImageEditingActivity() {
        this.arraylist = new ArrayList();
        this.c = 20;
        this.d = 50;
        this.n = true;
    }

    @SuppressLint({"NewApi", "WrongConstant"})
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_imageedit);

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);

        ll_contrast = findViewById(R.id.ll_contrast);
        ll_contrast.setOnClickListener(this);

        ll_hardness = findViewById(R.id.ll_hardness);
        ll_hardness.setOnClickListener(this);

        ll_gallery = findViewById(R.id.ll_gallery);
        ll_gallery.setOnClickListener(this);

        ll_save = findViewById(R.id.ll_save);
        ll_save.setOnClickListener(this);

        iv_contrast = findViewById(R.id.iv_contrast);
        iv_hardness = findViewById(R.id.iv_hardness);
        iv_gallery = findViewById(R.id.iv_gallery);
        iv_save = findViewById(R.id.iv_save);

        this.relative_ly = (RelativeLayout) findViewById(R.id.bgLayout);
        this.imageview = (ImageView) findViewById(R.id.image);
        this.seekbar = (SeekBar) findViewById(R.id.seekBar);
        this.seekbar.setOnSeekBarChangeListener(this);
        this.display = ((WindowManager) getBaseContext().getSystemService(
                "window")).getDefaultDisplay();
        this.point = new Point();
        if (VERSION.SDK_INT > 12) {
            this.display.getSize(this.point);
            this.f = this.point.x;
        } else {
            this.f = this.display.getWidth();
        }
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                this.f, this.f);
        layoutParams.addRule(13, -1);
        this.relative_ly.setLayoutParams(layoutParams);
        this.str = getIntent().getStringArrayExtra("all_path");
        try {
            b();
            a();
        } catch (Exception e) {
        }
        String file = Environment.getExternalStorageDirectory().toString();
        new File(new StringBuilder(String.valueOf(file)).append("/")
                .append(getString(R.string.app_name)).append("/temp")
                .toString()).mkdirs();
        if ("mounted".equals(Environment.getExternalStorageState())) {
            this.file = new File(new StringBuilder(String.valueOf(file))
                    .append("/").append(getString(R.string.app_name))
                    .append("/temp/").toString(), "Mosaic_Collage.jpg");
        } else {
            this.file = new File(getFilesDir(), "Mosaic_Collage.jpg");
        }
        this.imageview.setImageBitmap(bitmap(this.str[0]));
        try {
            this.imageview.setAlpha(0.8f);
        } catch (Exception e2) {
        }

        loadAds();
    }

    private void a() {
        try {
            Bitmap createBitmap = Bitmap.createBitmap(1000,
                    1000, Config.ARGB_8888);
            Random random = new Random();
            Canvas canvas = new Canvas(createBitmap);
            for (int i = 0; i < this.c; i++) {
                for (int i2 = 0; i2 < this.c; i2++) {
                    canvas.drawBitmap((Bitmap) this.arraylist.get(random
                                    .nextInt(this.str.length + 0)),
                            (float) (this.d * i2), (float) (this.d * i), null);
                }
            }
            this.relative_ly.setBackgroundDrawable(new BitmapDrawable(
                    createBitmap));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void b() {
        for (String str : this.str) {
            Options options = new Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(str, options);
            int i = options.outWidth;
            int i2 = options.outHeight;
            int i3 = i;
            i = 1;
            if (i3 <= 200 && i2 <= 200) {
            } else {
                i3 /= 2;
                i2 /= 2;
                i *= 2;
            }
            options = new Options();
            options.inSampleSize = i;
            this.arraylist.add(ThumbnailUtils.extractThumbnail(
                    BitmapFactory.decodeFile(str, options), this.d, this.d));
        }
    }

    private Bitmap bitmap(String str) {
        int i = 1;
        Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        int i2 = options.outWidth;
        int i3 = options.outHeight;
        while (true) {
            if (i2 > 1000 || i3 > 1000) {
                i2 /= 2;
                i3 /= 2;
                i *= 2;
            } else {
                Options options2 = new Options();
                options2.inSampleSize = i;
                return ThumbnailUtils
                        .extractThumbnail(
                                BitmapFactory.decodeFile(str, options2),
                                this.f, this.f);
            }
        }
    }

    @SuppressLint("WrongConstant")
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.iv_back:
                id = R.id.iv_back;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    startActivity(new Intent(ImageEditingActivity.this, HomeScreen.class));
                }
                break;

            case R.id.ll_contrast:
                iv_contrast.setImageResource(R.drawable.ic_contrast);
                iv_hardness.setImageResource(R.drawable.ic_unpress_hardness);
                iv_gallery.setImageResource(R.drawable.ic__unpress_gallery);
                iv_save.setImageResource(R.drawable.ic_unpress_save);

                findViewById(R.id.seekbarLayout).setVisibility(0);
                this.n = true;
                break;
            case R.id.ll_hardness:
                iv_contrast.setImageResource(R.drawable.ic_unpress_contrast);
                iv_hardness.setImageResource(R.drawable.ic_hardness);
                iv_gallery.setImageResource(R.drawable.ic__unpress_gallery);
                iv_save.setImageResource(R.drawable.ic_unpress_save);

                findViewById(R.id.seekbarLayout).setVisibility(0);
                this.n = false;
                break;
            case R.id.ll_gallery:
                iv_contrast.setImageResource(R.drawable.ic_unpress_contrast);
                iv_hardness.setImageResource(R.drawable.ic_unpress_hardness);
                iv_gallery.setImageResource(R.drawable.ic_gallery);
                iv_save.setImageResource(R.drawable.ic_unpress_save);

                findViewById(R.id.seekbarLayout).setVisibility(8);
                intent = new Intent("android.intent.action.PICK");
                intent.setType("image/*");
                startActivityForResult(intent, 1);
                break;
            case R.id.ll_save:
                iv_contrast.setImageResource(R.drawable.ic_unpress_contrast);
                iv_hardness.setImageResource(R.drawable.ic_unpress_hardness);
                iv_gallery.setImageResource(R.drawable.ic__unpress_gallery);
                iv_save.setImageResource(R.drawable.ic_save);

                id = R.id.ll_save;
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    SaveImage();
                }
                break;
            default:
                break;
        }
    }

    private void SaveImage() {
        this.relative_ly.setDrawingCacheEnabled(true);
        this.relative_ly.layout(0, 0, this.relative_ly.getMeasuredWidth(),
                this.relative_ly.getMeasuredHeight());
        Bitmap drawingCache = this.relative_ly.getDrawingCache(true);
        try {
            drawingCache.compress(CompressFormat.JPEG, 90,
                    new FileOutputStream(this.file));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        SharedPreferences defaultSharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(this);
        int i = defaultSharedPreferences.getInt("count", 0);
        Editor edit = defaultSharedPreferences.edit();
        i++;
        edit.putInt("count", i);
        edit.commit();

        String file = Environment.getExternalStorageDirectory().toString();
        new File(new StringBuilder(String.valueOf(file)).append("/")
                .append(getString(R.string.app_name)).toString()).mkdir();
        if ("mounted".equals(Environment.getExternalStorageState())) {
            this.f11a = new File(new StringBuilder(String.valueOf(file))
                    .append("/").append(getString(R.string.app_name))
                    .append("/Mosaic_Collage").append(i).append(".png")
                    .toString());
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(
                        this.f11a);
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
            }
        } else {
            this.f11a = new File(getFilesDir(), "Mosaic_Collage");
        }
        try {
            fileOutputStream_class(this.file, this.f11a);
        } catch (IOException e3) {
            e3.printStackTrace();
        }
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.f, this.f);
        layoutParams.addRule(13, -1);
        this.relative_ly.setLayoutParams(layoutParams);
        this.relative_ly.setDrawingCacheEnabled(false);

        try {
            MediaScannerConnection.scanFile(getApplicationContext(),
                    new String[]{this.f11a.getAbsolutePath()}, null,
                    new mediaScannerClass(this));
        } catch (Exception e4) {
            Log.i("inCathc Block", "Hello welcome in catch blocke");
            System.out.println("error is==" + e4);
        }

        progressDialog = ProgressDialog.show(ImageEditingActivity.this, "", "Loading...");
        new Thread() {
            public void run() {
                try {
                    Intent intent = new Intent(getApplicationContext(), ShareActivity.class);
                    intent.putExtra("ImageUri", f11a.getAbsolutePath());
                    startActivity(intent);
                    finish();

                } catch (Exception e) {
                }
                progressDialog.dismiss();
            }
        }.start();
    }

    private InterstitialAd interstitialAd;
    private AdView adView;
    private KProgressHUD hud;
    private int id;

    private void loadAds() {
        //Banner Ad
        adView = findViewById(R.id.AdView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(ImageEditingActivity.this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.loadAd(adRequestfull);
        interstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.iv_back:
                        startActivity(new Intent(ImageEditingActivity.this, HomeScreen.class));
                        break;

                    case R.id.ll_save:
                        SaveImage();
                        break;

                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitialAd.loadAd(adRequestfull);
    }

    private void requestNewInterstitial() {
        this.interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(ImageEditingActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitialAd.show();
            }
        }, 2000);
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1) {
            switch (i) {
                case 1:
                    try {
                        InputStream openInputStream = getContentResolver()
                                .openInputStream(intent.getData());
                        OutputStream fileOutputStream = new FileOutputStream(
                                this.file);
                        m18a(openInputStream, fileOutputStream);
                        fileOutputStream.close();
                        openInputStream.close();
                        Intent intent2 = new Intent(this, CropImage.class);
                        intent2.putExtra(CropImage.IMAGE_PATH, this.file.getPath());
                        intent2.putExtra(CropImage.SCALE, true);
                        intent2.putExtra(CropImage.ASPECT_X, 3);
                        intent2.putExtra(CropImage.ASPECT_Y, 3);
                        startActivityForResult(intent2, 2);
                        break;
                    } catch (Throwable e) {
                        Log.e("MainActivity", "Error while creating temp file", e);
                        break;
                    }
                case 2:
                    String stringExtra = intent
                            .getStringExtra(CropImage.IMAGE_PATH);
                    if (stringExtra != null) {
                        this.imageview.setImageBitmap(BitmapFactory
                                .decodeFile(stringExtra));
                        break;
                    }
                    return;
            }
            super.onActivityResult(i, i2, intent);
        }
    }

    private static void m18a(InputStream inputStream, OutputStream outputStream)
            throws IOException {
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read != -1) {
                outputStream.write(bArr, 0, read);
            } else {
                return;
            }
        }
    }

    private static void fileOutputStream_class(File file, File file2) throws IOException {
        InputStream fileInputStream = new FileInputStream(file);
        OutputStream fileOutputStream = new FileOutputStream(file2);
        byte[] bArr = new byte[1024];
        while (true) {
            int read = fileInputStream.read(bArr);
            if (read <= 0) {
                fileInputStream.close();
                fileOutputStream.close();
                return;
            }
            fileOutputStream.write(bArr, 0, read);
        }
    }

    protected void onStart() {
        super.onStart();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    protected void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    @SuppressLint({"NewApi"})
    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (this.n) {
            try {
                this.imageview.setAlpha(((float) i) / 100.0f);
                return;
            } catch (Exception e) {
                return;
            }
        }
        this.c = (i / 5) + 5;
        this.d = 1000 / this.c;
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        if (!this.n) {
            this.arraylist.clear();
            b();
            a();
        }
    }
}
