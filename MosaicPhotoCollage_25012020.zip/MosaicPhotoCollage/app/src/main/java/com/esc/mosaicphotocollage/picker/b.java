package com.esc.mosaicphotocollage.picker;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.esc.mosaicphotocollage.R;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

public final class b extends BaseAdapter {
	ImageLoader imgloader;
	private Context b;
	private LayoutInflater layoutinflater;
	private ArrayList<a> arraylist;
	private boolean e;

	@SuppressLint("WrongConstant")
	public b(final Context b, final ImageLoader a) {
		this.arraylist = new ArrayList<com.esc.mosaicphotocollage.picker.a>();
		this.layoutinflater = (LayoutInflater) b
				.getSystemService("layout_inflater");
		this.b = b;
		this.imgloader = a;
	}

	public final a object_a(int i) {
		return (a) this.arraylist.get(i);
	}

	public final ArrayList<a> ArraylistAdd() {
		ArrayList<a> arrayList = new ArrayList();
		for (int i = 0; i < this.arraylist.size(); i++) {
			if (((a) this.arraylist.get(i)).b) {
				arrayList.add((a) this.arraylist.get(i));
			}
		}
		return arrayList;
	}

	public final void setTabMethod(final View view, final int n) {
		if (this.arraylist.get(n).b) {
			this.arraylist.get(n).b = false;
		} else {
			this.arraylist.get(n).b = true;
		}
		((ViewHolder) view.getTag()).imageView2.setSelected(this.arraylist
				.get(n).b);
	}

	public final void arraylis_add(ArrayList<a> arrayList) {
		try {
			this.arraylist.clear();
			this.arraylist.addAll(arrayList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		notifyDataSetChanged();
	}

	public final void a(final boolean e) {
		this.e = e;
	}

	public final int getCount() {
		return this.arraylist.size();
	}

	public final long getItemId(int i) {
		return (long) i;
	}

	@SuppressLint("WrongConstant")
	public final View getView(final int i, View view, final ViewGroup viewGroup) {
		final ViewHolder holder = new ViewHolder();

		ViewHolder galleryAdapter;
		if (view == null) {
			view = layoutinflater.inflate(
					R.layout.image_picker_lib_gallery_item, null);
			galleryAdapter = new ViewHolder();
			galleryAdapter.imageView1 = (ImageView) view
					.findViewById(R.id.imgQueue);
			galleryAdapter.imageView2 = (ImageView) view
					.findViewById(R.id.imgQueueMultiSelected);
			if (this.e) {
				galleryAdapter.imageView2.setVisibility(0);
			} else {
				galleryAdapter.imageView2.setVisibility(8);
			}
			view.setTag(galleryAdapter);
		} else {
			galleryAdapter = (ViewHolder) view.getTag();
		}
		galleryAdapter.imageView1.setTag(Integer.valueOf(i));
		try {
			Log.e("img link", "" + this.arraylist.get(i).a);
			this.imgloader.displayImage("file://" + this.arraylist.get(i).a,
					galleryAdapter.imageView1,
					new SimpleImageLoadingListener() {
						@Override
						public final void onLoadingStarted(final String s,
								final View view) {
							super.onLoadingStarted(s, view);
						}
					});
			if (this.e) {
				galleryAdapter.imageView2.setSelected(this.arraylist.get(i).b);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return view;

	}

	public class ViewHolder {
		ImageView imageView1;
		ImageView imageView2;
	}

	public final Object getItem(int i) {
		return object_a(i);
	}

}
