package com.esc.mosaicphotocollage.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;

import com.esc.mosaicphotocollage.R;
import com.esc.mosaicphotocollage.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class ShareActivity extends Activity implements View.OnClickListener {
	String imageuri = null;
	private int c;
	private Point point;
	private Display display;
	private KProgressHUD hud;


	public void onBackPressed() {
		super.onBackPressed();
	}

	@SuppressLint({"NewApi", "WrongConstant"})
	protected void onCreate(Bundle paramBundle) {
		super.onCreate(paramBundle);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_share);

		this.display = ((WindowManager) getBaseContext().getSystemService(
				"window")).getDefaultDisplay();
		this.point = new Point();
		loadAds();

		if (Build.VERSION.SDK_INT > 12) {
			this.display.getSize(this.point);
		}
		for (this.c = this.point.x;; this.c = this.display.getWidth()) {
			this.imageuri = getIntent().getExtras().getString("ImageUri");

			findViewById(R.id.image).setBackgroundDrawable(
					new BitmapDrawable(this.imageuri));
			LayoutParams layoutparams = new LayoutParams(this.c
					- this.c / 10, this.c - this.c / 10);
			layoutparams.addRule(13, -1);

			findViewById(R.id.image).setLayoutParams(layoutparams);
			findViewById(R.id.iv_facebook).setOnClickListener(this);
			findViewById(R.id.iv_whatapp).setOnClickListener(this);
			findViewById(R.id.iv_instagram).setOnClickListener(this);
			findViewById(R.id.iv_more).setOnClickListener(this);
			findViewById(R.id.iv_back).setOnClickListener(this);
			findViewById(R.id.ivhome).setOnClickListener(this);

			return;
		}
	}

	@SuppressLint("WrongConstant")
	public void onClick(View paramView)
	{
		switch (paramView.getId())
		{
			default:
				break;
			case R.id.iv_back:
				id = R.id.iv_back;
				if (mInterstitialAd != null && mInterstitialAd.isLoaded()){
					DialogShow();
					AdsDialogShow();
				}else {
					Intent intent = new Intent(ShareActivity.this, MyStudioActivity.class);
					startActivity(intent);
					finish();
				}
				break;

			case R.id.ivhome:
				id = R.id.ivhome;
				if (mInterstitialAd != null && mInterstitialAd.isLoaded()){
					DialogShow();
					AdsDialogShow();
				}else {
					startActivity(new Intent(ShareActivity.this, HomeScreen.class));
					finish();
				}
				break;

			case R.id.iv_facebook:
				try {
					final Intent intent = new Intent("android.intent.action.SEND");
					intent.setType("image/*");
					intent.putExtra("android.intent.extra.STREAM",
							Uri.parse(this.imageuri));
					intent.setPackage("com.facebook.katana");
					startActivity(Intent.createChooser(intent, "..."));

				} catch (Exception ee) {
					Toast.makeText(this,
							"facebook is not installed in your device !", 0).show();
				}
				break;
			case R.id.iv_whatapp:
				try {
					final Intent intent = new Intent("android.intent.action.SEND");
					intent.setType("image/*");
					intent.putExtra("android.intent.extra.STREAM",
							Uri.parse(this.imageuri));
					intent.setPackage("com.whatsapp");
					startActivity(Intent.createChooser(intent,
							"Your Awesome Text and Pic..."));

				} catch (Exception ee) {
					Toast.makeText(this,
							"whatsapp is not installed in your device !", 0).show();
				}
				break;
			case R.id.iv_instagram:
				try {
					final Intent intent = new Intent("android.intent.action.SEND");
					intent.setType("image/*");
					intent.putExtra("android.intent.extra.STREAM",
							Uri.parse(this.imageuri));
					intent.setPackage("com.instagram.android");
					startActivity(Intent.createChooser(intent,
							"Your Awesome Text and Pic..."));

				} catch (Exception ee) {
					Toast.makeText(this,
							"instagram is not installed in your device !", 0)
							.show();
				}
				break;
			case R.id.iv_more:
				final Intent intent = new Intent("android.intent.action.SEND");
				intent.setType("image/*");
				intent.putExtra("android.intent.extra.STREAM",
						Uri.parse(this.imageuri));
				startActivity(Intent.createChooser(intent, "Share image using"));
				break;
		}
	}

	private int id;
	private InterstitialAd mInterstitialAd;
	private AdView adView;
	private void loadAds() {
		//Banner Ad
		adView = findViewById(R.id.AdView);
		final AdRequest adRequest = new AdRequest.Builder().build();
		adView.loadAd(adRequest);

		//interstitial FullScreenAd
		final AdRequest adRequestfull = new AdRequest.Builder().build();
		mInterstitialAd = new InterstitialAd(this);
		mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
		mInterstitialAd.loadAd(adRequestfull);
		mInterstitialAd.setAdListener(new AdListener() {
			public void onAdLoaded() {
				super.onAdLoaded();
			}

			public void onAdClosed() {
				hud.dismiss();
				switch (id) {
					case R.id.iv_back:
						startActivity(new Intent(ShareActivity.this, MyStudioActivity.class));
						finish();
						break;

					case R.id.ivhome:
						startActivity(new Intent(ShareActivity.this, HomeScreen.class));
						finish();
						break;
				}
				mInterstitialAd.loadAd(adRequestfull);
			}

			public void onAdFailedToLoad(int errorCode) {
				super.onAdFailedToLoad(errorCode);
				Log.i("TAG", "Ad Load failed" + errorCode);
			}
		});
		mInterstitialAd.loadAd(adRequestfull);
	}

	public void DialogShow() {
		try {
			hud = KProgressHUD.create(ShareActivity.this)
					.setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
					.setLabel("Showing Ads")
					.setDetailsLabel("Please Wait...");
			hud.show();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (NullPointerException e2) {
			e2.printStackTrace();
		} catch (Exception e3) {
			e3.printStackTrace();
		}
	}

	public void AdsDialogShow() {
		Handler mHandler = new Handler();
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				hud.dismiss();
				mInterstitialAd.show();
			}
		}, 2000);
	}

	protected void onDestroy() {
		super.onDestroy();
	}

	public void onPause() {
		super.onPause();
	}

	protected void onResume() {
		super.onResume();
	}

	protected void onStart() {
		super.onStart();
	}

	protected void onStop() {
		super.onStop();
	}
}
