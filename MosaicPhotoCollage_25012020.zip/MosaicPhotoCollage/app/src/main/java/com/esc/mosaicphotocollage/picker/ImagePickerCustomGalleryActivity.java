package com.esc.mosaicphotocollage.picker;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.Toast;

import com.esc.mosaicphotocollage.R;
import com.esc.mosaicphotocollage.activity.HomeScreen;
import com.esc.mosaicphotocollage.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.nostra13.universalimageloader.cache.disc.impl.UnlimitedDiskCache;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.listener.PauseOnScrollListener;
import com.nostra13.universalimageloader.utils.StorageUtils;

public class ImagePickerCustomGalleryActivity extends Activity implements View.OnClickListener {
    GridView grisdview;
    Handler handler;
    b c;
    ImageView imageview, iv_back;
    ImageView iv_done;
    String f;
    AdapterView.OnItemClickListener h;
    AdapterView.OnItemClickListener i;
    private ImageLoader imageloader;
    private KProgressHUD hud;
    private InterstitialAd mInterstitialAd;
    private int GALLERY_IMAGE_LIMIT_MIN = 0;

    public ImagePickerCustomGalleryActivity() {

        this.h = new AdapterView.OnItemClickListener() {
            public final void onItemClick(final AdapterView<?> adapterView,
                                          final View view, final int n, final long n2) {
                ImagePickerCustomGalleryActivity.this.c.setTabMethod(view, n);
            }
        };
        this.i = new AdapterView.OnItemClickListener() {
            public final void onItemClick(final AdapterView<?> adapterView,
                                          final View view, final int n, final long n2) {
                ImagePickerCustomGalleryActivity.this.setResult(-1,
                        new Intent().putExtra("single_path",
                                ImagePickerCustomGalleryActivity.this.c
                                        .object_a(n).a));
                ImagePickerCustomGalleryActivity.this.finish();
            }
        };
    }

    private ArrayList<a> a() {
        final ArrayList<a> list = new ArrayList<a>();
        try {
            final Cursor managedQuery = this.managedQuery(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{
                            "_data", "_id"}, null, null,
                    "_id");
            if (managedQuery != null && managedQuery.getCount() > 0) {
                while (managedQuery.moveToNext()) {
                    final a a = new a();
                    a.a = managedQuery.getString(managedQuery
                            .getColumnIndex("_data"));
                    list.add(a);
                }
            }
            Collections.reverse(list);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    @SuppressLint("WrongConstant")
    static void b(
            final ImagePickerCustomGalleryActivity imagePickerCustomGalleryActivity) {
        if (imagePickerCustomGalleryActivity.c.isEmpty()) {
            imagePickerCustomGalleryActivity.imageview.setVisibility(0);
            return;
        }
        imagePickerCustomGalleryActivity.imageview.setVisibility(8);
    }

    @SuppressLint("WrongConstant")
    public void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.requestWindowFeature(1);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.image_picker_lib_gallery);
        this.f = this.getIntent().getAction();
        if (this.f == null) {
            this.finish();
        }

        try {
            final String string = String.valueOf(Environment
                    .getExternalStorageDirectory().getAbsolutePath())
                    + "/.temp_tmp";
            new File(string).mkdirs();
            (this.imageloader = ImageLoader.getInstance())
                    .init(new ImageLoaderConfiguration.Builder(this
                            .getBaseContext())
                            .defaultDisplayImageOptions(
                                    new DisplayImageOptions.Builder()
                                            .cacheOnDisc(true)
                                            .imageScaleType(
                                                    ImageScaleType.EXACTLY)
                                            .bitmapConfig(Bitmap.Config.RGB_565)
                                            .build())
                            .discCache(
                                    new UnlimitedDiskCache(StorageUtils
                                            .getOwnCacheDirectory(
                                                    this.getBaseContext(),
                                                    string)))
                            .memoryCache(new WeakMemoryCache()).build());
            this.handler = new Handler();
            (this.grisdview = this.findViewById(R.id.gridGallery))
                    .setFastScrollEnabled(true);
            this.c = new b(this.getApplicationContext(), this.imageloader);
            this.grisdview
                    .setOnScrollListener(new PauseOnScrollListener(
                            this.imageloader, true, true));
            if (this.f.equalsIgnoreCase("luminous.ACTION_MULTIPLE_PICK")) {
                this.grisdview.setOnItemClickListener(this.h);
                this.c.a(true);
            }
            this.grisdview.setAdapter(this.c);
            this.imageview = this.findViewById(R.id.imgNoMedia);
            iv_back = findViewById(R.id.iv_back);
            iv_back.setOnClickListener(this);

            iv_done = findViewById(R.id.iv_done);
            iv_done.setOnClickListener(this);

            new Thread() {
                @Override
                public final void run() {
                    Looper.prepare();
                    ImagePickerCustomGalleryActivity.this.handler
                            .post(new Runnable() {
                                @Override
                                public final void run() {
                                    ImagePickerCustomGalleryActivity.this.c
                                            .arraylis_add(ImagePickerCustomGalleryActivity.this
                                                    .a());
                                    ImagePickerCustomGalleryActivity
                                            .b(ImagePickerCustomGalleryActivity.this);
                                }
                            });
                    Looper.loop();
                }
            }.start();
        } catch (Exception ex) {
        }

        loadAds();
    }

    @Override
    public void onClick(View view) {
        if (this.iv_back == view) {
            id = R.id.iv_back;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                Intent intent = new Intent(ImagePickerCustomGalleryActivity.this, HomeScreen.class);
                startActivity(intent);
            }
        }

        if (this.iv_done == view) {
            iv_done.setImageResource(R.drawable.ic_unpress_done);
            id = R.id.iv_done;
            if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                DialogShow();
                AdsDialogShow();
            } else {
                final ArrayList<a> a = ImagePickerCustomGalleryActivity.this.c.ArraylistAdd();
                final int size = a.size();
                final int gallery_IMAGE_LIMIT_MIN = this.GALLERY_IMAGE_LIMIT_MIN;
                final String[] array = new String[a.size()];

                if (size <= gallery_IMAGE_LIMIT_MIN) {
                    @SuppressLint({"StringFormatInvalid", "LocalSuppress"}) final Toast text = Toast.makeText(ImagePickerCustomGalleryActivity.this, String.format(this.getString(R.string.gallery_select_one), this.getLimitMin() + 1), Toast.LENGTH_SHORT);
                    text.setGravity(17, text.getXOffset() / 2, text.getYOffset() / 2);
                    text.show();
                    return;
                }
                for (int i = 0; i < array.length; ++i) {
                    array[i] = a.get(i).a;
                }
                ImagePickerCustomGalleryActivity.this.setResult(-1,
                        new Intent().putExtra("all_path", array));
                ImagePickerCustomGalleryActivity.this.finish();
            }
        }
    }

    private int id;
    private AdView adView;

    private void loadAds() {

        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        //interstitial FullScreenAd
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        mInterstitialAd.loadAd(adRequestfull);
        mInterstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
                super.onAdLoaded();
                Log.e("Loaded", "Ad Load");
            }

            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case R.id.iv_back:
                        Intent intent = new Intent(ImagePickerCustomGalleryActivity.this, HomeScreen.class);
                        startActivity(intent);
                        break;

                    case R.id.iv_done:
                        final ArrayList<a> a = ImagePickerCustomGalleryActivity.this.c.ArraylistAdd();
                        final int size = a.size();
                        final int gallery_IMAGE_LIMIT_MIN = GALLERY_IMAGE_LIMIT_MIN;
                        final String[] array = new String[a.size()];

                        if (size <= gallery_IMAGE_LIMIT_MIN) {
                            @SuppressLint({"StringFormatInvalid", "LocalSuppress"}) final Toast text = Toast.makeText(ImagePickerCustomGalleryActivity.this, String.format(getResources().getString(R.string.gallery_select_one), getLimitMin() + 1), Toast.LENGTH_SHORT);
                            text.setGravity(17, text.getXOffset() / 2, text.getYOffset() / 2);
                            text.show();
                            return;
                        }
                        for (int i = 0; i < array.length; ++i) {
                            array[i] = a.get(i).a;
                        }
                        ImagePickerCustomGalleryActivity.this.setResult(-1,
                                new Intent().putExtra("all_path", array));
                        ImagePickerCustomGalleryActivity.this.finish();
                        break;
                }
                mInterstitialAd.loadAd(adRequestfull);
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        mInterstitialAd.loadAd(adRequestfull);
    }


    public void DialogShow() {
        try {
            hud = KProgressHUD.create(ImagePickerCustomGalleryActivity.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("Please Wait...");
            hud.show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                mInterstitialAd.show();
            }
        }, 2000);
    }

    public int getLimitMin() {
        return this.GALLERY_IMAGE_LIMIT_MIN;
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ImagePickerCustomGalleryActivity.this, HomeScreen.class);
        startActivity(intent);
    }
}
