package com.esc.mosaicphotocollage.picker;

public final class a {
	public String a;
	public boolean b;

	public a() {
		this.b = false;
	}
}
