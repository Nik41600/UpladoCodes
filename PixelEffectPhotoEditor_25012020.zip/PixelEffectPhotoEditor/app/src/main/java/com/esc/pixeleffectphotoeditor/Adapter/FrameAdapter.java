package com.esc.pixeleffectphotoeditor.Adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.esc.pixeleffectphotoeditor.Activity.CropActivity;
import com.esc.pixeleffectphotoeditor.R;

import java.util.ArrayList;

public class FrameAdapter extends BaseAdapter {
    ArrayList<Integer> collage;
    Context context;
    private int height;
    ImageView ivEditing;
    ImageView ivMain;
    private LayoutInflater layoutInflater;
    private int width;

    public FrameAdapter(Context context, ArrayList<Integer> stickers) {
        this.context = context;
        this.collage = stickers;
        layoutInflater = (LayoutInflater) this.context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return this.collage.size();
    }

    public Object getItem(int i) {
        return this.collage.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = this.layoutInflater.inflate(R.layout.item_frame, null);
        }
        this.ivMain = (ImageView) convertView.findViewById(R.id.ImageView);
        this.ivEditing = (ImageView) convertView
                .findViewById(R.id.ivEditing);
        DisplayMetrics metrics = this.context.getResources()
                .getDisplayMetrics();
        this.width = metrics.widthPixels;
        this.height = metrics.heightPixels;
        int resource = ((Integer) this.collage.get(position)).intValue();
        this.ivMain.setImageBitmap(CropActivity.bitmapCropped);
        Glide.with(this.context).load(Integer.valueOf(resource))
                .override(this.width / 4, this.height / 7)
                .into(this.ivEditing);
        this.ivEditing.setColorFilter(ContextCompat.getColor(this.context,
                R.color.white));
        System.gc();
        return convertView;
    }
}
