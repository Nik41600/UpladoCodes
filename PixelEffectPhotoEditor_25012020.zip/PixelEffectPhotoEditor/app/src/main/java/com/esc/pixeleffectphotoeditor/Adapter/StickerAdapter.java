package com.esc.pixeleffectphotoeditor.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.esc.pixeleffectphotoeditor.R;
import com.esc.pixeleffectphotoeditor.Utils.ResizableImageView;

import java.util.ArrayList;

public class StickerAdapter extends BaseAdapter {
	Context context;
	ImageView imgEditing;
	private LayoutInflater inflater;
	ArrayList<Integer> integerArrayList;
	private ViewHolder viewholder;

	public class ViewHolder {
		ResizableImageView resizableImageView;
	}

	public StickerAdapter(Context context, ArrayList<Integer> stickers) {
		this.context = context;
		this.integerArrayList = stickers;
		inflater = ((LayoutInflater) this.context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE));
	}

	public int getCount() {
		return this.integerArrayList.size();
	}

	public Object getItem(int i) {
		return this.integerArrayList.get(i);
	}

	public long getItemId(int i) {
		return (long) i;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = this.inflater.inflate(R.layout.sticker_item, null);
		}
		this.imgEditing = (ImageView) convertView
				.findViewById(R.id.ivEditing);
		Glide.with(this.context)
				.load(((Integer) this.integerArrayList.get(position)).intValue())
				.into(this.imgEditing);
		System.gc();
		return convertView;
	}
}
