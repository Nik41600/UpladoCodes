package com.esc.pixeleffectphotoeditor.Activity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import com.esc.pixeleffectphotoeditor.Adapter.studioAdapter;
import com.esc.pixeleffectphotoeditor.R;
import com.esc.pixeleffectphotoeditor.Utils.Utils;
import com.esc.pixeleffectphotoeditor.kprogresshud.KProgressHUD;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.File;
import java.util.Collections;

public class ActivityStudio extends AppCompatActivity {
    private ImageView ivBack;
    private studioAdapter creationAdapter;
    private GridView Grid_Creationlist;
    private ImageView ivNoImage;
    private KProgressHUD hud;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_studio);
        loadAd();
    }

    protected void onResume() {
        super.onResume();
        bindView();
    }

    private void bindView() {
        this.ivNoImage = (ImageView) findViewById(R.id.novideoimg);
        this.Grid_Creationlist = (GridView) findViewById(R.id.grid_imgLst);
        getImages();
        if (Utils.IMAGEALLARY.size() <= 0) {
            this.ivNoImage.setVisibility(View.VISIBLE);
            this.Grid_Creationlist.setVisibility(View.GONE);
        } else {
            this.ivNoImage.setVisibility(View.GONE);
            this.Grid_Creationlist.setVisibility(View.VISIBLE);
        }
        this.ivBack = (ImageView) findViewById(R.id.ivBack);
        this.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = R.id.ivBack;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {

                    Intent i = new Intent(ActivityStudio.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }
            }
        });
        Collections.sort(Utils.IMAGEALLARY);
        Collections.reverse(Utils.IMAGEALLARY);
        this.creationAdapter = new studioAdapter(this, Utils.IMAGEALLARY);
        this.Grid_Creationlist.setAdapter(this.creationAdapter);
        Grid_Creationlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Intent i = new Intent(ActivityStudio.this,
                        ActivityImageDisplay.class);
                i.putExtra("position", position);
                startActivity(i);
            }
        });
    }

    private void getImages() {
        if (Build.VERSION.SDK_INT < 23) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                    5);
        }
    }

    private void fetchImage() {
        Utils.IMAGEALLARY.clear();
        Utils.listAllImages(new File("/mnt/sdcard/" + getString(R.string.app_name)
                + "/"));
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 5:
                if (grantResults[0] == 0) {
                    fetchImage();
                    return;
                } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                            new String[]{"android.permission.READ_EXTERNAL_STORAGE"},
                            5);
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
    }

    private InterstitialAd interstitial;
    private int id;

    private void loadAd()
    {
        //BannerAd
        adView = findViewById(R.id.adView);
        final AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed()
            {
                hud.dismiss();
                switch (id) {
                    case R.id.ivBack:
                        Intent i = new Intent(ActivityStudio.this, MainActivity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                        break;
                }
                requestNewInterstitial();
            }
            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {
            hud = KProgressHUD.create(ActivityStudio.this)
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(ActivityStudio.this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
