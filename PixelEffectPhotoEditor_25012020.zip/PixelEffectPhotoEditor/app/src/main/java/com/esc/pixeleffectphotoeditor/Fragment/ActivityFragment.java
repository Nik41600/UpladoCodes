package com.esc.pixeleffectphotoeditor.Fragment;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.esc.pixeleffectphotoeditor.Activity.CropActivity;
import com.esc.pixeleffectphotoeditor.Activity.ActivityStudio;
import com.esc.pixeleffectphotoeditor.Activity.MyApplication;
import com.esc.pixeleffectphotoeditor.Adapter.MoreAppAdapter;
import com.esc.pixeleffectphotoeditor.R;
import com.esc.pixeleffectphotoeditor.Utils.ImageLoadingUtils;
import com.esc.pixeleffectphotoeditor.kprogresshud.KProgressHUD;
import com.esc.pixeleffectphotoeditor.model.App_data;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.gson.Gson;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;

public class ActivityFragment extends Fragment {
    private View v;
    public static Bitmap bitmap;
    public static Uri imageUri;
    private ImageView ivMyCreation;
    private ImageView ivStart;
    String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
    };
    private ArrayList<App_data> array_appdata;
    private MoreAppAdapter moreAppAdapter;
    private RecyclerView recyclerView;
    private KProgressHUD hud;

    public ActivityFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_activity, container, false);

        array_appdata = new ArrayList<>();
        try {
            makeJsonRequest(getResources().getString(R.string.more_appurl));
        } catch (Exception e) {
            e.printStackTrace();
        }

        recyclerView = (RecyclerView) v.findViewById(R.id.ad_inter_recycle_view);
        final GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        initView();
        loadAd();
        nativeAd();
        return v;
    }

    private void initView() {
        this.ivStart = (ImageView) v.findViewById(R.id.ivStart);
        this.ivStart.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                id = 101;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (!hasPermissions(getActivity(), PERMISSIONS)) {
                            ActivityCompat.requestPermissions(getActivity(), PERMISSIONS,
                                    1);
                        } else {
                            openGallery();
                        }
                    } else {
                        openGallery();
                    }
                }
            }
        });

        this.ivMyCreation = (ImageView) v.findViewById(R.id.ivMyCreation);
        this.ivMyCreation.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                id = 102;
                if (interstitial != null && interstitial.isLoaded()) {
                    DialogShow();
                    AdsDialogShow();
                } else {
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (!hasPermissions(getActivity(), PERMISSIONS)) {
                            ActivityCompat.requestPermissions(getActivity(), PERMISSIONS,
                                    2);
                        } else {
                            startActivity(new Intent(getActivity(), ActivityStudio.class));
                        }
                    } else {
                        startActivity(new Intent(getActivity(), ActivityStudio.class));
                    }
                }
            }
        });
    }

    private void makeJsonRequest(String url) {
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("application_detail");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                App_data app_data = new Gson().fromJson(jsonArray.get(i).toString(), App_data.class);
                                if (!app_data.getApplication_name().equalsIgnoreCase(getString(R.string.app_name))) {
                                    array_appdata.add(app_data);
                                    moreAppAdapter = new MoreAppAdapter(getActivity(), array_appdata);
                                    recyclerView.setAdapter(moreAppAdapter);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("Error", "Error: " + error.getMessage());
            }
        });
        MyApplication.getInstance().addToRequestQueue(jsonObjReq, "");
    }

    private void openGallery() {

        startActivityForResult(new Intent("android.intent.action.PICK",
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 6);
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                getActivity(),
                                "Sorry We cant process ahead due to denied permission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                openGallery();
                return;
            case 2:
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(
                                getActivity(),
                                "Sorry We cant process ahead due to denied permission",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                startActivity(new Intent(getActivity(), ActivityStudio.class));
                return;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == -1) {
            switch (requestCode) {
                case 6:
                    this.imageUri = data.getData();
                    try {
                        new ImageCompressionAsyncTask(true)
                                .execute(new String[]{this.imageUri.toString()});
                        return;
                    } catch (Exception e) {
                        Log.e("TAG", "Error==> " + e.getMessage());
                        e.printStackTrace();
                        return;
                    }
                default:
                    return;
            }
        }
    }

    private InterstitialAd interstitial;
    private int id;

    private void loadAd() {
        final AdRequest adRequestfull = new AdRequest.Builder().build();
        interstitial = new InterstitialAd(getActivity());
        interstitial.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitial.loadAd(adRequestfull);
        this.interstitial.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                hud.dismiss();
                switch (id) {
                    case 101:
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (!hasPermissions(getActivity(), PERMISSIONS)) {
                                ActivityCompat.requestPermissions(getActivity(), PERMISSIONS,
                                        1);
                            } else {
                                openGallery();
                            }
                        } else {
                            openGallery();
                        }
                        break;
                    case 102:
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (!hasPermissions(getActivity(), PERMISSIONS)) {
                                ActivityCompat.requestPermissions(getActivity(), PERMISSIONS,
                                        2);
                            } else {
                                startActivity(new Intent(getActivity(), ActivityStudio.class));
                            }
                        } else {
                            startActivity(new Intent(getActivity(), ActivityStudio.class));
                        }
                        break;
                }
                requestNewInterstitial();
            }

            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                Log.i("TAG", "Ad Load failed" + errorCode);
            }
        });
        interstitial.loadAd(new AdRequest.Builder().build());
    }

    private void requestNewInterstitial() {
        this.interstitial.loadAd(new AdRequest.Builder().build());
    }

    public void DialogShow() {
        try {

            hud = KProgressHUD.create(getActivity())
                    .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                    .setLabel("Showing Ads")
                    .setDetailsLabel("pleas Wait...")
                    .show();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (NullPointerException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }

    public void AdsDialogShow() {
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
                interstitial.show();
            }
        }, 2000);
    }


    class ImageCompressionAsyncTask extends AsyncTask<String, Void, Bitmap> {
        private boolean fromGallery;

        public ImageCompressionAsyncTask(boolean fromGallery) {
            this.fromGallery = fromGallery;
        }

        protected Bitmap doInBackground(String... params) {
            return compressImage(params[0]);
        }

        public Bitmap compressImage(String imageUri) {
            String filePath = getRealPathFromURI(imageUri);
            Log.e("FILE_PATH", filePath);
            Bitmap scaledBitmap = null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            Bitmap bmp = BitmapFactory.decodeFile(filePath, options);
            int actualHeight = options.outHeight;
            int actualWidth = options.outWidth;
            float imgRatio = (float) (actualWidth / actualHeight);
            if (((float) actualHeight) > 2048.0f
                    || ((float) actualWidth) > 1440.0f) {
                if (imgRatio < 0.703125f) {
                    actualWidth = (int) (((float) actualWidth) * (2048.0f / ((float) actualHeight)));
                    actualHeight = 2048;
                } else if (imgRatio > 0.703125f) {
                    actualHeight = (int) (((float) actualHeight) * (1440.0f / ((float) actualWidth)));
                    actualWidth = 1440;
                } else {
                    actualHeight = 2048;
                    actualWidth = 1440;
                }
            }
            options.inSampleSize = ImageLoadingUtils.calculateInSampleSize(
                    options, actualWidth, actualHeight);
            options.inJustDecodeBounds = false;
            options.inDither = false;
            options.inPurgeable = true;
            options.inInputShareable = true;
            options.inTempStorage = new byte[16384];
            try {
                bmp = BitmapFactory.decodeFile(filePath, options);
            } catch (OutOfMemoryError exception) {
                exception.printStackTrace();
            }
            try {
                scaledBitmap = Bitmap.createBitmap(actualWidth, actualHeight,
                        Bitmap.Config.ARGB_8888);
            } catch (OutOfMemoryError exception2) {
                exception2.printStackTrace();
            }
            float ratioX = ((float) actualWidth) / ((float) options.outWidth);
            float ratioY = ((float) actualHeight) / ((float) options.outHeight);
            float middleX = ((float) actualWidth) / 2.0f;
            float middleY = ((float) actualHeight) / 2.0f;
            Matrix scaleMatrix = new Matrix();
            scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
            Canvas canvas = new Canvas(scaledBitmap);
            canvas.setMatrix(scaleMatrix);
            canvas.drawBitmap(bmp, middleX - ((float) (bmp.getWidth() / 2)),
                    middleY - ((float) (bmp.getHeight() / 2)), new Paint(2));
            try {
                int orientation = new ExifInterface(filePath).getAttributeInt(
                        "Orientation", 0);
                Matrix matrix = new Matrix();
                if (orientation == 6) {
                    matrix.postRotate(90.0f);
                } else if (orientation == 3) {
                    matrix.postRotate(180.0f);
                } else if (orientation == 8) {
                    matrix.postRotate(270.0f);
                }
                scaledBitmap = Bitmap.createBitmap(scaledBitmap, 0, 0,
                        scaledBitmap.getWidth(), scaledBitmap.getHeight(),
                        matrix, true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return scaledBitmap;
        }

        private String getRealPathFromURI(String contentURI) {
            Uri contentUri = Uri.parse(contentURI);
            Cursor cursor = getActivity().getContentResolver().query(
                    contentUri, null, null, null, null);
            if (cursor == null) {
                return contentUri.getPath();
            }
            cursor.moveToFirst();
            return cursor.getString(cursor.getColumnIndex("_data"));
        }

        protected void onPostExecute(Bitmap result) {
            super.onPostExecute(result);
            bitmap = result;
            SharedPreferences sPreferences = PreferenceManager
                    .getDefaultSharedPreferences(getActivity()
                            .getApplicationContext());
            Intent cropIntent = new Intent(getActivity(),
                    CropActivity.class);
            if (sPreferences.getBoolean("isHair", false)) {
                cropIntent.putExtra("hair", false);
                getActivity().startActivity(cropIntent);
                return;
            }
            cropIntent.putExtra("hair", false);
            getActivity().startActivity(cropIntent);
        }
    }

    public void onResume() {
        super.onResume();
    }

    private UnifiedNativeAd nativeAd;

    public void nativeAd() {
        AdLoader.Builder builder = new AdLoader.Builder(getActivity(), getResources().getString(R.string.AdMob_NativeAdvanceAd));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (nativeAd != null) {
                    nativeAd.destroy();
                }
                nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = v.findViewById(R.id.fl_adplaceholder);
                v.findViewById(R.id.tvLoadingAds).setVisibility(View.GONE);
                UnifiedNativeAdView adView = (UnifiedNativeAdView) getLayoutInflater().inflate(R.layout.ad_unifieldnativeadview_small, null);
                populateUnifiedNativeAdView(unifiedNativeAd, adView);
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView
            adView) {

        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {

                    super.onVideoEnd();
                }
            });
        }
    }

    @Override
    public void onDestroy() {
        if (nativeAd != null) {
            nativeAd.destroy();
        }
        super.onDestroy();
    }
}
